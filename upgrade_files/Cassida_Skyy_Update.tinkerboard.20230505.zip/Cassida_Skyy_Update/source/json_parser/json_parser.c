#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <memory.h>
#include <errno.h>

// json lib in header file from https://github.com/zserge/jsmn  (MIT license, see source)
#define JSMN_PARENT_LINKS
#include "jsmn.h"


int get_item_value_index(const char *szItem, const char *szBuf, jsmntok_t *pTok, int nTok, int iLevel);

int main(int argc, char *argv[])
{
char *pBuf, *p1;
int nBytes, nMax, nTok, i1;
jsmn_parser p;
jsmntok_t tok[65536];


//  if(argc < 2)
//  {
//    fprintf(stderr, "Usage:  x 'json.value.thingy'\n");
//    return 2;
//  }

  nMax = 0x8000000L; // 8MB
  pBuf = (char *)malloc(nMax);

  if(!pBuf)
  {
    fprintf(stderr, "no memory\n");
    return 1;
  }

  p1 = pBuf;

  while(!feof(stdin))
  {
    fgets(p1, nMax - (p1 - pBuf) - 1, stdin);

    if(ferror(stdin))
    {
      fprintf(stderr, "read error, errno=%d\n", errno);
    }

    p1 += strlen(p1);
  }

  jsmn_init(&p);
  nTok = jsmn_parse(&p, pBuf, strlen(pBuf), tok, sizeof(tok) / sizeof(tok[0]));


  if(argc < 2)
  {
    for(i1=0; i1 <  nTok; i1++)
    {
      if(tok[i1].type == JSMN_OBJECT)
        printf("%05d  type: OBJECT parent: %d\n", i1, tok[i1].parent);
      else if(tok[i1].type == JSMN_ARRAY)
        printf("%05d  type: ARRAY  parent: %d\n", i1, tok[i1].parent);
      else
        printf("%05d  type: %-6d parent: %d  %-.*s\n",
               i1,
               tok[i1].type,
               tok[i1].parent,
               tok[i1].end - tok[i1].start,//tok[i1].size,
               tok[i1].start + pBuf);
    }
    return 0;
  }

  // parsing out the following
  //
  //   {"responseData":{"tokenType":"bearer","accessToken":"beaa794e-b8bc-42d8-894c-e9b8de5e64c3"}}
  //
  // gives me
  //
  //   type: 1 parent: -1  {"responseData":{"tokenType":"bearer","accessToken":"beaa794e-b8bc-42d8-894c-e9b8de5e64c3"}}
  //   type: 3 parent: 0  responseData
  //   type: 1 parent: 1  {"tokenType":"bearer","accessToken":"beaa794e-b8bc-42d8-894c-e9b8de5e64c3"}
  //   type: 3 parent: 2  tokenType
  //   type: 3 parent: 3  bearer
  //   type: 3 parent: 2  accessToken
  //   type: 3 parent: 5  beaa794e-b8bc-42d8-894c-e9b8de5e64c3
  //

  i1=get_item_value_index(argv[1], pBuf, tok, nTok, 0);

  if(i1 >= 0)
  {
    printf("%-.*s\n", tok[i1].end - tok[i1].start, tok[i1].start + pBuf);
  }

  free(pBuf);

  return 0;
}


int get_item_value_index(const char *szItem, const char *szBuf, jsmntok_t *pTok, int nTok, int iLevel)
{
const char *p1;
int i1, i2, iTokLen;


  for(p1=szItem; *p1 && *p1 != '.'; p1++)
    ; // find dot or end of string

  iTokLen = p1 - szItem;

  //  for an array index allow szItem to be a number indicating the index
  //  within the array.  This would be if pTok[iLevel].type == JSMN_ARRAY

  if(pTok[iLevel].type == JSMN_ARRAY) // it's an array - more than one element
  {
    int nIndex = 0;
    const char *p2 = szItem;
    while(p2 < p1)
    {
      if(*p2 < '0' || *p2 > '9')
        return -1; // not valid

      nIndex = nIndex * 10 + *(p2++) - '0';
    }

    // look for the 'nIndex'th item with 'iLevel' as its parent

    for(i2=0; i2 < nTok && nIndex >= 0; i2++)
    {
      if(pTok[i2].parent == iLevel) // find the first one.  should only be one
      {
        nIndex--;

        if(nIndex <  0)
          break;
      }
    }
  }
  else
  {
    for(i1=0; i1 < nTok; i1++)
    {
      int iLen = pTok[i1].end - pTok[i1].start;
      const char *pS = pTok[i1].start + szBuf;

      if(pTok[i1].type == JSMN_STRING &&
         pTok[i1].parent == iLevel &&
         iLen == iTokLen &&
         !memcmp(pS, szItem, iTokLen))
      {
        break;
      }
    }

    if(i1 >= nTok) // not found
      return -1; // not found return value

    // at this point 'i1' is the index of the matching item

    // Now that I have the index of the string label, I need to get its value
    // so I must find the value directly associated with this index, object or string

    for(i2=0; i2 < nTok; i2++)
    {
      if(pTok[i2].parent == i1) // find the first one.  should only be one
        break;
    }
  }

  // at this point, i2 is the index of the associated value

  if(i2 >= nTok) // no value found
    return -1; // that's all she wrote

  if(*p1 &&
     (pTok[i2].type == JSMN_OBJECT ||
      pTok[i2].type == JSMN_ARRAY))
  {
    return get_item_value_index(p1 + 1, szBuf, pTok, nTok, i2);
  }
  else if(*p1) // not an object or array index
  {
    return -1; // for now; later, do what?
  }

  return i2;
}

