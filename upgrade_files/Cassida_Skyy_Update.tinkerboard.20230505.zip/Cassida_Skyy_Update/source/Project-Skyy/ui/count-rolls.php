<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Rolls = do_getconf($parseconf,"terms",'Rolls','Rolls');

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  // find out the entity name, and the 'origin' parameter (if assigned)
  // these are assigned via 'GET' parameters in the URL

  $Origin = empty($_GET) || empty($_GET["origin"]) ? "" : $_GET["origin"];
  if(strlen($Origin) > 0 && substr($Origin,0,1) != "/")
    $Origin = "/" . $Origin;

  $complete = empty($_GET) || empty($_GET["complete"]) ? "" : $_GET["complete"];

  if($complete == "Y")
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /glue/next-step-count-class.php");
    header("Expires: 0");

    if(!empty($_GET))
    {
      $c1 = empty($_GET["c1"]) ? 0 : $_GET["c1"];
      $c5 = empty($_GET["c5"]) ? 0 : $_GET["c5"];
      $c10 = empty($_GET["c10"]) ? 0 : $_GET["c10"];
      $c25 = empty($_GET["c25"]) ? 0 : $_GET["c25"];
      $c50 = empty($_GET["c50"]) ? 0 : $_GET["c50"];

      skyyreq("roll-quantity/1/" . $c1);
      skyyreq("roll-quantity/5/" . $c5);
      skyyreq("roll-quantity/10/" . $c10);
      skyyreq("roll-quantity/25/" . $c25);
      skyyreq("roll-quantity/50/" . $c50);
    }

    exit;
  }

  $Entity="";
  $EntityNum = 0;
  $Solution = skyyreq("count-entity");
  eval($Solution);

  // one more time to get 'step' info
  $Solution = skyyreq("count-entity-step");
  eval($Solution);


  // pre-load the 'rolls' count for this entity

  $roll1 = '0';
  $roll5 = '0';
  $roll10 = '0';
  $roll25 = '0';
  $roll50 = '0';  // is actually 50 cent coins
  $roll100 = '0';

  // this is an actual coin count.  Convert it into 'rolls'
  // and truncate any errors.  The user will have to accept it
  // this way or modify it to correct any problems.

  // TODO:  dollar rolls?  probably not...
//  $roll100 = floor($roll100 / 25);

  $Solution = skyyreq("result-rolls");
  eval($Solution);

  $roll1 = floor($roll1 / 50 + 0.001);
  $roll5 = floor($roll5 / 40 + 0.001);
  $roll10 = floor($roll10 / 50 + 0.001);
  $roll25 = floor($roll25 / 40 + 0.001);

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>ZC4 <?php print $Entity; ?> Count <?php print $Rolls; ?></title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
    .btn-plus
    {
      font-size:1rem;
      border-radius:2px;
      margin-left:0.5rem; /* 12 px */
      min-width:1.75rem;
      min-height: 1.75rem; /* 42px - necessary for increased button size */

      border: none;
      border-radius: 2px;
      display: inline-block;
      height: 1.5rem;
      line-height: 1.5rem;
      padding: 0 0.67rem;
      text-transform: uppercase;
      vertical-align: middle;
      outline: 0;
      text-decoration: none;
      color: #fff;
      background-color: #26a69a;
      text-align: center;
      letter-spacing: .5px;
      cursor: pointer;
      box-shadow: 2px 3px 7px 3px rgba(0,0,0,0.30) !important;
    }

    </style>

    <script>
      // global state
      var column = "1", output="rv1";
      var mode = "amount";
      var first = true;

      function OnChangeEntryMode()
      {
        if(document.getElementById("quantity_select").checked)
        {
          mode = "quantity";
          output = 'c' + column;

          document.getElementById("quantity").style.display="block";
          document.getElementById("quantity").style.visibility="visible";
          document.getElementById("amount").style.display="none";
          document.getElementById("amount").style.visibility="hidden";
        }
        else
        {
          mode = "amount";
          output = 'rv' + column;

          document.getElementById("amount").style.display="block";
          document.getElementById("amount").style.visibility="visible";
          document.getElementById("quantity").style.display="none";
          document.getElementById("quantity").style.visibility="hidden";
        }
      }

      function DoClick(key) // keypad click number key
      {
        var ww = document.getElementById(output);
        var strText = ww.value;

        console.log(output + ' ' + ww.id + ' ' + ww.value + ' ' + key);

        if(first)
        {
          console.log("first is true");

          first = false;
          if(ww.id == "rv1")
          {
            strText = "0.00";
          }
          else
          {
            strText = ""; // make sure I clear it on the first keystroke
          }
        }
        else
        {
          console.log("first is false");
        }

        if(ww.id == "rv1")
        {
          var vv = Math.floor(strText * 10 + 0.1); // add 0.1 to compensate for possible roundoff error

          console.log(vv);

          vv = (vv * 10 + Math.floor(key)) / 10;

          console.log(vv);

          ww.value = vv.toFixed(2);
        }
        else
        {
          ww.value = strText * 10 + Math.floor(key);
        }

        DoCalcTotal();
      }

      function DoClickClr() // keyboard click clear
      {
        document.getElementById(output).value = '0';
        DoFixTotal();
      }

      function DoClickEntor() // keyboard click 'entor' which is like 'enter' but more epic
      {
        console.log('Entor');
        NextColumn();
      }

      function DoFiftyCentPlus()
      {
        var vv = Math.floor(document.getElementById("c50").value); // as integer

        console.log("testin: " + vv);

        document.getElementById("c50").value = (vv + 1);
        DoFixTotal();
      }

      function DoFiftyCentMinus()
      {
        var vv = Math.floor(document.getElementById("c50").value);

        console.log("testin: " + vv);

        if(vv > 0)
          document.getElementById("c50").value = (vv - 1);
        else
          document.getElementById("c50").value = 0;

        DoFixTotal();
      }
    </script>

  </head>
  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">
          <?php print make_participle(make_singular($Rolls)); ?>
          <?php print make_singular($Coins); ?> <img src="img/rolls.svg"></a>
        <div class="area" style="font-size:1rem"><?php print strtoupper($Entity); ?></div>
      </div>
    </nav>
    <div class="container center">
      <div id="mode-selector" class="left-align">
        <h6 style="<?php if($CustomerMod == 2) print ';visibility:hidden;display:none'; ?>"> Entry mode</h6>
        <p style="line-height:1.2em;margin-top:0;margin-bottom:0.4rem<?php if($CustomerMod == 2) print ';visibility:hidden'; ?>">
          <label>
          <input id=quantity_select onChange="OnChangeEntryMode();" class="with-gap" value="quantity" name="entrymode" type="radio" />
          <span># of <?php print strtolower($Rolls); ?></span>
          </label>
        </p>
        <p style="line-height:1.2em;margin-top:0;margin-bottom:0<?php if($CustomerMod == 2) print ';visibility:hidden;display:none'; ?>">
          <label>
          <input id=amount_select onChange="OnChangeEntryMode();" class="with-gap"  value="amount" name="entrymode" type="radio" checked />
          <span>$ value</span>
          </label>
        </p>
      </div>

      <div class="row button-row selector-buttons right-align" <?php if($CustomerMod == 2) print 'style="margin-right:3.4rem"'; ?> >
        <div class="selector-button" id="b1">
          <a id="ba1" href="#" class="multi-click btn waves-effect btn-shadow primary-fill secondary-fill selected-button">1 ¢ </a>
        </div>
        <div class="selector-button" id="b5">
          <a id="ba5" href="#" class="multi-click btn waves-effect btn-shadow primary-fill">5 ¢ </a>
        </div>
        <div class="selector-button" id="b10">
          <a id="ba10" href="#" class="multi-click btn waves-effect btn-shadow primary-fill">10 ¢ </a>
        </div>
        <div class="selector-button" id="b25">
          <a id="ba25" href="#" class="multi-click btn waves-effect btn-shadow primary-fill">25 ¢ </a>
        </div>
      </div>

      <form name="submitRolls" id="submitRolls" action="/count-rolls.php" method="GET">
        <!-- send data to myself, process via 'complete=Y', must use GET so other redirs work -->
        <input  type="hidden" name="complete" value="Y" style="visibility:hidden" />
<?php
  if(strlen($Origin) > 0)
  {
?>
        <input  type="hidden" name="Origin" value="<?php print $Origin; ?>" style="visibility:hidden" />
<?php
  }
?>
        <!--################################################ -->
        <div id="quantity" class="right-align" style="display:none">
          <div class="row button-row">
            <div class="input-selector" id="a1">
              <label style="min-width:0.7rem">#</label>
              <div class="mdl-textfield denom">
                <input name="c1" id="c1" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
                 value=<?php print '"' . $roll1 . '"'; ?>
                 maxlength="3" disabled />
              </div>
            </div>
            <div class="input-selector" id="a2">
              <label style="min-width:0.7rem">#</label>
              <div class="mdl-textfield denom">
                <input name="c5" id="c5" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
                 value=<?php print '"' . $roll5 . '"'; ?>
                 maxlength="3" disabled />
              </div>
            </div>
            <div class="input-selector" id="a3">
              <label style="min-width:0.7rem">#</label>
              <div class="mdl-textfield">
                <input name="c10" id="c10" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
                 value=<?php print '"' . $roll10 . '"'; ?>
                 maxlength="3" disabled />
              </div>
            </div>
            <div class="input-selector" id="a4">
              <label style="min-width:0.7rem">#</label>
              <div class="mdl-textfield">
                <input name="c25" id="c25" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
                 value=<?php print '"' . $roll25 . '"'; ?>
                 maxlength="3" disabled />
              </div>
            </div>
          </div>
        </div>
<?php
  if($EntityNum > 0)     /* counting a register */
  {
    // add info about 50 cent pieces
?>
        <div style="position:absolute;width:25%;top:8.8rem;left:74%;white-space:nowrap;line-height:0.83rem;font-size:0.75rem">
            <a href="#" onClick="DoFiftyCentPlus();" class="btn-plus waves-effect secondary-fill multi-click"
               style="width:40px;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
          <!--div class="selector-button" id="b1"-->
            <span href="#" id="b50" onClick="DoFiftyCent();"
               style="width:3.33rem;margin:0;margin-left:10px;margin-right:10px;padding:0;font-size:1rem">50 ¢</span>
          <!--/div-->
            <a href="#" onClick="DoFiftyCentMinus();" class="btn-plus waves-effect secondary-fill multi-click"
               style="width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
        </div>

        <div style="position:absolute;width:25%;top:10.1rem;left:74%;white-space:nowrap;line-height:0.83rem;font-size:0.75rem">
          <div>
            <label style="min-width:0.7rem">$</label>
            <div class="mdl-textfield" style="width:auto">
              <input name="c50" id="c50" type="hidden"
               value=<?php print '"' . $roll50 . '"'; ?>
               maxlength="3" style="width:80px" disabled style="visibility:hidden" />
              <input name="rv50" id="rv50" class="mdl-textfield__input special-text-input tweek-inactive" type="text"
               value=<?php print '"' /*. $roll50 * 0.50*/ . '"'; ?>
               maxlength="8" style="width:4.1rem" disabled />
            </div>
          </div>
        </div>
<?php
  }
  else
  {
?>
        <input type=hidden name=c50 id=c50 value="0" style="visibility:hidden">
        <input type=hidden name=rv50 id=rv50 value="0.00" style="visibility:hidden">
<?php
  }
?>
      </form><!-- all of the things that get sent when i submit rolls -->

      <div id="amount" class="right-align" style="display:block<?php if($CustomerMod == 2) print ';margin-right:3.4rem'; ?>">
        <div class="row button-row">
          <div class="input-selector" id="a1">
            <label style="min-width:0.7rem">$</label><div class="mdl-textfield denom">
            <input id="rv1" class="mdl-textfield__input special-text-input tweek-inactive" type="text"
             value=<?php printf('"%.2f"', $roll1 * 0.50); ?>
             maxlength="4" disabled /></div>
          </div>
          <div class="input-selector" id="a2">
            <label style="min-width:0.7rem">$</label><div class="mdl-textfield denom">
            <input id="rv5" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
             value=<?php print '"' . $roll5 * 2 . '"'; ?>
             maxlength="4" disabled /></div>
          </div>
          <div class="input-selector" id="a3">
            <label style="min-width:0.7rem">$</label><div class="mdl-textfield">
            <input id="rv10" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
             value=<?php print '"' . $roll10 * 5 . '"'; ?>
             maxlength="4" disabled /></div>
          </div>
          <div class="input-selector" id="a4">
            <label style="min-width:0.7rem">$</label><div class="mdl-textfield">
            <input  id="rv25" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
             value=<?php print '"' . $roll25 * 10 . '"'; ?>
             maxlength="4" disabled /></div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class=" calc-card mdl-card mdl-shadow--2dp">
        <div class="buttons" id="wrapper">
          <button onClick="DoClick('7');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">7</button>
          <button onClick="DoClick('8');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">8</button>
          <button onClick="DoClick('9');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">9</button>
          <button onClick="DoClickClr();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent">
            <span style="display:none">backspace</span>
            <img src="img/baseline-backspace-24px.svg" style="color:white">
          </button>

          <button onClick="DoClick('4');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">4</button>
          <button onClick="DoClick('5');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">5</button>
          <button onClick="DoClick('6');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">6</button>
          <button class="mdl-button">&nbsp;</button>

          <button onClick="DoClick('1');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">1</button>
          <button onClick="DoClick('2');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">2</button>
          <button onClick="DoClick('3');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">3</button>
          <button onClick="DoClickEntor();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent tall"
                  style="line-height:1em;height:">
            E<br/>n<br/>t<br/>e<br/>r
          </button>

<?php
  if($CustomerMod != 2) // NOT Academy
  {
?>
          <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide">0</button>
<?php
  }
  else // Academy
  {
?>
          <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide3">0</button>
          <button onClick="DoClick('0');DoClick('0');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">00</button>
<?php
  }
?>
        </div>
      </div>
    </div>

    <div class="page-total">
      <span>$</span>
      <div class="page-total-textfield" style="line-height:20px">
        <input id="pageTotal" class="mdl-textfield__input special-text-input" type="text" value="0.00" maxlength="9" disabled />
      </div>
    </div>

    <form id="none" name="none" method="GET"></form>
<?php
  if(strlen($Origin)==0 && $Step == 0) // first one gets an 'Exit' button
  {
    // if I did not specify an origin, then this is the first thing I do in the flow
    // and so I'll display an 'Exit' button
    // However, if it's a till, do NOT specify the 'Exit' button, regardless, since it is last
?>
      <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:24px;left:12px;">
        <button type=submit formaction="/tasks.php" form="none" class="btn waves-effect primary-fill btn-shadow">Exit</button>
      </div>
<?php
  }
?>
      <div class="next-button">
        <button id="next" type="submit" form="submitRolls" class="btn waves-effect primary-fill btn-shadow">NEXT &gt;</button>
      </div>
    </form>

    <!--  Scripts-->
    <script  src="js/custom.js"></script>

    <script>

      function MyRemoveClassW(ww, removal)
      {
        if(ww != null)
          ww.classList.remove(removal);
      }

      function MyRemoveClass(classname, removal)
      {
        var ii, ww = document.getElementsByClassName(classname);

        if(ww != null)
        {
          for(ii=0; ii < ww.length; ii++)
          {
            MyRemoveClassW(ww[ii], removal);
          }
        }
        ii = null;
        ww = null;
      }

      function MyAddClass(classname, addit)
      {
        var ii, ww = document.getElementsByClassName(classname);

        if(ww != null)
        {
          for(ii=0; ii < ww.length; ii++)
          {
            ww[ii].classList.add(addit);
          }
        }
        ii = null;
        ww = null;
      }

      function DoClickSelector(evt)
      {
        var ww = evt.currentTarget;

        if(ww != null)
        {
          column = ww.id.substr(1); // column ID matches that of denom
          OnChangeColumn();
        }
      }

      function NextColumn()
      {
        console.log('column was ' + column);

        if(column == 1)
          column = 5;
        else if(column == 5)
          column = 10;
        else if(column == 10)
          column = 25;
        else if(column == 25) // do not wrap
        {
          DoFixTotal();
          return;
        }
        else
          column = 1;

        OnChangeColumn();
      }

      function OnChangeColumn()
      {
        console.log('column is now ' + column);

        // this is how the other one worked, so retaining basic functionality and method
        MyRemoveClass("btn", 'selected-button');
        MyRemoveClass("btn", 'secondary-fill');
        MyAddClass("btn", 'primary-fill');
        MyAddClass("tweek-inactive", 'inactive');

        MyAddClass("input", 'inactive');

        if(mode == "quantity")
        {
          output = 'c' + column;
        }
        else
        {
          output = 'rv' + column;
        }

        console.log(output);
        MyRemoveClassW(document.getElementById(output), 'inactive');

        document.getElementById("ba" + column).classList.add('secondary-fill');
        document.getElementById("ba" + column).classList.add('selected-button');

        first = true; // new behavior
//        if(mode != "quantity" && column == 1)
//          document.getElementById(output).value = '0.00';
//        else
//          document.getElementById(output).value = '0';

        DoFixTotal();
      }

      // iterate through each td based on class and add the values

      function DoFixTotal ()
      {
        DoCalcTotal(true);
      }

      function DoCalcTotal(fix_it = false)
      {
        var tval, c1, c5, c10, c25, oldsum;

        // this function is intended to be called whenever you hit 'enter'
        // and it will fix the totals so they're "even"

        if(mode != "quantity")
        {
          c1 = 1.0 * (document.getElementById("rv1").value);
          c5 = 1.0 * (document.getElementById("rv5").value);
          c10 = 1.0 * (document.getElementById("rv10").value);
          c25 = 1.0 * (document.getElementById("rv25").value);

          // add 0.25 to correct for roundoff in a sane way
          c1 = Math.floor(c1 / 50 * 100 + 0.25);  // * 100 -> div by 0.01
          c5 = Math.floor(c5 / 40 * 20 + 0.25);   // * 20 -> div by 0.05
          c10 = Math.floor(c10 / 50 * 10 + 0.25); // * 10 -> div by 0.10
          c25 = Math.floor(c25 / 40 * 4 + 0.25);   // * 4 -> div by 0.25

          document.getElementById("c1").value = c1.toFixed(0);
          document.getElementById("c5").value = c5.toFixed(0);
          document.getElementById("c10").value = c10.toFixed(0);
          document.getElementById("c25").value = c25.toFixed(0);
        }
        else
        {
          c1 = Math.floor(document.getElementById("c1").value);
          c5 = Math.floor(document.getElementById("c5").value);
          c10 = Math.floor(document.getElementById("c10").value);
          c25 = Math.floor(document.getElementById("c25").value);

          document.getElementById("rv1").value = (c1 * 50 * 0.01).toFixed(2);
          document.getElementById("rv5").value = (c5 * 40 * 0.05).toFixed(0);
          document.getElementById("rv10").value = (c10 * 50 * 0.10).toFixed(0);
          document.getElementById("rv25").value = (c25 * 40 * 0.25).toFixed(0);
        }

        oldsum = c1 * 50 * 0.01
               + c5 * 40 * 0.05
               + c10 * 50 * 0.10
               + c25 * 40 * 0.25;

        if(fix_it) // fix the sums
        {
          console.log('c1=' + c1 + '  c5=' + c5 + '  c10=' + c10 + '  c25=' + c25);

          document.getElementById("rv1").value = (c1.toFixed(0) * 50 * 0.01 + 0.0025).toFixed(2);
          document.getElementById("rv5").value = c5.toFixed(0) * 40 * 0.05;
          document.getElementById("rv10").value = c10.toFixed(0) * 50 * 0.10;
          document.getElementById("rv25").value = c25.toFixed(0) * 40 * 0.25;

          sum = oldsum;
        }
        else if(mode != "quantity")
        {
          // calc actual sum based on entry
          sum = parseFloat(document.getElementById("rv1").value);
          sum += parseFloat(document.getElementById("rv5").value);
          sum += parseFloat(document.getElementById("rv10").value);
          sum += parseFloat(document.getElementById("rv25").value);
        }


        tval = Math.floor(document.getElementById("c50").value) * 0.50;
        document.getElementById("rv50").value = currency_form(tval);
        sum += tval;

        console.log('sum ' + sum + ' ' + currency_form(sum) + '  oldsum=' + oldsum);
        document.getElementById("pageTotal").value = currency_form(sum);

        if(!fix_it && mode!="quantity")
        {
          if(sum.toFixed(2) == oldsum.toFixed(2))
          {
            document.getElementById("next").disabled = false;
          }
          else
          {
            document.getElementById("next").disabled = true;
          }
        }
        else
        {
          document.getElementById("next").disabled = false;
        }
      }

      function setTotal () // not used, left for reference
      {
        // this function calculates the total and syncs up between
        // the amount and quantity fields
        var sum=0;
        var oldsum=0;
        var tval;

        if (mode=="quantity")
        {
          sum += parseFloat(document.getElementById("c1").value) * 50 * 0.01;
          sum += parseFloat(document.getElementById("c5").value) * 40 * 0.05;
          sum += parseFloat(document.getElementById("c10").value) * 50 * 0.10;
          sum += parseFloat(document.getElementById("c25").value) * 40 * 0.25;
          document.getElementById("rv1").value = currency_form(document.getElementById("c1").value * 50 * 0.01);
          document.getElementById("rv5").value = (document.getElementById("c5").value * 40 * 0.05).toFixed(0);
          document.getElementById("rv10").value = (document.getElementById("c10").value * 50 * 0.1).toFixed(0);
          document.getElementById("rv25").value = (document.getElementById("c25").value * 40 * 0.25).toFixed(0);
        }
        else
        {
          sum += parseFloat(document.getElementById("rv1").value);
          sum += parseFloat(document.getElementById("rv5").value);
          sum += parseFloat(document.getElementById("rv10").value);
          sum += parseFloat(document.getElementById("rv25").value);
          document.getElementById("c1").value = (document.getElementById("rv1").value / 50 * 100).toFixed(0);
          document.getElementById("c5").value = (document.getElementById("rv5").value / 40 * 20).toFixed(0);
          document.getElementById("c10").value = (document.getElementById("rv10").value / 50 * 10).toFixed(0);
          document.getElementById("c25").value = (document.getElementById("rv25").value / 40 * 4).toFixed(0);
        }

        tval = Math.floor(document.getElementById("c50").value) * 0.50;
        document.getElementById("rv50").value = currency_form(tval);
        sum += tval;

        document.getElementById("pageTotal").value = currency_form(sum);
        oldsum = sum;

        if (mode!="quantity")
        {
          sum = parseFloat(document.getElementById("c1").value) * 50 * 0.01;
          sum += parseFloat(document.getElementById("c5").value) * 40 * 0.05;
          sum += parseFloat(document.getElementById("c10").value) * 50 * 0.10;
          sum += parseFloat(document.getElementById("c25").value) * 40 * 0.25;

          if(sum.toFixed(2) == oldsum.toFixed(2))
          {
            document.getElementById("next").disabled = false;
          }
          else
          {
            document.getElementById("next").disabled = true;
          }
        }
      }

      document.getElementById("submitRolls").onsubmit = function()
      {
        document.getElementById("c1").disabled = false;
        document.getElementById("c5").disabled = false;
        document.getElementById("c10").disabled = false;
        document.getElementById("c25").disabled = false;
        document.getElementById("c50").disabled = false;
      };

      // selector button needs click event listener
      {
        var ii, ww = document.getElementsByClassName("selector-button");
        if(ww != null)
        {
          for(ii=0; ii < ww.length; ii++)
          {
            ww[ii].addEventListener('click', DoClickSelector, false);
          }
        }
        ii = null;
        ww = null;
      }

      DoFixTotal();

    </script>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>

