<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Straps = do_getconf($parseconf,"terms",'Straps','Straps');

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  // find out the entity name, and the 'origin' parameter (if assigned)
  // these are assigned via 'GET' parameters in the URL

  $Origin = empty($_GET) || empty($_GET["origin"]) ? "" : $_GET["origin"];
  if(strlen($Origin) > 0 && substr($Origin,0,1) != "/")
    $Origin = "/" . $Origin;

  $complete = empty($_GET) || empty($_GET["complete"]) ? "" : $_GET["complete"];

  if($complete == "Y")
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /glue/next-step-count-class.php");
    header("Expires: 0");

    $c1 = empty($_GET["c1"]) ? 0 : $_GET["c1"];
    $c5 = empty($_GET["c5"]) ? 0 : $_GET["c5"];
    $c10 = empty($_GET["c10"]) ? 0 : $_GET["c10"];
    $c20 = empty($_GET["c20"]) ? 0 : $_GET["c20"];

    $c5 = floor($c5 / 5);
    $c10 = floor($c10/ 10);
    $c20 = floor($c20 / 20);

//    print "'" . $c1 . "', '" . $c5 . "', '" . $c10 . "', '" . $c20 . "'<br>\n";

    skyyreq("strap-quantity/1/" . $c1);
    skyyreq("strap-quantity/5/" . $c5);
    skyyreq("strap-quantity/10/" . $c10);
    skyyreq("strap-quantity/20/" . $c20);

    exit;
  }

  $Entity="";
  $EntityNum = 0;
  $Solution = skyyreq("count-entity");
  eval($Solution); // need better way, for now this

  // do this again for the 'count-entity-step'
  $Solution = skyyreq("count-entity-step");
  eval($Solution); // re-does $Entity, no big deal


  // pre-load the 'straps' count for this entity

  $strap1 = '0';
  $strap2 = '0';
  $strap5 = '0';
  $strap10 = '0';
  $strap20 = '0';
  $strap50 = '0';
  $strap100 = '0';

  $Solution = skyyreq("result-strap");
  eval($Solution);

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>ZC4 <?php print $Entity; ?> Count <?php print $Straps; ?></title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
    </style>

    <script>
      // global state
      var column = "1", output="c1";
      var first = true;

      function DoSubmit()
      {
        document.getElementById("c1").disabled = false;
        document.getElementById("c5").disabled = false;
        document.getElementById("c10").disabled = false;
        document.getElementById("c20").disabled = false;
        document.getElementById("submitStraps").submit();
      }

      function DoClick(key) // keypad click number key
      {
        var ww = document.getElementById(output);

        console.log(output + ' ' + ww.id + ' ' + ww.value + ' ' + key);

        if(first)
        {
          first = false;
          ww.value = ""; // make sure I clear it on the first keystroke
        }

        ww.value = ww.value * 10 + Math.floor(key);

        DoCalcTotal();
      }

      function DoClickClr() // keyboard click clear
      {
        document.getElementById(output).value = '0';
        DoFixTotal();
      }

      function DoClickEntor() // keyboard click 'entor' which is like 'enter' but more epic
      {
        console.log('Entor');
        NextColumn();
      }
    </script>

  </head>
  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">
          <?php print make_participle(make_singular($Straps)); ?>
          <?php print $Notes; ?> <img src="img/straps.svg"></a>
        <div class="area" style="font-size:1rem"><?php print strtoupper($Entity); ?></div>
      </div>
    </nav>
    <div class="container center">
      <div class="row button-row selector-buttons">
      <!--div class="row selector-buttons  center"-->
        <div class="selector-button" id="b1">
          <a id="ba1" href="#" class="multi-click btn waves-effect btn-shadow primary-fill secondary-fill selected-button">$ 1</a>
        </div>
        <div class="selector-button" id="b5">
          <a id="ba5" href="#" class="multi-click btn waves-effect btn-shadow primary-fill">$ 5</a>
        </div>
        <div class="selector-button" id="b10">
          <a id="ba10" href="#" class="multi-click btn waves-effect btn-shadow primary-fill">$ 10</a>
        </div>
        <div class="selector-button" id="b20">
          <a id="ba20" href="#" class="multi-click btn waves-effect btn-shadow primary-fill">$ 20</a>
        </div>
      </div>
    </div>

    <div id="quantity" class="center">
      <form name="submitStraps" id="submitStraps" action="/count-straps.php" method="GET">
        <!-- send data to myself, process via 'complete=Y', must use GET so other redirs work -->
        <input  type="hidden" name="complete" value="Y" style="visibility:hidden" />
<?php
  if(strlen($Origin) > 0)
  {
?>
        <input  type="hidden" name="Origin" value="<?php print $Origin; ?>" style="visibility:hidden" />
<?php
  }
?>
        <!--################################################ -->
        <div class="row button-row">
          <div class="input-selector" id="a1">
            <label style="min-width:0.7rem">$</label><div class="mdl-textfield denom">
            <input name="c1" id="c1" class="mdl-textfield__input special-text-input tweek-inactive" type="text"
             value=<?php print '"' . $strap1 . '"'; ?>
             maxlength="5" disabled /></div>
          </div>
          <div class="input-selector" id="a2">
            <label style="min-width:0.7rem">$</label><div class="mdl-textfield denom">
            <input name="c5" id="c5" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
             value=<?php print '"' . ($strap5 * 5) . '"'; ?>
             maxlength="5" disabled /></div>
          </div>
          <div class="input-selector" id="a3">
            <label style="min-width:0.7rem">$</label><div class="mdl-textfield">
            <input name="c10" id="c10" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
             value=<?php print '"' . ($strap10 * 10). '"'; ?>
             maxlength="5" disabled /></div>
          </div>
          <div class="input-selector" id="a4">
            <label style="min-width:0.7rem">$</label><div class="mdl-textfield">
            <input name="c20" id="c20" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
             value=<?php print '"' . ($strap20 * 20) . '"'; ?>
             maxlength="5" disabled /></div>
          </div>
        </div>
      </form>
    </div>

    <div class="row">
      <div class=" calc-card mdl-card mdl-shadow--2dp">
        <div class="buttons" id="wrapper">
          <button onClick="DoClick('7');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">7</button>
          <button onClick="DoClick('8');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">8</button>
          <button onClick="DoClick('9');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">9</button>
          <button onClick="DoClickClr();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent">
            <span style="display:none">backspace</span>
            <img src="img/baseline-backspace-24px.svg" style="color:white">
          </button>

          <button onClick="DoClick('4');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">4</button>
          <button onClick="DoClick('5');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">5</button>
          <button onClick="DoClick('6');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">6</button>
          <button class="mdl-button">&nbsp;</button>

          <button onClick="DoClick('1');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">1</button>
          <button onClick="DoClick('2');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">2</button>
          <button onClick="DoClick('3');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">3</button>
          <button onClick="DoClickEntor();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent tall"
                  style="line-height:1em;height:">
            E<br/>n<br/>t<br/>e<br/>r
          </button>

<?php
  if($CustomerMod != 2) // NOT Academy
  {
?>
          <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide">0</button>
<?php
  }
  else // Academy
  {
?>
          <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide3">0</button>
          <button onClick="DoClick('0');DoClick('0');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">00</button>
<?php
  }
?>
        </div>
      </div>
    </div>

    <div class="page-total">
      <span>$</span>
      <div class="page-total-textfield" style="line-height:20px">
        <input id="pageTotal" class="mdl-textfield__input special-text-input" type="text" value="0.00" maxlength="10" disabled />
      </div>
    </div>

    <form id="none" name="none" method="GET"></form>
<?php
  if(strlen($Origin)==0 && $Step == 0) // first one gets an 'Exit' button
  {
    // if I did not specify an origin, then this is the first thing I do in the flow
    // and so I'll display an 'Exit' button
    // However, if it's a till, do NOT specify the 'Exit' button, regardless, since it is last
?>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:24px;left:12px;">
      <button type="submit" formaction="/tasks.php" form="none" class="btn waves-effect primary-fill btn-shadow">Exit</button>
    </div>
<?php
  }
?>
    <div class="next-button">
      <button id="next" type="submit" onClick="DoSubmit();" class="btn waves-effect primary-fill btn-shadow" disabled=false>NEXT &gt;</button>
    </div>

    <!--  Scripts-->
    <script  src="js/custom.js"></script>

    <script>

      function MyRemoveClassW(ww, removal)
      {
        if(ww != null)
          ww.classList.remove(removal);
      }

      function MyRemoveClass(classname, removal)
      {
        var ii, ww = document.getElementsByClassName(classname);

        if(ww != null)
        {
          for(ii=0; ii < ww.length; ii++)
          {
            MyRemoveClassW(ww[ii], removal);
          }
        }
        ii = null;
        ww = null;
      }

      function MyAddClass(classname, addit)
      {
        var ii, ww = document.getElementsByClassName(classname);

        if(ww != null)
        {
          for(ii=0; ii < ww.length; ii++)
          {
            ww[ii].classList.add(addit);
          }
        }
        ii = null;
        ww = null;
      }

      function DoClickSelector(evt) /* adapted from poorly written JQuery code, basic functionality retained for now */
      {
        var ww = evt.currentTarget;

        if(ww != null)
        {
          column = ww.id.substr(1); // column ID matches that of denom
          OnChangeColumn();
        }
      }

      function NextColumn()
      {
        console.log('column was ' + column);

        if(column == 1)
          column = 5;
        else if(column == 5)
          column = 10;
        else if(column == 10)
          column = 20;
        else if(column == 20) // do not wrap
        {
          DoFixTotal();
          return;
        }
        else
          column = 1;

        OnChangeColumn();
      }

      function OnChangeColumn()
      {
        console.log('column is now ' + column);

        // this is how the other one worked, so retaining basic functionality and method
        MyRemoveClass("btn", 'selected-button');
        MyRemoveClass("btn", 'secondary-fill');
        MyAddClass("btn", 'primary-fill');
        MyAddClass("tweek-inactive", 'inactive');

        MyAddClass("input", 'inactive');

        output = 'c' + column;

        console.log(output);
        MyRemoveClassW(document.getElementById(output), 'inactive');

        document.getElementById("ba" + column).classList.add('secondary-fill');
        document.getElementById("ba" + column).classList.add('selected-button');

        first = true; // new behavior
    //    document.getElementById(output).value = '0';

        DoFixTotal();
      }

      // iterate through each td based on class and add the values

      function DoFixTotal ()
      {
        DoCalcTotal(true);
      }

      function DoCalcTotal(fix_it = false)
      {
        var tval, c1, c5, c10, c20, oldsum;

        // this function is intended to be called whenever you hit 'enter'
        // and it will fix the totals so they're "even"

        c1 = Math.floor(document.getElementById("c1").value);
        c5 = Math.floor(document.getElementById("c5").value);
        c10 = Math.floor(document.getElementById("c10").value);
        c20 = Math.floor(document.getElementById("c20").value);

        sum = c1 + c5 + c10 + c20;

        console.log('sum ' + sum + ' ' + currency_form(sum) + '  oldsum=' + oldsum);
        document.getElementById("pageTotal").value = currency_form(sum);

        if(Math.floor(c5 / 5) * 5 == c5 &&
           Math.floor(c10 / 10) * 10 == c10 &&
           Math.floor(c20 / 20) * 20 == c20)
        {
          document.getElementById("next").disabled = false;
        }
        else
        {
          document.getElementById("next").disabled = true;
        }
      }


      function setTotal ()
      {
        // this function calculates the total and syncs up between
        // the amount and quantity fields
        var sum=0;
        var oldsum=0;
        var tval;

        sum += parseFloat(document.getElementById("c1").value);
        sum += parseFloat(document.getElementById("c5").value);
        sum += parseFloat(document.getElementById("c10").value);
        sum += parseFloat(document.getElementById("c20").value);

        document.getElementById("pageTotal").value = currency_form(sum);
      }


      // selector button needs click event listener
      {
        var ii, ww = document.getElementsByClassName("selector-button");
        if(ww != null)
        {
          for(ii=0; ii < ww.length; ii++)
          {
            ww[ii].addEventListener('click', DoClickSelector, false);
          }
        }
        ii = null;
        ww = null;
      }

      DoFixTotal();

    </script>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>

