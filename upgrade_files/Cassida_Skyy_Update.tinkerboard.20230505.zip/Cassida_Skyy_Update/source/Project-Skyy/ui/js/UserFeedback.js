/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */


// User Feedback for 'waves-effect' buttons - simple and clean and FAST!
// the materialize stuff NEVER worked properly.  THIS, however, is really good.

// setting up focus events - better user feedback

function UserFeedback(evt)
{
  var w = evt.currentTarget;

  var ll = w.style.left;
  var tt = w.style.top;

  if(ll.substring(ll.length - 2, ll.length) == "px")
    ll = ll.substring(0, ll.length - 2);

  if(tt.substring(tt.length - 2, tt.length) == "px")
    tt = tt.substring(0, tt.length - 2);

  w.style.left = (Math.floor(ll - 0) + 2) + 'px';
  w.style.top = (Math.floor(tt - 0) + 2) + 'px';

  setTimeout(function(){EndUserFeedback(w);}, 50);
}

function UserFeedbackP(evt)
{
  var w = evt.currentTarget;

  w.style.right = '0.25rem';
  w.style.top = '0.41rem';

  setTimeout(function(){EndUserFeedbackP(w);}, 50);
}

function EndUserFeedback(w)
{
  var ll = w.style.left;
  var tt = w.style.top;

  if(ll.substring(ll.length - 2, ll.length) == "px")
    ll = ll.substring(0, ll.length - 2);

  if(tt.substring(tt.length - 2, tt.length) == "px")
    tt = tt.substring(0, tt.length - 2);

  w.style.left = (Math.floor(ll) - 2) + 'px';
  w.style.top = (Math.floor(tt) - 2) + 'px';

  console.log("tap"); // temporary for debugging
}

function EndUserFeedbackP(w)
{
  w.style.right = '0.33rem';
  w.style.top = '0.33rem';

  console.log("tap"); // temporary for debugging
}

function KickTheDog()
{
  var myRequest = new Request("/glue/nothing.php");

  fetch(myRequest)
    .then(function(response)
          {
            if (!response.ok)
            {
              console.log("nothing", response.status); // debug only (TODO: remove?  this is actually an error condition...)
            }
            return  response.text();
          })
    .then(function(text)
          {
            // TODO:  anything?
            console.log("bark!");
            myRequest = null;
          })
   .catch(function(err)
          {
            console.log("Error detected in KickTheDog()");
            console.error(err);
          });

  myRequest = null;
}

// setup for event handlers - run this last
{
  var ii, ww = document.getElementsByClassName("waves-effect");
  if(ww != null)
  {
    for(ii=0; ii < ww.length; ii++)
    {
      if(ww[ii].classList.contains("multi-click")) // multi-click clicks more than once
        ww[ii].addEventListener('click', UserFeedback, {capture:true});
      else
        ww[ii].addEventListener('focus', UserFeedback, {once:true, capture:true});
    }
  }

  // same with calc-button

  ww = document.getElementsByClassName("calc-button");
  if(ww != null)
  {
    for(ii=0; ii < ww.length; ii++)
    {
      // multi-click implied - clicks more than once
      ww[ii].addEventListener('click', UserFeedback, {capture:true});
    }
  }

  // special thing for power button
  ww = document.getElementsByClassName("off-button");

  if(ww != null)
  {
    for(ii=0; ii < ww.length; ii++)
    {
      ww[ii].addEventListener('click', UserFeedbackP, {capture:false});
    }
  }

  document.getElementsByTagName("BODY")[0].addEventListener('mousedown', KickTheDog, {capture:false});

  ii = null;
  ww = null;
}


