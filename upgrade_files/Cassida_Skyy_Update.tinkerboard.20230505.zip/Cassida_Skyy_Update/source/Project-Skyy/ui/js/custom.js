/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

//                    _                         _
//   ___  _   _  ___ | |_  ___   _ __ ___      (_) ___
//  / __|| | | |/ __|| __|/ _ \ | '_ ` _ \     | |/ __|
// | (__ | |_| |\__ \| |_| (_) || | | | | | _  | |\__ \
//  \___| \__,_||___/ \__|\___/ |_| |_| |_|(_)_/ ||___/
//                                           |__/
//
// javascript utilities, print button, 'getCount_X'
//

function formatDate(date)
{
  var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

  d = null;

  if (month.length < 2)
    month = '0' + month;

  if (day.length < 2)
    day = '0' + day;

  var rval=[year, month, day].join('-');

  year = null;
  month = null;
  day = null;

  return rval;
}

function currency_form0(xx)
{
  var yy = xx.toFixed(0);
  var zz;

  var n = yy.length;

  if(xx >= 1000)
  {
    if(xx >= 1000000)
    {
      if(xx >= 1000000000)
      {
        zz = yy.substr(0, n - 9)
           + ","
           + yy.substr(n - 9, 3)
           + ","
           + yy.substr(n - 6, 3)
           + ","
           + yy.substr(n - 3, 3);
      }
      else
      {
        zz = yy.substr(0, n - 6)
           + ","
           + yy.substr(n - 6, 3)
           + ","
           + yy.substr(n - 3, 3);
      }
    }
    else
    {
      zz = yy.substr(0, n - 3)
         + ","
         + yy.substr(n - 3, 3);
    }
  }
  else
  {
    zz = yy;
  }

  n = null;
  yy = null;

  return zz;
}

function currency_form(xx)
{
  var yy = xx.toFixed(2);
  var zz;

  var n = yy.length;

  if(xx >= 1000.00)
  {
    if(xx >= 1000000.00)
    {
      if(xx >= 1000000000.00)
      {
        zz = yy.substr(0, n - 12)
           + ","
           + yy.substr(n - 12, 3)
           + ","
           + yy.substr(n - 9, 3)
           + ","
           + yy.substr(n - 6, 6);
      }
      else
      {
        zz = yy.substr(0, n - 9)
           + ","
           + yy.substr(n - 9, 3)
           + ","
           + yy.substr(n - 6, 6);
      }
    }
    else
    {
      zz = yy.substr(0, n - 6)
         + ","
         + yy.substr(n - 6, 6);
    }
  }
  else
  {
    zz = yy;
  }

  n = null;
  yy = null;

  return zz;
}



//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
//   ____          _          _____                     _    _                      //
//  |  _ \   __ _ | |_  ___  |  ___|_   _  _ __    ___ | |_ (_)  ___   _ __   ___   //
//  | | | | / _` || __|/ _ \ | |_  | | | || '_ \  / __|| __|| | / _ \ | '_ \ / __|  //
//  | |_| || (_| || |_|  __/ |  _| | |_| || | | || (__ | |_ | || (_) || | | |\__ \  //
//  |____/  \__,_| \__|\___| |_|    \__,_||_| |_| \___| \__||_| \___/ |_| |_||___/  //
//                                                                                  //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////

function GetDaysInMonth(nYear, nMonth) // # of days in a specific month for a specific year
{
  if(nMonth == 9 || nMonth == 4 || nMonth == 6 || nMonth == 11) // september, april, june, november
    return 30;
  else if(nMonth != 2) // not February
    return 31;
  else if((nYear % 4) != 0 || ((nYear % 4) == 0 && (nYear % 400) != 0))
    return 28; // not a leap year
  else
    return 29;
}

function GetMonthName(nMonth)
{
var rVal;
var month_names = new Array("", "January", "February","March", "April", "May", "June",
                            "July", "August", "September", "October", "November", "December");

  if(nMonth < 1 || nMonth > 12)
    rVal = "*ERR*";
  else
    rVal = month_names[nMonth];

  month_names = null;
  return rVal;
}

function GetDayName(nDay)
{
var rVal;
var day_names = new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" );

  if(nDay < 0 || nDay > 6)
    rVal = "*ERR*";
  else
    rVal = day_names[nDay];

  day_names = null;
  return rVal;
}

function GetIntegerDate(nYear, nMonth, nDay) // integer date since 12/31/1899 which is a sunday
{
  // This function returns the number of days since 12/31/1899, which is 0, and a Sunday
  // It is something I wrote decades ago.  It has been given to the public domain and
  // adapted for JavaScript by the author (me).  It is essentially the same calculation that
  // MS Excel and Libre Office Calc use to calculate an integer date value.  Using the return
  // value makes it simple to calculate 'Day of Week' which is why it is here.
  //
  // nYear is any integer value with century included
  // nMonth is between 1 and 12, inclusive
  // nDay must be a valid date for the given month and year (1-28, 1-29, 1-30, 1-31)
  //
  // NOTE:  this algorithm is heavily tweeked for maximum efficiency

  // trivia - made you look - the day names based on visible-from-earth 'heavenly bodies'
  //    Sunday = Sun   Monday = Moon   Tuesday = Mars   Wednesday = Mercury
  //    Thursday "Thor's Day" = Jupiter   Friday = Venus    Saturday = Saturn

  var FOUR_HUNDRED_YEARS = 146097; /*(400 * 365 + 24 * 4 + 1)*/ // # of days in 400 years
  var total_days = new Array(0,31,59,90,120,151,181,212,243,273,304,334,365);
  var total_leap = new Array(0,31,60,91,121,152,182,213,244,274,305,335,366);
  var lRval;
  var n_years;
  var adjustment;

  adjustment = 0;              /* initially don't adjust for century */
  n_years = nYear - 1900;    /* # of years since 1900 */

  while(n_years < 0) // specified year is less than 1900
  {
    n_years += 400;                      /* add 400 years */
    adjustment -= FOUR_HUNDRED_YEARS;    /* subtract number of days in 400 years */
  }

  while(n_years >= 400) // specified year is more than 2299
  {
    n_years -= 400;                      /* subtract 400 years */
    adjustment += FOUR_HUNDRED_YEARS;    /* add number of days in 400 years */
  }

    /*    CALCULATE THE TOTAL NUMBER OF DAYS UP TO 1/1 THIS YEAR    */
    /* terms:  # of days + # of "Feb/29"s - # of non-leap centuries */

  lRval = 365 * n_years
        + ((n_years > 4)   ? Math.floor((n_years - 1) / 4)         // number of leap years to add 1 day
                           : 0 )
        + ((n_years > 100) ? (1 - Math.floor((n_years - 1) / 100)) // number of leap centuries to subtract one day
                           : 0);

        /* now add the total number of days up to this month */

  if(Math.floor(nYear % 400) == 0 || (Math.floor(nYear % 100) != 0 && Math.floor(nYear % 4) == 0))
  {
                         /** LEAP YEAR **/
    lRval += total_leap[nMonth - 1];  /* month-to-date totals (leap) */
  }
  else
  {
                        /** NORMAL YEAR **/
    lRval += total_days[nMonth - 1];  /* a slightly faster method! */
  }

  lRval += Math.floor(nDay);          /* lRval is now updated for exact # of days! */

  return(lRval + adjustment);         /* thdya thdya thdya that's all folks! */
}

function GetDayOfWeek(nYear, nMonth, nDay)
{
  var dayz = GetIntegerDate(nYear, nMonth, nDay);

  if(dayz >= 0)
  {
    return(Math.floor(dayz % 7));
  }
  else
  {
    return(7 + Math.floor((dayz % 7)));
  }
}



////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                            //
//      _                               _____                     _    _                      //
//     / \    ___  _   _  _ __    ___  |  ___|_   _  _ __    ___ | |_ (_)  ___   _ __   ___   //
//    / _ \  / __|| | | || '_ \  / __| | |_  | | | || '_ \  / __|| __|| | / _ \ | '_ \ / __|  //
//   / ___ \ \__ \| |_| || | | || (__  |  _| | |_| || | | || (__ | |_ | || (_) || | | |\__ \  //
//  /_/   \_\|___/ \__, ||_| |_| \___| |_|    \__,_||_| |_| \___| \__||_| \___/ |_| |_||___/  //
//                 |___/                                                                      //
//                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////

function custome_js_sleep(msec)
{
  return new Promise(resolve => setTimeout(resolve, msec));
}

async function getCount_C(completion_callback = null) // coin subtotal qc and vc
{
  var myRequest = new Request("/glue/count_coins.php");

  fetch(myRequest)
  .then(
      function(response)
      {
        myRequest = null;

        if (!response.ok)
        {
          console.log("count_coins", response.status); // debug only (TODO: remove?)
        }

        return  response.text();
      })
  .then(
      function(text)
      {
              // xx will be a DOM Parser type of object from which to parse XML
        var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
        var coin = xx.getElementsByTagName("coin");
        var type, qty, val;
        var qc, vc, row;
        var subCoin=0.0;

        if(coin != null)
        {
          for (var i1 = 0; i1 < coin.length; i1++)
          {
            var cc = coin[i1].children;

            if(cc.length > 0)
            {
              for ( var i2 = 0; i2 < cc.length; i2++)
              {
                if(cc[i2].nodeName == "type")
                  type = cc[i2].childNodes[0].nodeValue;

                if(cc[i2].nodeName == "qty")
                  qty = cc[i2].childNodes[0].nodeValue;
              }
//              console.log("  coin " + type + "  qty " + qty + "\n");
              val = parseFloat(type) * parseFloat(qty) * 0.01;

              row=document.getElementById("row" + type);
              qc=document.getElementById("qc" + type);
              vc=document.getElementById("vc" + type);

              if(qc != null)
              {
                qc.innerHTML = qty;
                if(qty > 0 && row != null)
                  row.style.visibility="visible";
              }
//              else
//                console.log("ERR:  did not find \"qc" + type + "\"\n");

              if(vc != null)
                vc.innerHTML = val.toFixed(2);
//              else
//                console.log("ERR:  did not find \"vc" + type + "\"\n");

              subCoin += val;

              qc = null;
              vc = null;

            }

            cc = null;
          }
        }

        vc = document.getElementById("coinsSubTotal");

        if(vc != null)
          vc.innerHTML = subCoin.toFixed(2);
//        else
//          console.log("WARN:  could not find coinsSubTotal\n");

        vc = null;
        qc = null;
        type = null;
        qty = null;
        val = null;
        coin = null;
        xx = null;

        if(completion_callback)
          completion_callback();
      })
  .catch(
      function(err)
      {
        console.log("Error detected in getCount_C()");
        console.error(err);
      });
}

async function getCount_R(completion_callback = null) // coin subtotal qc and vc
{
  var myRequest = new Request("/glue/count_rolls.php");

  fetch(myRequest)
  .then(
      function(response)
      {
        myRequest = null;

        if (!response.ok)
        {
          console.log("count_rolls", response.status); // debug only (TODO: remove?)
        }

        return  response.text();
      })
  .then(
      function(text)
      {
              // xx will be a DOM Parser type of object from which to parse XML
        var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
        var roll = xx.getElementsByTagName("roll");
        var type, qty, batch, val;
        var qr, vr;
        var subCoin=0.0;

        if(roll != null)
        {
          for (var i1 = 0; i1 < roll.length; i1++)
          {
            var cc = roll[i1].children;

            if(cc.length > 0)
            {
              for ( var i2 = 0; i2 < cc.length; i2++)
              {
                if(cc[i2].nodeName == "type")
                  type = cc[i2].childNodes[0].nodeValue;

                if(cc[i2].nodeName == "qty")
                  qty = cc[i2].childNodes[0].nodeValue;

                if(cc[i2].nodeName == "batch")
                  batch = cc[i2].childNodes[0].nodeValue;
              }
//              console.log("  roll " + type + "  qty " + qty + "  batch " + batch + "\n");
              val = parseFloat(type) * parseFloat(qty) * parseFloat(batch) * 0.01;

              qr=document.getElementById("qr" + type);
              vr=document.getElementById("vr" + type);

              if(qr != null)
                qr.innerHTML = qty;
//              else
//                console.log("ERR:  did not find \"qr" + type + "\"\n");

              if(vr!= null)
                vr.innerHTML = val.toFixed(2);
//              else
//                console.log("ERR:  did not find \"vr" + type + "\"\n");

              subCoin += val;

              qr = null;
              vr = null;

            }

            cc = null;
          }
        }

        vr = document.getElementById("rollsSubTotal");

        if(vr != null)
          vr.innerHTML = subCoin.toFixed(2);
//        else
//          console.log("WARN:  could not find coinsSubTotal\n");

        vr = null;
        qr = null;
        type = null;
        qty = null;
        batch = null;
        val = null;
        coin = null;
        xx = null;

        if(completion_callback)
          completion_callback();
      })
  .catch(
      function(err)
      {
        console.log("Error detected in getCount_R()");
        console.error(err);
      });
}

async function getCount_N(completion_callback = null) // coin subtotal qc and vc
{
  var myRequest = new Request("/glue/count_notes.php");

  fetch(myRequest)
  .then(
      function(response)
      {
        myRequest = null;

        if (!response.ok)
        {
          console.log("count_notes", response.status); // debug only (TODO: remove?)
        }

        return  response.text();
      })
  .then(
      function(text)
      {
              // xx will be a DOM Parser type of object from which to parse XML
        var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
        var note = xx.getElementsByTagName("note");
        var type, qty, val;
        var qn, vn;
        var subNotes=0.0;

        if(note != null)
        {
          for (var i1 = 0; i1 < note.length; i1++)
          {
            var cc = note[i1].children;

            if(cc.length > 0)
            {
              for ( var i2 = 0; i2 < cc.length; i2++)
              {
                if(cc[i2].nodeName == "type")
                  type = cc[i2].childNodes[0].nodeValue;

                if(cc[i2].nodeName == "qty")
                  qty = cc[i2].childNodes[0].nodeValue;
              }
//              console.log("  note " + type + "  qty " + qty + "\n");
              val = parseFloat(type) * parseFloat(qty);

              qn=document.getElementById("qn" + type);
              vn=document.getElementById("vn" + type);

              if(qn != null)
                qn.innerHTML = qty;
//              else
//                console.log("ERR:  did not find \"qn" + type + "\"\n");

              if(vn!= null)
                vn.innerHTML = val.toFixed(0);
//              else
//                console.log("ERR:  did not find \"vn" + type + "\"\n");

              subNotes += val;

              qn = null;
              vn = null;

            }

            cc = null;
          }
        }

        vn = document.getElementById("notesSubTotal");

        if(vn != null)
          vn.innerHTML = subNotes.toFixed(2);
//        else
//          console.log("WARN:  could not find coinsSubTotal\n");

        vn = null;
        qn = null;
        type = null;
        qty = null;
        val = null;
        coin = null;
        xx = null;

        if(completion_callback)
          completion_callback();
      })
  .catch(
      function(err)
      {
        console.log("Error detected in getCount_N()");
        console.error(err);
      });
}

async function getCount_S(completion_callback = null) // coin subtotal qc and vc
{
  var myRequest = new Request("/glue/count_straps.php");

  fetch(myRequest)
  .then(
      function(response)
      {
        myRequest = null;

        if (!response.ok)
        {
          console.log("count_straps", response.status); // debug only (TODO: remove?)
        }

        return  response.text();
      })
  .then(
      function(text)
      {
              // xx will be a DOM Parser type of object from which to parse XML
        var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
        var strap = xx.getElementsByTagName("strap");
        var type, qty, val;
        var qs, vs;
        var subNotes=0.0;

        if(note != null)
        {
          for (var i1 = 0; i1 < note.length; i1++)
          {
            var cc = note[i1].children;

            if(cc.length > 0)
            {
              for ( var i2 = 0; i2 < cc.length; i2++)
              {
                if(cc[i2].nodeName == "type")
                  type = cc[i2].childNodes[0].nodeValue;

                if(cc[i2].nodeName == "qty")
                  qty = cc[i2].childNodes[0].nodeValue;

                // TOdO:  this one has a 'batch' element also... use it?
              }
//              console.log("  strap " + type + "  qty " + qty + "\n");
              val = parseFloat(type) * parseFloat(qty);

              qs=document.getElementById("qn" + type);
              vs=document.getElementById("vn" + type);

              if(qs != null)
                qs.innerHTML = qty;
//              else
//                console.log("ERR:  did not find \"qs" + type + "\"\n");

              if(vs!= null)
                vs.innerHTML = val.toFixed(0);
//              else
//                console.log("ERR:  did not find \"vs" + type + "\"\n");

              subNotes += val;

              qs = null;
              vs = null;

            }

            cc = null;
          }
        }

        vs = document.getElementById("notesSubTotal");

        if(vs != null)
          vs.innerHTML = subNotes.toFixed(2);
//        else
//          console.log("WARN:  could not find coinsSubTotal\n");

        vs = null;
        qs = null;
        type = null;
        qty = null;
        val = null;
        coin = null;
        xx = null;

        if(completion_callback)
          completion_callback();
      })
  .catch(
      function(err)
      {
        console.log("Error detected in getCount_S()");
        console.error(err);
      });
}


// TODO: investigate a php-way of making this happen, better, with embedded content
//       particularly for the summary pages, which won't need live update

function DoAllCoinsTotal()
{
  var subTotalC, subTotalR, grandTotal, val=0.0;

  subTotalC = document.getElementById("coinsSubTotal");
  subTotalR = document.getElementById("rollsSubTotal");
  grandTotal = document.getElementById("allCoinsSubTotal");

  if(subTotalC)
    val += parseFloat(subTotalC.innerHTML);

  if(subTotalR)
    val += parseFloat(subTotalR.innerHTML);

  if(grandTotal)
    grandTotal.innerHTML = val.toFixed(2);

  subTotalC = null;
  subTotalR = null;
  grandTotal = null;
}

function DoGrandTotal()
{
  var subTotalC, subTotalN, subTotalS, grandTotal, val=0.0;

  DoAllCoinsTotal();

  subTotalC = document.getElementById("allCoinsSubTotal");
  subTotalN = document.getElementById("notesSubTotal");
  subTotalS = document.getElementById("strapsSubTotal");
  grandTotal = document.getElementById("page-total");

  if(subTotalC)
    val += parseFloat(subTotalC.innerHTML);

  if(subTotalN)
    val += parseFloat(subTotalN.innerHTML);

  if(subTotalS)
    val += parseFloat(subTotalS.innerHTML);

  subTotalC = null;
  subTotalN = null;
  subTotalS = null;
  grandTotal = null;
}

function DoNoteResultsUpdate() // do this periodically
{
  var subTotal, grandTotal, val=0.0;

  getCount_N(
    function()
    {
      subTotal = document.getElementById("notesSubTotal");
      grandTotal = document.getElementById("page-total");

      if(grandTotal != null)
      {
        if(subTotal != null)
        {
          val = parseFloat(subTotal.innerHTML);
        }

        grandTotal.value = "$ " + currency_form(val);
      }

      val = null;
      grandTotal = null;
      subTotal = null;
    });
}

async function DoCoinResultsUpdate() // do this periodically
{
  var subTotal, grandTotal, val=0.0;

  getCount_C(
    function()
    {
      subTotal = document.getElementById("coinsSubTotal");
      grandTotal = document.getElementById("page-total");

      if(grandTotal != null)
      {
        if(subTotal != null)
        {
          val = parseFloat(subTotal.innerHTML);
        }

        grandTotal.value = "$ " + currency_form(val);
      }

      val = null;
      grandTotal = null;
      subTotal = null;
    });
}

// call these next 3 functions once time on the appropriate page
// using:   $(document).ready(DoXXXXResults());

function DoCoinResults() // on-load function for coin results pages
{
  setInterval(DoCoinResultsUpdate, 777); // 777 msecs; does not coincide with others
}

function DoNoteResults() // on-load function for note results pages
{
  setInterval(DoNoteResultsUpdate, 444); // 444 msecs; does not coincide with others
}

function DoSummaryPageTotal() // do this one time on entry
{
  // new method does this asynchronously as 'completion' lambda functions
  // each is executed at the end of the function to which it is passed as a 'completion function'
  // that way A finishes, then does B, which does C, etc.

  getCount_C(
    function() // note:  this will be called asynchronously when the count has been obtained
    {
      getCount_R(
        function()
        {
          DoAllCoinsTotal(); // this may not be needed, but it was there before

          getCount_N(
            function()
            {
              getCountS(
                function()
                {
                  DoGrandTotal();
                });
            });
        });
    });
}


