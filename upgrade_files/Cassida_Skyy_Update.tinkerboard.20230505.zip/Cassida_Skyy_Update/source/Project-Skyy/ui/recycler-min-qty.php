<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "glue/common_utils.php";

  $auto = do_getvar("auto","");
  $back = do_getvar("back","/");

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');

  $Equipment = coin_counter_equipment(0);

  if(!coin_counter_is_recycler($Equipment))
  {
?>
      <HTML>
        <HEAD>
          <TITLE>re-direct</TITLE>
          <meta http-equiv="refresh" content="15;url=<?php
                if(strlen($auto) > 0) print $auto; else print $back; ?>">
<?php set_inbetween_style(); ?>
        </HEAD>
        <BODY>
          <br>
          <center>
            <H1>
              Internal Error
            </H1>
            <br>
            <br>
            <span style="font-size:1.7rem">
              This page only supports a<br>recycler that pays out <?php print $Coins; ?>
            </span>
          </center>
        </BODY>
      </HTML>
<?php
    exit;
  }

  $thingy = skyyreq("min-coin-quantity");
  eval($thingy);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title><?php print coin_counter_equipment();?> Min <?php print make_singular($Coins); ?> Levels</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
    </style>

    <script>
      // global state
      var column = "1", output="c1";
      var first = true;

      function DoSubmit()
      {
        document.getElementById("c1").disabled = false;
        document.getElementById("c5").disabled = false;
        document.getElementById("c10").disabled = false;
        document.getElementById("c25").disabled = false;
        document.getElementById("submitStraps").submit();
      }

      function DoClick(key) // keypad click number key
      {
        var ww = document.getElementById(output);
        var strText = ww.value;

        console.log(output + ' ' + ww.id + ' ' + ww.value + ' ' + key);

        if(first)
        {
          console.log("first is true");

          first = false;
          strText = ""; // make sure I clear it on the first keystroke
        }
        else
        {
          console.log("first is false");
        }

        ww.value = strText * 10 + Math.floor(key);

        DoCalcTotal();
      }

      function DoClickClr() // keyboard click clear
      {
        document.getElementById(output).value = '0';
        DoFixTotal();
      }

      function DoClickEntor() // keyboard click 'entor' which is like 'enter' but more epic
      {
        console.log('Entor');
        NextColumn();
      }
    </script>

  </head>
<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">Min <?php print make_singular($Coins); ?> Levels
        <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
             src="img/coins.svg">
      </a>
      <div class="area" style="font-size:0.83rem">PAYOUT</div>
    </div>
  </nav>
  <div class="container center">
    <div class="row button-row selector-buttons">
      <div class="selector-button" id="b1">
        <a id="ba1" href="#" class="multi-click btn btn-shadow waves-effect primary-fill secondary-fill selected-button">1 ¢ </a>
      </div>
      <div class="selector-button" id="b5">
        <a id="ba5" href="#" class="multi-click btn btn-shadow waves-effect primary-fill">5 ¢ </a>
      </div>
      <div class="selector-button" id="b10">
        <a id="ba10" href="#" class="multi-click btn btn-shadow waves-effect primary-fill">10 ¢ </a>
      </div>
      <div class="selector-button" id="b25">
        <a id="ba25" href="#" class="multi-click btn btn-shadow waves-effect primary-fill">25 ¢ </a>
      </div>
    </div>
  </div>

  <div id="quantity" class="center">
    <form name="submitBatch" id="submitBatch" method="POST">
      <div class="row button-row">
        <div class="input-selector" id="a1">
          <label style="min-width:0.7rem">#</label><div class="mdl-textfield denom">
          <input name="c1" id="c1" class="mdl-textfield__input special-text-input tweek-inactive" type="text"
           value=<?php print '"' . $min_pennies . '"'; ?>
           maxlength="5" disabled /></div>
        </div>
        <div class="input-selector" id="a2">
          <label style="min-width:0.7rem">#</label><div class="mdl-textfield denom">
          <input name="c5" id="c5" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
           value=<?php print '"' . $min_nickels . '"'; ?>
           maxlength="5" disabled /></div>
        </div>
        <div class="input-selector" id="a3">
          <label style="min-width:0.7rem">#</label><div class="mdl-textfield">
          <input name="c10" id="c10" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
           value=<?php print '"' . $min_dimes . '"'; ?>
           maxlength="5" disabled /></div>
        </div>
        <div class="input-selector" id="a4">
          <label style="min-width:0.7rem">$</label><div class="mdl-textfield">
          <input name="c25" id="c25" class="mdl-textfield__input special-text-input tweek-inactive inactive" type="text"
           value=<?php print '"' . $min_quarters . '"'; ?>
           maxlength="5" disabled /></div>
        </div>
      </div>
<?php
  if($auto == 'Y') // auto mode includes a 'next' variable that indicates where to re-direct to after setting batch
  {
?>
    <input type=hidden name=next value="/" style="visibility:hidden" />
<?php
  }
  else if(strlen($back) > 0) // NOT auto mode, so just pass this along as-is as 'next'
  {
?>
    <input type=hidden name=next value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
  </div>

  <div class="row">
    <div class=" calc-card mdl-card mdl-shadow--2dp">
      <div class="buttons" id="wrapper">
        <button onClick="DoClick('7');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">7</button>
        <button onClick="DoClick('8');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">8</button>
        <button onClick="DoClick('9');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">9</button>
        <button onClick="DoClickClr();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent">
          <span style="display:none">backspace</span>
          <img src="img/baseline-backspace-24px.svg" style="color:white">
        </button>

        <button onClick="DoClick('4');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">4</button>
        <button onClick="DoClick('5');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">5</button>
        <button onClick="DoClick('6');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">6</button>
        <button class="mdl-button">&nbsp;</button>

        <button onClick="DoClick('1');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">1</button>
        <button onClick="DoClick('2');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">2</button>
        <button onClick="DoClick('3');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">3</button>
        <button onClick="DoClickEntor();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent tall"
                style="line-height:1em;height:">
          E<br/>n<br/>t<br/>e<br/>r
        </button>

        <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide">0</button>
      </div>
    </div>
  </div>

  <form id="none" method=GET></form>
  <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:24px;left:12px;">
    <button formaction=<?php print '"' . $back . '"'; ?>
            form="none" class="btn waves-effect primary-fill btn-shadow">Exit</button>
  </div>

  <script>

    function MyRemoveClassW(ww, removal)
    {
      if(ww != null)
        ww.classList.remove(removal);
    }

    function MyRemoveClass(classname, removal)
    {
      var ii, ww = document.getElementsByClassName(classname);

      if(ww != null)
      {
        for(ii=0; ii < ww.length; ii++)
        {
          MyRemoveClassW(ww[ii], removal);
        }
      }
      ii = null;
      ww = null;
    }

    function MyAddClass(classname, addit)
    {
      var ii, ww = document.getElementsByClassName(classname);

      if(ww != null)
      {
        for(ii=0; ii < ww.length; ii++)
        {
          ww[ii].classList.add(addit);
        }
      }
      ii = null;
      ww = null;
    }

    function DoClickSelector(evt) /* adapted from poorly written JQuery code, basic functionality retained for now */
    {
      var ww = evt.currentTarget;

      if(ww != null)
      {
        column = ww.id.substr(1); // column ID matches that of denom
        OnChangeColumn();
      }
    }

    function NextColumn()
    {
      console.log('column was ' + column);

      if(column == 1)
        column = 5;
      else if(column == 5)
        column = 10;
      else if(column == 10)
        column = 25;
      else if(column == 25) // do not wrap
      {
        DoFixTotal();
        return;
      }
      else
        column = 1;

      OnChangeColumn();
    }

    function OnChangeColumn()
    {
      console.log('column is now ' + column);

      // this is how the other one worked, so retaining basic functionality and method
      MyRemoveClass("btn", 'selected-button');
      MyRemoveClass("btn", 'secondary-fill');
      MyAddClass("btn", 'primary-fill');
      MyAddClass("tweek-inactive", 'inactive');

      MyAddClass("input", 'inactive');

      output = 'c' + column;

      console.log(output);
      MyRemoveClassW(document.getElementById(output), 'inactive');

      document.getElementById("ba" + column).classList.add('selected-button');
      document.getElementById("ba" + column).classList.add('secondary-fill');

      first = true; // new behavior
//      document.getElementById(output).value = '0';

      DoFixTotal();
    }

    // iterate through each td based on class and add the values

    function DoFixTotal ()
    {
      DoCalcTotal(true);
    }

    function DoCalcTotal(fix_it = false)
    {
      var tval, c1, c5, c10, c25;

      // this function is intended to be called whenever you hit 'enter'
      // and it will fix the totals so they're "even"

      c1 = Math.floor(document.getElementById("c1").value);
      c5 = Math.floor(document.getElementById("c5").value);
      c10 = Math.floor(document.getElementById("c10").value);
      c25 = Math.floor(document.getElementById("c25").value);

//      document.getElementById("next").disabled = false;
    }

    function doEnableInputs()
    {
      document.getElementById("c1").disabled = false;
      document.getElementById("c5").disabled = false;
      document.getElementById("c10").disabled = false;
      document.getElementById("c25").disabled = false;
    }


    // selector button needs click event listener
    {
      var ii, ww = document.getElementsByClassName("selector-button");
      if(ww != null)
      {
        for(ii=0; ii < ww.length; ii++)
        {
          ww[ii].addEventListener('click', DoClickSelector, false);
        }
      }
      ii = null;
      ww = null;
    }

    </script>


    <div class="next-button">
      <button form="submitBatch" onClick="doEnableInputs();" type="submit"
              formaction="/glue/set-min-coin-amounts.php"
              id="set_c400"
              class="btn waves-effect primary-fill btn-shadow">
<?php
  if($auto != 'Y')
  {
    print "      Done";
  }
  else
  {
    print "      Save";
  }
?>
      </button>
    </div>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>

