<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  // grab entity information among other things...
  // TODO rather than 'class=' param, get it from skyy

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  // find out the entity name, and the 'origin' parameter (if assigned)
  // these are assigned via 'GET' parameters in the URL

  $Origin = empty($_GET) || empty($_GET["origin"]) ? "" : $_GET["origin"];
  if(strlen($Origin) > 0 && substr($Origin,0,1) != "/")
    $Origin = "/" . $Origin;

  $complete = empty($_GET) || empty($_GET["complete"]) ? "" : $_GET["complete"];

  if($complete == "Y")
  {
    if(!empty($_GET))
    {
      $ChangeOrder = empty($_GET["theNumber"]) ? 0 : $_GET["theNumber"];
      $result = skyyreq("change-order/" . $ChangeOrder);
//      print $result;
//      exit;
    }

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /glue/next-step-count-class.php");
    header("Expires: 0");

    exit;
  }

  $Entity="";
  $EntityNum = 0;
  $Solution = skyyreq("count-entity");
  eval($Solution);

  // one more time to get 'step' info
  $Solution = skyyreq("count-entity-step");
  eval($Solution);

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title><?php print strtoupper($Entity); ?> Change Order</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
      table, th, td, tdata, tr
      {
        border: 0px;
        padding: 0;
      }
<?php
  $CalcCardOverride="";
  $CalcButtonOverride="";
  $MDLCardOverride="";
  $MDLButtonAccentOverride="";
?>
    </style>

    <script>
      var output = "amount";

      function DoClick(key) // keypad click number key
      {
        var ww = document.getElementById(output);
        var strText = ww.value;

        console.log(output + ' ' + ww.id + ' ' + ww.value + ' ' + key);

        if(ww.id == "rv1")
        {
          var vv = Math.floor(strText * 10);

          console.log(vv);

          vv = (vv * 10 + Math.floor(key)) / 10;

          console.log(vv);

          ww.value = vv.toFixed(2);
        }
        else
        {
          ww.value = ww.value * 10 + Math.floor(key);
        }
      }

      function DoClickClr() // keyboard click clear
      {
        document.getElementById(output).value = '0';
      }

      function DoClickEntor() // keyboard click 'entor' which is like 'enter' but more epic
      {
        console.log('Entor');
      }

    </script>

  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar"> <!-- style="visibility:visible !important;display:inline-block !important" -->
          Change Order
          <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
               src="/img/straps.svg" style="margin:0;padding:0;border:0;">
        </a>
        <div class="area" style="font-size:0.83rempx">
          <?php print strtoupper($Entity); ?>
        </div>
      </div>
    </nav>

  <form name="skip" id="skip"
        action="/change-order.php"
        method="GET">
    <input type="hidden" name="complete" value="Y" style="visibility:hidden" />
  </form>
  <form name="submitTheNumber" id="submitTheNumber"
        action="/change-order.php"
        method="GET">
    <input  type="hidden" name="complete" value="Y" style="visibility:hidden" />
    <input  type="hidden" id="theNumber" name="theNumber" value="0" style="visibility:hidden" />
      <table width="100%" style="padding:0;margin:0;line-height:1.2rem">
        <tr style="padding:0;margin:0;line-height:1.2rem;max-height:1.4rem">
          <td width=30%>&nbsp;</td>
          <td width=35%>
            <div class="row button-row">
              <div class="input-selector" id="a1">
                <label>Change Order $</label>
                <div class="mdl-textfield denom">
                  <input name="amount" id="amount"
                         class="mdl-textfield__input special-text-input"
                         type="text" value="" maxlength="6" disabled />
                </div>
              </div>
            </div>
          </td>
          <td width=35%>
            <div id="value-warn" style="display:none;font-size:20px">Must be greater or equal to 0
            </div>
          </td>
        </tr>
      </table>
    </form>

    <div id="quantity" class="center">
      <div class="row">
        <div id="registers-calc" class=" calc-card <?php print $CalcCardOverride; ?> mdl-card <?php print $MDLCardOverride; ?> mdl-shadow--2dp">
        <div class="buttons" id="wrapper">
          <button onClick="DoClick('7');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">7</button>
          <button onClick="DoClick('8');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">8</button>
          <button onClick="DoClick('9');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">9</button>
          <button onClick="DoClickClr();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent">
            <span style="display:none">backspace</span>
            <img src="img/baseline-backspace-24px.svg" style="color:white">
          </button>

          <button onClick="DoClick('4');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">4</button>
          <button onClick="DoClick('5');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">5</button>
          <button onClick="DoClick('6');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">6</button>
          <button class="mdl-button">&nbsp;</button>

          <button onClick="DoClick('1');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">1</button>
          <button onClick="DoClick('2');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">2</button>
          <button onClick="DoClick('3');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">3</button>
          <button onClick="DoClickEntor();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent tall"
                  style="line-height:1em;height:">
            E<br/>n<br/>t<br/>e<br/>r
          </button>

<?php
  if($CustomerMod != 2) // NOT Academy
  {
?>
          <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide">0</button>
<?php
  }
  else // Academy
  {
?>
          <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide3">0</button>
          <button onClick="DoClick('0');DoClick('0');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">00</button>
<?php
  }
?>
        </div>
      </div>
    </div>
    <form id=none method="GET"></form>
    <div class="next-button">
      <button form="skip" class="waves-effect btn-flat primary-text">Skip</button>
      <button name="next" id="next" form="submitTheNumber" type="button" onclick="OnClickNext();" class="btn waves-effect primary-fill btn-shadow" disabled>NEXT &gt;</button>
    </div>
  </div>

    <!--  Scripts-->
    <script>
    //-- Set Defaults  --//
      var nDisplayed = 10;

      function setTotal ()
      {
        // does nothing, presence required by some of the previously written scripts
      }

      function OnClickNext()
      {
        var x = document.getElementById("amount").value;
        if (x == "" || x < 0)
        {
          if(nDisplayed < 10)
          {
            document.getElementById("value-warn").style = "font-size:20px";
            nDisplayed += 1;
          }
          else
          {
            document.getElementById("value-warn").style = "display:none;font-size:20px";
          }
        }

        document.getElementById("theNumber").value = x; // assign here
        document.getElementById("amount").disabled = false; // needs to be enabled
        document.forms["submitTheNumber"].submit();
      }

      function DoCheckValidNumber()
      {
        var x = document.getElementById("amount").value;
        if (x == "" || x < 0)
        {
          document.getElementById("next").disabled = true;
          if(nDisplayed < 10)
          {
            document.getElementById("value-warn").style = "font-size:20px";
            nDisplayed += 1;
          }
          else
          {
            document.getElementById("value-warn").style = "display:none;font-size:20px";
          }
        }
        else
        {
          document.getElementById("next").disabled = false;
          nDisplayed = 0;
          document.getElementById("value-warn").style = "display:none;font-size:20px";
        }
      }

      setInterval(DoCheckValidNumber, 200);

    </script>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>

