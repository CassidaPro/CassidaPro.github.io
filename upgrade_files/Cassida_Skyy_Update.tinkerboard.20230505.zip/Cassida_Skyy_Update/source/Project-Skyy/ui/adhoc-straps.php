<?php
/*          Copyright 2019-2020 by Cassida          */
/* Use only in accordance with the supplied license */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Straps = do_getconf($parseconf,"terms",'Straps','Straps');

  $Equipment = coin_counter_equipment();
  $IsSRB = coin_counter_is_recycler($Equipment);

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Ad Hoc <?php print $Straps; ?></title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- CSS  -->

    <style>
<?php
  set_ideal_font_height();
?>
      .message-thing
      {
        color:#000000;/*#585858 works for bold font*/
        font-size:1.15rem /*28px*/;
        font-weight:500; /* normal - 700 is bold */
        position:absolute;
        padding-left: 10px;
        padding-top: 0px;
        padding-bottom: 0px;
        min-height: 2.67rem /* 64px*/;
        max-height: 3.5rem;
        bottom: 1rem /*24px*/; /* this page needs it at 24px, not 48px */
        width: 18.3rem /*440px*/;
        left:12px;
        line-height:120%;
        vertical-align:bottom;
        text-align:left;
      }
    </style>
  </head>
<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">Make <?php print $Straps; ?> <img src="img/count-notes.svg"></a>
      <div id="entity" class="area"><?php print make_singular(strtoupper($Notes)); ?> <?php print make_singular(strtoupper($Straps)); ?></div>
    </div>
  </nav>

  <div class="container">
    <div class="section">
      <div class="row center">
        <img src="<?php if($IsSRB) print "/img/srb-system-count-zeus.png"; else print "/img/zeus.svg"; ?>"
             id="load-zeus"
             width=<?php print round(cached_font_size() * 440 / 24); ?>px
             height=<?php print round(cached_font_size() * 325 / 24); ?>px>
      </div>
    </div>
    <div>
      <div id="zeus-message" class="message-thing">
      </div>
      <div class="next-button">
        <form method="GET">
          <button id=done
                  formaction="/glue/complete-adhoc-straps.php"
                  class="waves-effect btn-flat primary-text">
            SKIP
          </button>
        </form>
      </div>
    </div>
  </div>

  <script>
    var intervalID;
//    var nNextTime = Date.now();

    function getZeusStatus()
    {
      var myRequest = new Request("/glue/status-zeus.php");

      fetch(myRequest)
        .then(function(response)
              {
                myRequest = null;

                if (!response.ok)
                {
                  console.log("status-zeus", response.status);
                }

                return  response.text();
              })
        .then(function(text)
              {
                var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                var tt = xx.getElementsByTagName("tick");
                var ee = xx.getElementsByTagName("entity");

                if(tt == null || tt[0] == null || tt[0].childNodes == null || tt[0].childNodes[0] == null ||
                   ee == null || ee[0] == null || ee[0].childNodes == null || ee[0].childNodes[0] == null)
                {
                  document.getElementById("zeus-message").innerHTML = "Server not responding";
                  if(intervalID  != null)
                  {
                    clearInterval(intervalID ); // status codes no longer needed
                    intervalID  = null;
                  }

                  tt = null;
                  ee = null;
                  return;
                }

                var tick = tt[0].childNodes[0].nodeValue;
                var entity = ee[0].childNodes[0].nodeValue;
                var the_date = xx.getElementsByTagName("date")[0];
                var st = xx.getElementsByTagName("status")[0].children;
                var status_code = "";
                var status_text = "";
                var today = "";

                tt = null;
                ee = null;

                if(the_date && the_date.childNodes.length > 0)
                {
                  today = the_date.childNodes[0].nodeValue
                }
                else
                {
                  today = "unknown date";
                }

                for (var i1 = 0; i1 < st.length; i1++)
                {
                  if(st[i1].nodeName == "code")
                    status_code = st[i1].childNodes[0].nodeValue;
                  else if(st[i1].nodeName == "text")
                    status_text = st[i1].childNodes[0].nodeValue;
                }

                // at the first ';' or '.' insert a '<br>'
                status_text = status_text.replace(/;/,";<br>").replace(/\./,".<br>");

                if(status_code=="1")
                {
                  clearInterval(intervalID);

                  window.location.href = 'adhoc-notes-results.php?Strap=1'; // open up results page
                }
                else // if(Date.now() >= nNextTime)
                {
                  if(status_code != 0)
                  {
                    document.getElementById("zeus-message").innerHTML = status_text; // display text
                    // TODO:  for error text, do I muck with colors? see adhoc-notes-results.php
                  }
                  else
                  {
                    document.getElementById("zeus-message").innerHTML = "";
                  }
                }

                xx = null;
                entity = null;
                the_date = null;
                tick = null;
                st = null;
                status_code = null;
                status_text = null;
                today = null;
              })
        .catch(function(error) { console.log(error);  });
    }

    intervalID = setInterval(getZeusStatus, 250);

  </script>

  <script src="/js/UserFeedback.js"></script>

</body>
</html>

