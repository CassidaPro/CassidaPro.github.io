<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>ZC4 - Cleaning</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>

    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Cleaning</a>
        <div class="area">START</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button">
          <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
               src="/img/poweroff.svg" />
        </a>
      </div>
    </nav>
    <div class="container">
      <div class="row center">
        <div class="col s0 light"  style="margin-top:0;margin-left:2.92rem">
          <!--a href="/glue/daily-cleaning-video.php" class="btn btn-ytiny waves-effect primary-fill" width=10%-->
          <a href="/glue/daily-cleaning-video.php" class="btn-flat btn-ytiny waves-effect primary-text" width=10%  style="margin-top:32px">
            <img src="/img/daily.svg"
                 style="width:<?php print round(cached_font_size() * 86 / 24); ?>px;height:<?php print round(cached_font_size() * 77 / 24); ?>px;margin:0;margin-left:-18px;margin-top:-18px;border:0">
          </a><br/>
          <a href="/glue/weekly-cleaning-video.php" class="btn-flat btn-ytiny waves-effect primary-text" width=10%>
            <img src="/img/weekly.svg"
                 style="width:<?php print round(cached_font_size() * 86 / 24); ?>px;height:<?php print round(cached_font_size() * 77 / 24); ?>px;margin:0;margin-left:-18px;margin-top:-18px;border:0">
          </a><br/>
<?php
//  if($CustomerMod != 1)
//  {
?>
          <a href="/glue/monthly-cleaning-video.php" class="btn-flat btn-ytiny waves-effect primary-text" width=10%>
            <img src="/img/monthly.svg"
                 style="width:<?php print round(cached_font_size() * 86 / 24); ?>px;height:<?php print round(cached_font_size() * 77 / 24); ?>px;margin:0;margin-left:-18px;margin-top:-18px;border:0">
          </a>
<?php
//  }
?>
          <!--a href="/glue/cleaning-video.php" class="btn-large waves-effect primary-fill">Watch Video<p><img src="/img/cleaning.svg" width=48 height=48></p></a-->
        </div>
        <div class="col s0 light"  style="margin-top:0;margin-left:2.08rem">
          <!--a href="/glue/daily-cleaning-video.php" class="btn btn-ytiny waves-effect primary-fill" width=10%-->
          <a href="/glue/print-daily-cleaning.php" class="btn-flat btn-ytiny waves-effect primary-text" width=10%  style="margin-top:32px">
            <img src="/img/printer_button.png"
                 style="width:<?php print round(cached_font_size() * 80 / 24); ?>px;height:<?php print round(cached_font_size() * 70 / 24); ?>px;margin:0;margin-left:-16px;margin-top:-18px;border:0">
          </a><br/>
          <a href="/glue/print-weekly-cleaning.php" class="btn-flat btn-ytiny waves-effect primary-text" width=10%>
            <img src="/img/printer_button.png"
                 style="width:<?php print round(cached_font_size() * 80 / 24); ?>px;height:<?php print round(cached_font_size() * 70 / 24); ?>px;margin:0;margin-left:-16px;margin-top:-18px;border:0">
          </a><br/>
<?php
//  if($CustomerMod != 1)
//  {
?>
          <a href="/glue/print-monthly-cleaning.php" class="btn-flat btn-ytiny waves-effect primary-text" width=10%>
            <img src="/img/printer_button.png"
                 style="width:<?php print round(cached_font_size() * 80 / 24); ?>px;height:<?php print round(cached_font_size() * 70 / 24); ?>px;margin:0;margin-left:-16px;margin-top:-18px;border:0">
          </a>
<?php
//  }
?>
          <!--a href="/glue/cleaning-video.php" class="btn-large waves-effect primary-fill">Watch Video<p><img src="/img/cleaning.svg" width=48 height=48></p></a-->
        </div>
        <div class="col s4 light" style="margin:0;padding:0">
          <a href="/daily-cleaning.php" class="btn btn-xmed waves-effect primary-fill" min-width=60%  style="margin-top:32px">
<?php
  if($CustomerMod == 1)
  {
?>
            <img src="/img/cleaning.svg" class="invertible-icon"
                 style="left:10px"><span style="font-size:1.1rem">&nbsp; &nbsp;QUICK CLEAN</span>
<?php
  }
  else
  {
?>
            <img src="/img/cleaning.svg" class="invertible-icon" style="left:10px">&nbsp; &nbsp;DAILY
<?php
  }
?>
          </a><br/>
          <a href="/weekly-cleaning.php" class="btn btn-xmed waves-effect primary-fill" min-width=60%>
            <img src="/img/cleaning.svg" class="invertible-icon" style="left:10px">&nbsp; &nbsp;WEEKLY
          </a><br/>
<?php
//  if($CustomerMod != 1)
//  {
?>
          <a href="/monthly-cleaning.php" class="btn btn-xmed waves-effect primary-fill" min-width=60%>
            <img src="/img/cleaning.svg" class="invertible-icon">&nbsp; &nbsp;MONTHLY
          </a>
<?php
//  }
?>
        </div>
      </div>
    </div>
    <div style="position:absolute;margin:0px;padding:0;bottom:2.67rem;left:0px;width:100%">
      <center>Please review all instructions and videos before cleaning</center>
    </div>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:0.75rem;left:0.5rem;vertical-align:middle">
      <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow" >
        <img src="img/drawer.svg" class="invertible-icon"
             height=<?php print round(cached_font_size() * 1.34); ?>px width=<?php print round(cached_font_size() * 1.34); ?>px
             style="margin-top:0.15rem">
        <img src="img/safe.svg" class="invertible-icon"
             height=<?php print round(cached_font_size() * 1.34); ?>px width=<?php print round(cached_font_size() * 1.34); ?>px
             style="margin-top:0.15rem">
        <img src="img/register.svg" class="invertible-icon"
             height=<?php print round(cached_font_size() * 1.34); ?>px width=<?php print round(cached_font_size() * 1.34); ?>px
             style="margin-top:0.15rem">
        <span style="vertical-align:middle">&nbsp; &nbsp;BACK</span>
      </a><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

