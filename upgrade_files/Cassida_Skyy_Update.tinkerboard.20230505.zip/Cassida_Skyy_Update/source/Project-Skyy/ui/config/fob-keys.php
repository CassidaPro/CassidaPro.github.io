<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/common_utils.php";

//  if(empty($_SESSION["admin"]))
//  {
//    $admin = parse_ini_file($ConfigFileName,
//                            TRUE, // to process sections
//                            INI_SCANNER_NORMAL);
//
//    $_SESSION["admin"] = $admin;
//  }
//  else
//  {
//    $admin=$_SESSION["admin"];
//  }

  $auth = ltrim(rtrim(skyyreq("authenticated")));

  if($auth != "OK")
  {
    $authenticate = do_getvar("authenticate", "");
    if($authenticate == "Y")
    {
      $auth = ltrim(rtrim(skyyreq("fobkey-auth")));
      if($auth != "OK")
      {
?>
        <HTML>
          <HEAD>
            <TITLE>re-direct</TITLE>
            <meta http-equiv="refresh" content="10;url=/">
<?php set_inbetween_style(); ?>
          </HEAD>
          <BODY>
            <center>
              <br><br>
              <H1>Authentication FAILED</H1>
              <H2>Return code:  <?php print $auth; ?></H2>
            </center>
          </BODY>
        </HTML>
<?php
      }
      else
      {
//        header("HTTP/1.0 302 Moved Temporarily");
//        header("Location: /config/fob-keys.php");
?>
        <HTML>
          <HEAD>
            <TITLE>re-direct</TITLE>
            <meta http-equiv="refresh" content="0.5;url=/config/fob-keys.php">
<?php set_inbetween_style(); ?>
          </HEAD>
          <BODY>
            <center>
              <br><br>
              <H1>Authenticated</H1>
            </center>
          </BODY>
        </HTML>
<?php
      }

      exit;
    }
    else
    {
?>
      <HTML>
        <HEAD>
          <TITLE>re-direct</TITLE>
          <meta http-equiv="refresh" content="0.5;url=fob-keys.php?authenticate=Y">
<?php set_inbetween_style(); ?>
        </HEAD>
        <BODY>
          <center>
            <br><br>
            <H1>Please Authenticate</H1>
            <H2>Place Admin FOB key on reader</H2>
          </center>
        </BODY>
      </HTML>
<?php
      exit;
    }
  }

  // see if I'm posting an edit
  $fobkey_mod = do_postvar("fobkey_mod", "");
  $delete = do_postvar("delete", "");
  $authstring = do_postvar("authstring", "");
  if($fobkey_mod == "Y")
  {
    $fobkey = do_postvar("fobkey", "");
    $fobkey_value = do_postvar("fobkey_value", ""); // URL encoded already

    $thingy = ltrim(rtrim(skyyreq("fobkey-mod/" . $fobkey . "/" . $fobkey_value)));
    if($thingy != "OK")
    {
//      print $thingy . "<br>\r\n";
//      print $fobkey . "<br>\r\n";
//      print $fobkey_value . "<br>\r\n";
//      exit;
    }
  }
  else if($delete == "Y")
  {
    $fobkey = do_postvar("fobkey_to_delete", "");

    $thingy = ltrim(rtrim(skyyreq("fobkey-del/" . $fobkey)));
    if($thingy != "OK")
    {
//      print $thingy . "<br>\r\n";
//      print $fobkey . "<br>\r\n";
//      print $fobkey_value . "<br>\r\n";
//      exit;
    }
  }
  else if(strlen($authstring) > 0)
  {
    $fobkey = do_postvar("fobkey", "");
    $fobkey_value = do_postvar("fobkey_value", ""); // URL encoded already

    $thingy = ltrim(rtrim(skyyreq("fobkey-auth-required/" . $authstring)));
    if($thingy != "OK")
    {
//      print $thingy . "<br>\r\n";
//      print $fobkey . "<br>\r\n";
//      print $fobkey_value . "<br>\r\n";
//      exit;
    }
  }

  $parseconf = do_load_parseconf("/var/cache/skyy/fobkey.conf");

  if(empty($parseconf["keys"]))
  {
    $keylist = array(0);
    $nkeys=0;
  }
  else
  {
    $keylist = $parseconf["keys"];
    $nkeys = sizeof($keylist);
  }

  $logging = do_getconf($parseconf, "settings", "transaction_logging", 0);

  $auth_payout = do_getconf($parseconf, "authentication", "payout", 1);
  $auth_count = do_getconf($parseconf, "authentication", "count", 0);

//  print $auth_payout . ", " . $auth_count . "<br>\n";

  $capabilities = array(3);
  $capabilities[0] = "Admin";
  $capabilities[1] = "User";
  $capabilities['N'] = "None";

?>

<!DOCTYPE html5>
<html lang="en">
  <HEAD>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <TITLE>Split Recycler System - FOB keys</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico" />
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }
    </style>

    <script>
      function doClosePlaceFobkey()
      {
        document.getElementById("place_fobkey").style.display = "none";
        document.getElementById("place_fobkey").style.visibility = "hidden";
      }

      function doAddButton()
      {
          document.getElementById("place_fobkey").style.display = "block";
          document.getElementById("place_fobkey").style.visibility = "visible";
          document.getElementById("place_fobkey_text").innerHTML = "Please place FOB key<br>on the FOB reader";

          var myRequest = new Request("/glue/fob_key.php");

          fetch(myRequest)
            .then(function(response)
                  {
                    if (!response.ok)
                    {
                      console.log("fobkey read", response.status); // debug only (TODO: remove?  this is actually an error condition...)
                    }
                    return  response.text();
                  })
            .then(function(text)
                  {
                    var xx, ff, fobkey="";

                    xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                    if(xx != null)
                    {
                      ff = xx.getElementsByTagName("fobkey");

                      if(ff != null)
                      {
                        for (var i1 = 0; i1 < ff.length; i1++)
                        {
                          var cc = ff[i1].children;

                          if(cc != null && cc.length > 0)
                          {
                            for ( var i2 = 0; i2 < cc.length; i2++)
                            {
                              if(cc[i2].nodeName == "key" &&
                                 cc[i2].childNodes &&
                                 cc[i2].childNodes[0])
                              {
                                fobkey = cc[i2].childNodes[0].nodeValue;
                                break;
                              }
                            }
                          }

                          cc = null;
                        }
                      }
                      else
                      {
                        console.log("ff is NULL");
                      }
                    }

                    ff = null;
                    xx = null;

                    doClosePlaceFobkey();

                    var aVessels = new Array();
<?php
                    // transfer 'vessels in PHP to javascript 'aVessels'
                    $maxID = 0;
                    foreach($keylist as $kk => $kval)
                    {
                      print "        /* fill array with PHP extracted values */\r\n";
                      if(!empty($kk) && substr($kk,0,1) >= '0' && substr($kk,0,1) <= '9')
                      {
                        print "        aVessels['" . $kk . "']='" . urldecode($kval) . "';\n";
                      }
                      print "        /* array end */\r\n\r\n";
                    }
?>

                    if(fobkey.length > 0)
                    {
                      if(aVessels[fobkey] != null)
                      {
                        document.getElementById("place_fobkey").style.display = "block";
                        document.getElementById("place_fobkey").style.visibility = "visible";
                        document.getElementById("place_fobkey_text").innerHTML = "The FOB key " + fobkey + "<br>already exists";

                        setTimeout(doClosePlaceFobkey, 5000); // display for 5 seconds
                      }
                      else
                      {
                        document.getElementById("edit_fobkey_title").innerHTML = "Add New FOB Key";
                        document.getElementById("fobkey_id").value = fobkey;
                        document.getElementById("fobkey_id").readOnly = false;
                        document.getElementById("fobkey_name").value = "new";
                        document.getElementById("fobkey_type").value = "1";

                        document.getElementById("edit_fobkey").style.display = "block";
                        document.getElementById("edit_fobkey").style.visibility = "visible";
                      }
                    }

                    aVessels = null;
                    myRequest = null;
                  })
           .catch(function(err)
                  {
                    console.log("Error detected in fobkey read");
                    console.error(err);

                    document.getElementById("place_fobkey").style.display = "none";
                    document.getElementById("place_fobkey").style.visibility = "hidden";

                    aVessels = null;
                    myRequest = null;
                  });

      }

      function doEditButton(strID)
      {
        var aVessels = new Array();
<?php
        // transfer 'vessels in PHP to javascript 'aVessels'
        $maxID = 0;
        foreach($keylist as $kk => $kval)
        {
          print "        /* fill array with PHP extracted values */\r\n";
          if(!empty($kk) && substr($kk,0,1) >= '0' && substr($kk,0,1) <= '9')
          {
            print "        aVessels['" . $kk . "']='" . urldecode($kval) . "';\n";
          }
          print "        /* array end */\r\n\r\n";
        }

?>
        var nn = aVessels[strID].split(':');

        document.getElementById("edit_fobkey_title").innerHTML = "Edit New FOB Key";
        document.getElementById("fobkey_id").value = strID;
        document.getElementById("fobkey_id").readOnly = true;
        document.getElementById("fobkey_name").value = nn[1] != null ? nn[1] : "" ;
        document.getElementById("fobkey_type").value = nn[0] != null ? nn[0] : "1" ;

        document.getElementById("edit_fobkey").style.display = "block";
        document.getElementById("edit_fobkey").style.visibility = "visible";

        nn = null;
        aVessels = null;
      }

      function doClickKB(strID)
      {
        do_vkey_single(strID, null);
      }

      function doCancelEdit()
      {
        document.getElementById("edit_fobkey").style.display = "none";
        document.getElementById("edit_fobkey").style.visibility = "hidden";
      }

      function doSave()
      {
        document.getElementById("edit_fobkey").style.display = "none";
        document.getElementById("edit_fobkey").style.visibility = "hidden";


        document.getElementById("fobkey").value = document.getElementById("fobkey_id").value;
        document.getElementById("fobkey_value").value = document.getElementById("fobkey_type").value + ":"
                                                      + encodeURIComponent(document.getElementById("fobkey_name").value);

        document.getElementById("place_fobkey").style.display = "block";
        document.getElementById("place_fobkey").style.visibility = "visible";
        document.getElementById("place_fobkey_text").innerHTML = "Updating...";

        document.getElementById("main").submit(); // re-submit back to myself
      }

      function doDelButton(strID)
      {
        console.log("DoDelButton(" + strID + ")");
        document.getElementById("fobkey_to_delete").value = strID;

        console.log(document.getElementById("fobkey_to_delete").value);

        document.getElementById("place_fobkey").style.display = "block";
        document.getElementById("place_fobkey").style.visibility = "visible";
        document.getElementById("place_fobkey_text").innerHTML = "Updating...";

        document.getElementById("do_delete").submit(); // re-submit back to myself
      }


      function OnChangeAuth()
      {
        var pp, cc, ll; // payout and count bits

        pp = document.getElementById("auth_payout").checked ? '1' : '0';
        cc = document.getElementById("auth_count").checked ? '1' : '0';
        ll = document.getElementById("logging").checked ? '1' : '0';

        document.getElementById("authstring").value = pp + cc + ll;
//        console.log(pp + cc);

        document.getElementById("place_fobkey").style.display = "block";
        document.getElementById("place_fobkey").style.visibility = "visible";
        document.getElementById("place_fobkey_text").innerHTML = "Updating...";

        document.getElementById("auth_auth").submit();
      }

      function DoClickExit()
      {
        var myRequest = new Request("/glue/deauthenticate.php");
        // will request de-authentication since I was authenticated

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("OnClickNext() print receipt", response.status); // debug only (TODO: remove?  this is actually an error condition...)
                    return "ERROR";
                  }
                  return  response.text();
                })
          .then(function(text)
                {
                  window.location.assign("/"); // always go back to root
                });
      }

    </script>
  </HEAD>
  <BODY>
    <center>
      <H1 style="margin:0px;padding=0px;">
        Split Recycler System - FOB keys
      </H1>
      <form id=blank method=GET></form>
      <form id=main method=POST action="./fob-keys.php">
        <input type=hidden id=fobkey_mod name=fobkey_mod value="Y" style="visibility:none" />
        <input type=hidden id=fobkey name=fobkey value="" style="visibility:none" />
        <input type=hidden id=fobkey_value name=fobkey_value value="" style="visibility:none" />
      </form>
      <form id=auth_auth method=POST action="./fob-keys.php">
        <input id=authstring name=authstring type=hidden value="10" style="visibility:none" />
      </form>
      <form id=do_delete method=POST action="./fob-keys.php">
        <input type=hidden name=delete value="Y" style="visibility:none" />
        <input type=hidden id=fobkey_to_delete name=fobkey_to_delete value="" style="visibility:none" />
      </form>
      <table>
        <tbody>
          <tr style="text-align:left">
            <td>
              <input id=auth_payout name=auth_payout form=auth_auth onChange="OnChangeAuth();" type="checkbox"
                     style="margin:0;padding:0;max-height:0.8rem" <?php if($auth_payout != 0) print "checked"; ?>>
                <span style="margin-left:0;font-size:0.75rem">Require FOB key for payout</span>
              </input>
            </td>
          </tr>
          <tr style="text-align:left">
            <td>
              <input id=auth_count name=auth_count form=auth_auth onChange="OnChangeAuth();" type="checkbox"
                     style="margin:0;padding:0;max-height:0.8rem" <?php if($auth_count != 0) print "checked"; ?>>
                <span style="margin-left:0;font-size:0.75rem">Require FOB key for count</span>
              </input>
            </td>
          </tr>
          <tr style="text-align:left">
            <td>
              <input id=logging name=logging form=auth_auth onChange="OnChangeAuth();" type="checkbox"
                     style="margin:0;padding:0;max-height:0.8rem" <?php if($logging != 0) print "checked"; ?>>
                <span style="margin-left:0;font-size:0.75rem">Enable Transaction Logging</span>
              </input>
            </td>
          </tr>
        </tbody>
      </table>
      <table width=95%>
        <tbody>
          <tr align=center>
            <td align=center>
              <table style="height:11rem;display:inline-block;overflow:auto;">
                <tr>
                  <th style="text-align:left;padding-right:1em;border-right:0.5em;border-bottom:2px solid #f8fff0;font-size:0.87rem">
                    FOB Key
                  </th>
                  <th style="font-size:0.87rem">&nbsp;</th>
                  <th style="text-align:left;padding-right:1em;border-right:0.5em;border-bottom:2px solid #f8fff0;font-size:0.87rem">
                    Capabilities
                  </th>
                  <th style="font-size:0.87rem">&nbsp;</th>
                  <th style="text-align:left;padding-right:1em;border-right:0.5em;border-bottom:2px solid #f8fff0;font-size:0.87rem">
                    User Name
                  </th>
                </tr>
                <tbody>
<?php
    foreach($keylist as $k => $kval)
    {
      $kk = explode(':', $kval . '::');

      // Each key entry will have a button associated with it.  Pressing the
      // button will send the form data to /glue/admin-delkey.php such that the
      // value of 'delkey' will be the key number associated with the button I pressed.
      // This way I will know which button I pressed, and which key to delete.

      print '                  <tr>' . "\r\n";
      print '                    <td style="padding-right:2em;border-right:0.5em;border-bottom:1px solid #f8fff0"><input type=hidden name=' . $k . ' value="' . $k . '"/>' . "\r\n";
      print '                      <span style="font-size:0.75rem">' . $k . "</span>\r\n";
      print '                    </td>' . "\r\n";
      print '                    <td style="font-size:0.87rem">&nbsp;</td>' . "\r\n";
      print '                    <td style="padding-right:2em;border-right:0.5em;border-bottom:1px solid #f8fff0">' . "\r\n";
      print '                      <span style="font-size:0.75rem">' . $capabilities[$kk[0]] . "</span>\r\n";
      print '                    </td>' . "\r\n";
      print '                    <td style="font-size:0.87rem">&nbsp;</td>' . "\r\n";
      print '                    <td style="padding-right:2em;border-right:0.5em;border-bottom:1px solid #f8fff0">' . "\r\n";
      print '                      <span style="font-size:0.75rem">' . urldecode($kk[1]) . "</span>\r\n";
      print '                    </td>' . "\r\n";
      print '                    <td>' . "\r\n";
      print '                      <button name=delkey value=' . $k . ' type=submit onClick="doDelButton(' . "'" . $k . "'" . ');"' . "\r\n";
      print '                              style="border:0;height:32px;width:32px;font-size:12px;margin:0;padding:0" >' . "\r\n";
      print '                        <img src="/img/delete_button.png" style="width:24px;height:24px;margin:0;padding:0">' . "\r\n";
      print '                      </button>' . "\r\n";
      print '                      <button name=delkey value=' . $k . ' type=submit onClick="doEditButton(' . "'"  . $k . "'"  . ');"' . "\r\n";
      print '                              style="border:0;height:32px;width:32px;font-size:12px;margin:0;padding:0" >' . "\r\n";
      print '                        <img src="/img/edit_button.png" style="width:24px;height:24px;margin:0;padding:0">' . "\r\n";
      print '                      </button>' . "\r\n";
      print '                    </td>' . "\r\n";
      print '                  </tr>' . "\r\n";
    }
?>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
    </center>

    <table style="text-align:center;position:absolute;bottom:0.75rem;left:25%;width:50%">
      <tbody>
        <tr>
          <!--td width=33% align=center>
            <button form="main" formaction="fob-keys.php" type=submit >
              Save&nbsp;Changes
            </button>
          </td-->
          <td width=50% align=center>
            <button onclick='doAddButton();'  type=submit >
              Add&nbsp;Key
            </button>
          </td>
          <td width=50% align=center>
            <button type=button onclick="DoClickExit();">
              Exit
            </button>
          </td>
        </tr>
      </tbody>
    </table>



    <!-- add/edit FOB key -->
                <!--a id=_keyboard onClick='doClickKB("fobkey_id");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a-->
    <div id=place_fobkey class="modal-container">
      <div style="background-color:#fef8fc;color:#000000;position:absolute;width:16.67rem;height:4rem;right:8.33rem;top:35%;z-index:90;">
        <center>
          <br>
          <H4 id="place_fobkey_text" style="margin:4px;padding:4px">Please place FOB key<br>on the FOB reader</H4>
        </center>
      </div>
    </div>


    <div id=edit_fobkey class="modal-container">
      <div style="background-color:#fef8fc;color:#000000;position:absolute;width:16.67rem;height:10rem;right:8.33rem;top:4.16rem;z-index:90;">
        <center>
          <H4 id="edit_fobkey_title" style="margin:4px;padding:4px">Add FOB Key</H4>
          <table style="min-width:15rem;height:6rem;display:inline-block;overflow:auto;z-index:99">
            <tr style="font-size:0.75rem;line-height:1.3em;vertical-align:middle">
              <td style="vertical-align:middle;text-align:right;color:#000000">
                <span style="font-size:0.83rem">FOB Key:&nbsp;&nbsp;</span>
              </td>
              <td style="font-size:0.83rem">&nbsp;&nbsp;</td>
              <td style="vertical-align:middle;text-align:left;color:#000000">
                <input type=text size=12 id=fobkey_id value="" style="font-size:0.75rem;line-height:1.3em;vertical-align:middle;max-width:9em" />
              </td>
            </tr>
            <tr style="font-size:0.75rem;line-height:1.3em;vertical-align:middle">
              <td style="vertical-align:middle;text-align:right;color:#000000">
                <span style="font-size:0.83rem">User Name:&nbsp;&nbsp;</span>
              </td>
              <td>&nbsp;&nbsp;</td>
              <td style="vertical-align:middle;text-align:left;color:#000000">
                <input type=text id="fobkey_name" size=14 value="" style="font-size:0.75rem;line-height:1.3em;vertical-align:middle;"/>
                <a onClick='doClickKB("fobkey_name");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
            <tr style="font-size:0.75rem;line-height:1.3em;vertical-align:middle">
              <td style="text-align:right;color:#000000">
                <span style="font-size:0.83rem">Key Type:&nbsp;&nbsp;</span>
              </td>
              <td>&nbsp;&nbsp;</td>
              <td style="color:#000000">
                <select id=fobkey_type style="font-size:0.83rem;padding-left:4;padding-right:4">
                  <option value="0" >Admin</option>
                  <option value="1" >User</option>
                  <option value="N" >None</option>
                </select>
              </td>
            </tr>
          </table>
        </center>
        <input type=submit onClick='doCancelEdit()'; value="Cancel" style="position:absolute;width:4.16rem;left:2.08rem;"/>
        <input type=submit onClick='doSave()'; value="Save" style="position:absolute;width:4.16rem;right:50px;"/>
      </div>
    </div>


<?php

  include "../glue/virtual_keyboard.php";

?>

  </BODY>
</HTML>

