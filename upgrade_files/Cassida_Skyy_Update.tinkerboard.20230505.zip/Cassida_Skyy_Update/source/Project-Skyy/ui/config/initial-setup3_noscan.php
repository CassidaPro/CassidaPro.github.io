<?php

    header("HTTP/1.0 302 Moved Temporarily");

    header("Location: /config/initial-setup3.php?NoScan=Y");

?>

