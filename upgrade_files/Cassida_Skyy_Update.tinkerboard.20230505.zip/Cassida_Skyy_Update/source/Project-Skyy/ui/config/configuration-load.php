<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/config_utils.php";

  $parseconf = load_parseconf();

  $Submit=do_getvar("Submit", "");

  $LoadFromDrive = do_getvar("LoadFromDrive", "");
  $StoreID = do_getvar("StoreID", "");
  $LoadFrom = do_getvar("LoadFrom", "");
  $doohickey = do_getvar("doohickey", "");

  if(strlen($LoadFrom) > 0)
  {
    ///////////////////////////
    // LOAD CONFIGURATION FILE
    ///////////////////////////

    // need to sanitize this

    $yy = strpos($LoadFrom, "\\");  // is there one?
    if($yy === false)
      $yy = strpos($LoadFrom, "/.");  // is there one?
    if($yy === false)
      $yy = strpos($LoadFrom, "*");  // is there one?
    if($yy === false)
      $yy = strpos($LoadFrom, "?");  // is there one?
    if($yy === false)
      $yy = strpos($LoadFrom, "'");  // is there one?
    if($yy === false)
      $yy = strpos($LoadFrom, '"');  // is there one?
    if($yy === false)
      $yy = strpos($LoadFrom, "`");  // is there one?


    if($yy !== false ||
       substr($LoadFromDrive, 0, 10) != "/media/pi/" ||
       !strlen($LoadFromDrive) ||
       substr($LoadFrom, 0, strlen($LoadFromDrive)) != $LoadFromDrive ||
       strlen($LoadFrom) < strlen($LoadFromDrive) + 16 ||
       substr($LoadFrom, strlen($LoadFromDrive), 14) != "/configuration")
    {
      header("HTTP/1.0 500 Server Error");
?>
      <HTML>
        <HEAD>
          <TITLE>Server Error</TITLE>
          <meta http-equiv="refresh" content="10;url=/maintenance.php">
          <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
          <link rel="shortcut icon" href="../img/favicon.ico">
          <style>
<?php
  set_ideal_font_height();
?>
          </style>
        </HEAD>
        <BODY>
          <H1><center>SERVER ERROR</center></H1>
          <br><br><br>
          <H3><center>unable to perform desired action. RESET in 10 seconds...</center></H3>
          <br>
        </BODY>
      </HTML>
<?php
      exit;
    }

    // for now just make a copy of it.  also put source file in single quotes
    shell_exec("sudo -u pi /bin/cp '" . $LoadFrom . "' /var/cache/skyy/configuration.conf");
    // TODO:  check permissions, ownership, group?
    // see /etc/sudoers.d/997_wifi where permissions for doing this exist
    shell_exec("sudo -u pi -g www-data /bin/chown pi:www-data /var/cache/skyy/configuration.conf");
    shell_exec("sudo -u pi /bin/chmod 664 /var/cache/skyy/configuration.conf");

    shell_exec("curl http://localhost:3042/reload"); // perform a reset - this will reload everything

    shell_exec("sync");

    // unmount the drive, now.
    shell_exec("sudo /usr/bin/eject '" . $LoadFromDrive . "'");

//    header("HTTP/1.0 302 Moved Temporarily");
//    header("Location: /config/");
?>
    <HTML>
      <HEAD>
        <TITLE>Load Configuration Info</TITLE>
        <meta http-equiv="refresh" content="3;url=/maintenance.php">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Load Configuration Info</center></H1>
        <br><br><br>
        <H3><center>Load complete - you may remove the USB Drive</center></H3>
        <br>
      </BODY>
    </HTML>
<?php
    exit;
  }

  ///////////////////////////////
  // SELECT DRIVE OR CONFIG FILE
  ///////////////////////////////

  // NOTE:  need to run this at least once to stop popup dialog box on inserting a drive
  // (NO) gsettings set org.gnome.desktop.media-handling automount-open false
  //
  // edit /home/pi/.config/pcmanfm/LXDE-pi/pcmanfm.conf change 'autorun=1 to 'autorun=0'

  // step 1:  find out if there are mounted volumes.  if thre aren't, have the user insert a drive
  // and press the button [which will refresh this page]

  if(strlen($LoadFromDrive) == 0) // select drives
  {
    ////////////////////////
    // SELECTING A USB DRIVE
    ////////////////////////

    $Result = shell_exec("/bin/grep /dev/sd </proc/mounts | awk '{ print " . '$2' . "; }'");

    $aList = [];
    $aList0 = explode("\n", ltrim(rtrim($Result)));

    // NOTE:  /proc/mounts can convert chars into 4 char octal sequences, like '\040' for a space
    //        which is necessary to make columns work properly.  So this code will "fix it"
    foreach($aList0 as $jj => $xx)
    {
      $xxx = $xx;
      $newval = "";
      // look for '\040' and other escapes, convert back to normal ASCII
      while(true)
      {
        $yy = strpos($xxx, "\\");  // is there one?
        if($yy === false)
        {
          $newval = $newval . $xxx;
          break;
        }

  //      print "yy=" . $yy . '  xxx="' . $xxx . '"  ' . octdec(substr($xxx,1,4)) . "<br>\n";

        if($yy > 0)
          $newval = $newval . substr($xxx, 0, $yy); // up to but not including the backslash

        $xxx = substr($xxx, $yy, strlen($xxx));

        $newval = $newval . chr(octdec(substr($xxx, 1, 4)));

        $xxx = substr($xxx, 4, strlen($xxx));
      }

      $aList0[$jj] = $newval; // replace it
    }

    // look for 'configuration.conf' on the drive
    $aList = [];
    if(!empty($aList0))
    {
      $command = "";
      $ii=0;

      foreach($aList0 as $xx)
      {
        // This just looks for ANY of them having a configuration*.conf file
        if(strlen($xx) > 0)
        {
          $command = "sudo -u pi /bin/ls -x '" . $xx . "/'";

          $Result = shell_exec($command . " | grep configuration");
          $aList1 = explode("\n", ltrim(rtrim($Result)));

          if(!empty($aList1) && !empty($aList1[0])) // this one has a configurations
          {
            $aList[$ii] = $xx;
            $ii++;
          }

          $aList1 = null;
        }
      }
    }

    if(empty($aList)) // none have configurations
    {
?>
      <HTML>
        <HEAD>
          <TITLE>Load Configuration Info</TITLE>
          <meta http-equiv="refresh" content="2;url=/config/configuration-load.php">
          <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
          <link rel="shortcut icon" href="../img/favicon.ico">
          <style>
<?php
  set_ideal_font_height();
?>
          </style>
        </HEAD>
        <BODY>
          <H1><center>Load Configuration Info</center></H1>
          <br><br><br>
          <H3><center>Insert USB drive containing a configuration</center></H3>
          <br>
          <br>
          <form action="./" method=GET>
            <center>
              <input type=submit value="Cancel" />
            </center>
          </form,>
        </BODY>
      </HTML>
<?php
      exit;
    }
  }
  else if($doohickey != "Y")
  {
?>
    <HTML>
      <HEAD>
        <TITLE>Load Configuration File List</TITLE>
        <meta http-equiv="refresh" content=
          <?php print '"0.2;url=/config/configuration-load.php?';
                if(strlen($StoreID) > 0) print "StoreID=" . urlencode($StoreID) . "&";
                print "LoadFromDrive=" . urlencode($LoadFromDrive) . '&doohickey=Y"'; ?> >
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <br>
        <br>
        <br>
        <H1><center>Loading Configuration File List</center></H1>
        <br>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else // select one of the config files rather than drives
  {
    //////////////////////////////////
    // SELECTING A CONFIGURATION FILE
    //////////////////////////////////

    $yy = strpos($LoadFromDrive, "\\");  // is there one?
    if($yy === false)
      $yy = strpos($LoadFromDrive, "/.");  // is there one?

    // simple sanitization
    if($yy !== false)
    {
      header("HTTP/1.0 500 Server Error");
?>
      <HTML>
        <HEAD>
          <TITLE>Server Error</TITLE>
          <meta http-equiv="refresh" content="10;url=/maintenance.php">
          <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
          <link rel="shortcut icon" href="../img/favicon.ico">
          <style>
<?php
  set_ideal_font_height();
?>
          </style>
        </HEAD>
        <BODY>
          <H1><center>SERVER ERROR</center></H1>
          <br><br><br>
          <H3><center>unable to perform desired action. RESET in 10 seconds...</center></H3>
          <br>
        </BODY>
      </HTML>
<?php
      exit;
    }

    if(strlen($StoreID) > 0)
      $Result = skyyreq("list-configuration/" . $StoreID . $LoadFromDrive);
    else
      $Result = skyyreq("list-configuration/" . $LoadFromDrive);

    $aList0 = explode("\n", ltrim(rtrim($Result)));

    $aList =  null;
    $aList = [];
    if(empty($aList0) || empty($aList0[0]))
    {
?>
      <HTML>
        <HEAD>
          <TITLE>Load Configuration Info</TITLE>
          <meta http-equiv="refresh" content="2;url=/config/configuration-load.php">
          <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
          <link rel="shortcut icon" href="../img/favicon.ico">
          <style>
<?php
  set_ideal_font_height();
?>
          </style>
        </HEAD>
        <BODY>
          <H1><center>Load Configuration Info</center></H1>
          <br><br><br>
          <H3><center>Insert USB drive containing a configuration</center></H3>
          <br>
          <br>
          <form action="./" method=GET>
            <center>
              <input type=submit value="Cancel" />
            </center>
          </form,>
        </BODY>
      </HTML>
<?php
      exit;
    }
    else
    {
      $ii=-1;
      foreach($aList0 as $xx)
      {
        // first one is drive path (to detect errors)
        if($ii < 0)
        {
          $ii = 0;
        }
        else if(strlen($xx) > 0)
        {
          $aList[$ii] = $xx;
          $ii++;
        }
      }
    }
  }



?>
<HTML>
  <HEAD>
    <TITLE>Load Configuration Info</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </HEAD>
  <BODY>
    <H1><center>Load Configuration Info</center></H1>
<?php
  if(strlen($LoadFromDrive) > 0)
  {
?>
    <H3><center>Indicate which configuration to load</center></H3>
<?php
  }
  else
  {
?>
    <H3><center>Indicate which drive to load from</center></H3>
<?php
  }
?>
    <center>
<?php
  if(strlen($LoadFromDrive) > 0)
  {
     print "<span><b>" . $LoadFromDrive;
     if(strlen($StoreID) > 0)
     {
       print "&nbsp;&nbsp;StoreID " . $StoreID;
     }

     print "</b></span><br>\n";
?>
      <div style='overflow-y:auto;height:8.75rem;width:60%' >
        <table width=100% style='border-collapse:collapse' >
<?php
  }
  else
  {
?>
      <table width="55%" style='border-collapse:collapse' >
<?php
  }
?>


<?php
  if(strlen($LoadFromDrive) > 0)
  {
    /////////////
    // FILE LIST
    /////////////
    foreach($aList as $vv)
    {
      $qq = ltrim(rtrim($vv));
      if(strlen($qq) > 0)
      {
        $aList1 = explode("\t", $qq);
        if(!empty($aList1) && !empty($aList1[0]))
        {
          print "          <tr style='font-size:0.9rem;line-height:1.2em;margin:1px;padding:0px'>\n";
          print "            <td width='70%' style='vertical-align:middle;'>"
                 . $aList1[0] . "</td>\n            <td>&nbsp;&nbsp;"
                 . $aList1[1] . "</td>\n";
          print "            <td width='30%' style='text-align:center'>\n";
          print "              <form method=GET action='/config/configuration-load.php' style='margin:0'>\n";
          print "                <input type=hidden name=LoadFromDrive style='visibility:hidden' value='" . $LoadFromDrive . "'>\n";

          print "                <input type=hidden name=LoadFrom";
          print " style='visibility:hidden' value='" . $LoadFromDrive . "/" . $aList1[0] . "'>\n";

          print "                <input type=submit value='Load' style='height:1.4rem;'/>\n"
              . "              </form>\n            </td>\n          </tr>\n";
        }
      }
    }
  }
  else
  {
    /////////////
    // DRIVE LIST
    /////////////
    foreach($aList as $vv)
    {
      $qq = ltrim(rtrim($vv));
      if(strlen($qq) > 0)
      {
        print "<tr style='font-size:0.9rem'>";
        print "<td width='70%'><div style='text-align:center;vertical-align:middle;line-height:1.2em'>" . $qq . "</div></td><td>&nbsp;</td>";
        print "<td width='30%' style='text-align:center'>";
        print "<form method=GET action='/config/configuration-load.php' style='margin:0'>";

        print "<input type=hidden ";
        print "name=LoadFromDrive style='visibility:hidden' value='" . $qq . "'>";

        print "<input type=submit value='Select' /></form></td></tr>\n";
      }
    }
  }
?>
<?php
  if(strlen($LoadFromDrive) > 0)
  {
?>
        </table>
      </div>
<?php
  }
  else
  {
?>
      </table>
<?php
  }
?>
      <br>
      <form id=cancel action="/maintenance.php" method=GET  style='margin:0'>
<?php
  if(strlen($LoadFromDrive) > 0)
  {
?>
      </form>
      <form id=store_id action="/config/configuration-load.php" method=GET style='margin:0'>
        <input type=hidden name=LoadFromDrive style='visibility:hidden' value=<?php print '"' . $LoadFromDrive . '"'; ?> >
        <input type=hidden id=StoreID name=StoreID style='visibility:hidden' value="" >
      </form>
      <center>
        <table width="50%">
          <tr>
            <td width='50%'><center><input type=submit form=cancel value="Cancel" /></center></td>
            <td width='50%'><center><input type=submit onclick="SelectStoreID();" value="Select Store ID" /></center></td>
          </tr>
        </table>
      </center>
<?php
  }
  else
  {
?>
        <center>
          <input type=submit form=cancel value="Cancel" />
        </center>
      </form>
<?php
  }
?>

<?php
  if(strlen($LoadFromDrive) > 0)
  {
?>
    <!-- popup keypad -->
    <div id=popup_keypad class="modal-container">
      <div id=kb class="keyboard-container" style="visibility:visible;left:11.67rem;width:10rem">
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('1');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:1.25rem;bottom:7.08rem" >
                  1</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('2');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:3.33rem;bottom:7.08rem" >
                  2</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('3');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:5.41rem;bottom:7.08rem" >
                  3</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_bs_click();
                  style="position:absolute;width:1.67rem;height:1.67rem;left:7.5rem;bottom:7.08rem" >
                  &lt=</button>

          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('4');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:1.25rem;bottom:5rem" >
                  4</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('5');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:3.33rem;bottom:5rem" >
                  5</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('6');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:5.41rem;bottom:5rem" >
                  6</button>

          <button type=submit class="me-and-my-shadow"
                  onclick=on_enter_click();
                  style="position:absolute;width:1.67rem;height:5.8rem;left:7.5rem;bottom:0.82rem;line-heigh:0.9rem" >
                  E<br>n<br>t<br>e<br>r</button>

          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('7');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:1.25rem;bottom:2.91rem" >
                  7</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('8');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:3.33rem;bottom:2.91rem" >
                  8</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('9');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:5.41rem;bottom:2.91rem" >
                  9</button>

          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('0');
                  style="position:absolute;width:5.83rem;height:1.67rem;left:1.25rem;bottom:0.83rem" >
                  0</button>
      </div>
      <div id=numeric_container class="me-and-my-shadow"
         style="position:absolute;left:10.4rem;width:12.5rem;bottom:9.16rem;height:2.25rem;border-radius:20px;background-color:#ffffe0;visibility:hidden">
        <input type=text id=numeric style="position:relative;left:0px;top:0.42rem;min-width:8.33rem;height:1.25rem;"/>
      </div>
    </div>
<?php
  }
?>
  </BODY>
  <SCRIPT>
    function SelectStoreID()
    {
      document.getElementById("numeric_container").style.visibility="visible";
      document.getElementById("popup_keypad").style.visibility="visible";
      document.getElementById("popup_keypad").style.display="block";
    }
    function on_vkey_click(kk)
    {
      document.getElementById("numeric").value = document.getElementById("numeric").value + kk;
    }

    function on_bs_click()
    {
      document.getElementById("numeric").value = "";
    }

    function on_enter_click(kk)
    {
      document.getElementById("StoreID").value = document.getElementById("numeric").value;

      document.getElementById("numeric_container").style.visibility="hidden";
      document.getElementById("popup_keypad").style.visibility="hidden";

      document.forms["store_id"].submit();
    }

  </SCRIPT>
</HTML>

