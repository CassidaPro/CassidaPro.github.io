<?php

  include "../glue/config_utils.php";

  // use sessions for the wizard (always)
  session_start(); // using session control

  $back = do_getvar("back", "");

  if(strlen($back) > 0) // editing the global file
  {
    if(isset($_SESSION["LocalConfig"]))
      unset($_SESSION["LocalConfig"]);

    $LocalConfig = "";
  }
  else if(isset($_SESSION["LocalConfig"]))
  {
    $LocalConfig = $_SESSION["LocalConfig"];
  }
  else
  {
    $LocalConfig = "";
  }

  $Submit3a = do_getvar("Submit3a", "");

  // use skyy to parse the config file
  $parseconf = load_parseconf($LocalConfig);

  $AutoStart = empty($parseconf["settings"]["AutoStart"]) ? "off"
             : ($parseconf["settings"]["AutoStart"] == "1" ? "on" : "off");

  // Payout Batch is the old config term - remove this and make it the text "off" after all units update
  $PayoutBatch = empty($parseconf["settings"]["PayoutBatch"]) ? "off"
               : ($parseconf["settings"]["PayoutBatch"] == "1" ? "on" : "off");

  $PayoutAsync = empty($parseconf["settings"]["PayoutAsync"]) ? $PayoutBatch
               : ($parseconf["settings"]["PayoutAsync"] == "1" ? "on" : "off");

  // NOTE:  installed equipment is in the 'equipment_stats.conf' file
  $parsestats = load_parsestats(); // load that file into '$parsestats' array

  // enumerate the 'equipment' tag for keys, and populate '$NoteCounter' '$CoinCountr' '$Printer'

  $NoteCounter = "";
  $NoteCounterMAC = "";
  $NoteCounterSerial = "";

  $CoinCounter = "";
  $CoinCounterSerial = "";

  $Printer = "";
  $PrinterSerial = "";
  $PrinterInverted = "";

  foreach($parsestats["equipment"] as $kk => $vv)
  {
//    print "kk=" . $kk . ",  vv=" . $vv . "<br>\n";
    if($kk == "Zeus")
    {
      $NoteCounter = $kk;
      $NoteCounterMAC = $vv;
      $NoteCounterSerial = $parsestats[$kk . " " . $vv]["Serial"];
    }
    else if($kk == "C300" || $kk == "C400" || $kk == "C400R" || coin_counter_is_recycler($kk))
    {
      $CoinCounter = $kk;
      $CoinCounterSerial = $vv;
    }
    else if($kk == "Printer")
    {
      $Printer = $parsestats[$kk . " " . $vv]["Model"];
      $PrinterInverted = empty($parsestats[$kk . " " . $vv]["Inverted"]) ? "off"
                       : ($parsestats[$kk . " " . $vv]["Inverted"] == "1" ? "on" : "off");
      $PrinterSerial = $vv;
    }
  }


  if($Submit3a == "Y")
  {
    $XPrinterInverted   = do_getvar("PrinterInverted", "off");
    $XPayoutAsync       = do_getvar("PayoutAsync", "off");
    $XAutoStart         = do_getvar("AutoStart", "");

    // TODO:  sanitize user input data first?  go back and re-edit?
?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=initial-setup3a.php?Submit3a=YY<?php
            if(strlen($back) > 0)
              print "&back=" . urlencode($back);
            print "&PrinterInverted=" . urlencode($XPrinterInverted);
            print "&PayoutAsync=" . urlencode($XPayoutAsync);
            print "&AutoStart=" . urlencode($XAutoStart);
            ?>" >
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($Submit3a == "YY")
  {
    // the only entries under 'equipment' should match what I have installed
    $XPrinterInverted   = do_getvar("PrinterInverted", "off");
    $XPayoutAsync       = do_getvar("PayoutAsync", "off");
    $XAutoStart         = do_getvar("AutoStart", "");

    // this next section updates the config files with anything that changed there...
    if($PrinterInverted !== $XPrinterInverted)
    {
      $parsestats["Printer " . $PrinterSerial]["Inverted"] = ($XPrinterInverted == "on") ? "1" : "0";

      write_statistics_file($parsestats, "initial-setup3.php", $LocalConfig);
    }

    if($PayoutAsync !== $XPayoutAsync || $AutoStart !== $XAutoStart)
    {
      if($XPayoutAsync == "on")
        $parseconf["settings"]["PayoutAsync"] = "1";
      else
        $parseconf["settings"]["PayoutAsync"] = "0";

      if($XAutoStart == "on")
        $parseconf["settings"]["AutoStart"] = "1";
      else
        $parseconf["settings"]["AutoStart"] = "0";

      write_configuration_file($parseconf, "initial-setup3a.php", $LocalConfig);
    }

    skyyreq("reload"); // must do this

    // flow through to the next page


    header("HTTP/1.0 302 Moved Temporarily");
    if(strlen($back) > 0)
      header("Location: " . $back);
    else
      header("Location: initial-setup4.php");

//    if(strlen($back) > 0)
//    {
//      shell_exec("curl http://localhost:3042/reload");
//    }

    exit;
  }


?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Configuration for Split Recycler System</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }
    </style>
    <script>
      function doClickKB(strID)
      {
        // do something using 'strID' to locate the input component
        // and display virtual KB and accept input, assigning the
        // controls' inner HTML or value when the keyboard is closed
      }
      function doClickClear(strID)
      {
        var xx = document.getElementById(strID);

        if(xx != null)
        {
          xx.value = "";
        }
      }
    </script>
  </HEAD>
  <BODY bgcolor="#101824" text="#ffffe0">
    <center>
      <b>
        <H1 style="margin:0;padding:0">
<?php
  if(strlen($back) != 0)
  {
?>
          Split Recycler - Edit Config
<?php
  }
  else if(strlen($LocalConfig) != 0)
  {
?>
          Split Recycler - New Config
<?php
  }
  else
  {
?>
          Split Recycler - Initial Setup
<?php
  }
?>
        </H1>
<?php
  if(strlen($LocalConfig) == 0)
  {
?>
        <H4 style="margin:0;margin-bottom:0.83rem !important;padding:0">Equipment Serial Numbers</H4>
<?php
  }
  else
  {
?>
        <H4 style="margin:0;margin-bottom:0.83rem !important;padding:0">Equipment (local config settings only)</H4>
<?php
  }
?>
      </b>
    </center>
    <form id=none method=GET></form>
    <form id=refresh method=GET>
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <form id=the_form method=GET>
      <input type=hidden name="Submit3a" value="Y" style="visibility:hidden" />
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
      <center>
<?php
  if(strlen($LocalConfig) == 0)
  {
?>
        <table border=1 width="85%">
          <thead><th>Equipment</th><th>Serial Number</th><th>MAC Address</th></thead>
          <tr>
            <td width="30%">
              <table>
                <tr>
                  <td width=90px>
                    Notes:&nbsp;&nbsp;
                  </td>
                  <td>
                    <span><?php print $NoteCounter; ?></span>
                  </td>
                </tr>
              </table>
            </td>
            <td width="40%" style="font-size:0.83rem;margin-right:10px">
              <div style="text-align:center">
                <span><?php print $NoteCounterSerial; ?></span>
              </div>
            </td>
            <td width="30%">
              <div style="text-align:center;margin:0;padding:0;vertical-align:middle">
                <?php print $NoteCounterMAC; ?>
              </div>
            </td>
          </tr>

          <tr>
            <td width="30%">
              <table>
                <tr>
                  <td width=90px>
                    Coins:&nbsp;&nbsp;
                  </td>
                  <td>
                    <span><?php print $CoinCounter; ?></span>
                  </td>
                </tr>
              </table>
            </td>
            <td width="40%" style="font-size:0.83rem;margin-right:10px">
              <div style="text-align:center">
                <span><?php print $CoinCounterSerial; ?></span>
              </div>
            </td>
            <td width="30%">
              &nbsp;
            </td>
          </tr>

          <tr>
            <td width="30%">
              <table>
                <tr>
                  <td width=90px>
                    Printer:&nbsp;&nbsp;
                  </td>
                  <td>
                    <span><?php print $Printer; ?></span>
                  </td>
                </tr>
              </table>
            </td>
            <td width="40%" style="font-size:0.83rem;margin-right:10px">
              <div style="text-align:center">
                <span><?php print $PrinterSerial; ?></span>
              </div>
            </td>
            <td width="30%">
              &nbsp;
            </td>
          </tr>
        </table>
<?php
  }
?>
        <input id=AutoStart name=AutoStart type=checkbox <?php if($AutoStart == "on") print "checked"; ?> >
<?php
  if(coin_counter_is_recycler($CoinCounter))
  {
?>
          Background Coin Count
<?php
  }
  else
  {
?>
          Auto Start Coin Count
<?php
  }
?>
        </input>&nbsp;&nbsp;&nbsp;&nbsp;
        <input id=PrinterInverted name=PrinterInverted type=checkbox <?php if($PrinterInverted == "on") print "checked"; ?> >
          Invert Printout
        </input>
        <br>
<?php
  if(coin_counter_is_recycler($CoinCounter))
  {
?>
        <input id=PayoutAsync name=PayoutAsync type=checkbox <?php if($PayoutAsync == "on") print "checked"; ?> >
          Payout Batch Mode
        </input>
<?php
  }
?>
      </center>
    </form>

<?php
  if(strlen($back) > 0)
  {
?>
    <input type=submit form=none
           formaction="<?php print $back; ?>"
           value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem"/>
<?php
  }
  else if(strlen($LocalConfig) > 0)
  {
?>
    <input type=submit form=none
           formaction="initial-setup2.php"
           value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem"/>
<?php
  }
?>
    <input type=submit form=refresh formaction="initial-setup3a.php"
           value="Re-load" style="position:absolute;bottom:0.75rem;width:5rem;right:14.3rem"/>
    <input type=submit form=the_form formaction="initial-setup3a.php"
           value="Next" style="position:absolute;bottom:0.75rem;width:3.33rem;right:3.33rem"/>

  </BODY>
</HTML>

