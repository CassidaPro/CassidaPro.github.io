<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include '../glue/config_utils.php';

  // use sessions for the wizard (always)
  session_start(); // using session control

  $back = do_getvar("back", "");

  if(strlen($back) > 0) // editing the global file
  {
    if(isset($_SESSION["LocalConfig"]))
      unset($_SESSION["LocalConfig"]);

    $LocalConfig = "";
  }
  else if(isset($_SESSION["LocalConfig"]))
  {
    $LocalConfig = $_SESSION["LocalConfig"];
  }
  else
  {
    $LocalConfig = "";
  }

  $parseconf = load_parseconf($LocalConfig);

  $AutoStart = empty($parseconf["settings"]["AutoStart"]) ? "off"
             : ($parseconf["settings"]["AutoStart"] == "1" ? "on" : "off");

  $SubmitD = do_getvar("SubmitD", "");

  // this page is for class 1 vessels
  $VesselClass = "Class4";
  $VesselClassName = do_getconf($parseconf, "vessels", $VesselClass, "Class 4");
  $Class4Icon = do_getconf($parseconf, "icons", "Class4", ""); // for now use blank as default

  $CustomerMod = do_getconf($parseconf, "settings", "CustomerMod", "0");

  // get terms for straps and rolls and stuff
  $Straps = do_getconf($parseconf,"terms",'Straps','Straps');
  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Rolls = do_getconf($parseconf,"terms",'Rolls','Rolls');


  if($SubmitD == "Y" || $SubmitD == "Z")
  {
    $StrapsEnable = do_getvar("StrapsEnable", "off");
    $NotesEnable = do_getvar("NotesEnable", "off");
    $CoinsEnable = do_getvar("CoinsEnable", "off");
    $RollsEnable = do_getvar("RollsEnable", "off");
    $AutoStartDisabled = do_getvar("AutoStartDisabled", "");

    $count=do_getvar("count", "");

    if($SubmitD == "Z")
    {
      $AddEditItemIndex = do_getvar("AddEditItemIndex", "");
      $AddEditItemName = do_getvar("AddEditItemName", false); // special, default is 'false'
      if($CustomerMod == 2)
      {
        $AddEditDisableLooseCoins = do_getvar("AddEditDisableLooseCoins","0");
      }
    }

    // TODO:  additional sanitization checks.  Go back and re-edit if bad

    if(empty($count) ||
       ($StrapsEnable != "on" &&
        $NotesEnable != "on" &&
        $CoinsEnable != "on" &&
        $RollsEnable != "on" ) ||
       ($StrapsEnable == "on" && empty($Straps)) ||
       ($NotesEnable == "on" && empty($Notes)) ||
       ($CoinsEnable == "on" && empty($Coins)) ||
       ($RollsEnable == "on" && empty($Rolls))  )
    {
?>
      <HTML>
        <HEAD>
          <TITLE>Saving Configuration Info</TITLE>
          <meta http-equiv="refresh" content="10;url=initial-setup-Class4.php?Refresh=Y<?php
                if(strlen($back) > 0)
                  print "&back=" . urlencode($back);
                if(strlen($AutoStartDisabled) > 0)
                  print "&AutoStartDisabled=" . urlencode($AutoStartDisabled);
                print "&StrapsEnable=" . urlencode($StrapsEnable);
                print "&NotesEnable=" . urlencode($NotesEnable);
                print "&CoinsEnable=" . urlencode($CoinsEnable);
                print "&RollsEnable=" . urlencode($RollsEnable);
                print "&count=" . urlencode($count);
                ?>" >
        </HEAD>
        <BODY bgcolor="#e0e0e0" text="#8068ff">
          <br><br><br><br>
          <H1><center>ERROR - Bad Configuration Info</center></H1>
<?php
  print $StraqpsEnable . ", " . $NotesEnable . ", " . $CoinsEnable . ", "
        . $RollsEnable . ", " . $Straps . ", " . $Notes . ", "
        . $Coins . ", " . $Rolls;
?>
        </BODY>
      </HTML>
<?php
      exit;
    }

?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=initial-setup-Class4.php?SubmitD=<?php
            print $SubmitD . $SubmitD; // double it for the next phase
            if(strlen($back) > 0)
              print "&back=" . urlencode($back);
            if(strlen($AutoStartDisabled) > 0)
              print "&AutoStartDisabled=" . urlencode($AutoStartDisabled);
            print "&StrapsEnable=" . urlencode($StrapsEnable);
            print "&NotesEnable=" . urlencode($NotesEnable);
            print "&CoinsEnable=" . urlencode($CoinsEnable);
            print "&RollsEnable=" . urlencode($RollsEnable);
            print "&count=" . urlencode($count);
            if($SubmitD == "Z")
            {
              print "&AddEditItemIndex=" . urlencode($AddEditItemIndex);
              print "&AddEditItemName=" . urlencode($AddEditItemName);
              if($CustomerMod == 2)
              {
                print "&AddEditDisableLooseCoins=" . urlencode($AddEditDisableLooseCoins);
              }
            }
            ?>" >
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($SubmitD == "YY" || $SubmitD == "ZZ")
  {
    $StrapsEnable = do_getvar("StrapsEnable", "off");
    $NotesEnable = do_getvar("NotesEnable", "off");
    $CoinsEnable = do_getvar("CoinsEnable", "off");
    $RollsEnable = do_getvar("RollsEnable", "off");
    $AutoStartDisabled = do_getvar("AutoStartDisabled", "");

    $count=do_getvar("count", "");

    if($SubmitD == "ZZ")
    {
      $AddEditItemIndex = do_getvar("AddEditItemIndex", "");
      $AddEditItemName = do_getvar("AddEditItemName", false); // special, default is 'false'
      if($CustomerMod == 2)
      {
        $AddEditDisableLooseCoins = do_getvar("AddEditDisableLooseCoins","0");
      }
    }

    if($StrapsEnable != "on")
      $Straps = "";
    if($NotesEnable != "on")
      $Notes = "";
    if($CoinsEnable != "on")
      $Coins = "";
    if($RollsEnable != "on")
      $Rolls = "";

    if($AutoStart == "on")
    {
      $XAutoStartEnabled = $AutoStartDisabled != "on"
                         ? "1" : "0";
    }
    else
    {
      $XAutoStartEnabled = do_getconf($parseconf,$VesselClass,"AutoStart","1"); // whatever it is right now in the conf file, or blank
    }

    $changed = $parseconf[$VesselClass]["count"] !== $count
             || $XAutoStartEnabled != do_getconf($parseconf, $VesselClass, "AutoStart", "1");

    if($changed || $SubmitD == "ZZ")
    {
      // if the description changed, make sure I change the key to match the new one
      // if the key exists, that is...

      // re-naming the entries (as needed)

      $parseconf[$VesselClass]["count"] = $count;

      $parseconf[$VesselClass]["AutoStart"] = $XAutoStartEnabled;

      if($SubmitD == "ZZ")
      {
        // if the description changed, make sure I change the key to match the new one
        // if the key exists, that is...

        // this suports re-naming the entries (as needed)

        if(empty($parseconf[$VesselClass][$AddEditItemIndex]))
          $oldsection = false;
        else
          $oldsection = $VesselClass . "." . $parseconf[$VesselClass][$AddEditItemIndex];

        if($AddEditItemName === false) // delete it
        {
          unset($parseconf[$VesselClass][$AddEditItemIndex]); // = false;

          if($oldsection !== false)
          {
            unset($parseconf[$oldsection]); // = false; // delete the old section associated with it
          }
        }
        else
        {
          $parseconf[$VesselClass][$AddEditItemIndex] = $AddEditItemName;

          $newsection = $VesselClass . "." . $AddEditItemName;

          if($oldsection !== false && $oldsection != $newsection
             && !empty($parseconf[$oldsection]))
          {
            $parseconf[$newsection] = $parseconf[$oldsection]; // copy to new location
            unset($parseconf[$oldsection]); // = false; // deletes it
          }
          else
          {
            $parseconf[$AddEditItemName] = []; // new empty section
          }

          if($CustomerMod == 2)
          {
            $parseconf[$newsection]["disable_loose_coins"] = $AddEditDisableLooseCoins;
          }

          // TODO:  any 'newsection' things that need to be written...

        }
      }

      write_configuration_file($parseconf, "initial-setup-Class4.php", $LocalConfig);
    }

    // flow through to the next page

    header("HTTP/1.0 302 Moved Temporarily");

    // the next one I go to depends on what I've configured

    if($SubmitD == "ZZ")
    {
      if(strlen($back) > 0)
        header("Location: initial-setup-Class4.php?back=" . urlencode($back)); // back to me, and include 'back='
      else
        header("Location: initial-setup-Class4.php"); // back to me, refreshing everything
    }
    else if(strlen($back) > 0)
      header("Location: " . $back);
    else if(!empty($parseconf["vessels"]["Class5"]))
      header("Location: initial-setup-Class5.php");
    else if(!empty($parseconf["vessels"]["Build"]) ||
            !empty($parseconf["vessels"]["Verify"]))
      header("Location: initial-setup-Build-Verify.php");
    else
      header("Location: initial-setup6.php");

    if(strlen($back) > 0)
    {
      shell_exec("curl http://localhost:3042/reload");
    }

    exit;
  }

  $Refresh=empty($_GET) || empty($_GET["Refresh"]) ? "" : $_GET["Refresh"];

  $Process = do_getconf($parseconf,"terms",'Process','Daily Tasks');

//  print $Process . "<br>;\n";
//  print_r($parseconf);
//  exit;


  if($Refresh=='Y')
  {
    // TODO:  add the ability to re-invoke this page by specifying
    //        the previous values and selecting focus on an item that
    //        has a problem

    $StrapsEnable = do_getvar("StrapsEnable", "off");
    $NotesEnable = do_getvar("NotesEnable", "off");
    $CoinsEnable = do_getvar("CoinsEnable", "off");
    $RollsEnable = do_getvar("RollsEnable", "off");

    if($AutoStart == "on")
    {
      $AutoStartDisabled  = do_getvar("AutoStartDisabled", "off");
    }
    else
    {
      $AutoStartDisabled  = "off"; // for now just do this
    }

    $count = do_getvar("count", "");
  }
  else
  {
    $StrapsEnable = "off";
    $NotesEnable = "off";
    $CoinsEnable = "off";
    $RollsEnable = "off";

    if($AutoStart == "on")
    {
      $AutoStartEnabled  = do_getconf($parseconf, $VesselClass, "AutoStart", "1");

      if(strlen($AutoStartEnabled) > 0 && $AutoStartEnabled != "1" && $AutoStartEnabled != "yes")
        $AutoStartDisabled = "on";
      else
        $AutoStartDisabled = "off";
    }
    else
    {
      $AutoStartDisabled  = "";
    }

    $count = do_getconf($parseconf,$VesselClass,
                        'count','straps,notes,coins,rolls');
  }


  // TODO:  sanitize this and if enabled items aren't included, or specified more than once,
  //        fix it so that it is as correct as possible.  Then proceed.

  // First, parse $count as best as I can
  $aCount=explode(",", $count . ",,,,");
  $aCountTypes = [];
  $Rows=[];

  // pre-assign zeros and clean up $aCount
  for($ii=0; $ii < 4; $ii++)
  {
    $vv = rtrim(ltrim($aCount[$ii]));
    if($vv == "straps")
    {
      $StrapsEnable = "on";
      $aCount[$ii] = 1;  // temporarily use a number
    }
    else if($vv == "notes")
    {
      $NotesEnable = "on";
      $aCount[$ii] = 2;
    }
    else if($vv == "coins")
    {
      $CoinsEnable = "on";
      $aCount[$ii] = 3;
    }
    else if($vv == "rolls")
    {
      $RollsEnable = "on";
      $aCount[$ii] = 4;
    }
    else
    {
      $aCount[$ii] = "";
    }

    $aCountTypes[$ii+1] = 0; // pre-zerio it
  }

  // create an inverse index in '$aCountTypes'
  for($ii=0; $ii < 5; $ii++)
  {
    if($aCount[$ii] == "") // skip
      break; // I am done

    $aCountTypes[$aCount[$ii]] = $ii + 1; // 1-based row number essentially
  }

  // try to fill in things not already present in '$aCount'
  // this needs to be improved to avoid missing classes
  for($jj=1; $jj <= 5; $jj++)
  {
    if(!array_key_exists($jj,$aCountTypes) ||
       $aCountTypes[$jj] == 0) // count type has no row
    {
      $ii++;
      $aCountTypes[$jj] = $ii; // assign next row index to it
    }
  }

  // map 'aCount' back to 'Rows' so that 'Rows' is an array of count names
  $CountNames = ["","Straps","Notes","Coins","Rolls"]; // these are related to the names of the controls
  for($ii=1; $ii <= 4; $ii++)
  {
    // map rows to count types using the name
    $Rows[$aCountTypes[$ii]] = $CountNames[$ii];
  }

//  if($Refresh=='Y')
//  {
//    print "\"" . $Rows[1] . "\", \"" . $Rows[2] . "\", \"" . $Rows[3] . "\", \"" . $Rows[4] . "\", \"" . $Rows[5] . "\"";
//    print_r($aCount);
//    print_r($aCountTypes);
//    print_r($count);
//    exit;
//  }

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Configuration for Split Recycler System</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }
    </style>
    <script>
      function validate_vessel_id(strID, strVal)
      {
        var nVal = Number(strVal);

        if(nVal > 0 && nVal <= 99)
        {
          // prompt invalid value?
          document.getElementById(strID).value = nVal;
        }
        else
        {
          if(!window.confirm("The id value '" + strVal + "' is out of range - must be 1 through 99"))
          {
            doCancelEdit();
          }
        }
      }

      function doClickKB(strID)
      {
        if(strID == "vessel_id")
        {
          do_vkey_numeric(strID, validate_vessel_id);
        }
        else
          do_vkey_single(strID, null);
      }

      function doDelButton(strID)
      {
        document.getElementById("AddEditItemIndex").value = strID;
        document.getElementById("AddEditItemIndex").disabled = false;
        document.getElementById("AddEditItemOldIndex").value = "";
        document.getElementById("AddEditItemOldIndex").disabled = true;
        document.getElementById("AddEditItemName").value = "";
        document.getElementById("AddEditItemName").disabled = true; // make sure, it means 'delete'

        // disable 'Refresh', enable 'SubmitD' with 'SubmitD's value set to 'Z'
        document.getElementById("Refresh").disabled = true;
        document.getElementById("SubmitD").disabled = false;
        document.getElementById("SubmitD").value = "Z"; // this means to submit but come back HERE

        // now, submit the form
        document.getElementById("the_form").submit();
      }


<?php
  if($CustomerMod == 2)
  {
?>
      function doEditButton(strID, disableLooseCoins)
<?php
  }
  else
  {
?>
      function doEditButton(strID)
<?php
  }
?>
      {
        var aVessels = new Array();
<?php
        // transfer 'vessels in PHP to javascript 'aVessels'
        $maxID = 0;
        foreach($parseconf[$VesselClass] as $kk => $vv)
        {
          if(!empty($kk) && substr($kk,0,1) >= '0' && substr($kk,0,1) <= '9')
          {
            // sanitize '$vv' if it has single-quotes in it
            $vv2 = str_replace("'", "\\'", $vv);

            print "aVessels[" . $kk . "]='" . $vv2 . "';\n";

            if($kk > $maxID)
              $maxID = $kk;
          }
        }
?>
        document.getElementById("old_id").value = strID;

        if(strID == "")
        {
          document.getElementById("edit_vessel_title").innerHTML = "<?php print 'Add New ' . make_singular($VesselClassName); ?>";
          document.getElementById("vessel_id").value = <?php print $maxID + 1; ?>;
          document.getElementById("vessel_id").readOnly = false;
          document.getElementById("vessel_id_keyboard").enabled = true;
          document.getElementById("vessel_id_keyboard").style.visibility = "visible";
          document.getElementById("vessel_name").value = "<?php print 'New ' . $VesselClassName; ?>";
<?php
  if($CustomerMod == 2)
  {
?>
          document.getElementById("vessel_disable_loose_coins").checked = false;
<?php
  }
?>
        }
        else
        {
          document.getElementById("edit_vessel_title").innerHTML = "<?php print 'Edit ' . make_singular($VesselClassName); ?> " + strID;
          document.getElementById("vessel_id").value = strID;
          document.getElementById("vessel_id").readOnly = true;
          document.getElementById("vessel_id_keyboard").enabled = false;
          document.getElementById("vessel_id_keyboard").style.visibility = "hidden";
          document.getElementById("vessel_name").value = aVessels[strID];
<?php
  if($CustomerMod == 2)
  {
?>
          document.getElementById("vessel_disable_loose_coins").checked =
            (disableLooseCoins.length > 0 &&  disableLooseCoins > 0) ? true : false;
<?php
  }
?>
        }

        document.getElementById("edit_vessel").style.display = "block";
        document.getElementById("edit_vessel").style.visibility = "visible";
      }

      function doAddEdit()
      {
        var aVessels = new Array();
<?php
        // transfer 'vessels in PHP to javascript 'aVessels'
        $maxID = 0;
        foreach($parseconf[$VesselClass] as $kk => $vv)
        {
          if(!empty($kk) && substr($kk,0,1) >= '0' && substr($kk,0,1) <= '9')
          {
            // sanitize '$vv' if it has single-quotes in it
            $vv2 = str_replace("'", "\\'", $vv);

            print "aVessels[" . $kk . "]='" . $vv2 . "';\n";

            if($kk > $maxID)
              $maxID = $kk;
          }
        }
?>
        // copy appropriate values into the 'add' form things and enable them
        document.getElementById("AddEditItemIndex").value = document.getElementById("vessel_id").value;
        document.getElementById("AddEditItemIndex").disabled = false;
        document.getElementById("AddEditItemName").value = document.getElementById("vessel_name").value;
        document.getElementById("AddEditItemName").disabled = false;

<?php
  if($CustomerMod == 2)
  {
?>
        document.getElementById("AddEditDisableLooseCoins").value =
          (document.getElementById("vessel_disable_loose_coins").checked) ? 1 : 0;
        document.getElementById("AddEditDisableLooseCoins").disabled = false;
<?php
  }
?>
        document.getElementById("AddEditItemOldIndex").value = ""; // initially
        document.getElementById("AddEditItemOldIndex").disabled = true;

        var id = Number(document.getElementById("vessel_id").value);

        if(id <= 0 || id > 99)
        {
          if(!window.confirm("The id value '" + id + "' is out of range - must be 1 through 99"))
          {
            doCancelEdit();
            return;
          }

          document.getElementById("vessel_id").focus(); // go there
          return;
        }

        if(document.getElementById("old_id").value == "" || // new one
           id != document.getElementById("old_id").value)  // id changed, and isn't a new one
        {
          // data validation
          // see if I used an index for something that exists already...

          if(aVessels[id] && aVessels[id].length > 0) // oops
          {
            if(!window.confirm("The id value '" + id + "' is already in use"))
            {
              doCancelEdit();
              return;
            }

            document.getElementById("vessel_id").focus(); // go there
            return;
          }

          if(document.getElementById("old_id").value != "") // NOT a new one
          {
            document.getElementById("AddEditItemOldIndex").value = document.getElementById("old_id").value;
            document.getElementById("AddEditItemOldIndex").disabled = false;
          }
        }

        // disable 'Refresh', enable 'SubmitD' with 'SubmitD's value set to 'Z'
        document.getElementById("Refresh").disabled = true;
        document.getElementById("SubmitD").disabled = false;
        document.getElementById("SubmitD").value = "Z"; // this means to submit but come back HERE

        document.getElementById("edit_vessel").style.display = "none"; // on general principle
        document.getElementById("edit_vessel").style.visibility = "hidden";

        // now, submit the form
        document.getElementById("the_form").submit();
      }

      function doCancelEdit()
      {
        document.getElementById("edit_vessel").style.display = "none";
        document.getElementById("edit_vessel").style.visibility = "hidden"; // hide it
      }

      function doFixCount()
      {
        var ii;
        var xTemp;
        var aRows = new Array();
<?php
        // transfer '$Rows' in PHP to javascript 'aRows'
        for($ii=1; $ii <= 5; $ii++)
        {
          if(array_key_exists($ii,$Rows))
            print "aRows[" . $ii . "]='" . $Rows[$ii] . "';\n";
          else
            print "aRows[" . $ii . "]='0';\n";
        }
?>
        xTemp = "";
        for(ii=1; ii <= 5; ii++)
        {
          if(aRows[ii].length > 0)
          {
            var xx = document.getElementById(aRows[ii] + "Enable");
            if(xx && xx.checked == true)
            {
              var jj = aRows[ii].toLowerCase(); // convert case to lower case - an artifact of the naming convention

              if(xTemp.length > 0)
                xTemp = xTemp + ",";

              xTemp = xTemp + jj;
            }
          }
        }

        // assign the 'count' hidden field
        document.getElementById("count").value = xTemp;
      }

      function doUpButton(strID)
      {
        var ii;
        var xTemp;
        var aRows = new Array();
//        var szAlert = "";
<?php
        // transfer '$Rows' in PHP to javascript 'aRows'
        for($ii=1; $ii <= 5; $ii++)
        {
          if(array_key_exists($ii,$Rows))
            print "aRows[" . $ii . "]='" . $Rows[$ii] . "';\n";
          else
            print "aRows[" . $ii . "]='0';\n";
        }
?>
        for(ii=2; ii <= 5; ii++)
        {
          // bump this one item up in the list by
          // exchanging it with the one above
          if(strID == aRows[ii])
          {
            xTemp = aRows[ii - 1];
            aRows[ii - 1] = aRows[ii];

            aRows[ii] = xTemp; // exchange with item above
            break;
          }
        }

        // rebuild 'count' and assign to 'count' element's value

        xTemp = "";
        for(ii=1; ii <= 5; ii++)
        {
          if(aRows[ii].length > 0)
          {
            var xx = document.getElementById(aRows[ii] + "Enable");
            if(xx && xx.checked == true)
            {
              var jj = aRows[ii].toLowerCase(); // convert case to lower case - an artifact of the naming convention

              if(xTemp.length > 0)
                xTemp = xTemp + ",";

              xTemp = xTemp + jj;
            }
          }
        }

//        szAlert = szAlert + "xTemp=" + xTemp + "\n";

        document.getElementById("count").value = xTemp;

//        alert(szAlert);

        // invoke the form's 'submit' method
        document.getElementById("the_form").submit();
      }

      function doDownButton(strID)
      {
        var ii;
        var xTemp;
        var aRows = new Array();
//        var szAlert = "";
<?php
        // transfer '$Rows' in PHP to javascript 'aRows'
        for($ii=1; $ii <= 5; $ii++)
        {
          if(array_key_exists($ii,$Rows))
            print "aRows[" . $ii . "]='" . $Rows[$ii] . "';\n";
          else
            print "aRows[" . $ii . "]='0';\n";
        }
?>
        for(ii=1; ii < 5; ii++)
        {
          // bump this one item down in the list by
          // exchanging it with the one above
          if(strID == aRows[ii])
          {
            xTemp = aRows[ii + 1];
            aRows[ii + 1] = aRows[ii];

            aRows[ii] = xTemp; // exchange with item underneath

            break;
          }
        }

        // rebuild 'count' and assign to 'count' element's value

        xTemp = "";
        for(ii=1; ii <= 5; ii++)
        {
          if(aRows[ii].length > 0)
          {
            var xx = document.getElementById(aRows[ii] + "Enable");
            if(xx && xx.checked == true)
            {
              var jj = aRows[ii].toLowerCase(); // convert case to lower case - an artifact of the naming convention

              if(xTemp.length > 0)
                xTemp = xTemp + ",";

              xTemp = xTemp + jj;
            }
          }
        }

//        szAlert = szAlert + "xTemp=" + xTemp + "\n";

        document.getElementById("count").value = xTemp;

//        alert(szAlert);

        // invoke the form's 'submit' method
        document.getElementById("the_form").submit();
      }

      function doClickEnable(strID)
      {
        var xx;

        doFixCount();

        // for now, just do this
        document.getElementById("the_form").submit();
      }

    </script>
  </HEAD>
  <BODY bgcolor="#101824" text="#ffffe0">
    <form id=none></form>
    <form id=reload>
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <center>
      <b>
<?php
  if(strlen($Class4Icon) > 0)
  {
?>
        <img src="../img/<?php print $Class4Icon; ?>" width=48 height=48 style="position:absolute;left:0.83rem;top:0.42rem;">
        <img src="../img/<?php print $Class4Icon; ?>" width=48 height=48 style="position:absolute;right:20px;top:0.42rem;">
<?php
  }
?>
        <H1 style="margin:0;padding:0">
<?php
  if(strlen($back) != 0)
  {
?>
          Split Recycler - Edit Config
<?php
  }
  else if(strlen($LocalConfig) != 0)
  {
?>
          Split Recycler - New Config
<?php
  }
  else
  {
?>
          Split Recycler - Initial Setup
<?php
  }
?>
        </H1>
        <H4 style="margin:0;padding:0;vertical-align:middle">
          <?php print $VesselClassName; ?> - Vessel Setup
        </H4>
        <div style="margin:0;padding:0;font-size:15px;line-height:15px;margin-bottom:10px">
          Use checkbox to enable a count; Use arrow buttons to change the order.
        </div>
      </b>
    </center>
    <form id=none method=GET></form>
    <form id=the_form method=GET action="initial-setup-Class4.php">
      <input type=hidden id=Refresh name="Refresh" value="Y" style="visibility:hidden" />
      <input type=hidden id=SubmitD name="SubmitD" value="Y" style="visibility:hidden" disabled />
      <input type=hidden id=count   name="count" value="<?php print $count; ?>" style="visibility:hidden" />
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
      <table width=100%><tr style="vertical-align:top;"> <!-- use this to do side-by-side columns -->
        <td width=40%>
          <center>
            <table><!-- width="300px"-->
<?php
  for($ii=1; $ii <= 4; $ii++)
  {
    $rr = $Rows[$ii];
    if($rr == "Straps")
    {
?>
              <tr>
                <td width="45%" style="valign:top;text-align:left;font-size:0.75rem;">
                  <input id=StrapsEnable name=StrapsEnable type=checkbox <?php if($StrapsEnable == "on") print "checked"; ?>
                         onClick='doClickEnable("Straps");'>
                    <?php print $Straps; ?>
                  </input>
                </td>
                <td width="10%">&nbsp;</td>
                <td width="45%" style="font-size:0.83rem;margin-right:10px">
                  <a onClick='doUpButton("Straps");'><img src="../img/up-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                  <a onClick='doDownButton("Straps");'><img src="../img/down-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                </td>
              </tr>
<?php
    }
    else if($rr == "Notes")
    {
?>
              <tr>
                <td style="valign:top;text-align:left;font-size:0.75rem;">
                  <input id=NotesEnable name=NotesEnable type=checkbox <?php if($NotesEnable == "on") print "checked"; ?>
                         onClick='doClickEnable("Notes");'>
                    <?php print $Notes; ?>
                  </input>
                </td>
                <td>&nbsp;</td>
                <td style="font-size:0.83rem;margin-right:10px">
                  <a onClick='doUpButton("Notes");'><img src="../img/up-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                  <a onClick='doDownButton("Notes");'><img src="../img/down-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                </td>
              </tr>
<?php
    }
    else if($rr == "Coins")
    {
?>
              <tr>
                <td style="valign:top;text-align:left;font-size:0.75rem;">
                  <input id=CoinsEnable name=CoinsEnable type=checkbox <?php if($CoinsEnable == "on") print "checked"; ?>
                         onClick='doClickEnable("Coins");'>
                    <?php print $Coins; ?>
                  </input>
                </td>
                <td>&nbsp;</td>
                <td style="font-size:0.83rem;margin-right:10px">
                  <a onClick='doUpButton("Coins");'><img src="../img/up-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                  <a onClick='doDownButton("Coins");'><img src="../img/down-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                </td>
              </tr>
<?php
    }
    else if($rr == "Rolls")
    {
?>
              <tr>
                <td style="valign:top;text-align:left;font-size:0.75rem;">
                  <input id=RollsEnable name=RollsEnable type=checkbox <?php if($RollsEnable == "on") print "checked"; ?>
                         onClick='doClickEnable("Rolls");' >
                    <?php print $Rolls; ?>
                  </input>
                </td>
                <td>&nbsp;</td>
                <td style="font-size:0.83rem;margin-right:10px">
                  <a onClick='doUpButton("Rolls");' ><img src="../img/up-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                  <a onClick='doDownButton("Rolls");' ><img src="../img/down-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                </td>
              </tr>
<?php
    }
  }
?>
          <!-- TODO:  put things like pulls, banking, dfault start amount here -->

            </table>

            <div style="position:absolute;left:1.67rem;top:11.25rem;width:9.58rem;text-align:left">
<?php
  if($AutoStart == "on")
  {
?>
              <br>
              <input id=AutoStartDisabled name=AutoStartDisabled type=checkbox <?php if($AutoStartDisabled == "on") print "checked"; ?> >
                Disable Auto-Start
              </input>
<?php
  }
?>
            </div>

          </td>
          <td>
            <H4 style="margin:0;border:0;padding:0;">List of Vessels</H4>
            <table border=1 style="width:17rem;height:10rem;display:inline-block;overflow:auto;">
              <thead>
                <tr style="font-size:0.67rem">
                  <th>ID</th>
                  <th>Vessel Name</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
<?php
  $aVV = $parseconf[$VesselClass];
  $aV = [];
  foreach($aVV as $kk => $vv)
  {
    if(substr($kk,0,1) >= '0' && substr($kk,0,1) <= '9')
    {
      $jj = "0000000000" . $kk; // prepend 10 zeros
      $aV[$kk] = substr($jj, strlen($jj) - 10, 10); // right-hand 10 chars
    }
  }

  asort($aV); // sorts numerically

  foreach($aV as $kk => $vvv)
  {
    $vv = $aVV[$kk]; // grab value from previous array

//    if(substr($kk,0,1) >= '0' && substr($kk,0,1) <= '9')
    {
      if($CustomerMod == 2)
      {
        $ventry = $VesselClass . "." . $vv;
        $disable_loose_coins = do_getconf($parseconf, $ventry, "disable_loose_coins", "0");
      }
      print '<tr><td width="2.5rem" style="min-width:2.5rem">' . $kk . '</td><td width="10.4rem" style="min-width:10.4rem">' . $vv . "</td>";
?>
                  <td width="2.5rem" style="min-width:2.5rem;white-space: nowrap;">
                    <a onClick='doDelButton("<?php print $kk; ?>");' >
                      <img src="../img/delete_button.png"
                           width=<?php print round(cached_font_size() * 32 / 24); ?>px height=<?php print round(cached_font_size() * 32 / 24); ?>px
                           style="vertical-align:middle">
                    </a>
<?php
      if($CustomerMod == 2)
      {
?>
                    <a onClick='doEditButton("<?php print $kk; ?>","<?php print $disable_loose_coins; ?>");' >
<?php
      }
      else
      {
?>
                    <a onClick='doEditButton("<?php print $kk; ?>");' >
<?php
      }
?>
                      <img src="../img/edit_button.png"
                           width=<?php print round(cached_font_size() * 32 / 24); ?>px height=<?php print round(cached_font_size() * 32 / 24); ?>px
                           style="vertical-align:middle">
                    </a>
                  </td>
                </tr>
<?php
    }
  }
?>
              </tbody>
            </table>
          </td></tr>
        </table
        <!-- enable these to send an item to add or update -->
        <input type=hidden id=AddEditItemIndex name=AddEditItemIndex value="" disabled />
        <input type=hidden id=AddEditItemOldIndex name=AddEditItemOldIndex value="" disabled />
        <input type=hidden id=AddEditItemName name=AddEditItemName value="" disabled />
<?php
  if($CustomerMod == 2)
  {
?>
        <input type=hidden id=AddEditDisableLooseCoins name=AddEditDisableLooseCoins value="" disabled />
<?php
  }
?>
        <!-- TODO add others as needed, turn off 'disabled' and process with form submit -->
      </center>
    </form>

    <input type=submit form=none formaction=
<?php
      print '"';

      if(strlen($back) > 0)
        print $back;
      else if(!empty($parseconf["vessels"]["Class3"]))
        print "initial-setup-Class3.php";
      else if(!empty($parseconf["vessels"]["Class2"]))
        print "initial-setup-Class2.php";
      else if(!empty($parseconf["vessels"]["Class1"]))
        print "initial-setup-Class1.php";
      else
        print "initial-setup5.php";

      print '"';
?>
           value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem" />

    <input type=submit value="Add New" onClick='doEditButton("");'
           style="position:absolute;bottom:0.75rem;width:5.5rem;left:9.5rem" />

    <input type=submit form=reload formaction="initial-setup-Class4.php"
           value="Re-load"
           style="position:absolute;bottom:0.75rem;width:5rem;right:10.3rem" />
    <input type=submit value="Next"
           style="position:absolute;bottom:0.75rem;width:3.33rem;right:3.33rem"
           onClick='document.getElementById("SubmitD").disabled = false; document.getElementById("Refresh").disabled = true; document.getElementById("the_form").submit();' />

    <!-- add/edit vessel -->
    <div id=edit_vessel class="modal-container">
      <input type=hidden id=old_id value="1" style="visibility:hidden" />
      <div style="background-color:#fef8fc;color:#000000;position:absolute;width:16.67rem;height:12.5rem;right:8.33rem;top:4.16rem;z-index:90;">
        <center>
          <H4 id=edit_vessel_title style="margin:4px;padding:4px">New Vessel Entry</H4>
          <table style="min-width:15rem;height:8.33rem;display:inline-block;overflow:auto;z-index:99">
            <tr>
              <td>
                <a id=vessel_id_keyboard onClick='doClickKB("vessel_id");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                <input type=numeric size=4 id=vessel_id value="1" style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
              </td>
              <td>&nbsp;&nbsp;</td>
              <td style="color:#000000">
                <input type=text id=vessel_name size=14 value="<?php print sanitize_for_html($VesselClassName); ?>" />
                <a onClick='doClickKB("vessel_name");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
<?php
  if($CustomerMod == 2)
  {
?>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>
                <input id=vessel_disable_loose_coins type=checkbox style="white-space:nowrap;">
                  Disable&nbsp;Loose&nbsp;<?php print $Coins ?>
                </input>
              </td>
            </tr>
<?php
  }
?>
          </table>
        </center>
          <input type=submit onClick='doCancelEdit()'; value="Cancel" style="position:absolute;width:4.16rem;left:2.08rem;"/>
          <input type=submit onClick='doAddEdit()'; value="Save" style="position:absolute;width:4.16rem;right:50px;"/>
      </div>
    </div>

<?php

  include "../glue/virtual_keyboard.php";

?>

  </BODY>
</HTML>

