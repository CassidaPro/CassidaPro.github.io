<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/config_utils.php";

  // use sessions for the wizard (always)
  session_start(); // using session control

  $back = do_getvar("back", "");

  if(strlen($back) > 0) // editing the global file
  {
    if(isset($_SESSION["LocalConfig"]))
      unset($_SESSION["LocalConfig"]);

    $LocalConfig = "";
  }
  else if(isset($_SESSION["LocalConfig"]))
  {
    $LocalConfig = $_SESSION["LocalConfig"];
  }
  else
  {
    $LocalConfig = "";
  }

  $parseconf = load_parseconf($LocalConfig);

  $Submit2 = do_getvar("Submit2", "");

  if($Submit2 == "Y")
  {
    $Notes  = do_getvar("notes", "");
    $Coins  = do_getvar("coins", "");
    $Straps = do_getvar("straps", "");
    $Rolls  = do_getvar("rolls", "");
    $Pulls  = do_getvar("pulls", "");
    $Process= do_getvar("process", "");
    $Preload= do_getvar("preload", "");
    $Baggies= do_getvar("baggies", "");

    // sanitization
    // TODO:  check for other things, like 'too long' and bad embedded chars

    if(empty($Notes))
      $Notes = 'Notes'; // use default if blank (TODO:  go back and re-enter?)
    if(empty($Coins))
      $Coins = 'Coins';
    if(empty($Straps))
      $Straps = 'Straps';
    if(empty($Rolls))
      $Rolls = 'Rolls';
    if(empty($Pulls))
      $Pulls = 'Pulls';
    if(empty($Process))
      $Process = 'Daily Task';
    if(empty($Preload))
      $Preload = 'Preload';
    if(empty($Baggies))
      $Baggies = 'Baggies';

    // TODO:  sanitize user input data first?  go back and re-edit?

?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=initial-setup2.php?Submit2=YY<?php
            if(strlen($back) > 0)
              print "&back=" . urlencode($back);
            print "&notes=" . urlencode($Notes);
            print "&coins=" . urlencode($Coins);
            print "&straps=" . urlencode($Straps);
            print "&rolls=" . urlencode($Rolls);
            print "&pulls=" . urlencode($Pulls);
            print "&process=" . urlencode($Process);
            print "&preload=" . urlencode($Preload);
            print "&baggies=" . urlencode($Baggies); ?>" >
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($Submit2 == "YY")
  {
    $Notes  = do_getvar("notes", "");
    $Coins  = do_getvar("coins", "");
    $Straps = do_getvar("straps", "");
    $Rolls  = do_getvar("rolls", "");
    $Pulls  = do_getvar("pulls", "");
    $Process= do_getvar("process", "");
    $Preload= do_getvar("preload", "");
    $Baggies= do_getvar("baggies", "");

    $changed = $parseconf["terms"]["Notes"] !== $Notes ||
               $parseconf["terms"]["Coins"] !== $Coins ||
               $parseconf["terms"]["Straps"] !== $Straps ||
               $parseconf["terms"]["Rolls"] !== $Rolls ||
               $parseconf["terms"]["Pulls"] !== $Pulls ||
               $parseconf["terms"]["Process"] !== $Process ||
               $parseconf["terms"]["Preload"] !== $Preload ||
               $parseconf["terms"]["Baggies"] !== $Baggies;

    if($changed)
    {
      $parseconf["terms"]["Notes"] = $Notes;
      $parseconf["terms"]["Coins"] = $Coins;
      $parseconf["terms"]["Straps"] = $Straps;
      $parseconf["terms"]["Rolls"] = $Rolls;
      $parseconf["terms"]["Pulls"] = $Pulls;
      $parseconf["terms"]["Process"] = $Process;
      $parseconf["terms"]["Preload"] = $Preload;
      $parseconf["terms"]["Baggies"] = $Baggies;

      write_configuration_file($parseconf, "initial-setup2.php", $LocalConfig);
    }

    // flow through to the next page

    header("HTTP/1.0 302 Moved Temporarily");
    if(strlen($back) > 0)
      header("Location: " . $back);
    else if(strlen($LocalConfig) > 0)
      header("Location: initial-setup3a.php");
    else
      header("Location: initial-setup3.php");

    if(strlen($back) > 0)
    {
      shell_exec("curl http://localhost:3042/reload");
    }

    exit;
  }

  // TODO:  add the ability to re-invoke this page by specifying
  //        the previous values and selecting focus on an item that
  //        has a problem

  $Notes   = do_getconf($parseconf,"terms",'Notes','Notes');
  $Coins   = do_getconf($parseconf,"terms",'Coins','Coins');
  $Straps  = do_getconf($parseconf,"terms",'Straps','Straps');
  $Rolls   = do_getconf($parseconf,"terms",'Rolls','Rolls');
  $Pulls   = do_getconf($parseconf,"terms",'Pulls','Pulls');
  $Process = do_getconf($parseconf,"terms",'Process','Daily Task');
  $Preload = do_getconf($parseconf,"terms",'Preload','Preload');
  $Baggies = do_getconf($parseconf,"terms",'Baggies','Baggies');

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Configuration for Split Recycler System</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }

      .me-and-my-shadow /* can apply to a button on white background */
      {
        box-shadow: 0 4px 4px 0 rgba(0, 0, 0, .14), 0 6px 2px -2px rgba(0, 0, 0, .2), 0 2px 10px 0 rgba(0, 0, 0, .12) !important;
      }
      .me-and-my-highlight /* can apply to a screen on dark green background */
      {
        box-shadow: 0 4px 4px 0 rgba(0, 255, 0, .14), 0 6px 2px -2px rgba(0, 255, 0, .2), 0 2px 10px 0 rgba(0, 255, 0, .12) !important;
      }
      .medium-modal /* this can become a standard; for now its just in the middle of the screen */
      {
        font-size:0.9rem;
        position:relative;
        left:6.2rem /*150px*/;
        top: 3.12rem /*75px*/;
        width: 20.83rem /*500px*/;
        height: 8.33rem /*200px*/;
        color: #000000;
        background-color: #fffff8; /* off-white for eye preservation */
        border-radius: 10px
        z-index:90;
      }
    </style>
    <script>
      function doClickQ(strID)
      {
        if(strID == "notes")
        {
          document.getElementById("the_help_text").innerHTML =
            "NOTES:  The term used to describe paper currency";
        }
        else if(strID == "coins")
        {
          document.getElementById("the_help_text").innerHTML =
            "COINS:  The term used to describe metal currency";
        }
        else if(strID == "straps")
        {
          document.getElementById("the_help_text").innerHTML =
            "STRAPS:  The term used to describe fixed bundles of paper currency";
        }
        else if(strID == "rolls")
        {
          document.getElementById("the_help_text").innerHTML =
            "ROLLS:  The term used to describe fixed bundles of coins that use standard coin counts";
        }
        else if(strID == "baggies")
        {
          document.getElementById("the_help_text").innerHTML =
            "BAGGIES:  The term used to describe fixed bundles of coins that use assigned coin batch amounts";
        }
        else if(strID == "pulls")
        {
          document.getElementById("the_help_text").innerHTML =
            "PULLS:  The term used to describe currency that is periodically removed from a vessel, and counted separately";
        }
        else if(strID == "process")
        {
          document.getElementById("the_help_text").innerHTML =
            "PROCESS:  The term used to describe the counting task itself.";
        }
        else if(strID == "preload")
        {
          document.getElementById("the_help_text").innerHTML =
            "PRELOAD:  The term used to describe the total amount of 'working' currency that is assigned to a vessel after counting";
        }

        document.getElementById("help_container").style.visibility="visible";
        document.getElementById("help_container").style.display="block";
        document.getElementById("the_cancel_button").focus();
      }
      function doClickKB(strID)
      {
        do_vkey_single(strID, null);
      }
    </script>
  </HEAD>
  <BODY bgcolor="#101824" text="#ffffe0">
    <form id=none></form>
    <center>
      <b>
        <H1 style="margin:0;padding:0">
<?php
  if(strlen($back) != 0)
  {
?>
          Split Recycler - Edit Config
<?php
  }
  else if(strlen($LocalConfig) != 0)
  {
?>
          Split Recycler - New Config
<?php
  }
  else
  {
?>
          Split Recycler - Initial Setup
<?php
  }
?>
        </H1>
        <H4 style="margin:0;margin-bottom:0.83rem !important;padding:0">Assigned Terms</H4>
      </b>
    </center>
    <form id=none method=GET></form>
    <form id=reload>
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <form id=the_form method=GET>
      <input type=hidden name="Submit2" value="Y" style="visibility:hidden" />
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
      <center>
        <table width="85%">
          <tr>
            <td width="30%">
              <a onClick='doClickQ("notes");'><img src="../img/help_button.png" width=24 height=24 style="vertical-align:top"></a>
              'Notes' Term:
            </td>
            <td width="70%" style="font-size:0.83rem;margin-right:10px">
              <input type=text size=20 id=notes name=notes style="width:12.5rem"
                     value=<?php print '"' . sanitize_for_html($Notes) . '"'; ?> />
              <a onClick='doClickKB("notes");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a onClick='doClickQ("coins");'><img src="../img/help_button.png" width=24 height=24 style="vertical-align:top"></a>
              'Coins' Term:
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=20 id=coins name=coins style="width:12.5rem"
                     value=<?php print '"' . sanitize_for_html($Coins) . '"'; ?> />
              <a onClick='doClickKB("coins");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a onClick='doClickQ("straps");'><img src="../img/help_button.png" width=24 height=24 style="vertical-align:top"></a>
              'Straps' Term:
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=20 id=straps name=straps style="width:12.5rem"
                     value=<?php print '"' . sanitize_for_html($Straps) . '"'; ?> />
              <a onClick='doClickKB("straps");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a onClick='doClickQ("rolls");'><img src="../img/help_button.png" width=24 height=24 style="vertical-align:top"></a>
              'Rolls' Term:
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=20 id=rolls name=rolls style="width:12.5rem"
                     value=<?php print '"' . sanitize_for_html($Rolls) . '"'; ?> />
              <a onClick='doClickKB("rolls");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a onClick='doClickQ("baggies");'><img src="../img/help_button.png" width=24 height=24 style="vertical-align:top"></a>
              'Baggies' Term:
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=20 id=baggies name=baggies style="width:12.5rem"
                     value=<?php print '"' . sanitize_for_html($Baggies) . '"'; ?> />
              <a onClick='doClickKB("baggies");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a onClick='doClickQ("pulls");'><img src="../img/help_button.png" width=24 height=24 style="vertical-align:top"></a>
              'Pulls' Term:
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=20 id=pulls name=pulls style="width:12.5rem"
                     value=<?php print '"' . sanitize_for_html($Pulls) . '"'; ?> />
              <a onClick='doClickKB("pulls");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a onClick='doClickQ("process");'><img src="../img/help_button.png" width=24 height=24 style="vertical-align:top"></a>
              'Process' Term:
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=20 id=process name=process style="width:12.5rem"
                     value=<?php print '"' . sanitize_for_html($Process) . '"'; ?> />
              <a onClick='doClickKB("process");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
          <tr>
            <td>
              <a onClick='doClickQ("preload");'><img src="../img/help_button.png" width=24 height=24 style="vertical-align:top"></a>
              'Preload' Term:
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=20 id=preload name=preload style="width:12.5rem"
                     value=<?php print '"' . sanitize_for_html($Preload) . '"'; ?> />
              <a onClick='doClickKB("preload");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
        </table>
      </center>
    </form>

    <input type=submit form=none
           formaction="<?php if(strlen($back) > 0) print $back; else print "initial-setup.php"; ?>"
           value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem"/>
    <input type=submit form=reload
           formaction="initial-setup2.php"
           value="Re-load" style="position:absolute;bottom:0.75rem;width:5rem;left:14.2rem"/>
    <input type=submit form=the_form
           formaction="initial-setup2.php"
           value="Next" style="position:absolute;bottom:0.75rem;width:3.33rem;right:3.33rem"/>

    <!-- popup help dialog goes here - content is dynamically assigned -->
    <div id=help_container class="modal-container">
      <div class="me-and-my-highlight medium-modal">
        <div id="the_help_text" style="margin:20px;margin-top:30px;height:140px">
          Hello, World
        </div>
        <button id=the_cancel_button type=cancel class="me-and-my-shadow"
                onclick='document.getElementById("help_container").style.display="none";'
                style="position:relative;width:4.16rem;left:8.33rem;bottom:0px" >Close</botton>
      </div>
    </div>

<?php

  include "../glue/virtual_keyboard.php";

?>

  </BODY>
</HTML>

