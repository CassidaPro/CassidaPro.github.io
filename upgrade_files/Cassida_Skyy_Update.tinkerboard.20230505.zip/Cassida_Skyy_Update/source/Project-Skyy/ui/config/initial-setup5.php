<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include '../glue/config_utils.php';

  // use sessions for the wizard (always)
  session_start(); // using session control

  $back = do_getvar("back", "");

  if(strlen($back) > 0) // editing the global file
  {
    if(isset($_SESSION["LocalConfig"]))
      unset($_SESSION["LocalConfig"]);

    $LocalConfig = "";
  }
  else if(isset($_SESSION["LocalConfig"]))
  {
    $LocalConfig = $_SESSION["LocalConfig"];
  }
  else
  {
    $LocalConfig = "";
  }

  $parseconf = load_parseconf($LocalConfig);

  $parsestats = load_parsestats();
  $Equipment = coin_counter_equipment($parsestats);

  $Submit5=do_getvar("Submit5", "");

  if($Submit5 == "Y")
  {
    $Class1Button = do_getvar("Class1Button", "");
    $Class2Button = do_getvar("Class2Button", "");
    $Class3Button = do_getvar("Class3Button", "");
    $Class4Button = do_getvar("Class4Button", "");
    $Class5Button = do_getvar("Class5Button", "");
    $BuildButton  = do_getvar("BuildButton", "");
    $VerifyButton = do_getvar("VerifyButton", "");

    $Class1Icon = do_getvar("Class1Icon", "");
    $Class2Icon = do_getvar("Class2Icon", "");
    $Class3Icon = do_getvar("Class3Icon", "");
    $Class4Icon = do_getvar("Class4Icon", "");
    $Class5Icon = do_getvar("Class5Icon", "");
    $BuildIcon  = do_getvar("BuildIcon", "");
    $VerifyIcon = do_getvar("VerifyIcon", "");

    // sanitization
    // TODO:  check for other things, like 'too long' and bad embedded chars

    if(empty($Class1Button))
      $Class1Button = 'Safe'; // use default if blank (TODO:  go back and re-enter?)
    if(empty($Class2Button))
      $Class2Button = 'Cash Drawer';
    if(empty($Class3Button))
      $Class3Button = 'Count Tills';
    if(empty($BuildButton))
      $BuildButton = 'Build Tills';
    if(empty($VerifyButton))
      $VerifyButton = 'Verify Deposits';

    // TODO:  sanitize user input data first?  go back and re-edit?

?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=initial-setup5.php?Submit5=YY<?php
            if(strlen($back) > 0)
              print "&back=" . urlencode($back);
            print "&Class1Button=" . urlencode($Class1Button);
            print "&Class2Button=" . urlencode($Class2Button);
            print "&Class3Button=" . urlencode($Class3Button);
            print "&Class4Button=" . urlencode($Class4Button);
            print "&Class5Button=" . urlencode($Class5Button);
            print "&BuildButton=" . urlencode($BuildButton);
            print "&VerifyButton=" . urlencode($VerifyButton);
            print "&Class1Icon=" . urlencode($Class1Icon);
            print "&Class2Icon=" . urlencode($Class2Icon);
            print "&Class3Icon=" . urlencode($Class3Icon);
            print "&Class4Icon=" . urlencode($Class4Icon);
            print "&Class5Icon=" . urlencode($Class5Icon);
            print "&BuildIcon=" . urlencode($BuildIcon);
            print "&VerifyIcon=" . urlencode($VerifyIcon);
            ?>" >
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($Submit5 == "YY")
  {
    $Class1Button = do_getvar("Class1Button", "");
    $Class2Button = do_getvar("Class2Button", "");
    $Class3Button = do_getvar("Class3Button", "");
    $Class4Button = do_getvar("Class4Button", "");
    $Class5Button = do_getvar("Class5Button", "");
    $BuildButton  = do_getvar("BuildButton", "");
    $VerifyButton = do_getvar("VerifyButton", "");

    $Class1Icon = do_getvar("Class1Icon", "");
    $Class2Icon = do_getvar("Class2Icon", "");
    $Class3Icon = do_getvar("Class3Icon", "");
    $Class4Icon = do_getvar("Class4Icon", "");
    $Class5Icon = do_getvar("Class5Icon", "");
    $BuildIcon  = do_getvar("BuildIcon", "");
    $VerifyIcon = do_getvar("VerifyIcon", "");

    $Class1Btn = array_key_exists("Class1Button", $parseconf["terms"])
               ? $parseconf["terms"]["Class1Button"] : "";
    $Class2Btn = array_key_exists("Class2Button", $parseconf["terms"])
               ? $parseconf["terms"]["Class2Button"] : "";
    $Class3Btn = array_key_exists("Class3Button", $parseconf["terms"])
               ? $parseconf["terms"]["Class3Button"] : "";
    $Class4Btn = array_key_exists("Class4Button", $parseconf["terms"])
               ? $parseconf["terms"]["Class4Button"] : "";
    $Class5Btn = array_key_exists("Class5Button", $parseconf["terms"])
               ? $parseconf["terms"]["Class5Button"] : "";
    $BuildBtn  = array_key_exists("BuildButton", $parseconf["terms"])
               ? $parseconf["terms"]["BuildButton"] : "";
    $VerifyBtn = array_key_exists("VerifyButton", $parseconf["terms"])
               ? $parseconf["terms"]["VerifyButton"] : "";

    $changed = $Class1Btn !== $Class1Button ||
               $Class2Btn !== $Class2Button ||
               $Class3Btn !== $Class3Button ||
               $Class4Btn !== $Class4Button ||
               $Class5Btn !== $Class5Button ||
               $BuildBtn !== $BuildButton ||
               $VerifyBtn !== $VerifyButton ||
               $parseconf["icons"]["Class1"] !== $Class1Icon ||
               $parseconf["icons"]["Class2"] !== $Class2Icon ||
               $parseconf["icons"]["Class3"] !== $Class3Icon ||
               (empty($parseconf["icons"]["Class4"]) ? !empty($Class4Icon)
                : $parseconf["icons"]["Class4"] !== $Class4Icon) ||
               (empty($parseconf["icons"]["Class5"]) ? !empty($Class4Icon)
                : $parseconf["icons"]["Class5"] !== $Class5Icon) ||
               $parseconf["icons"]["Build"] !== $BuildIcon ||
               $parseconf["icons"]["Verify"] !== $VerifyIcon;

    if($changed)
    {
      $parseconf["terms"]["Class1Button"] = $Class1Button;
      $parseconf["terms"]["Class2Button"] = $Class2Button;
      $parseconf["terms"]["Class3Button"] = $Class3Button;

      if(empty($Class4Button))
        unset($parseconf["terms"]["Class4Button"]); // = false;
      else
        $parseconf["terms"]["Class4Button"] = $Class4Button;

      if(empty($Class5Button))
        unset($parseconf["terms"]["Class5Button"]); // = false;
      else
        $parseconf["terms"]["Class5Button"] = $Class5Button;

      $parseconf["terms"]["BuildButton"] = $BuildButton;
      $parseconf["terms"]["VerifyButton"] = $VerifyButton;

      $parseconf["icons"]["Class1"] = $Class1Icon;
      $parseconf["icons"]["Class2"] = $Class2Icon;
      $parseconf["icons"]["Class3"] = $Class3Icon;

      if(empty($Class4Icon))
        unset($parseconf["icons"]["Class4"]); // = false;
      else
        $parseconf["icons"]["Class4"] = $Class4Icon;

      if(empty($Class5Icon))
        unset($parseconf["icons"]["Class5"]); // = false;
      else
        $parseconf["icons"]["Class5"] = $Class5Icon;

      $parseconf["icons"]["Build"] = $BuildIcon;
      $parseconf["icons"]["Verify"] = $VerifyIcon;

      write_configuration_file($parseconf, "initial-setup5.php", $LocalConfig);
    }

    // flow through to the next page

    header("HTTP/1.0 302 Moved Temporarily");
    // the next one I go to depends on what I've configured

    if(strlen($back) > 0)
      header("Location: " . $back);
    else if(!empty($parseconf["vessels"]["Class1"]))
      header("Location: initial-setup-Class1.php");
    else if(!empty($parseconf["vessels"]["Class2"]))
      header("Location: initial-setup-Class2.php");
    else if(!empty($parseconf["vessels"]["Class3"]))
      header("Location: initial-setup-Class3.php");
    else if(!empty($parseconf["vessels"]["Class4"]))
      header("Location: initial-setup-Class4.php");
    else if(!empty($parseconf["vessels"]["Class5"]))
      header("Location: initial-setup-Class5.php");
    else if(!empty($parseconf["vessels"]["Build"]) ||
            !empty($parseconf["vessels"]["Verify"]))
      header("Location: initial-setup-Build-Verify.php");
    else
      header("Location: initial-setup6.php");

    if(strlen($back) > 0)
    {
      shell_exec("curl http://localhost:3042/reload");
    }

    exit;
  }

  // TODO:  add the ability to re-invoke this page by specifying
  //        the previous values and selecting focus on an item that
  //        has a problem

  $Class1Button = do_getconf($parseconf,"terms",'Class1Button','Class1Button');
  $Class2Button = do_getconf($parseconf,"terms",'Class2Button','Class2Button');
  $Class3Button = do_getconf($parseconf,"terms",'Class3Button','Class3Button');
  $Class4Button = do_getconf($parseconf,"terms",'Class4Button','Class4Button');
  $Class5Button = do_getconf($parseconf,"terms",'Class5Button','Class5Button');
  $BuildButton  = do_getconf($parseconf,"terms",'BuildButton','BuildButton');
  $VerifyButton = do_getconf($parseconf,"terms",'VerifyButton','Daily Task');

  $Class1 = do_getconf($parseconf, "vessels", "Class1", "");
  $Class2 = do_getconf($parseconf, "vessels", "Class2", "");
  $Class3 = do_getconf($parseconf, "vessels", "Class3", "");
  $Class4 = do_getconf($parseconf, "vessels", "Class4", "");
  $Class5 = do_getconf($parseconf, "vessels", "Class5", "");

  $Build = do_getconf($parseconf, "vessels", "Build", "");
  $Verify = do_getconf($parseconf, "vessels", "Verify", "");

  $Class1Icon = do_getconf($parseconf, "icons", "Class1", "safe.svg");
  $Class2Icon = do_getconf($parseconf, "icons", "Class2", "drawer.svg");
  $Class3Icon = do_getconf($parseconf, "icons", "Class3", "till.svg");
  $Class4Icon = do_getconf($parseconf, "icons", "Class4", "coins.svg");
  $Class5Icon = do_getconf($parseconf, "icons", "Class5", "coins.svg");

  $BuildIcon = do_getconf($parseconf, "icons", "Build", "build_tills.png");
  $VerifyIcon = do_getconf($parseconf, "icons", "Verify", "notes.png");


  $Process = do_getconf($parseconf,"terms",'Process','Daily Tasks');



?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Configuration for Split Recycler System</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link href="../css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      html
      {
        background-color:#0a240a;
        color:#ffffe0;
      }
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }
    </style>
    <script>
      var strIconFor = "";
      function doClickIcon(strID)
      {
        strIconFor = strID;
        document.getElementById("icon_list").style.display="block";
        document.getElementById("icon_list").style.visibility="visible";
      }

      function doSelectIcon(strID)
      {
        // if strID is not blank, select the icon

        if(strID > "")
        {
          document.getElementById(strIconFor + "Icon").value = strID;
          document.getElementById(strIconFor + "IconIcon").src = "../img/" + strID;
        }

        document.getElementById("icon_list").style.display="none";
        document.getElementById("icon_list").style.visibility="hidden";
        strIconFor = "";
      }

      function doClickKB(strID)
      {
        do_vkey_single(strID, null);
      }
    </script>
  </HEAD>
  <BODY bgcolor="#101824" text="#ffffe0">
    <form id=none></form>
    <form id=reload>
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <center>
      <b>
        <H1 style="margin:0;padding:0">
<?php
  if(strlen($back) != 0)
  {
?>
          Split Recycler - Edit Config
<?php
  }
  else if(strlen($LocalConfig) != 0)
  {
?>
          Split Recycler - New Config
<?php
  }
  else
  {
?>
          Split Recycler - Initial Setup
<?php
  }
?>
        </H1>
        <H4 style="margin:0;margin-bottom:0.83rem !important;padding:0"><?php print $Process; ?> - Button Text and Icons</H4>
      </b>
    </center>
    <form id=the_form method=GET>
      <input type=hidden name="Submit5" value="Y" style="visibility:hidden" />
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
      <center>
        <table width="65%">
<?php
  if(!empty($Class1))
  {
?>
          <tr>
            <td width="40%"><?php print $Class1; ?> Button:</td>
            <td width="10%" class="primary-fill waves-effect" style="text-align:center;padding:2px;">
              <input type=hidden id=Class1Icon name=Class1Icon value="<?php print $Class1Icon; ?>" style="visibility:hidden" />
              <a onClick='doClickIcon("Class1");'>
                <img class="invertible-icon"  id=Class1IconIcon src="../img/<?php print $Class1Icon; ?>" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
            <td width="50%" style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Class1Button name=Class1Button style="width:8.33rem"
                     value=<?php print '"' . sanitize_for_html($Class1Button) . '"'; ?> />
              <a onClick='doClickKB("Class1Button");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
<?php
  }
  if(!empty($Class2))
  {
?>
          <tr>
            <td><?php print $Class2; ?> Button:</td>
            <td class="primary-fill waves-effect" style="text-align:center;padding:2px;">
              <input type=hidden id=Class2Icon name=Class2Icon value="<?php print $Class2Icon; ?>" style="visibility:hidden" />
              <a onClick='doClickIcon("Class2");'>
                <img class="invertible-icon"  id=Class2IconIcon src="../img/<?php print $Class2Icon; ?>" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Class2Button name=Class2Button style="width:8.33rem"
                     value=<?php print '"' . sanitize_for_html($Class2Button) . '"'; ?> />
              <a onClick='doClickKB("Class2Button");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
<?php
  }
  if(!empty($Class3))
  {
?>
          <tr>
            <td><?php print $Class3; ?> Button:</td>
            <td class="primary-fill waves-effect" style="text-align:center;padding:2px;">
              <input type=hidden id=Class3Icon name=Class3Icon value="<?php print $Class3Icon; ?>" style="visibility:hidden" />
              <a onClick='doClickIcon("Class3");'>
                <img class="invertible-icon"  id=Class3IconIcon src="../img/<?php print $Class3Icon; ?>" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Class3Button name=Class3Button style="width:8.33rem"
                     value=<?php print '"' . sanitize_for_html($Class3Button) . '"'; ?> />
              <a onClick='doClickKB("Class3Button");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
<?php
  }
  if(!empty($Class4))
  {
?>
          <tr>
            <td><?php print $Class4; ?> Button:</td>
            <td class="primary-fill waves-effect" style="text-align:center;padding:2px;">
              <input type=hidden id=Class4Icon name=Class4Icon value="<?php print $Class4Icon; ?>" style="visibility:hidden" />
              <a onClick='doClickIcon("Class4");'>
                <img class="invertible-icon"  id=Class4IconIcon src="../img/<?php print $Class4Icon; ?>" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Class4Button name=Class4Button style="width:8.33rem"
                     value=<?php print '"' . sanitize_for_html($Class4Button) . '"'; ?> />
              <a onClick='doClickKB("Class4Button");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
<?php
  }
  if(!empty($Class5))
  {
?>
          <tr>
            <td><?php print $Class5; ?> Button:</td>
            <td class="primary-fill waves-effect" style="text-align:center;padding:2px;">
              <input type=hidden id=Class5Icon name=Class5Icon value="<?php print $Class5Icon; ?>" style="visibility:hidden" />
              <a onClick='doClickIcon("Class5");'>
                <img class="invertible-icon"  id=Class5IconIcon src="../img/<?php print $Class5Icon; ?>" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Class5Button name=Class5Button style="width:8.33rem"
                     value=<?php print '"' . sanitize_for_html($Class5Button) . '"'; ?> />
              <a onClick='doClickKB("Class5Button");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
<?php
  }
  if(!empty($Build))
  {
?>
          <tr>
            <td>Build Button:</td>
            <td class="primary-fill waves-effect" style="text-align:center;padding:2px;">
              <input type=hidden id=BuildIcon name=BuildIcon value="<?php print $BuildIcon; ?>" style="visibility:hidden" />
              <a onClick='doClickIcon("Build");'>
                <img class="invertible-icon"  id=BuildIconIcon src="../img/<?php print $BuildIcon; ?>" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=BuildButton name=BuildButton style="width:8.33rem"
                     value=<?php print '"' . sanitize_for_html($BuildButton) . '"'; ?> />
              <a onClick='doClickKB("BuildButton");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
<?php
  }
  if(!empty($Verify))
  {
?>
          <tr>
            <td>Verify Button:</td>
            <td class="primary-fill waves-effect" style="text-align:center;padding:2px;">
              <input type=hidden id=VerifyIcon name=VerifyIcon value="<?php print $VerifyIcon; ?>" style="visibility:hidden" />
              <a onClick='doClickIcon("Verify");'>
                <img class="invertible-icon" id=VerifyIconIcon src="../img/<?php print $VerifyIcon; ?>" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=VerifyButton name=VerifyButton style="width:8.33rem"
                     value=<?php print '"' . sanitize_for_html($VerifyButton) . '"'; ?> />
              <a onClick='doClickKB("VerifyButton");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
<?php
  }
?>
        </table>
      </center>
    </form>

    <!-- icon list -->
    <div id=icon_list class="modal-container">
      <div style="background-color:#fef8fc;color:#000000;position:absolute;width:16.67rem;height:12.5rem;right:8.33rem;top:4.16rem">
        <center>
          <H4 style="margin:4px;padding:4px">Choose an icon from the list</H4>
          <table style="min-width:12.5rem;height:8.33rem;display:inline-block;overflow:auto;z-index:99">
<?php

//  $file_list = [ "safe.svg", "register.svg", "drawer.svg", "build_tills.png", "notes.svg", "delete_button.png" ]; // for testing
  $Solution = shell_exec("/usr/bin/find /var/www/html/img -name '*.svg' -print0 | xargs -r -L 1 -0 ls | sed 's/\/var\/www\/html\/img\///' | sort -u")
            . shell_exec("/usr/bin/find /var/www/html/img -name '*.png' -print0 | xargs -r -L 1 -0 ls | sed 's/\/var\/www\/html\/img\///' | sort -u");
  $file_list = explode("\n", $Solution);

  foreach($file_list as $ff)
  {
    $filename=rtrim(ltrim($ff));
    if(strlen($filename) > 0 &&
       $filename != "daily.svg" &&
       $filename != "weekly.svg" &&
       $filename != "monthly.svg" &&
       $filename != "cs400.svg" &&
       $filename != "c300.png" &&
       $filename != "c300.orig.png" && // TEMPORARY, dev file name
       (substr($filename,0,4) != "c300" || $Equipment == "C300") &&
       (substr($filename,0,4) != "c400" || $Equipment == "C400") &&
       $filename != "zeus.svg" &&
       $filename != "norolledcoins.png" &&
       $filename != "incomplete-task.png" &&
       $filename != "complete-task.png" &&
       substr($filename, 0, 7) != "Loading" &&
       substr($filename, 0, 4) != "srb-" &&
       substr($filename, 0, 5) != "twin-" &&
       substr($filename, 0, 7) != "refill-" &&
       substr($filename, 0, 8) != "recycler" &&
       $filename != "baseline-backspace-24px.svg" )
    {
?>
            <tr>
              <td border=1 width=50px class="primary-fill waves-effect" style="text-align:center;padding:2px;">
                <a onclick='doSelectIcon("<?php print $filename; ?>");'>
                  <img class="invertible-icon" src="../img/<?php print $filename; ?>" width="<?php print cached_font_size() * 1.33; ?>px" height="<?php print cached_font_size() * 1.33; ?>px" style="vertical-align:middle">
                </a>
              </td>
              <td>&nbsp;&nbsp;</td>
              <td style="color:#000000">
                <?php print $filename; ?>
              </td>
            </tr>
<?php
    }
  }
?>
          </table>
        </center>
        <input type=submit onClick='doSelectIcon("")'; value="Cancel" style="margin-top:0.3rem;position:absolute;width:4.16rem;right:6.25rem;"/>
      </div>
    </div>

    <input type=submit form=none
           formaction="<?php if(strlen($back) > 0) print $back; else print "initial-setup4.php"; ?>"
           value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem"/>
    <input type=submit form=reload formaction="initial-setup5.php"
           value="Re-load" style="position:absolute;bottom:0.75rem;width:5rem;left:14.2rem"/>
    <input type=submit form=the_form formaction="initial-setup5.php"
           value="Next" style="position:absolute;bottom:0.75rem;width:3.33rem;right:3.33rem"/>

<?php

  include "../glue/virtual_keyboard.php";

?>

  </BODY>
</HTML>

