<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Daily Tasks - Current Date</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <!-- this hack moves the modal dialog up and left -->
    <style>
<?php
  set_ideal_font_height();
?>
      /* OLD DATEPICKER FIXES */
      .orig-select-month
      {
        min-width: 7.5rem /*180px*/;
        width: 7.5rem /*180px*/ !important;
        margin-left: 0px;
        margin-right: 0px;
      }
      .datepicker-controls .select-month input
      {
        width: 3.75rem /*90px*/;
      }
      .dropdown-content
      {
        visibility:hidden;
        display:none;
      }
      /* END OLD DATEPICKER FIXES */

      .input-field /* moved from style.css, ONLY used here */
      {
        position: relative;
        margin-bottom: 1rem;
      }

      #date-box
      {
        margin-top: 40px;
        margin-left: 10%;
      }

      #date-input
      {
        font-size:24px;
      }

      .input-field.col label
      {
        left: 0.75rem;
      }

      .input-field > label
      {
        color: #9e9e9e;
        position: absolute;
        top: 0;
        left: 0;
        font-size: 1rem;
        cursor: text;
        transform-origin: 0% 100%;
        text-align: initial;
        transform: translateY(12px);
      }

      .input-field .helper-text
      {
        position: relative;
        min-height: 0.75rem;
        display: block;
        font-size: 0.5rem;
        color: rgba(0, 0, 0, 0.54);
      }

      .input-field .helper-text::after
      {
        opacity: 1;
        position: absolute;
        top: 0;
        left: 0;
      }

      .helper-text
      {
        font-size:0.67rem !important;
      }

      /* see which of these are still necessary */

      .date-text
      {
        font-size: 40px !important;
        margin-top: 40px;
      }

      .datepicker-select, .caret
      {
        visibility:hidden;
        display:none;
      }

      /* TODO:  consolidate 'datepicker' stuff into a NEW class and ELIMINATE these */
      /*        this used to be in style.css but as it only is used HERE, it should be HERE */

      .datepicker-modal /* this can become a standard; for now its just in the middle of the screen */
      {
        position:relative;
        left: 1.5rem;
        top: 2.75rem;
        width: 70%;
        color: #000000;
        background-color: #fffff8; /* off-white for eye preservation */
        border-radius: 0.4rem /*10px*/; /* rounded corners */
        z-index: 100;
        min-width: 12.5rem; /*300px*/
        max-width: 26.04rem; /*625px*/
        min-height: 12rem;
        max-height: none;
      }

      .datepicker_guts
      {
        position:absolute;
        font-size:1.2rem;
        font-weight:300;
        line-height:1.1em;
        left:3rem;
        top:3rem;
        min-height:12rem;
        text-align:center;
        margin:0;
        padding:0;
        display:block
      }

      /* datepicker styles from style.css - moved here to clean things up */

      .datepicker-container.modal-content
      {
        display: -webkit-box;
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-orient: vertical;
        -webkit-box-direction: normal;
        -webkit-flex-direction: column;
            -ms-flex-direction: column;
                flex-direction: column;
        padding: 0;
      }

      .datepicker-controls
      {
        display: -webkit-box;
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-pack: justify;
        -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
                justify-content: space-between;
        width: 11.6rem; /*280px*/
        margin: 0 auto;
      }

      .datepicker-controls .selects-container
      {
        display: -webkit-box;
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex;
      }

      .datepicker-controls .select-wrapper input
      {
        border-bottom: none;
        text-align: center;
        margin: 0;
      }

      .datepicker-controls .select-wrapper input:focus
      {
        border-bottom: none;
      }

      .datepicker-controls .select-wrapper .caret
      {
        display: none;
      }

      .datepicker-controls .select-year input
      {
        width: 2.08rem; /*50px*/
      }

      .datepicker-controls .select-month input
      {
        width: 2.91em; /*70px;*/
      }

      .month-prev, .month-next
      {
        margin-top: 4px;
        cursor: pointer;
        background-color: transparent;
        border: none;
      }

      /* Date Display */
      .datepicker-date-display
      {
        -webkit-box-flex: 1;
        -webkit-flex: 1 auto;
            -ms-flex: 1 auto;
                flex: 1 auto;
        color: #fff;
        padding: 0.83rem 0.91rem;
        font-weight: 500;
      }

      .datepicker-date-display .year-text
      {
        display: block;
        font-size: 1.5rem;
        line-height: 1.04rem; /*25px;*/
        color: rgba(255, 255, 255, 0.7);
      }

      .datepicker-date-display .date-text
      {
        display: block;
        font-size: 2.8rem;
        line-height: 1.95rem; /*47px;*/
        font-weight: 500;
      }

      /* Calendar */
      .datepicker-calendar-container
      {
        -webkit-box-flex: 2.5;
        -webkit-flex: 2.5 auto;
            -ms-flex: 2.5 auto;
                flex: 2.5 auto;
      }

      .datepicker-table
      {
        width: 11.6rem; /*280px*/
        font-size: 1rem;
        margin: 0 auto;
      }

      .datepicker-table thead
      {
        border-bottom: none;
      }

      .datepicker-table th
      {
        padding 0.41rem 0.20rem;
        text-align: center;
      }

      .datepicker-table tr
      {
        border: none;
      }

      .datepicker-table abbr
      {
        text-decoration: none;
        color: #999;
      }

      .datepicker-table td
      {
        border-radius: 50%;
        padding: 0;
        background-color: transparent !important;
      }

      .datepicker-table td.is-today
      {
        color: #26a69a;
      }

      .has-focus /* a bug fix */
      {
        background-color: rgba(43, 161, 150, 0.25) !important; /* the color of the blue highlight on the day */
        font-weight:700;
        outline: none;
      }

      .datepicker-table td.is-outside-current-month, .datepicker-table td.is-disabled
      {
        color: rgba(0, 0, 0, 0.3);
        pointer-events: none;
      }

      .datepicker-day-button
      {
        font-size:100%;
        background-color: transparent;
        border: none;
        line-height: 1.58rem; /*38px*/
        display: block;
        width: 100%;
        border-radius: 50%;
        padding: 0 5px;
        cursor: pointer;
        color: inherit;
      }

/*
      .datepicker-day-button:focus
      {
        background-color: rgba(43, 161, 150, 0.25) !important;
        outline: none;
      }
*/
      /* Footer */
      .datepicker-footer
      {
        width: 280px;
        margin: 0 auto;
        padding-bottom: 5px;
        display: -webkit-box;
        display: -webkit-flex;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-pack: justify;
        -webkit-justify-content: space-between;
            -ms-flex-pack: justify;
                justify-content: space-between;
      }

      .datepicker-cancel,
      .datepicker-clear,
      .datepicker-today,
      .datepicker-done
      {
/*        color: #26a69a; */
        padding: 0 1rem;
      }

      .datepicker-clear
      {
        color: #F44336;
      }

      .datepicker-container.modal-content
      {
        -webkit-box-orient: horizontal;
        -webkit-box-direction: normal;
        -webkit-flex-direction: row;
            -ms-flex-direction: row;
                flex-direction: row;
      }
      .datepicker-date-display
      {
        -webkit-box-flex: 0;
        -webkit-flex: 0 1 270px;
            -ms-flex: 0 1 270px;
                flex: 0 1 270px;
      }
      .datepicker-controls,
      .datepicker-table,
      .datepicker-footer
      {
        width: 13.3rem; /*320px;*/
      }

    </style>

  </head>
<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">Enter Date of Record</a>
      <div class="area">START</div>
    </div>
  </nav>
  <form id="none"></form>
  <form name="submitDate" id="submitDate" action="/glue/set-date.php" method="post">
    <input name="date" id="the_date" type="hidden" style="visibility:hidden" value="" />
  </form>
  <div class="container">
    <div class="row center">
      <br/><br/><!-- move it down towards the middle of the page -->
      <div id="date-box" class="input-field col s9 center">
        <label for="date">Date of Record</label><br>
        <input id="date-input" type="text" class="special-text-input datepicker" required>
        <span class="helper-text" data-error="wrong" data-success="right">Enter Today's Date</span>
        <!-- span class="helper-text" data-error="wrong" data-success="right">Touch to Enter Date of Sales Receipts</span -->
      </div>
    </div>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;left:0px">
      <button id="back" type=submit form=none formaction="/" class="btn btn-small waves-effect primary-fill btn-shadow">
        BACK
      </button>
    </div>
    <div class="next-button">
      <button id="done" class="btn btn-small waves-effect primary-fill btn-shadow" type="submit" form="submitDate">
        DONE
      </button>
    </div>
  </div>

  <!-- date picker - pick-a-little talk-a-little chick-chick-chick -->
  <div id=popup_alert class="modal-container"
       style="position:absolute;top:0px;visibility:hidden;background-color: rgba(0, 0, 0, 0.4) !important">
    <div id=datepicker_dlg class="datepicker-modal me-and-my-shadow datepicker_modal">
      <div id=datepicker_guts class="datepicker_guts">
        The Content
      </div>
    </div>
  </div>

  <!--  Scripts-->
  <script src="js/custom.js"></script>

  <script>
    var the_date, other_date;     // assigned via 'getDate()'
    var cur_date, other_cur_date; // temp values for datepicker
    var cal_year, cal_month;      // year and month for displayed calendar

    function getDate() // gets the date of record from skyy
    {
      var myRequest = new Request("/glue/taskinfo.php");

      fetch(myRequest)
        .then(function(response)
              {
                if (!response.ok)
                {
                  console.log("status", response.status);
                }
                return  response.text();
              })
        .then(function(text)
              {
                text = text.trim();
                if(text.length == 0) // tracking zero-length return as skyy not running
                {
                  // TODO:  something??
                }
                else
                {
                  var xx = (new window.DOMParser()).parseFromString(text, "text/xml");

                  if(xx == null
                     || xx.getElementsByTagName("taskinfo") == null
                     || xx.getElementsByTagName("taskinfo")[0] == null
                     || xx.getElementsByTagName("taskinfo")[0].childNodes == null
                     || xx.getElementsByTagName("taskinfo")[0].childNodes[0] == null) // server error
                  {
                    console.log("oops no taskinfo");
                  }
                  else
                  {
                    var _the_date = xx.getElementsByTagName("datestr")[0];
                    var _the_other_date = xx.getElementsByTagName("date")[0];

                    if(_the_date && _the_date.childNodes.length > 0)
                    {
                      the_date /*today*/ = _the_date.childNodes[0].nodeValue;
                      console.log("The Date is " + the_date /*today*/);
                      document.getElementById("date-input").value = the_date /*today*/;
                    }
                    if(_the_other_date && _the_other_date.childNodes.length > 0)
                    {
                      other_date = _the_other_date.childNodes[0].nodeValue;
                      console.log("The OTHER Date is " + other_date);
                      document.getElementById("the_date").value = other_date /*today*/;
                    }

                    _the_date = null;
                    _the_other_date = null;
                  }
                  xx = null;
                }

                myRequest = null;
              });
    }

    function CalendarClick(evt)
    {
      var ww = evt.currentTarget; // what window am I?
      var year, month, day, dow;


      var xx = document.getElementsByClassName("has-focus");

      if(xx != null)
      {
        for(var ii=0; ii < xx.length; ii++) // should be only 1
        {
            xx[ii].classList.remove("has-focus"); // fixing a chrome bug
        }
      }

      xx = null;
      ww.classList.add("has-focus"); // fixing a chrome bug - add this class to the list for button I click


      year = ww.getAttribute("data-year");
      month = ww.getAttribute("data-month");
      day = ww.getAttribute("data-day");

      dow = GetDayOfWeek(year, month, day);
      document.getElementById("dddmmmd").innerHTML = GetDayName(dow) + ', ' + GetMonthName(month) + ' ' + day;

      if (year.length < 2)
        year = '0' + year;
      if (year.length < 3)
        year = '0' + year;
      if (year.length < 4)
        year = '0' + year;

      cur_date = GetMonthName(month) + ' ' + day + ', ' + year

      if (month.length < 2)
        month = '0' + month;

      if (day.length < 2)
        day = '0' + day;

      other_cur_date = month + '/' + day + '/' + year

      console.log(cur_date + ' ' + other_cur_date);

      ww= null;
    }

    function DisplayDatePickerTable()
    {
      var year, month, day, xx, ii, nn, dd, ww, tmp;

      tmp = other_cur_date.split('/');
      month = tmp[0] * 1;
      day = tmp[1] * 1;
      year = tmp[2] * 1;
      tmp = null;

      xx = // datepicker-table content - move this part into its own function
           '        <table class="datepicker-table" role="grid" aria-labelledby="datepicker-title-wl" cellspacing="0" cellpadding="0">\n'
         + '          <thead>\n'
         + '            <tr>\n'
         + '              <th scope="col"><abbr title="Sunday">S</abbr>\n'
         + '              </th>\n'
         + '              <th scope="col">\n'
         + '                <abbr title="Monday">M</abbr>\n'
         + '              </th>\n'
         + '              <th scope="col">\n'
         + '                <abbr title="Tuesday">T</abbr>\n'
         + '              </th>\n'
         + '              <th scope="col">\n'
         + '                <abbr title="Wednesday">W</abbr>\n'
         + '              </th>\n'
         + '              <th scope="col">\n'
         + '                <abbr title="Thursday">T</abbr>\n'
         + '              </th><th scope="col">\n'
         + '                <abbr title="Friday">F</abbr>\n'
         + '              </th>\n'
         + '              <th scope="col">\n'
         + '                <abbr title="Saturday">S</abbr>\n'
         + '              </th>\n'
         + '            </tr>\n'
         + '          </thead>\n'
         + '          <tbody>\n';

      // construct the calendar
      nn = GetDaysInMonth(cal_year, cal_month);
      dd = GetDayOfWeek(cal_year, cal_month, 1); // 0 is sunday
      ww = 0;
      for(ii = 1 - dd; ii <= nn + 7; ii++)
      {
        if(ww == 0)
        {
          xx = xx
             + '            <tr class="datepicker-row">\n';
        }

        if(ii < 1 || ii > nn) // blank day
        {
          xx = xx
             + '              <td class="is-empty">\n'
             + '              </td>\n';
        }
        else
        {
          xx = xx
             + '              <td data-day="' + ii + '" class="'
             + ((cal_year == year && cal_month == month && ii == day) ? 'is-today' : '')
             + '" >\n'
             + '                <button class="datepicker-day-button" type="button"\n'
             + '                        data-year="' + cal_year + '"\n'
             + '                        data-month="' + cal_month + '"\n'
             + '                        data-day="' + ii + '">\n'
             + '                  ' + ii + '\n'
             + '                </button>\n'
             + '              </td>\n';
        }

        ww++;
        if(ww >= 7)
        {
          xx = xx
             + '            </tr>\n';
          ww = 0;
          if(ii >= nn)
            break;
        }
      }

      xx = xx
         + '          </tbody>\n'
         + '        </table>\n';

      // end of datepicker-table content

      try
      {
        document.getElementById("datepicker-table").innerHTML = xx;

        ww = document.getElementsByClassName("datepicker-day-button");

        if(ww != null)
        {
          for(ii=0; ii < ww.length; ii++)
          {
            ww[ii].addEventListener('click', CalendarClick, false);
          }
        }

        ii = null;
        ww = null;
      }
      catch(err)
      {
        console.error(err);
      }
      finally { }
    }

    function CalendarPrev()
    {
      cal_month--;
      if(cal_month < 1)
      {
        cal_year--;
        cal_month = 12;
      }

      DisplayDatePickerTable();

      document.getElementById("yyyy").innerHTML = cal_year;
      document.getElementById("dddmmmd").innerHTML = "";
      document.getElementById("cal_month_name").innerHTML = GetMonthName(cal_month);
      document.getElementById("cal_year").innerHTML = cal_year;
    }

    function CalendarNext()
    {
      cal_month++;
      if(cal_month > 12)
      {
        cal_year++;
        cal_month = 1;
      }

      DisplayDatePickerTable();

      document.getElementById("yyyy").innerHTML = cal_year;
      document.getElementById("dddmmmd").innerHTML = "";
      document.getElementById("cal_month_name").innerHTML = GetMonthName(cal_month);
      document.getElementById("cal_year").innerHTML = cal_year;
    }

    function CalendarOK()
    {
      the_date = cur_date;
      other_date = other_cur_date;

      document.getElementById("date-input").value = the_date;
      document.getElementById("the_date").value = other_date;

      EndDatePicker();
    }

    function CalendarCancel()
    {
      EndDatePicker();
    }

    function ShowDatePicker()
    {
      var year, month, day, xx, ii, nn, dd, ww, tmp;

      document.getElementById("back").disabled = true;
      document.getElementById("done").disabled = true;

      cur_date = the_date;
      other_cur_date = other_date; // cache first

      tmp = other_cur_date.split('/');
      month = tmp[0] * 1;
      day = tmp[1] * 1;
      year = tmp[2] * 1;
      tmp = null;

      cal_year = year;
      cal_month = month;

      // build dialog HTML using current information
      // start with the panel on the left
      xx = '<div class="modal-content datepicker-container">'
         + '  <div class="datepicker-date-display" style="min-width:9.5rem">\n'
         + '    <span id=yyyy class="year-text" style="font-size:1.5rem !important">' + cal_year + '</span>\n'
         + '    <span id=dddmmmd class="date-text" style="font-size:1.4rem !important">'
         + GetDayName(GetDayOfWeek(cal_year, cal_month, day)) + ', ' + GetMonthName(cal_month) + ' ' + day + '</span>\n'
         + '  </div>\n';

      // the calendar part
      xx = xx
         + '  <div class="datepicker-calendar-container">\n'
         + '    <div class="datepicker-calendar">\n'
         + '      <div id="datepicker-title-wl" class="datepicker-controls" role="heading" aria-live="assertive">\n'
         + '        <button class="month-prev" type="button" onClick="CalendarPrev()">\n'
         + '          <svg fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">\n'
         + '            <path d="M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z">\n'
         + '            </path>\n'
         + '            <path d="M0-.5h24v24H0z" fill="none">\n'
         + '              </path>\n'
         + '          </svg>\n'
         + '        </button>\n'
         + '        <div class="selects-container" style=width:100%;display:inline" >\n'
         + '          <div class="select-wrapper select-month" style="width:70%;text-align:center">\n'
         + '            <span id=cal_month_name>\n'
         + '              ' + GetMonthName(cal_month)
         + '            </span>\n'
         + '          </div>\n'
         + '          <div class="select-wrapper select-year" style="width:30%;text-align:left">\n'
         + '            <span id=cal_year>\n'
         + '              ' + cal_year
         + '            </span>\n'
         + '          </div>\n'
         + '        </div>\n'
         + '        <button class="month-next" type="button" onClick="CalendarNext()">\n'
         + '          <svg fill="#000000" height="24" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M8.59 16.34l4.58-4.59-4.58-4.59L10 5.75l6 6-6 6z">\n'
         + '            </path>\n'
         + '            <path d="M0-.25h24v24H0z" fill="none">\n'
         + '            </path>\n'
         + '          </svg>\n'
         + '        </button>\n'
         + '      </div>\n'
         + '      <div id=datepicker-table class="datepicker-table-wrapper">\n';

      xx = xx
         + '      </div>\n'
         + '    </div>\n'
         + '  <div class="datepicker-footer">\n'
         + '    <button class="btn-flat datepicker-clear waves-effect" style="visibility: hidden;" type="button">\n'
         + '    </button>\n'
         + '    <div class="confirmation-btns">\n'
         + '      <button class="btn-flat datepicker-cancel waves-effect" type="button" onClick="CalendarCancel()">Cancel</button>\n'
         + '      <button class="btn-flat datepicker-done waves-effect" type="button" onClick="CalendarOK()">OK</button>\n'
         + '    </div>\n'
         + '  </div>\n'
         + '</div>\n';

      try
      {
        document.getElementsByClassName("modal-container")[0].style.visibility="visible";
        document.getElementsByClassName("modal-container")[0].style.display="block";

        document.getElementById("datepicker_dlg").style.visibility="visible";
        document.getElementById("datepicker_dlg").style.display="block";

        document.getElementById("datepicker_dlg").innerHTML = xx;

        DisplayDatePickerTable();

        var ww = document.getElementsByClassName("is-today");

        if(ww != null)
        {
          for(var ii=0; ii < ww.length; ii++) // should be only 1
          {
            // the button within this block needs the focus
            if(ww[ii].firstElementChild)
            {
              ww[ii].firstElementChild.focus();
              ww[ii].firstElementChild.classList.add("has-focus"); // fixing a chrome bug
            }
          }
        }

        ww = null;
      }
      catch(err)
      {
        console.error(err);
      }
      finally { }

    }

    function EndDatePicker()
    {
      try
      {
        document.getElementsByClassName("modal-container")[0].style.visibility="hidden";
        document.getElementsByClassName("modal-container")[0].style.display="none";
        document.getElementById("datepicker_dlg").style.visibility="hidden";
        document.getElementById("datepicker_dlg").style.display="none";
        document.getElementById("datepicker_dlg").innerHTML="";
      }
      finally { }

      document.getElementById("back").disabled = false;
      document.getElementById("done").disabled = false;
    }

    // OLD DATE PICKER CODE BELOW

    function doOnOpenDatePicker()
    {
      document.getElementById("back").disabled = true;
      document.getElementById("done").disabled = true;
    }

    function doOnCloseDatePicker()
    {
      document.getElementById("back").disabled = false;
      document.getElementById("done").disabled = false;
    }

    getDate(); // must perform before document ready

    document.getElementById("date-input").addEventListener('click',ShowDatePicker);
    </script>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>
