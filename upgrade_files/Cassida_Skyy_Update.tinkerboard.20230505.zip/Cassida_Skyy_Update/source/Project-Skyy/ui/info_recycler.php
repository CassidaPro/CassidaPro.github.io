<?php

  include "glue/common_utils.php";

  $poobah = do_getvar("poobah","");
  $next = do_getvar("next","");
  $do_print = do_getvar("print","");

  $Equipment = coin_counter_equipment(0);

  if($poobah != "Y")
  {
    if(strlen($next) > 0)
      $next = "&next=" . urlencode($next);
?>
    <HTML>
      <HEAD>
        <TITLE>Recycler Info</TITLE>
<?php
    if($do_print == "1")
    {
?>
        <meta http-equiv="refresh" content="0.1;url=/info_recycler.php?print=1&poobah=Y<?php print $next; ?>">
<?php
    }
    else
    {
?>
        <meta http-equiv="refresh" content="0.1;url=/info_recycler.php?poobah=Y<?php print $next; ?>">
<?php
    }

    set_inbetween_style();
?>
      </HEAD>
      <BODY>
        <br><br>
        <H1>
          <center>
<?php
    if($do_print == "1")
    {
?>
            Print <?php print $Equipment; ?> Info
<?php
    }
    else
    {
?>
            Get <?php print $Equipment; ?> Info
<?php
    }
?>
          </center>
        </H1>
        <center>
          <div style="font-size:1.5rem">
            <br><br><br>
            <a href="/info_recycler.php">
              Tap HERE to re-try
            </a>
            <br>
            <br>
            <a href=
<?php
    if(strlen($next) > 0)
      print '"' . $next . '"';
    else
      print '"/maintenance.php"';
?>
            >
              Tap HERE to exit
            </a>
          </div>
        </center>
      </BODY>
    </HTML>
<?php
    exit;
  }

  if($do_print == "1")
  {
    skyyreq("print-info-recycler");
  }

  $Results = skyyreq("info-recycler");

  if(strlen($Results) < 10 ||
     substr($Results, 0, 5) == "ERROR")
  {
?>
    <!DOCTYPE html5>
    <HTML>
      <HEAD>
        <TITLE>Recycler Info - Error</TITLE>
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <center>
          <H1>
            Error - <?php print $Equipment; ?> Info
          </H1>
          <H3>
            <?php print $Results; ?>
          </H3>
        </center>
        <br><br><br>
        <center><a href="/info_recycler.php">Tap HERE to re-try</a></center>
        <br>
        <br>
        <center><a href=
<?php
    if(strlen($next) > 0)
      print '"' . $next . '"';
    else
      print '"/maintenance.php"';
?>
        >Tap HERE to exit</a></center>
      </BODY>
    </HTML>
<?php
    exit;
  }
?>
<!DOCTYPE html5>
<HTML>
<HEAD>
  <TITLE>Recycler Info</TITLE>
  <STYLE>
    html
    {
      font-size:<?php print round(cached_font_size() * 0.5); ?>px !important; /* 12px */
    }
    body
    {
      font-size: inherit;
      background-color: #003030;
      color: #ffffe0;
    }

    input
    {
     font-size: 2rem;
     font-weight: bold;
     height : 3.5rem;
    }
    @font-face
    {
     font-family: Lato;
     src: url(/fonts/lato-v15-latin-regular.woff);
    }
  </STYLE>
</HEAD>
<BODY>
  <H2><center><?php print $Equipment; ?> Info Report</center></H2>
  <table align=center>
    <tr style="font-size:1.34rem">
      <td>
        <pre>
<?php print $Results; ?>
        </pre>
      </td>
    </tr>
  </table>
  <br>
  <form id=none method=GET></form>
  <form id=print method=GET>
    <input type=hidden name="print" style"visibility:none" value=1 />
<?php
    if(strlen($next) > 0)
      print '    <input type=hidden name="next" style"visibility:none" value="' . $next .'" />' . "\r\n";
?>
  </form>
  <table align=center width=60%>
    <tr>
      <td align=center>
        <input type=submit form=print formaction="/info_recycler.php" style="font-size:1.75rem;height:2.75rem" value="Print" />
      </td>
      <td align=center>
        <input type=submit form=none formaction=
<?php
    if(strlen($next) > 0)
      print '"' . $next . '"';
    else
      print '"/maintenance.php"';
?>
        style="font-size:1.75rem;height:2.75rem" value="Back" />
      </td>
    </tr>

  </table>
</BODY>
</HTML>

