<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */


  // utility functions - most copied from freefall
  // not compatible with common_utils.php

  include "common_utils.php"; // things common to all

  // REMAINING FUNCTIONS UNIQUE TO CONF SCREENS

  function parse_conf($conffile)
  {
    $Solution = shell_exec("/home/pi/bin/skyy -C" . rtrim($conffile));
    eval($Solution);

    if($Status != 'OK')
    {
      return [];
    }

    return $parseconf;
  }

  // TODO:  see if I need this for real
  function html_tag_with_lingo()
  {
    /*global $lingo;
    if($lingo == 'es')
      print '<HTML lang="es">' . "\n";
    else*/
      print '<HTML lang="en">' . "\n";
  }

  // TODO:  see if I need this for real
  function do_multi_lingo_text($text_en, $text_es="", $text_fr="") /* TODO add params as needed */
  {
    /*global $lingo;
    if($lingo == 'es' && strlen($text_es) > 0)
      print $text_es;
    else if($lingo == 'fr' && strlen($text_fr) > 0)
      print $text_fr;
    else*/
      print $text_en;
  }

  function my_get_var($vname, $default="")
  {
    if(empty($_GET))
      return $default;

    if(!isset($_GET[$vname])) // use this, allows for blanks and 0
      return $default;

    return $_GET[$vname];
  }

  function my_post_var($vname, $default="")
  {
    if(empty($_POST))
      return $default;

    if(!isset($_POST[$vname])) // use this, allows for blanks and 0
      return $default;

    return $_POST[$vname];
  }

  function need_sanitize_input_field($invalue)
  {
    // fail if 'bad characters' are in the text
    if(strpos($invalue, '\\') === false &&  // no escapes or windows directories
       strpos($invalue, '/') === false &&   // no POSIX directories or URI paths
       strpos($invalue, '"') === false &&   // no quote marks
       strpos($invalue, "'") === false &&   // no single quotes
       strpos($invalue, "*") === false &&   // no wildcards
       strpos($invalue, "?") === false &&   // no wildcards and/or param indicators
       strpos($invalue, '\n') === false &&  // newline
       strpos($invalue, '\r') === false)    // carriage return
    {
      return false;
    }
/* debug output - enable if needed
    print "returning 'true' for " . $invalue;
    print strpos($invalue, '\\') === false ? "1 ":"0 " . // no escapes or windows directories
          strpos($invalue, '/') === false ? "1 ":"0 " .  // no POSIX directories or URI paths
          strpos($invalue, '"') === false ? "1 ":"0 " .  // no quote marks
          strpos($invalue, "'") === false ? "1 ":"0 " .  // no single quotes
          strpos($invalue, "*") === false ? "1 ":"0 " .  // no wildcards
          strpos($invalue, "?") === false ? "1 ":"0 " .  // no wildcards and/or param indicators
          strpos($invalue, '\n') === false ? "1 ":"0 " . // newline
          strpos($invalue, '\r') === false ? "1":"0";    // carriage return
*/
    return true; // needs sanitization
  }

  function need_sanitize_uri_field($invalue)
  {
    // fail if 'bad characters' are in the text
    if(strpos($invalue, '\\') === false &&  // no escapes or windows directories
       strpos($invalue, '/..') === false && // no relative directory jumping
       strpos($invalue, '../') === false && // no relative directory jumping
       strpos($invalue, '"') === false &&   // no quite marks
       strpos($invalue, "'") === false &&   // no single quotes
       strpos($invalue, "*") === false &&   // no wildcards
//       strpos($invalue, "?") === false &&   // no wildcards and/or param indicators (TODO check placement?)
       strpos($invalue, '\n') === false &&  // newline
       strpos($invalue, '\r') === false)    // carriage return
    {
      return false;
    }

    return true; // needs sanitization
  }

  /* SYSTEM GLOBALS */

  $ProductName="Split Recycler"; // change later if needed
  $BodyTagDefs='';//'bgcolor="#004020" text="#ffffe0"'; // body tag defs
  $ErrorPageBodyTagDefs='bgcolor="#e0e0e0" text="#6050e0"'; // body tag defs for error pages was text=8068ff

  $ConfigFileName="/var/cache/skyy/configuration.conf";

  $req_uri = $_SERVER['REQUEST_URI']; // should be safe to use as-is

  if((empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] == 'off') && $_SERVER['SERVER_PORT'] != 443)
  {
    $req_proto="http://";
  }
  else
  {
    $req_proto="https://";
  }

  // assign '$req_url' to the request URL.  This is needed elsewhere for login re-directs

  $req_url = $req_proto . $_SERVER['HTTP_HOST'] . $req_uri;

  // now, '$req_uri' will be stripped of the parameters so I can re-build as needed
  $parameters = strstr($req_uri, '?');

  if($parameters === false) // maybe?
  {
    $parameters = "";
  }
  else
  {
    $parameters = substr($parameters, 1, strlen($parameters) - 1); // trim leading ?
    $req_uri = strstr($req_uri, '?', true); // give me up to but not including '?'
  }

  // DETERMINE IF I AM IN 'AP' MODE

  if($_SERVER['HTTP_HOST']=="192.168.0.1") // running in AP mode (temporary, use IP address)
    $isAP=true;
  else
    $isAP=false;

?>

