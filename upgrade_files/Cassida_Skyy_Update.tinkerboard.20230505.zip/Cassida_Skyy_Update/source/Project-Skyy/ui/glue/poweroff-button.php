<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  // if this system has a power button I must execute that
  // versinn; otherwise just jump to 'poweroff.php'

  $yy = rtrim(ltrim(shell_exec("/bin/bash -c \"if test -e /home/pi/bin/power-button-pressed.sh ; then echo 'Y' ; else echo 'N' ; fi\"")));

  if($yy != "Y")
  {
//    if($yy == "N")
//    {
      header("HTTP/1.0 302 Moved Temporarily");
      header("Location: /glue/poweroff.php");
      exit;
//    }
//
//    print "ERROR - yy is '" . $yy . "'\n";
//    exit;
  }

  shell_exec("/usr/bin/sudo -u pi /home/pi/bin/power-button-pressed.sh");

  sleep(1);
?>
<!DOCTYPE html>
<HTML>
  <HEAD>
    <TITLE>Power Off Button Press</TITLE>
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  </HEAD>
  <BODY onLoad="window.history.back()">
  </BODY>
</HTML>

