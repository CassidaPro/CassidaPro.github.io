<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  // assume count is started and get 'step' info from session vars

  // OK find out what I'm counting, and go there
  $thing = skyyreq("count-entity-next");

  if(strlen($thing) == 0 || substr($thing, 0, 1) != '$')
  {
    header("HTTP/1.0 500 Server Error");
?>
    <HTML><HEAD><TITLE>Server Error</TITLE>
    <meta http-equiv="refresh" content="10;url=/">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br><br><br>
        <H1><center>Internal Server Error</center></H1>
        <H3><center>Reference:  Next Count Entity</center></H3>
    </BODY>
    </HTML>
<?php
  }

  eval($thing); // see skyy.c /count-entity-next for vars it assigns

  header("HTTP/1.0 302 Moved Temporarily");

  if($CountStep == "straps")
  {
    header("Location: /count-straps.php");
  }
  else if($CountStep == "rolls")
  {
    header("Location: /count-rolls.php");
  }
  else if($CountStep == "notes")
  {
    header("Location: /count-notes.php");
  }
  else if($CountStep == "coins")
  {
    // if we are running coins in the background we need to see
    // if a background coin count is in progress, and if so we
    // attach to the background proces.  Otherwise, count coins
    // as we normally would

    if(coin_counter_is_recycler($CoinCounterEquipment)
       && $AutoStart != 0)
    {
      skyyreq("join-background"); // this should do it

      // NOTE:  if the UI hesitates, put an in-between page with a timeout re-direct
      //        before the HTTP header line (above) for this condition

      header("Location: /coins-results.php"); // already running, so go here
    }
    else
    {
      header("Location: /count-coins.php");
    }
  }
  else if($CountStep == "change") // change order - issue #141
  {
    header("Location: /change-order.php");
  }
  else if($CountStep == "")
  {
    // should not happen, but...
    if($Class == 3) // tills
      header("Location: /register-summary.php");
    else
      header("Location: /count-summary.php");
  }
  else
  {
    // just go back to tasks, for now
    header("Location: /tasks.php");
  }
?>

