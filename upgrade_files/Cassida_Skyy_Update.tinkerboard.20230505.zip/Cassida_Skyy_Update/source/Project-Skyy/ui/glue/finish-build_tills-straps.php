<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Straps = do_getconf($parseconf,"terms",'Straps','Straps');
  $Rolls = do_getconf($parseconf,"terms",'Rolls','Rolls');
  $Baggies = do_getconf($parseconf,"terms",'Baggies','Baggies');

  $BuildButton = do_getconf($parseconf,"terms",'BuildButton','Build Tills');

  $Register = do_getconf($parseconf,"vessels",'Class3','Tills');

  $doohickey=do_getvar("doohickey","");

  // this differs from 'complete-build_tills-straps.php' in that it finishes
  // the 'build-tills' process in skyy, and re-directs back to 'tasks.php'

  if($doohickey=="")
  {
    // this web page needs to display some final instructions and
    // has a 'done' button to re-invoke me with 'doohickey="Y"'
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
<?php
    if($CustomerMod == 1)
    {
?>
        <!-- this one shows the animation -->
        <meta http-equiv="refresh" content="0.2;url=/glue/finish-build_tills-straps.php?doohickey=N">
<?php
    }
    else
    {
?>
        <meta http-equiv="refresh" content="0.2;url=/glue/finish-build_tills-straps.php?doohickey=Y">
<?php
    }

    set_inbetween_style();
?>
      </HEAD>
      <BODY>
        <br><br><br><br>
        <center>
          <H1>
            <?php print $BuildButton; ?>
            <br>
            Making <?php print $Straps; ?> Completed
          </H1>
        </center>
      </BODY>
    </HTML>
<?php
  }
  else if($doohickey=="N")
  {
    skyyreq("complete");

?>
    <HTML>
      <HEAD>
        <TITLE><?php print $BuildButton; ?> - Completed</TITLE>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>

        <link href="/css/style.css" type="text/css" rel="stylesheet"/>
        <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
        <link rel="shortcut icon" href="/img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <nav class="secondary-fill lighten-1" role="navigation">
          <div class="nav-wrapper container">
            <a id="logo-container" href="#" class="brand-logo titlebar"><?php print make_singular($Register); ?> Bags<img src="/img/count-coins.svg"><img src="/img/rolls.svg"><img src="/img/count-notes.svg"></a>
            <div id="entity" class="area"><?php print strtoupper($BuildButton); ?></div>
          </div>
        </nav>
        <div style="font-size:1rem;margin-top:16px;">
          <center>
            <b>Place</b> <?php print make_singular($Coins) . " " . $Baggies; ?>,
               <?php print $Rolls; ?>, and <?php print $Notes; ?> into
               <?php print make_singular($Register); ?> Bags
            <br>
            <img height=<?php print round(cached_font_size() * 240 / 24); ?>px src="/img/MoneyBag.gif">
          </center>
        </div>

        <div class="next-button">
          <form method="GET" action="/glue/finish-build_tills-straps.php">
            <input type=hidden name="doohickey" value="Y" style="visibility:hidden" />
            <button id=finish_straps class="btn waves-effect primary-fill btn-shadow">Done</button>
          </form>
        </div>

        <script src="/js/UserFeedback.js"></script>

      </BODY>
    </HTML>
<?php
  }
  else
  {
    if($doohickey=="Y") // if I was sent from doohicky=="" and did not do 'N' I go here directly
    {
      skyyreq("complete"); // calling more than once does not harm anything
    }

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /tasks.php");

    skyyreq("complete-ad-hoc");

    skyyreq("complete-build-tills");
      // this last one just makes the check mark show up
  }
?>

