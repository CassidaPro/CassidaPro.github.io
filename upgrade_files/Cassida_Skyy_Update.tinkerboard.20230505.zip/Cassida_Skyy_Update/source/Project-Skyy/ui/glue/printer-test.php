<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

    include "common_utils.php";

    header("Content-type: text/plain; charset=UTF-8");

    print skyyreq("printer-test" );
?>

