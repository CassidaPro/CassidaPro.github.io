<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $Equipment = coin_counter_equipment();

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/plain");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems

  if(coin_counter_is_recycler($Equipment))
  {
    // position - 1 for rolls, 0 for coin tray

    if(coin_counter_is_recycler_twin($Equipment))
      print skyyreq("status-recycler-drawer");
    else
      print "0\r\n"; // TODO:  do other recyclers have this?
  }
  else
  {
    print "0\r\n";
  }


?>

