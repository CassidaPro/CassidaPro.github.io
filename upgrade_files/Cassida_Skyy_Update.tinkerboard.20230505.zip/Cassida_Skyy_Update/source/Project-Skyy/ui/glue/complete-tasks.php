<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php"; // things common to all

  $doohickey=do_getvar("doohickey", "");
  $complete=do_getvar("complete", "");

//  extract($_GET, EXTR_OVERWRITE);

  if($complete == '')
  {
    header("HTTP/1.0 500 Server Error");
  }
  else if($doohickey=="")
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="0.2;url=/glue/complete-tasks.php?doohickey=Y;complete=<?php print $complete; ?>">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY><br><br><br><br><H1><center>Completing Task</center></H1>
    </BODY>
    </HTML>
<?php
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /tasks.php");

    // TODO:  validate '$complete', as it can only be 'safe' 'drawer' or 'register'

    skyyreq("complete-" . $complete);
  }
?>

