<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  header("HTTP/1.0 302 Moved Temporarily");
//  header("Location: /glue/initiate-verify_deposit.php");
  header("Location: /glue/verify_deposit-start-zeus.php");

  // for this I simply complete whatever current task is running, not the entire process
  // this way I won't mark the 'verify deposit' task as completed yet.
  // HOWEVER I do want to start the count at zero again.
  skyyreq("complete");

  // also need to re-start the 'verify deposit', then initiate zeus count
  // the note amount will be zero again, starting fresh
  // but the snapshot of coin counter inventory will stay the same

  skyyreq("verify-deposit");

?>

