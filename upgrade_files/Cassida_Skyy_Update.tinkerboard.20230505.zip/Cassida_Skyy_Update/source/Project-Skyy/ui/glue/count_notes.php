<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/xml");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE count SYSTEM "count.dtd">
<count>
<?php

$Entity = '';
$CountDate = '';

// loose bills
$count1 = '0';
$count2 = '0';
$count5 = '0';
$count10 = '0';
$count20 = '0';
$count50 = '0';
$count100 = '0';

  $Solution = skyyreq("count-entity");
  eval($Solution);

  $Solution = skyyreq("result-zeus");
  eval($Solution);
?>

<entity><?php print $Entity;?></entity>
<date><?php print $CountDate;?></date>
<note><type>1</type><qty><?php print $count1?></qty></note>
<note><type>2</type><qty><?php print $count2?></qty></note>
<note><type>5</type><qty><?php print $count5?></qty></note>
<note><type>10</type><qty><?php print $count10?></qty></note>
<note><type>20</type><qty><?php print $count20?></qty></note>
<note><type>50</type><qty><?php print $count50?></qty></note>
<note><type>100</type><qty><?php print $count100?></qty></note>

</count>

