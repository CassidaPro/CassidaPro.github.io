<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

    $xx = rtrim(ltrim(skyyreq("printer-self-test" )));

    if($xx != "OK")
    {
      header("HTTP/1.0 500 Server Error");
?>
      <HTML>
        <HEAD>
          <TITLE>Server Error</TITLE>
          <meta http-equiv="refresh" content="10;url=/maintenance.php">
          <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
          <link rel="shortcut icon" href="../img/favicon.ico">
          <style>
<?php
  set_ideal_font_height();
?>
          </style>
        </HEAD>
        <BODY>
          <H1><center>PRINTER ERROR</center></H1>
          <br><br><br>
          <H4>
            <center>
              Error self-testing printer<br>
              <?php print $xx; ?><br>
              <br>
              Screen RESET in 10 seconds...
            </center>
          </H4>
          <br>
        </BODY>
      </HTML>
<?php
    }
    else
    {
?>
      <HTML>
        <HEAD>
          <TITLE>Printer Self Test</TITLE>
          <meta http-equiv="refresh" content="10;url=/maintenance.php">
          <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
          <link rel="shortcut icon" href="../img/favicon.ico">
          <style>
<?php
  set_ideal_font_height();
?>
          </style>
        </HEAD>
        <BODY>
          <H1><center>PRINTER SELF-TEST SENT</center></H1>
          <br><br><br>
          <H4>
            <center>
              Please check the printer for a printout<br>
              indicating a successful reset and self-test.<br>
              <br>
              For additional assistance, contact Cassida Customer Support.<br>
            </center>
          </H4>
          <br>
        </BODY>
      </HTML>
<?php
    }
?>


