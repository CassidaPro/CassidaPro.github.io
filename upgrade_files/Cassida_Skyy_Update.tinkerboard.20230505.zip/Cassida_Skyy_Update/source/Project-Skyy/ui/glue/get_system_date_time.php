<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  header("Content-Type text/plain");

  if(!empty($_GET) && !empty($_GET["plain"]) && $_GET["plain"] == "Y")
  {
    // return a 'plain' date of format YYYYMMDDHHMMSS and TZ at the end
    // need to indicate also whether it's automatic sync or manual set

    $sync = ltrim(rtrim(shell_exec("/usr/bin/timedatectl show 2>&1 | grep '^NTP='")));
    $sync = substr($sync, 4, 99);

    $zone = ltrim(rtrim(shell_exec("/usr/bin/timedatectl show 2>&1 | grep '^Timezone='")));
    $zone = substr($zone, 9, 99);

    // resulting output looks like this:
    //     YYYYMMDDHHMMSS timezone [yes|no]

    print ltrim(rtrim(shell_exec("/bin/date +'%Y%m%d%H%M%S'")))
          . " " . $zone . " " . $sync . "\n";
  }
  else
  {
    print shell_exec("/bin/date");
  }
?>

