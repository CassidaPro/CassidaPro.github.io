<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');

  $doohickey=do_getvar("doohickey","");

//  extract($_GET, EXTR_OVERWRITE);

  if($doohickey=="")
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="0.2;url=/glue/complete-adhoc-notes.php?doohickey=Y">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY><br><br><br><br><H1><center><?php print $Notes; ?> Count Complete</center></H1>
    </BODY>
    </HTML>
<?php
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /");

    skyyreq("complete");

    skyyreq("complete-ad-hoc");

    skyyreq("clear-zeus" );
  }
?>

