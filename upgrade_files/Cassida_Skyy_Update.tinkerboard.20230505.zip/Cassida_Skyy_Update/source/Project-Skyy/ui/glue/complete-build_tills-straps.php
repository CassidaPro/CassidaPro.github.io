<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Straps = do_getconf($parseconf,"terms",'Straps','Straps');
  $BuildButton = do_getconf($parseconf,"terms",'BuildButton','Build Tills');

  $doohickey=do_getvar("doohickey", "");

  if($doohickey=="")
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="0.2;url=/glue/complete-build_tills-straps.php?doohickey=Y">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br><br><br>
      <H2>
        <center>
          <H2>
            <?php print $BuildButton; ?>
            <br>
            Making <?php print $Straps; ?> Completed
          </H2>
        </center>
      </H2>
    </BODY>
    </HTML>
<?php
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /build_tills-strap-qty.php");

    skyyreq("complete");

    skyyreq("complete-ad-hoc");
  }
?>

