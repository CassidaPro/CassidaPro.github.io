<?php
/*          Copyright 2019-21 by Cassida            */
/* Use only in accordance with the supplied license */

  include "config_utils.php";

  $doohickey = do_getvar("doohickey","");

  if($doohickey != "Y")
  {
?>
  <HTML>
    <HEAD>
      <TITLE>Print Daily Cleaning Instructions</TITLE>
      <meta http-equiv="refresh" content="2;url=/glue/print-weekly-cleaning.php?doohickey=Y">
  <?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br><br><br>
      <H1>
        <center>
          Printing Cleaning Instructions
        </center>
      </H1>
    </BODY>
  </HTML>
<?php
    exit;
  }

  $Equipment = coin_counter_equipment();

  $parseconf = load_parseconf();

  $Note = make_singular(do_getconf($parseconf,"terms",'Notes','Notes'));
  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Coin = make_singular($Coins);

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  $text = "            WEEKLY CLEANING\n"
        . "            ====== ========\n";

//  $text = $text . "0123456789012345678901234567890123456789\n";

  if(coin_counter_is_recycler($Equipment))
  {
//          "0123456789012345678901234567890123456789\n";
    $text = $text . "\n"
          . "Soft Bristle Brush & Air Duster Cleaning\n"
          . "* Turn off the system from the power\n"
          . "  switch located on the front panel.\n"
          . "* From the bottom, lift the left-hand\n"
          . "  " . $Note . " Counter access door.\n"
          . "\n"
          . "Soft Bristle Brush & Air Duster Cleaning\n"
          . "* Grab the Soft Bristled Brush and\n"
          . "  Canned Air Duster.\n"
          . "* Locate the sensors on the front of\n"
          . "  the Zeus unit. Use the Canned Air\n"
          . "  Duster to blow away any loose\n"
          . "  particles/dust.\n"
          . "* Clean Hopper Sensors, Reject Sensors,\n"
          . "  Stacker Sensors\n"
          . "* Locate the sensors on the front of\n"
          . "  the Zeus unit. Use the soft bristled\n"
          . "  brush to sweep away any loose\n"
          . "  particles/dust.\n"
          . "* Clean Hopper Sensors, Reject Sensors,\n"
          . "  Stacker Sensors\n"
          . "* Open the upper cover on the back of\n"
          . "  the Zeus and locate the PS1 sensors\n"
          . "  and magnetic sensor bar.\n"
          . "* Using the soft bristle brush, sweep\n"
          . "  away any particles/dust that are\n"
          . "  covering the sensors.\n"
          . "* Open the lower cover on the back of\n"
          . "  the Zeus and locate the PS2 sensors\n"
          . "  and metal bearings.\n"
          . "* Using the soft bristle brush, sweep\n"
          . "  away any particles/dust that are\n"
          . "  covering the sensors.\n"
          . "\n"
          . "CleanPro Swab Cleaning\n"
          . "* Grab the CleanPro Cleaning Swab.\n"
          . "* Locate the sensors on the front of\n"
          . "  the Zeus unit. Use the CleanPro swab\n"
          . "  to wipe away any loose\n"
          . "  particles/dust. Make sure you do the\n"
          . "  Daily Cleaning before swabbing.\n"
          . "* Clean Hopper Sensors, Reject Sensors,\n"
          . "  Stacker Sensors\n"
          . "* Open the upper cover on the back of\n"
          . "  the Zeus and locate the PS1 sensors\n"
          . "  and magnetic sensor bar.\n"
          . "* Using the CleanPro swab, wipe away\n"
          . "  any particles/dust that are covering\n"
          . "  the sensors.\n"
          . "* Open the lower cover on the back of\n"
          . "  the Zeus and locate the PS2 sensors\n"
          . "  and metal bearings.\n"
          . "* Using the CleanPro swab, wipe away\n"
          . "  any particles/dust that are covering\n"
          . "  the sensors.\n"
          . "\n"
          . $Coin . " Recycler Cleaning\n"
//          . "* Turn off the system from the power\n"
//          . "  switch located on the front panel.\n"
          . "* From the bottom, lift the right-hand\n"
          . "  " . $Coin . " Counter access door.\n"
          . "* On the right-hand hopper, press the\n"
          . "  front latch adjacent to the coin\n"
          . "  reject port and lift up. It is\n"
          . "  hinged in the back, and opens from\n"
          . "  the front.\n"
          . "* Inspect the inside of the Feeder,\n"
          . "  and remove any foreign debris.\n"
          . "* Using the soft bristle brush, sweep\n"
          . "  away any dust or particles that may\n"
          . "  be in the coin feeder, coin track,\n"
          . "  and coin wheel.\n"
          . "* Close the Feeder by moving the\n"
          . "  funnel towards you, until the\n"
          . "  assembly latches\n"
          . "* Lower the right-hand " . $Coin . " Counter\n"
          . "  access door, ensuring that the two\n"
          . "  hoppers and the Feeder easily mate\n"
          . "  up with the cover and coin ports.\n"
//          . "* Re-energize the system using the\n"
//          . "  front panel power switch.\n"
          . "\n";
/*
          . "* From the bottom, lift the right-hand\n"
          . "  " . $Coin . " Counter access door.\n"
          . "* To clean the Recycler, locate the\n"
          . "  semi-circular latch on the lower\n"
          . "  front of each panel.\n"
          . "* Press up and slide each hopper\n"
          . "  assembly towards you to remove.\n"
          . "* For the right-hand hopper, press\n"
          . "  the front latch adjacent to the coin\n"
          . "  reject port and lift up.\n"
          . "  It is hinged in the back, and opens\n"
          . "  from the front.\n"
          . "* Inspect the inside of the Feeder, and\n"
          . "  remove any foreign debris.\n"
          . "* Using the soft bristle brush, sweep\n"
          . "  away any dust or particles that may\n"
          . "  be in the coin feeder, coin track,\n"
          . "  and coin wheel.\n"
          . "* To clean the coin sensor take the\n"
          . "  Canned Air Duster and dust the area\n"
          . "  as shown by the red arrow.\n"
          . "  Do not insert the nozzle more than\n"
          . "  half an inch into the opening.\n"
          . "\n"
          . "* Remove the feeder assembly from the\n"
          . "  right-hand hopper by lifting up the\n"
          . "  latch in the back, and sliding the\n"
          . "  assembly 1-2 inches away from you.\n"
          . "  The entire assembly can then be\n"
          . "  lifted up to expose the coins.\n"
          . "* Inspect the inside of the right hand\n"
          . "  hopper, and remove any foreign debris.\n"
          . "* Take the Canned Air Duster and dust\n"
          . "  the inside of the hopper, with special\n"
          . "  attenton to the coin elevator on the\n"
          . "  left side, and the payout port.\n"
          . "* Without removing the coins, tilt back\n"
          . "  the hopper so that you can see the 2\n"
          . "  ports underneath, and dust both\n"
          . "  ports.\n"
          . "* Replace the feeder assembly, placing\n"
          . "  it on top of the hopper so that it\n"
          . "  fits in the rails, then sliding\n"
          . "  towards you until it clicks into\n"
          . "  place.\n"
          . "* Close the Feeder by moving the\n"
          . "  funnel towards you, until the\n"
          . "  assembly latches.\n"
          . "* For the left-hand hopper, press the\n"
          . "  latch on top of the plastic cover,\n"
          . "  near the back,and sliding the assembly\n"
          . "  1-2 inches away from you.  The cover\n"
          . "  can then be lifted up to expose the\n"
          . "  coins.\n"
          . "* Inspect the inside of the left hand\n"
          . "  hopper, and remove any foreign debris.\n"
          . "* Take the Canned Air Duster and dust\n"
          . "  the inside of the hopper, with special\n"
          . "  attenton to the coin elevator on the\n"
          . "  left side, and the payout port.\n"
          . "* Without removing the coins, tilt back\n"
          . "  the hopper so that you can see the 2\n"
          . "  ports underneath, and dust both ports.\n"
          . "* Check for any dust or debris on the\n"
          . "  Recycler baseplate, and remove it with\n"
          . "  a cleaning cloth.\n"
          . "* Slide each hopper back onto the base,\n"
          . "  pushing all the way back until they\n"
          . "  latch.\n"
          . "* Lower the right-hand " . $Coin . " Counter\n"
          . "  access door, ensuring that the two\n"
          . "  hoppers and the Feeder easily mate up\n"
          . "  with the cover and coin ports.\n"
          . "* Re-energize the system using the front\n"
          . "  panel power switch.\n"
          . "\n";
*/
  }
  else
  {
    $text = $text . "\n"
          . "Soft Bristle Brush & Air Duster Cleaning\n"
          . "  Turn off the system from the power\n"
          . "  switch located behind the ZEUS.\n"
          . "  Grab the Soft Bristled Brush and\n"
          . "  Canned Air Duster.\n"
          . "  Locate the sensors on the front of\n"
          . "  the Zeus unit. Use the Canned Air\n"
          . "  Duster to blow away any loose\n"
          . "  particles/dust.\n"
          . "  Clean Hopper Sensors, Reject Sensors,\n"
          . "  Stacker Sensors\n"
          . "  Locate the sensors on the front of\n"
          . "  the Zeus unit. Use the soft bristled\n"
          . "  brush to sweep away any loose\n"
          . "  particles/dust.\n"
          . "  Clean Hopper Sensors, Reject Sensors,\n"
          . "  Stacker Sensors\n"
          . "  Open the upper cover on the back of\n"
          . "  the Zeus and locate the PS1 sensors\n"
          . "  and magnetic sensor bar.\n"
          . "  Using the soft bristle brush, sweep\n"
          . "  away any particles/dust that are\n"
          . "  covering the sensors.\n"
          . "  Open the lower cover on the back of\n"
          . "  the Zeus and locate the PS2 sensors\n"
          . "  and metal bearings.\n"
          . "  Using the soft bristle brush, sweep\n"
          . "  away any particles/dust that are\n"
          . "  covering the sensors.\n"
          . "\n"
          . "CleanPro Swab Cleaning\n"
          . "  Grab the CleanPro Cleaning Swab.\n"
          . "  Locate the sensors on the front of\n"
          . "  the Zeus unit. Use the CleanPro swab\n"
          . "  to wipe away any loose\n"
          . "  particles/dust. Make sure you do the\n"
          . "  Daily Cleaning before swabbing.\n"
          . "  Clean Hopper Sensors, Reject Sensors,\n"
          . "  Stacker Sensors\n"
          . "  Open the upper cover on the back of\n"
          . "  the Zeus and locate the PS1 sensors\n"
          . "  and magnetic sensor bar.\n"
          . "  Using the CleanPro swab, wipe away\n"
          . "  any particles/dust that are covering\n"
          . "  the sensors.\n"
          . "  Open the lower cover on the back of\n"
          . "  the Zeus and locate the PS2 sensors\n"
          . "  and metal bearings.\n"
          . "  Using the CleanPro swab, wipe away\n"
          . "  any particles/dust that are covering\n"
          . "  the sensors.\n"
          . "\n"
          . "C400 Cleaning\n"
          . "  To clean the C400, locate the latch\n"
          . "  on the front of the C400.\n"
          . "  Press the latch firmly and with your\n"
          . "  free hand grab the front hopper wall\n"
          . "  and lift.\n"
          . "  Remove foreign debris such as rubber\n"
          . "  bands, currency straps, paper clips,\n"
          . "  etc.\n"
          . "  Using the soft bristle brush, sweep\n"
          . "  away any dust or particles that may\n"
          . "  be in and around the coin feeder and\n"
          . "  circular coin plate.\n"
          . "  To clean the coin sensor take the\n"
          . "  Canned Air Duster and dust the area\n"
          . "  as shown by the red arrow. Be sure\n"
          . "  to place the nozzle at least half an\n"
          . "  inch into the vent.\n";
  }


  printer_output($text);

//  print shell_exec("cat /home/pi/fakeprinter.txt");

//  header("HTTP/1.0 302 Moved Temporarily");
//  header("Location: /cleaning.php");

?>
<HTML>
  <HEAD>
    <TITLE>Starting <?php print $Equipment; ?></TITLE>
    <meta http-equiv="refresh" content="2;url=/cleaning.php">
<?php set_inbetween_style(); ?>
  </HEAD>
  <BODY>
    <br><br><br><br>
    <H1>
      <center>
        Printing Cleaning Instructions
      </center>
    </H1>
  </BODY>
</HTML>

