<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

    include "common_utils.php";

    $StartCount = do_getvar("StartCount","");
    $EndCount = do_getvar("EndCount","");

    // parse config file for things I need
    $parseconf = load_parseconf();

    $Coins = do_getconf($parseconf,"terms",'Coins','Coins');

    header("Content-type: text/plain; charset=UTF-8");

    if(strlen($StartCount) == 0 ||
       strlen($EndCount) == 0 ||
       $StartCount == $EndCount)
    {
      print "\n"; // empty
    }

    $S = explode("/", $StartCount . "/////");
    $E = explode("/", $EndCount . "/////");

    $c1   = $S[0] - $E[0];
    $c5   = $S[1] - $E[1];
    $c10  = $S[2] - $E[2];
    $c25  = $S[3] - $E[3];
    $c100 = $S[4] - $E[4];

    $cc = $c1 + $c5 + $c10 + $c25 + $c100;
    $cT = $c1 * 0.01 + $c5 * 0.05 + $c10 * 0.10 + + $c25 * 0.25 + $c100;

    $ee = $E[0] + $E[1] + $E[2] + $E[3] + $E[4];
    $eT = $E[0] * 0.01 + $E[1] * 0.05 + $E[2] * 0.10  + $E[3] * 0.25 + $E[4];

    $Coins = strtoupper($Coins);
    $Coin = make_singular($Coins);
    $T1 = $Coin . " DISPENSE RECEIPT";
    $T2 = "DISPENSED " . $Coins;
    $T3 = "REMAINING " . $Coins . " IN RECYCLER";

    // user name (if any)
    $UU = ltrim(rtrim(skyyreq("authenticated-username")));
    if(strlen($UU) > 0)
      $UU = "USER: " . substr($UU,0,32);

    $blanks = "                    ";
    $T1 = substr($blanks, 1, (40 - strlen($T1)) / 2) . $T1;
    $T2 = substr($blanks, 1, (40 - strlen($T2)) / 2) . $T2;
    $T3 = substr($blanks, 1, (40 - strlen($T3)) / 2) . $T3;

    if(strlen($UU) > 0)
      $UU = substr($blanks, 1, (40 - strlen($UU)) / 2) . $UU . "\n";

    // build printer output into $data starting with title
    $data = "" . $T1 . "\n\n" // line end plus one blank line
          . $UU . "\n";       // line (if any) plus additional blank line

    if($c1 != 0 || $c5 != 0 || $c10 != 0 || $c25 != 0 || $c100 != 0)
    {
      // dispensed amount if not zero
      $data = $data
            . sprintf("" . $T2 . "\n" .
                      "\n" .
                      "    Dollars:   %5d    %9.2f\n" .
                      "   Quarters:   %5d    %9.2f\n" .
                      "      Dimes:   %5d    %9.2f\n" .
                      "    Nickels:   %5d    %9.2f\n" .
                      "    Pennies:   %5d    %9.2f\n" .
                      "              ------ ------------\n" .
                      "               %5d    %9.2f\n" .
                      "\n",
                      $c100, $c100 * 1.0,
                      $c25, $c25 * 0.25,
                      $c10, $c10 * 0.10,
                      $c5, $c5 * 0.05,
                      $c1, $c1 * 0.01,
                      $cc, $cT);
    }

    // print out whatever remains in the can and a grand total
    $data = $data
          . sprintf("" . $T3 . "\n" .
                    "\n" .
                    "    Dollars:   %5d    %9.2f\n" .
                    "   Quarters:   %5d    %9.2f\n" .
                    "      Dimes:   %5d    %9.2f\n" .
                    "    Nickels:   %5d    %9.2f\n" .
                    "    Pennies:   %5d    %9.2f\n" .
                    "              ------ ------------\n" .
                    "               %5d    %9.2f\n" .
                    "\n" .
                    "                     ============\n" .
                    "GRAND TOTAL:           %10.2f\n",
                    $E[4],$E[4] * 1.0,
                    $E[3],$E[3] * 0.25,
                    $E[2],$E[2] * 0.10,
                    $E[1],$E[1] * 0.05,
                    $E[0],$E[0] * 0.01,
                    $ee, $eT,
                    $cT + $eT);

    printer_output($data);

    print "OK\n" . $data . "\n";
?>

