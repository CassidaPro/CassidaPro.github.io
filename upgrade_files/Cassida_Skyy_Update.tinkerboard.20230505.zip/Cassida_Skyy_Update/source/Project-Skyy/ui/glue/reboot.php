<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

?>
<!DOCTYPE html>
<HTML>
  <HEAD>
    <TITLE>Reboot System</TITLE>
    <STYLE>
      @font-face
      {
       font-family: Lato;
       src: url(/fonts/lato-v15-latin-regular.woff);
      }
      html
      {
        font-size:<?php print round(cached_font_size()); ?>px !important;
      }
      body
      {
        font-size: inherit;
        background-color: #e0e0e0;
        color: #8068ff;
      }
    </STYLE>
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  </HEAD>
  <BODY>
<?php

  shell_exec( "/usr/bin/nohup /home/pi/bin/reboot-delay.sh  >/dev/null 2>&1 &" );

?>
    <br><br><br><br><br><br>
    <center>
      <table width="70%">
        <tr>
          <td>
            <b>
              <center>
                <font style="font-size:2rem">
                  Rebooting in 5 seconds...
                </font>
              </center>
            </b>
          </td>
        </tr>
      </table>
    </center>
  </BODY>
</HTML>

