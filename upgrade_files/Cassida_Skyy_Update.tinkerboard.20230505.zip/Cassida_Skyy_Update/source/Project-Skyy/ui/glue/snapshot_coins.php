<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */
/*         this one is used by javascript           */

  include "common_utils.php";

  $Equipment = coin_counter_equipment();

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/xml");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE count SYSTEM "count.dtd">
<count>
<?php


$Entity = '';
$CountDate = '';

// loose coin
$count1c = '0';
$count5c = '0';
$count10c = '0';
$count25c = '0';
$count100c = '0';

  $Solution = skyyreq("count-entity");
  eval($Solution);

  if($Equipment == "C300")
    $Solution = skyyreq("snapshot-c300");
  else if(coin_counter_is_recycler($Equipment))
    $Solution = skyyreq("snapshot-recycler");
  else
    $Solution = skyyreq("snapshot-c400");
  eval($Solution);
?>

<entity><?php print $Entity;?></entity>
<date><?php print $CountDate;?></date>
<coin><type>1</type><qty><?php print $count1c?></qty></coin>
<coin><type>5</type><qty><?php print $count5c?></qty></coin>
<coin><type>10</type><qty><?php print $count10c?></qty></coin>
<coin><type>25</type><qty><?php print $count25c?></qty></coin>
<coin><type>100</type><qty><?php print $count100c?></qty></coin>

</count>

