<?php
/*          Copyright 2019-21 by Cassida            */
/* Use only in accordance with the supplied license */

  include "config_utils.php";

  $doohickey = do_getvar("doohickey","");

  if($doohickey != "Y")
  {
?>
  <HTML>
    <HEAD>
      <TITLE>Print Daily Cleaning Instructions</TITLE>
      <meta http-equiv="refresh" content="2;url=/glue/print-daily-cleaning.php?doohickey=Y">
  <?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br><br><br>
      <H1>
        <center>
          Printing Cleaning Instructions
        </center>
      </H1>
    </BODY>
  </HTML>
<?php
    exit;
  }

  $Equipment = coin_counter_equipment();

  $parseconf = load_parseconf();

  $Note = make_singular(do_getconf($parseconf,"terms",'Notes','Notes'));
  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Coin = make_singular($Coins);

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  if($CustomerMod == 1)
  {
    $text = "              QUICK CLEAN\n"
          . "              ===== =====\n";
  }
  else
  {
    $text = "             DAILY CLEANING\n"
          . "             ===== ========\n";
  }

//  $text = $text . "0123456789012345678901234567890123456789\n";

  if(coin_counter_is_recycler($Equipment))
  {
    $text = $text . "\n"
          . "Zeus " . $Note . " Counter\n"
          . "  Soft Bristle Brush Cleaning\n"
          . "* Grab the Soft Bristled Brush.\n"
          . "* Locate the sensors on the front of\n"
          . "  the Zeus unit. Use the soft\n"
          . "  bristled brush to sweep away any\n"
          . "  loose particles/dust.\n"
          . "* Clean Hopper Sensors, Reject\n"
          . "  Sensors, Stacker Sensors\n"
          . "\n";
  }
  else
  {
    $text = $text . "\n"
          . "Soft Bristle Brush Cleaning\n"
          . "  Grab the Soft Bristled Brush.\n"
          . "  Locate the sensors on the front of\n"
          . "  the Zeus unit. Use the soft\n"
          . "  bristled brush to sweep away any\n"
          . "  loose particles/dust.\n"
          . "  Clean Hopper Sensors, Reject\n"
          . "  Sensors, Stacker Sensors\n"
          . "\n"
          . "C400 Cleaning\n"
          . "  To clean the C400, locate the latch\n"
          . "  on the front of the C400.\n"
          . "  Remove foreign debris such as\n"
          . "  rubber bands, currency straps,\n"
          . "  paper clips, etc.\n"
          . "  Using the soft bristle brush, sweep\n"
          . "  away any dust or particles that may\n"
          . "  be in and around the coin feeder\n"
          . "  and circular coin plate.\n"
          . "\n";
  }

  printer_output($text);

//  print shell_exec("cat /home/pi/fakeprinter.txt");

//  header("HTTP/1.0 302 Moved Temporarily");
//  header("Location: /cleaning.php");

?>
<HTML>
  <HEAD>
    <TITLE>Print Daily Cleaning Instructions</TITLE>
    <meta http-equiv="refresh" content="2;url=/cleaning.php">
<?php set_inbetween_style(); ?>
  </HEAD>
  <BODY>
    <br><br><br><br>
    <H1>
      <center>
        Printed Cleaning Instructions
      </center>
    </H1>
  </BODY>
</HTML>

