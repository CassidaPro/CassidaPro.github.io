<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $Result = "";

  if(do_getvar("No_I_Really_Really_Mean_It", "") === "YES") // strict checking
  {
    $TZone=do_getvar("TZone", "");
    if($TZone != "")
    {
//      print "Setting time zone to " . '"' . $TZone . '"' . "\n";

      // must not contain ';' '..' or newline
      if(strpos($TZone, ";") !== false ||
         strpos($TZone, "..") !== false ||
         strpos($TZone, "$") !== false ||
         strpos($TZone, "[") !== false ||
         strpos($TZone, "]") !== false ||
         strpos($TZone, "\r") !== false ||
         strpos($TZone, "\n") !== false)
      {
        print "ERROR";
        exit;
      }

      // set the new time zone
      $Result = skyyreq("set-timezone/" . $TZone);
    }

    $Auto=do_getvar("Auto","");
    if($Auto == "Y") // switch to auto time
    {
      $Result = $Result . skyyreq("set-time/auto");
    }
    else // auto is off
    {
      $DateTimeStr=do_getvar("DateTimeStr","");

      if(strlen($DateTimeStr) == 0)
        $DateTimeStr = "now"; // simply turns off 'auto'

      $Result = $Result . skyyreq("set-time/" . $DateTimeStr);
    }


  }

  // always return the current date and time

  header("Content-Type text/plain");
//  print $Result . "\n";
  print shell_exec("/bin/date");
?>

