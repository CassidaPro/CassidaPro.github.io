<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  setup_screen_res(); // must do this to handle poweroff properly with power button

?>
<!DOCTYPE html>
<HTML>
  <HEAD>
    <TITLE>Power Off</TITLE>
    <STYLE>
      @font-face
      {
        font-family: Lato;
        src: url(/fonts/lato-v15-latin-regular.woff);
      }
      html
      {
        font-size:<?php print round(cached_font_size()); ?>px !important;
      }
      body
      {
        font-size: inherit;
        background-color: #e0e0e0;
        color: #8068ff;
      }
    </STYLE>
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  </HEAD>
  <BODY>
<?php

  skyyreq("kill-kill-kill"); // a nicer way to do it

  shell_exec("/usr/bin/nohup /home/pi/bin/poweroff-delay.sh >/dev/null 2>&1 &" );

?>
    <br><br><br><br><br><br>
    <center>
      <table width="70%">
        <tr>
          <td>
            <b>
              <center>
                <font style="font-size:2rem">
                  Power Off in 30 seconds...
                </font>
              </center>
            </b>
          </td>
        </tr>
      </table>
    </center>
  </BODY>
</HTML>

