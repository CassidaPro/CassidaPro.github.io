<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

//  extract($_GET, EXTR_OVERWRITE);
  include "common_utils.php"; // things common to all

  $doohickey=do_getvar("doohickey");

  if($doohickey=="")
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="0.2;url=/glue/complete-cleaning.php?doohickey=Y">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY><br><br><br><br><H1><center>Complete Zeus Cleaning</center></H1>
    </BODY>
    <!--script>
      function DoIt()
      {
        window.location.href = "/glue/sample-goes-here.php?doohickey=Y";
      }
      function MyWait(f) /* borrowed from online example */
      {
        // if doc ready state has an 'in' in it, re-run
        /in/.test(document.readyState)?setTimeout('MyWait('+f+')',9):f()
      }

      MyWait(
        function()
        {
          setTimeout(DoIt, 100);
        });
    </script-->
    </HTML>
<?php
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /cleaning.php"); // return back to main cleaning page

    skyyreq("complete-cleaning");
  }
?>

