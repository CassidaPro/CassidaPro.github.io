<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/xml");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE taskinfo SYSTEM "taskinfo.dtd">
<taskinfo>
<?php
$Entity = '';
$CountDate = '';
$CountTick = '0';
$RegistersComplete = '0';
$DrawerComplete = '0';
$SafeComplete = '0';
$BuildTillsComplete = '0';
$Safe = '';
$Drawer = '';
$Registers = '';
$BuildTills = '';


  $thingy = skyyreq("count-entity" );

  eval($thingy); // TODO:  consider a safer method than 'eval'

  // generate XML for consumption by UI

  if($SafeComplete != 0)
    $Safe = "complete";
  else
    $Safe = "incomplete";

  if($DrawerComplete != 0)
    $Drawer = "complete";
  else
    $Drawer = "incomplete";

  if($RegistersComplete != 0)
    $Registers = "complete";
  else
    $Registers = "incomplete";

  if($BuildTillsComplete != 0)
    $BuildTills = "complete";
  else
    $BuildTills = "incomplete";

  if($VerifyDepositComplete != 0)
    $VerifyDeposit = "complete";
  else
    $VerifyDeposit = "incomplete";

  print "<entity>" . $Entity . "</entity>\r\n";
  print "<date>" . $CountDate . "</date>\r\n";
  print "<datestr>" . $CountDateStr . "</datestr>\r\n";
  print "<tick>" . $CountTick . "</tick>\r\n";
  print "<safe>" . $Safe . "</safe>\r\n";
  print "<drawer>" . $Drawer . "</drawer>\r\n";
  print "<registers>" . $Registers . "</registers>\r\n";
  print "<build_tills>" . $BuildTills . "</build_tills>\r\n";
  print "<verify_deposit>" . $VerifyDeposit . "</verify_deposit>\r\n";

?>
</taskinfo>

