<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  //  This file does a LOT.  It checks the coin counter's current count
  //  and, if it is NOT zero, either allows you to clear first or continue
  //  dispensing coins.  In the case of a Recycler it differs in that
  //  a Recycler has the capability of dispensing coins with whatever
  //  coins are stored inside.  Additionally you may need to 'Dump' or 'Empty'
  //  the coins from the Recycler and zero out the count.  The basic user
  //  interface for controlling those operations is MOSTLY provided here.


  include "common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Rolls = do_getconf($parseconf,"terms",'Rolls','Rolls');
  $Baggies = do_getconf($parseconf,"terms",'Baggies','Baggies');

  // coin bag threshold - the level above which the 'dispense coins' screen appears after this one
  $coin_bag_threshold = 10 * intval(do_getconf($parseconf, "settings", "CoinBagThresholdPercent", "50"));

  $clear_first=do_getvar("clear_first","");
  $doohickey=do_getvar("doohickey","");
  $c400status=do_getvar("c400status","");

  $Equipment = coin_counter_equipment(0);

  // Use GET parameters to determine the action to take.
  // Various states post parameters back to itself to perform
  // functions that display different page content based on
  // the current state.

  if($clear_first=="Y")  // I am clearing first, then will start the count
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /glue/adhoc-start-c400-clear.php");

    skyyreq("complete");
    skyyreq("count-ad-hoc");

    exit;
  }
  else if($clear_first=="D" || $clear_first == "S")  // DUMP - Recycler - instruct skyy to empty the recycler and zero the count
  {
    // Legacy - dump and stir are perrormed here, returns to / when done

    if(coin_counter_is_recycler($Equipment))
    {
      if($clear_first=="D")
        skyyreq("dump-recycler");
      else
        skyyreq("stir-recycler");
    }
    else
    {
      header("HTTP/1.0 500 server error");
?>
      <HTML><HEAD><TITLE>re-direct</TITLE>
      <meta http-equiv="refresh" content="10;url=/">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY><br><br><br><br><H1><center>Server Error - <?php print $Equipment; ?></center></H1>
      </BODY></HTML>
<?php
      exit;
    }

    // special version for 'dump' and 'stir'
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
<?php
    if($clear_first=="D")
    {
?>
    <title><?php print $Equipment; ?> Empty <?php print $Coins; ?></title>
<?php
    }
    else
    {
?>
    <title><?php print $Equipment; ?> Stir <?php print $Coins; ?></title>
<?php
    }
?>
    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- CSS  -->

    <style>
<?php
    set_ideal_font_height();
?>
    </style>
  </head>
  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">
<?php
    if($clear_first=="D")
    {
      print "Empty ";
    }
    else
    {
      print "Stir ";
    }

    print $Coins;
?>
      <img src="/img/count-coins.svg"></a>
        <div id="entity" class="area">COUNT</div>
      </div>
    </nav>

    <div class="container">
      <div class="section">
        <div class="row center">
<?php
    if(coin_counter_is_recycler($Equipment))
    {
?>
        <img src="/img/srb-system-recycler.png" width=320 height=240>
<?php
    }
?>
        </div>
        <br/>
        <br/>
        <div>
          <center>
            <span id=messagething>Idle</span>
          </center>
        </div>
      </div>
    </div>
    <script>

      var thing;

      function getC400Status()
      {
        // NOTE:  this glue page also works for C300 - it will check installed equipment
        var myRequest = new Request("/glue/status-c400.php");

        fetch(myRequest)
          .then(function(response)
                {
                  myRequest = null;

                  if(!response.ok)
                  {
                    console.log("status-c400", response.status); // debug only (TODO: remove?)
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                  // xx will be a DOM Parser type of object from which to parse XML
                  var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                  var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
                  var the_date = xx.getElementsByTagName("date")[0];
                  var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
                  var st = xx.getElementsByTagName("status")[0].children;
                  var status_code = "";
                  var status_text = "";
                  var today = "";

                  if(the_date && the_date.childNodes.length > 0)
                  {
                    today = the_date.childNodes[0].nodeValue
                  }
                  else
                  {
                    today = "unknown date";
                  }

                  for (var i1 = 0; i1 < st.length; i1++)
                  {
                    if(st[i1].nodeName == "code")
                      status_code = st[i1].childNodes[0].nodeValue;
                    else if(st[i1].nodeName == "text")
                      status_text = st[i1].childNodes[0].nodeValue;
                  }

                  if(status_code == 0) // this happens at the end
                  {
                    if(thing != null)
                      clearInterval(thing); // prevent certain problems while loading next page

                    thing = null;

                    // auto-start - machine begins counting

                    document.location.href = "/"; // dump and stir go back to main screen
                  }
                  else // if(status_code != 0)
                  {
                    document.getElementById("messagething").innerHTML = status_text;
                  }

                  xx = null;
                  entity = null;
                  the_date = null;
                  tick = null;
                  st = null;
                  status_code = null;
                  status_text = null;
                  today = null;
                });
      }

      thing = setInterval(getC400Status, 500); // assume 0.5 sec enough to get non-zero status (1/2 sec sometimes messes up internally)

    </script>
    <script src="/js/UserFeedback.js"></script>
    </BODY>
  </HTML>
<?php
    exit;
  }
  else if($clear_first=="DD")  // DUMP - perform the operation, re-direct to /
  {
    // special version for 'dump'
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /");

    skyyreq("complete");
    skyyreq("dump-recycler");

    exit;
  }
  else if($clear_first=="N") // continue bagging oins with whatever is in the coin bags at this time
  {
    if($doohickey=="") // display Initializing message and re-direct with 'doohickey=Y' in URL
    {
?>
      <HTML><HEAD><TITLE>re-direct</TITLE>
      <meta http-equiv="refresh" content="0.2;url=/glue/initiate-adhoc-coins.php?clear_first=N&doohickey=Y">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY><br><br><br><br><H1><center>Initializing <?php if(substr($Equipment,0,4)=="C400") print "C400"; else print $Equipment; ?></center></H1>
      </BODY></HTML>
<?php
    }
    else // initiate the count, re=-direct to count start page
    {
      header("HTTP/1.0 302 Moved Temporarily");
      header("Location: /glue/adhoc-start-c400.php");

      skyyreq("complete");
      skyyreq("count-ad-hoc");
    }
    exit;
  }

  // at this point I need to prompt whether to clear or not
  // but first I want the C400 count status.  this is trixsy

  if($c400status == "") // display 'Checking Status' message and re-direct back with c400status == -1
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="0.2;url=/glue/initiate-adhoc-coins.php?c400status=-1"; ?> >
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY><br><br><br><br><H1><center>Checking <?php if(substr($Equipment,0,4)=="C400") print "C400"; else print $Equipment; ?> Status</center></H1>
    </BODY></HTML>
<?php
    exit;
  }
  else if($c400status < 0)  // snapshot the current count
  {
    $count1c = '0';
    $count5c = '0';
    $count10c = '0';
    $count25c = '0';
    $count100c = '0';

    if($Equipment == "C300")
    {
      $rval = skyyreq("snapshot-c300");
    }
    else if(coin_counter_is_recycler($Equipment))
    {
      $rval = skyyreq("snapshot-recycler");
    }
    else
    {
      $rval = skyyreq("snapshot-c400");
    }

    eval($rval);
    if($count1c > 0 || $count5c > 0 || $count10c > 0
       || $count25c > 0 || $count100c > 0)
    {
      $c400status = "1";
    }
    else
    {
      $c400status = "0";
    }
    // display a 'checking status' message but re-direct back with c400status equal to $c400status (assigned above)
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content=<?php print '"0.2;url=/glue/initiate-adhoc-coins.php?c400status=' . $c400status . '"'; ?> >
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY><br><br><br><br><H1><center>Checking <?php if(substr($Equipment,0,4)=="C400") print "C400"; else print $Equipment; ?> Status</center></H1>
    </BODY></HTML>
<?php
    exit;
  }
  else if($c400status == "0") // zero coin count so just start things
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /glue/adhoc-start-c400.php");

    skyyreq("complete");
    skyyreq("count-ad-hoc");

    exit;
  }

  // for Recycler, grab the count again and display it

  if(coin_counter_is_recycler($Equipment))
  {
    $count1c = '0';
    $count5c = '0';
    $count10c = '0';
    $count25c = '0';
    $count100c = '0';

    $rval = skyyreq("snapshot-recycler");
    eval($rval);

    $rval = skyyreq("batch-quantity");
    eval($rval); // note var names match coin counting, below

    $rval = skyyreq("min-coin-quantity");
    eval($rval); // similar to getting batch qty but it's min qty

    $batch1 = $pennies_batch ? $pennies_batch : 1;     // store batch qty in different vars - easier to edit below
    $batch5 = $nickels_batch ? $nickels_batch : 1;
    $batch10 = $dimes_batch ? $dimes_batch : 1;
    $batch25 = $quarters_batch ? $quarters_batch : 1;
    $batch100 = $dollars_batch ? $dollars_batch : 1;

    $min1 = strlen($min_pennies) > 0 ? $min_pennies : 10;  // similasr to abopve
    $min5 = strlen($min_nickels) > 0 ? $min_nickels : 10;
    $min10 = strlen($min_dimes) > 0 ? $min_dimes : 10;
    $min25 = strlen($min_quarters) > 0 ? $min_quarters : 10;
    $min100 = strlen($min_dollars) > 0 ? $min_dollars : 0;
  }

  // Display the main page, giving a choice of actions based on the equipment type

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title><?php print $Equipment; ?> Count <?php print $Coins; ?></title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- CSS  -->
    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>
  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">Count <?php print $Coins; ?> <img src="/img/count-coins.svg"></a>
        <div id="entity" class="area">COUNT</div>
      </div>
    </nav>

    <div class="container">
      <div class="section">
        <div class="row center">
<?php
  if(coin_counter_is_recycler($Equipment))
  {
?>
        <img src="/img/srb-system-recycler.png" width=<?php print round(cached_font_size() * 320 / 24); ?>px
             height=<?php print round(cached_font_size() * 240 / 24); ?>px style="background-color:transparent">
          <!-- width=320 height=240 -->
<?php
  }
  else if($Equipment == "C300")
  {
?>
        <img src="/img/c300.svg"
             width=<?php print round(cached_font_size() * 320 / 24); ?>px
             height=<?php print round(cached_font_size() * 240 / 24); ?>px>
<?php
  }
  else
  {
?>
        <img src="/img/cs400.svg"
             width=<?php print round(cached_font_size() * 320 / 24); ?>px
             height=<?php print round(cached_font_size() * 240 / 24); ?>px>
<?php
  }
?>
        </div>

<?php
  if(coin_counter_is_recycler($Equipment))
  {
?>
        <div
<?php

  // thermometer at y=133 to y=308 scaled for cached font size
  // top is at around 5.54 rem
  // center is 7 em from right of screen

  $emfactor = 1.0 / 24.0; // convert to em (height)
  $emfactorW = 1.0 / cached_font_size();
  $pos=308;   // bottom of thermometer bar (based on originalo scale of graphic)
  $scale=175; // scale (height) of thermometer bar at 100%

  $coinz = coin_count_and_relative_volume(true);
  $vol0 = floor($coinz["volume"] * $scale / 1000 + 0.5); // 1000 -> 'scale' px

  if($coin_bag_threshold <= 0 || $coin_bag_threshold > 1000)
    $coin_bag_threshold = $scale / 2;
  else
    $coin_bag_threshold = $coin_bag_threshold * $scale / 1000;

  if($vol0 >= $coin_bag_threshold)
    $vol = $coin_bag_threshold;
  else
    $vol = $vol0;

  // bottom at specific point below the top of the screen
  $bottomedge = $pos * $emfactor + 0.125;
  // left edge is 4 rem from right of screen minus 0.125 em, with 3 pixel border width
  $leftedge = (cached_screen_width() * $emfactorW - 4 - 0.125);

  // draw bounding rectangle2
  print 'style="background-color:#000000;margin:0;padding:0;'
      . ';position:absolute;left:' . ($leftedge - 0.1)
      . 'rem;width:' . (14 * $emfactor + 0.2) . 'rem;';
  print 'top:' . ($bottomedge - $scale * $emfactor - 0.1) . 'rem;';
  print 'height:' . ($scale * $emfactor + 0.2) . 'rem;"' . "><!--" . $leftedge . "-->\n";
  print "        </div>\n        <div ";

  print 'style="background-color:#ffffff;margin:0;padding:0;'
      . ';position:absolute;left:' . $leftedge
      . 'rem;width:' . (14 * $emfactor) . 'rem;';
  print 'top:' . ($bottomedge - $scale * $emfactor) . 'rem;';
  print 'height:' . ($scale * $emfactor) . 'rem;"' . ">\n";
  print "        </div>\n        <div ";

//  print 'style="background-color:#00ff00;position:absolute;left:393px;width:14px;';
  print 'style="background-color:#00ff00;margin:0;padding:0;'
      . ';position:absolute;left:' . $leftedge
      . 'rem;width:' . 14 * $emfactor . 'rem;';
  print 'top:' . (($pos - $vol) * $emfactor + 0.125). 'rem;';
  print 'height:' . $vol * $emfactor . 'rem;"' . ">\n";

  if($vol0 > $coin_bag_threshold)
  {
    if($vol0 > $scale) // handle overflows
      $vol0 = $scale;

    $scale2 = $scale - $coin_bag_threshold; // the remaining amount

    $vol = $vol0 - $coin_bag_threshold;
    $the_color = "#ffa000"; // light orange

    if($vol > $scale2 / 2)
    {
      if($vol < $scale2 * 3 / 4)
        $the_color = "#ff4040"; // darker orange
      else
        $the_color = "#ff0000"; // red
    }

    print "        </div>\n";

    print "        <div\n";
    print 'style="background-color:' . $the_color
        . ';position:absolute;left:'. $leftedge
        . 'rem;width:' . 14 * $emfactor . 'rem;';
    print 'top:' . (($pos - ($scale - $scale2) - $vol) * $emfactor + 0.125) . 'rem;';
    print 'height:' . $vol * $emfactor. 'rem;"' . ">\n";
  }
?>
        </div>
        <div class="row center" style="position:absolute;right:0;top:3.5rem;width:8rem;line-height:1.1rem">
          <center>
            <table style="width:80%">
<?php
    // text above the thermometer
    $coinz = coin_count_and_relative_volume(true);
    print '<tr>'
          . '<td style="padding:0px !important;margin:0px !important;line-height:1rem !important;font-size:0.8rem;text-align:right">'
          . "Coins:&nbsp;&nbsp;</td>"
          . '<td style="padding:0px !important;margin:0px !important;line-height:1rem !important;font-size:0.8rem;text-align:right">'
          . $coinz["coins"] . "&nbsp;</td>"
          . '</tr><tr>'
          . '<td style="padding:0px !important;margin:0px !important;line-height:1rem !important;font-size:0.8rem;text-align:right">'
          . "Rel Vol:&nbsp;&nbsp;</td>"
          . '<td style="padding:0px !important;margin:0px !important;line-height:1rem !important;font-size:0.8rem;text-align:right">'
          . sprintf("%0.1f%%", $coinz["volume"] / 10.0) . "</td>"
          . "</tr>\n";
?>
            </table>
          </center>
        </div>
<?php
  }
?>

<?php
  if(coin_counter_is_recycler($Equipment))
  {
    // only use available quantities to calculate things (and make sure they never go below zero)
    $avail1   = $count1c > $min1     ? $count1c - $min1 : 0;
    $avail5   = $count5c > $min5     ? $count5c - $min5 : 0;
    $avail10  = $count10c > $min10   ? $count10c - $min10 : 0;
    $avail25  = $count25c > $min25   ? $count25c - $min25 : 0;
    $avail100 = $count100c > $min100 ? $count100c - $min100 : 0;

    if($batch1 > 1)
      $rolls1 = floor($avail1 / $batch1);
    else
      $rolls1 = "";

    if($batch5 > 1)
      $rolls5 = floor($avail5 / $batch5);
    else
      $rolls5 = "";

    if($batch10 > 1)
      $rolls10 = floor($avail10 / $batch10);
    else
      $rolls10 = "";

    if($batch25 > 1)
      $rolls25 = floor($avail25 / $batch25);
    else
      $rolls25 = "";

    if($batch100 > 1)
      $rolls100 = floor($avail100 / $batch100);
    else
      $rolls100 = "";

    // Recycler includes the current coin count in the display
?>
        <div class="row center" style="width:25em;line-height:1.2rem"> <!--500px -->
            <table>
              <tr>
                <th style="width:2em;padding:0px;margin:0px;text-align:center">&nbsp;</th>
                <th style="padding:0px;margin:0px;text-align:center">pennies</th>
                <th style="padding:0px;margin:0px;text-align:center">nickels</th>
                <th style="padding:0px;margin:0px;text-align:center">dimes</th>
                <th style="padding:0px;margin:0px;text-align:center">quarters</th>
                <th style="padding:0px;margin:0px;text-align:center">dollars</th>
                <th style="width:2em;padding:0px;margin:0px;text-align:center">&nbsp;</th>
              </tr>
              <tr>
                <td style="width:2em;padding:0px;margin:0px;text-align:center">&nbsp;</td>
                <td style="padding:0px;margin:0px;text-align:right"><?php print $count1c; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:0px;margin:0px;text-align:right"><?php print $count5c; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:0px;margin:0px;text-align:right"><?php print $count10c; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:0px;margin:0px;text-align:right"><?php print $count25c; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:0px;margin:0px;text-align:right"><?php print $count100c; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="width:2em;padding:0px;margin:0px;text-align:center">&nbsp;</td>
              </tr>
              <tr>
                <td style="width:2em;padding:0px;margin:0px;text-align:center">Rolls:</td>
                <td style="padding:0px;margin:0px;text-align:right"><?php print $rolls1; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:0px;margin:0px;text-align:right"><?php print $rolls5; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:0px;margin:0px;text-align:right"><?php print $rolls10; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:0px;margin:0px;text-align:right"><?php print $rolls25; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:0px;margin:0px;text-align:right"><?php print $rolls100; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="width:2em;padding:0px;margin:0px;text-align:center">&nbsp;</td>
              </tr>
            </table>
        </div>
<?php
  }
?>
      </div>
    </div>

<?php
  if(coin_counter_is_recycler($Equipment))
  {
    if(coin_counter_is_recycler_twin($Equipment)) // DEFAULT TO MULTI
    {
//    <form action="/make-coin-baggies2.php" method=GET>  old screen, left for reference
?>
    <form action="/dispense-coins.php" method=GET>
<?php
    }
    else
    {
?>
    <form action="/make-coin-baggies.php" method=GET>
<?php
    }
?>
      <div class="next-button" style="position:absolute;text-align:center;width:33%;margin:0px;padding:0;bottom:0.6rem;left:0">
          <button id=resume type=submit class="btn waves-effect primary-fill btn-shadow">Harvest <?php print $Rolls; ?></button>
      </div>
    </form>
    <form action="/glue/initiate-adhoc-coins.php" method=GET>
      <input type=hidden style="visibility:hidden" name=clear_first value="N"></input>
      <div class="next-button" style="position:absolute;text-align:center;width:38%;margin:0px;padding:0;bottom:0.6rem;right:25%">
          <button id=start type=submit class="btn waves-effect primary-fill btn-shadow">Add/Count Coins</button>
      </div>
    </form>
    <form action="/" method=GET>
      <div class="next-button" style="position:absolute;text-align:center;width:25%;margin:0px;padding:0;bottom:0.6rem;right:0">
          <button id=start type=submit class="btn waves-effect primary-fill btn-shadow">Exit</button>
      </div>
    </form>
<?php
  }
  else
  {
    // C400 and C300 can 'Finish Coin Baggies' or do 'New Count'.  'New Count' does a 'clear' first
?>
    <form action="/glue/initiate-adhoc-coins.php" method=GET>
      <input type=hidden style="visibility:hidden" name=clear_first value="N"></input>
      <div class="next-button" style="position:absolute;margin:0px;padding:0;bottom:18px;left:0px">
          <button id=resume type=submit class="btn waves-effect primary-fill btn-shadow">Finish Coin <?php print $Baggies;?></button>
      </div>
    </form>
    <form action="/glue/initiate-adhoc-coins.php" method=GET>
      <input type=hidden style="visibility:hidden" name=clear_first value="Y"></input>
      <div class="next-button" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
          <button id=start type=submit class="btn waves-effect primary-fill btn-shadow">New Count</button>
      </div>
    </form>
<?php
  }
?>
    <script src="/js/UserFeedback.js"></script>
  </body>
</html>

