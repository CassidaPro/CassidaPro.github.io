<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');

  $Equipment = coin_counter_equipment();

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Ad Hoc <?php print $Coins; ?> Results</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
      .single tr th:last-child
      {
        text-align:right !important;
        padding-right:40px;
      }
      .message-thing
      {
        color:#000000;/*#585858 works for bold font*/
        font-size: 1.1rem; /*28px;*/
        font-weight:500; /* normal - 700 is bold */
        position:absolute;
        padding-left: 0.4rem /*10px*/;
        padding-top: 0px;
        padding-bottom: 0px;
        height: 2.87rem /*64px*/;
        bottom: 1.8rem /*48px*/;
        width: 20rem /*440px*/;
        left: 0.5rem /*12px*/;
        line-height:1.1rem;
        vertical-align:bottom;
        text-align:left;
      }
    </style>
  </head>
<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
    <a id="logo-container" href="#" class="brand-logo titlebar">Count <?php print $Coins; ?><img src="img/count-coins.svg"></a>
      <div id="entity" class="area">COUNT</div>
    </div>
  </nav>

  <div class="container">
    <div class="section">
      <div class="single-table-container center">
      <p class="table-name"><?php print $Coins; ?></p>
        <table id="coins" class="striped single">
          <tbody>
            <tr>
              <th>¢</th>
              <th>Qty</th>
              <th>Val&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
            </tr>
            <tr>
              <td>1¢</td><td id="qc1">0</td><td id="vc1">0.00</td>
            </tr>
            <tr>
              <td>5¢</td><td id="qc5">0</td><td id="vc5">0.00</td>
            </tr>
            <tr>
              <td>10¢</td><td id="qc10">0</td><td id="vc10">0.00</td>
            </tr>
            <tr>
              <td>25¢</td><td id="qc25">0</td><td id="vc25">0.00</td>
            </tr>
            <tr id="row100" style="visibility:hidden">
              <td>$1</td><td id="qc100">0</td><td id="vc100">0.00</td>
            </tr>
          </tbody>
        </table>
      <div class="subtotal" style="display:none" id="coinsSubTotal">0.00</div>
    </div>
    <div class="page-total  grand_total">
      <div class="page-total-textfield"><label>Total</label>
          <input id="page-total" class="mdl-textfield__input special-text-input" type="text" value="$ 0.00" maxlength="9" disabled />
      </div>
    </div>
    <div class="message-thing"><p id="messagething"></p></div>
  </div>

  <!-- coins prompts alerts -->
  <div id=popup_alert class="modal-container"
       style="position:absolute;top:0px;visibility:hidden;background-color: rgba(0, 0, 0, 0.4) !important">
    <div id=alert_dlg class="medium-modal me-and-my-shadow coins_prompts_modal"
         style="position:relative;left:25%;width:50%;top:4rem;min-height:14rem">
      <H1 id=alert_dlg_title
          style="color:rgba(98, 92, 255, 1) !important;font-size:1.6rem;text-align:center;width:100%;margin:0;margin-bottom:0.5rem;padding:0">
        The Title
      </H1>
      <div id=alert_dlg_guts class="coins_prompts_guts">
        The Content
      </div>
    </div>
  </div>

<!-- STOP button - ->
<script>
  function DoStop()
  {
    var myRequest = new Request("/glue/stop-c400.php");

    fetch(myRequest)
      .then(function(response)
            {
              if (!response.ok)
              {
                console.log("status", response.status);
              }
              return  response.text();
            })
      .then(function(text)
            {
              document.getElementById("stop").disabled = true; // disable button; do here for better feedback
            });
  }
</script>
  <div style="position:absolute;margin:0px;padding:0px;bottom:18px;right:12px">
    <button id=stop name=stop onClick="DoStop();" class="btn waves-effect primary-fill btn-shadow">
      STOP
    </button>
  </div>
<!-- -->

  <!--  Scripts-->
  <!--script src="js/sweetalert2.min.js"></script-->
  <script src="js/coins-prompts.js"></script>
  <script src="js/custom.js"></script>

  <script>
    // script overrides
  //  CustomerMod='<?php print $CustomerMod; ?>';
    isRecycler = <?php if(coin_counter_is_recycler($Equipment)) print "true"; else print "false"; ?>;
    isC400 = <?php if(coin_counter_is_c400($Equipment) && !coin_counter_is_c400r($Equipment)) print "true"; else print "false"; ?>;
    isC400R = <?php if(coin_counter_is_c400r($Equipment)) print "true"; else print "false"; ?>;
    isC300 = <?php if(coin_counter_is_c300($Equipment)) print "true"; else print "false"; ?>;
    MD_font_size = '<?php print cached_font_size(); ?>';

  <?php
    if(coin_counter_is_recycler($Equipment))
    {
  ?>
    HasAutoResume = true;
    refreshInterval = 250;
    restartInterval = 10; // for Recycler, no need for extra delay
  <?php
    }
  ?>

    function CoinsTerm()
    {
      return "<?php print $Coins; ?>";
    }

    // this function is defined and returns TRUE to have a print button
    function ShowPrintButton()
    {
      return true;
    }

    function doPrint()
    {
      document.getElementById("messagething").innerHTML = "Printing Receipt...";
      document.getElementById("messagething").style.color="#000000"; // BLACK
      document.getElementById("messagething").style.backgroundColor="#ffffff"; // WHITE

      var myRequest = new Request("/glue/print.php");

      fetch(myRequest)
        .then(function(response)
              {
                myRequest = null;

                if (!response.ok)
                {
                  console.log("status-c400", response.status); // debug only (TODO: remove?)
                }

                return  response.text();
              })
        .then(function(text)
              {
                document.getElementById("messagething").innerHTML = text;
              });

    }

    function doFinished()
    {
      window.location.href="/glue/complete-adhoc-coins.php";
    }


  </script>

  <script src="/js/UserFeedback.js"></script>

</body>
</html>

