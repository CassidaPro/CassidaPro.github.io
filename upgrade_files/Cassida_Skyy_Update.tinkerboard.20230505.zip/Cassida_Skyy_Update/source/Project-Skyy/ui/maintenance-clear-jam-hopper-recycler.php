<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $Equipment = coin_counter_equipment(0);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Test C400</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>

  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">
          JAM - Recycler
          <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
               src="/img/<?php if(coin_counter_is_recycler_twin($Equipment)) print "twin-recycler-only.png" ; else print "recycler-only.png"; ?>" >
        </a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <table style="width:85%;border:0">
        <tr>
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle;margin:15 0 0 0px">Clearing JAM from the Coin Recycler Hoppers
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Remove coin inlet assembly by pressing the upper rear latch, while sliding it away
                                                                       from you, and then up to remove it. In a similar fashion, remove 2nd coin hopper cover.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Check for stuck coins and remove any foreign material</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">If needed, remove each hopper from the baseplate by pressing the lower rear latch,
                                                                       sliding the hopper towards you, and then:
                    <UL>
                      <LI style="list-style-type:circle;margin:15 0 0 0px">Remove all coins from each hopper, keeping each hopper's coins separated.
                      <LI style="list-style-type:circle;margin:15 0 0 0px">Carefully rotate the Coin Disk anti-clockwise to dislodge stuck coins.</LI>
                      <LI style="list-style-type:circle;margin:15 0 0 0px">Retrieve any coins that drop out of the hopper</LI>
                      <LI style="list-style-type:circle;margin:15 0 0 0px">Replace coins back into their respective hoppers, then slide each hopper back onto the baseplate.</LI>
                    </UL>
                  </LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Replace hopper cover and inlet assembly</LI>
                </UL>
              </LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>
    <form id=set_batch method=GET action="/c400-do-set-batch.php"><input type=hidden name=next value="/maintenance-c400-received.php" /></form>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/maintenance-clear-jam-recycler.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">Done</span>
      </a>
      <br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

