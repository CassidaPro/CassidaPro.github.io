<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Strap = do_getconf($parseconf,"terms",'Straps','Straps');

  $IsStrap = do_getvar("Strap", "0"); // non-zero if strapping

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
<?php
  if($IsStrap == 1)
  {
?>
    <title>Ad-Hoc <?php print make_singular($Strap) . " " . $Notes; ?></title>
<?php
  }
  else
  {
?>
    <title>Ad-Hoc Count <?php print $Notes; ?></title>
<?php
  }
?>

    <!-- CSS  -->

    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- CSS  -->

    <style>
<?php
  set_ideal_font_height();
?>
      .single tr td:last-child
      {
        text-align:right !important;
        padding-right:100px;
      }
      .message-thing
      {
        color:#000000;/*#585858 works for bold font*/
        font-size: 1.15rem /*28px*/;
        font-weight:500; /* normal - 700 is bold */
        position:absolute;
        padding-left: 10px;
        padding-top: 0px;
        padding-bottom: 0px;
        min-height: 2.67rem /* 64px*/;
        max-height: 3.5rem;
        bottom: 2rem /*24px, was 48px*/;
        width: 18.3rem /*440px*/;
        left:12px;
        line-height:110%;
        vertical-align:bottom;
        text-align:left;
      }
    </style>
  </head>
<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">
<?php
  if($IsStrap == 1)
  {
    print make_singular($Strap) . " " . $Notes;
  }
  else
  {
    print "Count " . $Notes;
  }
?>
        <img src="img/count-notes.svg">
      </a>
      <div id="entity" class="area">COUNT</div>
    </div>
    <button id="print-button" class="btn secondary-fill print-button" type="submit"><img src="img/printer.svg"> PRINT</button>
  </nav>

  <div class="container">
    <div class="section">
      <div class="single-table-container center">
        <p class="table-name"><?php print $Notes; ?></p>
        <table id="notes" class="striped single">
          <tbody>
            <tr>
              <th>$</th>
              <th>Qty</th>
              <th>Val&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
              <!--th>Val </th-->
            </tr>
            <tr>
              <td>$1</td><td id="qn1">0</td><td id="vn1">0</td></tr>
            <tr>
              <td>$2</td><td id="qn2">0</td><td id="vn2">0</td></tr>
            <tr>
              <td>$5</td><td id="qn5">0</td><td id="vn5">0</td></tr>
            <tr>
              <td>$10</td><td id="qn10">0</td><td id="vn10">0</td></tr>
            <tr>
              <td>$20</td><td id="qn20">0</td><td id="vn20">0</td></tr>
            <tr>
              <td>$50</td><td id="qn50">0</td><td id="vn50">0</td></tr>
            <tr>
              <td>$100</td><td id="qn100">0</td><td id="vn100">0</td></tr>
          </tbody>
        </table>
        <div class="subtotal" style="display:none" id="notesSubTotal">0</div>
      </div>
    </div>

    <div class="page-total  grand_total">
      <div class="page-total-textfield"><label>Total</label>
        <input id="page-total" class="mdl-textfield__input special-text-input" type="text" value="$0" maxlength="9" disabled />
      </div>

    </div>
    <div class="message-thing"><p id="zeus-message"></p></div>
    <div class="next-button">
      <form>
        <button id=new_count
<?php
  if($IsStrap == 1)
  {
?>
                formaction="/glue/adhoc-straps-new-count.php"
<?php
  }
  else
  {
?>
                formaction="/glue/adhoc-notes-new-count.php"
<?php
  }
?>
                class="waves-effect btn-flat primary-text">New Count </button>
        <button id=done formaction="/glue/complete-adhoc-notes.php" class="btn waves-effect primary-fill btn-shadow">DONE</button>
      </form>
    </div>
  </div>


  <!--  Scripts-->
  <script src="js/custom.js"></script>

  <script>
    var refreshTable = null; // use this to un-schedule and re-schedule updates

    function DoSetZeusStatusInterval()
    {
      if(refreshTable != null)
      {
        clearInterval(refreshTable); // so that these messages don't interfere
      }

      refreshTable= setInterval(getZeusStatus, 500);
    }

    function getZeusStatus()
    {
        var myRequest = new Request("/glue/status-zeus.php");

        fetch(myRequest)
          .then(function(response)
                {
                  myRequest = null;

                  if (!response.ok)
                  {
                    console.log("status-zeus", response.status);
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                  var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                  var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
                  var the_date = xx.getElementsByTagName("date")[0];
                  var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
                  var st = xx.getElementsByTagName("status")[0].children;
                  var status_code = "";
                  var status_text = "";
                  var today = "";

                  if(the_date && the_date.childNodes.length > 0)
                  {
                    today = the_date.childNodes[0].nodeValue
                  }
                  else
                  {
                    today = "unknown date";
                  }

                  for (var i1 = 0; i1 < st.length; i1++)
                  {
                    if(st[i1].nodeName == "code")
                      status_code = st[i1].childNodes[0].nodeValue;
                    else if(st[i1].nodeName == "text")
                      status_text = st[i1].childNodes[0].nodeValue;
                  }

                  document.getElementById("zeus-message").style.color="#000000"; // BLACK
                  document.getElementById("zeus-message").style.backgroundColor="#ffffff"; // WHITE

                  // at the first ';' or '.' insert a '<br>'
                  status_text = status_text.replace(/;/,";<br>").replace(/\./,".<br>");

                  if(status_code=="1")
                  {
                    document.getElementById("zeus-message").innerHTML = "Counting...";

                    document.getElementById("new_count").disabled=true;
                    document.getElementById("done").disabled=true;
                  }
                  else if(status_code != 0)
                  {
                    document.getElementById("zeus-message").innerHTML = status_text;

                    if(status_code == "15") // an error
                    {
                      document.getElementById("zeus-message").style.color="#800000"; // RED
                      document.getElementById("zeus-message").style.backgroundColor="#ffff00"; // YELLOW
                    }
                    else if(status_code == "6") // insufficient strap qty in stacker
                    {
                      document.getElementById("zeus-message").style.color="#802000"; // rededish-brown
                      document.getElementById("zeus-message").style.backgroundColor="#c0ffff"; // light cyan
                    }
                    else
                    {
                      document.getElementById("zeus-message").style.color="#000000"; // black
                      document.getElementById("zeus-message").style.backgroundColor="#ffffff"; // white
                    }

                    if(status_code == 15 // error
  //                     || status_code == 4  // hopper empty
                       || status_code == 8) // hopper and stacker empty
                    {
                      document.getElementById("new_count").disabled=false;
                      document.getElementById("done").disabled=false;
                    }
                    else
                    {
                      document.getElementById("new_count").disabled=true;
                      document.getElementById("done").disabled=true;
                    }
                  }
                  else
                  {
                    document.getElementById("zeus-message").innerHTML = "";

                    document.getElementById("new_count").disabled=false;
                    document.getElementById("done").disabled=false;
                  }

                  xx = null;
                  entity = null;
                  the_date = null;
                  tick = null;
                  st = null;
                  status_code = null;
                  status_text = null;
                  today = null;
                })
          .catch(function(error) { console.log(error);  });
    }

    // on-click event for print button - was in 'custom.js' but only used here

    function DoPrintButton()
    {
      var msg="Unable to invoke receipt print";

      if(refreshTable != null)
      {
        clearInterval(refreshTable); // so that these messages don't interfere
        refreshTable = null;
      }

      try
      {

        // if I have a 'messagething' element, assign it to the correct message
        // this on-click handler is only called from one place so this part is unlikely to fail
        document.getElementById("zeus-message").innerHTML = "Printing Receipt...";
        document.getElementById("zeus-message").style.color="#000000";
        document.getElementById("zeus-message").style.backgroundColor="#ffffff"; // WHITE
      }
      catch(e)
      {
        // ignore any errors
      }

      var myRequest = new Request("/glue/print.php");

      fetch(myRequest)
        .then(function(response)
              {
                myRequest = null;

                if (!response.ok)
                {
                  console.log("print", response.status); // debug only (TODO: remove?)
                }

                return  response.text();
              })
        .then(function(text)
              {
                try
                {
                  document.getElementById("zeus-message").innerHTML = text;
                }
                finally { }
              });

      setTimeout(DoSetZeusStatusInterval, 1000); // after 1 second, restart zeus status interval
    }

    document.getElementById("print-button").addEventListener('click', DoPrintButton);

    DoSetZeusStatusInterval();

  //  $(document).ready(DoNoteResults());
    DoNoteResults();

  </script>

  <script src="/js/UserFeedback.js"></script>

</body>
</html>

