<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');

  $Equipment = coin_counter_equipment();
?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Ad Hoc Count <?php print $Coins; ?></title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- CSS  -->

    <style>
<?php
  set_ideal_font_height();
?>
    .message-thing
    {
      color:#000000;/*#585858 works for bold font*/
      font-size: 1.17rem; /*28px*/
      font-weight:500; /* normal - 700 is bold */
      position:absolute;
      padding-left: 0.35em; /*10px*/
      padding-top: 0px;
      padding-bottom: 0px;
      height: 2.28em; /*64px;*/
      bottom: 2em; /*48px*/
      width: 15.7em /*440px*/
      left: 0.42em; /*12px*/
      line-height:110%;
      vertical-align:bottom;
      text-align:left;
    }
    </style>
  </head>
<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
    <a id="logo-container" href="#" class="brand-logo titlebar">Count <?php print $Coins; ?> <img src="img/count-coins.svg"></a>
      <div id="entity" class="area">COUNT</div>
    </div>
  </nav>

  <div class="container">
    <div class="section">
      <div class="row center">
<?php
  if(coin_counter_is_c300($Equipment))
  {
?>
        <img src="img/c300.png"
<?php
  }
  else if(coin_counter_is_recycler($Equipment))
  {
    /* <img src="img/recycler.png" */
?>
        <img src="img/srb-system-count-recycler.png"
<?php
  }
  else if(coin_counter_is_c400r($Equipment))
  {
?>
        <img src="img/cs400r.png"
<?php
  }
  else // if(coin_counter_is_c400($Equipment))
  {
?>
        <img src="img/cs400.svg"
<?php
  }
?>
             width=<?php print round(cached_font_size() * 320 / 24); ?>px
             height=<?php print round(cached_font_size() * 240 / 24); ?>px>
      </div>

      <div class="message-thing"><p id="messagething"></p></div>
      <div class="next-button">
        <form>
          <button formaction="/glue/complete-adhoc-coins.php" class="waves-effect btn-flat primary-text">Skip</button>
<?php
  // for recyclers I keep the loop going
  if(coin_counter_is_recycler($Equipment))
  {
?>
          <input id=start type=hidden style="visibility:hidden" disabled>
<?php
  }
  else
  {
?>
          <button id=start name=start
                  formaction="/glue/adhoc-start-count-c400.php"
                  class="btn waves-effect primary-fill btn-shadow"
                  disabled>START</button>
<?php
  }
?>
        </form>
      </div>
    </div>

<?php
  if(coin_counter_is_recycler($Equipment))
  {
?>
    <div id=coin_tray_warning
         style="visibility:hidden;display:none;position:absolute;right:9rem;top:10rem;width:20%;height:20%;z-order:99">
      <img height=<?php print round(cached_font_size() * 3); ?>px
           src="img/coin_drawer_rotate_ccw.png"
           style="visibility:inherit" />
    </div>

<?php
  }
?>

    <div id="modal1" class="modal">
      <div class="modal-content">
        <h6></h6>
        <p></p>
      </div>
    </div>
  </div>

  <!--  Scripts-->
  <script src="js/custom.js"></script>

  <script>
    var thing = null;

    function getC400Status()
    {
      // NOTE:  this glue page also works for C300 - it will check installed equipment
      var myRequest = new Request("/glue/status-c400.php");

      fetch(myRequest)
        .then(function(response)
              {
                myRequest = null;

                if(!response.ok)
                {
                  console.log("status-c400", response.status); // debug only (TODO: remove?)
                }

                return  response.text();
              })
        .then(function(text)
              {
                // xx will be a DOM Parser type of object from which to parse XML
                var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                var tt = xx.getElementsByTagName("tick");
                var ee = xx.getElementsByTagName("entity");

                if(tt == null || tt[0] == null || tt[0].childNodes == null || tt[0].childNodes[0] == null ||
                   ee == null || ee[0] == null || ee[0].childNodes == null || ee[0].childNodes[0] == null)
                {
                  document.getElementById("messagething").innerHTML = "Server not responding";
                  if(thing != null)
                  {
                    clearInterval(thing); // status codes no longer needed
                    thing = null;
                  }

                  tt = null;
                  ee = null;
                  return;
                }

                var tick = tt[0].childNodes[0].nodeValue;
                var entity = ee[0].childNodes[0].nodeValue;
                var the_date = xx.getElementsByTagName("date")[0];
                var st = xx.getElementsByTagName("status")[0].children;
                var status_code = "";
                var status_text = "";
                var today = "";

                tt = null;
                ee = null;

                if(the_date && the_date.childNodes.length > 0)
                {
                  today = the_date.childNodes[0].nodeValue
                }
                else
                {
                  today = "unknown date";
                }

                for (var i1 = 0; i1 < st.length; i1++)
                {
                  if(st[i1].nodeName == "code")
                    status_code = st[i1].childNodes[0].nodeValue;
                  else if(st[i1].nodeName == "text")
                    status_text = st[i1].childNodes[0].nodeValue;
                }

  <?php
    if(coin_counter_is_recycler($Equipment))
    {
  ?>
                if(status_code == 30)
                {
                  document.getElementById("coin_tray_warning").style.visibility = "visible";
                  document.getElementById("coin_tray_warning").style.display = "block";
                }
                else
                {
                  document.getElementById("coin_tray_warning").style.visibility = "hidden";
                  document.getElementById("coin_tray_warning").style.display = "none";
                }
  <?php
    }
  ?>
                if(status_code == 16 || status_code == 19)
                {
  <?php
    if(!coin_counter_is_recycler($Equipment))
    {
  ?>
                  document.getElementById("messagething").innerHTML = "Please add <?php print $Coins; ?> to the hopper";
                  clearInterval(thing); // status codes no longer needed
                  thing = null;
                  document.getElementById("start").disabled = false;
  <?php
    }
    else
    {
      // for recyclers I will keep the loop going and display status as-is
  ?>
                  document.getElementById("messagething").innerHTML = status_text;
  <?php
    }
  ?>
                }
  <?php
    if(coin_counter_is_recycler($Equipment))
    {
  ?>
                else if(status_code == "22")
                {
                  xx = null;
                  entity = null;
                  the_date = null;
                  tick = null;
                  st = null;
                  status_code = null;
                  status_text = null;
                  today = null;

                  clearInterval(thing); // status codes no longer needed
                  thing = null;

                  // auto-start - machine begins counting
                  document.location.href = "/glue/adhoc-start-count-c400.php"; // go there immediately
                }
  <?php
    }

    if(coin_counter_is_recycler($Equipment))
    {
  ?>
                else if(status_code == 30)
                {
                  document.getElementById("messagething").innerHTML = status_text;
                  // TODO:  something?
                }
  <?php
    }
  ?>
                else if(status_code != 0)
                {
  <?php
    if(coin_counter_is_recycler($Equipment))
    {
  ?>
                  if(document.getElementById("start").disabled) // only if I disabled it
  <?php
    }
  ?>
                  document.getElementById("messagething").innerHTML = status_text;
                }

                xx = null;
                entity = null;
                the_date = null;
                tick = null;
                st = null;
                status_code = null;
                status_text = null;
                today = null;
              });
    }

    thing = setInterval(getC400Status, 500);   // document is ready when I get to this point anyway (getting rid of JQuery)

  </script>

  <script src="/js/UserFeedback.js"></script>

</body>
</html>

