#!/bin/sh

#####################################################################
# CASSIDA SKYY UPDATE - COPYRIGHT 2019-2021 by CASSIDA
#
# To avoid having to update TWICE, use "$upgrade_dir/post-fix.source"
# whenever a 'newerer' upgrader is likely to add things not in the
# previous upgrade list of files.
#
#####################################################################
#
# this file uses /bin/sh so '==' needs to be '=' as bash and test
# both support '==' and '=' but sh only supports '='
#
#####################################################################



# I always have local display selected for this one as the dialog
# needs to pop up on the main page.
export DISPLAY=:0.0

###############################################################################
#
#  ###
#   #  #    # # ##### #   ##   #      # ######   ##   ##### #  ####  #    #
#   #  ##   # #   #   #  #  #  #      #     #   #  #    #   # #    # ##   #
#   #  # #  # #   #   # #    # #      #    #   #    #   #   # #    # # #  #
#   #  #  # # #   #   # ###### #      #   #    ######   #   # #    # #  # #
#   #  #   ## #   #   # #    # #      #  #     #    #   #   # #    # #   ##
#  ### #    # #   #   # #    # ###### # ###### #    #   #   #  ####  #    #
#
###############################################################################


upgrade_dir=""
config_file=""
wallpaper_file=""
tarball_file=""
devdir=""


if ! test -z "$1" ; then
  # presence of a parameter, an upgrade file!!
  tarball_file=`realpath "${1}"`

  if test -e /home/pi/upgrade_files ; then
    sudo rm -rf /home/pi/upgrade_files
  fi

  mkdir /home/pi/upgrade_files
  if ! tar -C /home/pi/upgrade_files -xJ -f "${tarball_file}" ; then
    zenity --info --ok-label "OK" --width 400 \
           --title "Error In Upgrade File" \
           --text 'There was an error attempting to unpack the upgrade file "'"$1"'".\nUpgrade terminated'
    exit
  fi

  # TODO: validate the sha256 signature of the file using an online source that's guaranteed
  # to be a Cassida server, using the tarball file name.

  yy=/home/pi/upgrade_files
  if test -d "$yy/Cassida_Skyy_Update" ; then
    upgrade_dir="$yy/Cassida_Skyy_Update"
  fi
  if test -e "$yy/configuration.conf" ; then
    # just record them as I find them.  last one found wins
    config_file="$yy/configuration.conf"
  fi
  if test -e "$yy/wallpaper.png" ; then
    # just record them as I find them.  last one found wins
    wallpaper_file="$yy/wallpaper.png"
  fi

else
  echo "waiting 16 seconds"

  # running as part of the shell
  sleep 16

  # see what is mounted, first

  devdir=`grep /dev/sd /proc/mounts | awk '{ print $2; }'`

  if test -z "$devdir" ; then
    echo nothing found for update or config load, exiting
    exit
  fi

  for xx in "$devdir" ; do
    # /proc/mounts sometimes puts \nnn octals into funky file names
    # by using 'printf' I can resolve them, then pass normally as 'yy'
    # this is caused by disk labels being used for automount, and
    # specifically having a label with WHITE SPACE in its name

    yy=`printf "$xx"`
    if test -d "$yy/Cassida_Skyy_Update" ; then
      upgrade_dir="$yy/Cassida_Skyy_Update"
    fi
    if test -e "$yy/configuration.conf" ; then
      # just record them as I find them.  last one found wins
      config_file="$yy/configuration.conf"
    fi
    if test -e "$yy/wallpaper.png" ; then
      # just record them as I find them.  last one found wins
      wallpaper_file="$yy/wallpaper.png"
    fi

    if ! test -z "${upgrade_dir}${config_file}${wallpaper_file}" ; then
      devdir="$yy"
      break;
    fi

    # re-blank these
    upgrade_dir=""
    config_file=""
    wallpaper_file=""

  done
fi

###############################
#  SANITY CHECK UPGRADE IMAGE
###############################

if ! test -z "$upgrade_dir" ; then

  if ! test -e "$upgrade_dir/version.txt" ; then
    ls "$upgrade_dir/version.txt"

    echo version file does not exist, not doing upgrade
    upgrade_dir=""
  else

    version=`cat "$upgrade_dir/version.txt"`

    if test -z "$version" ; then
      echo version string is empty, not doing upgrade
      upgrade_dir=""
    fi
  fi

  #################################################################
  #
  #  #     #    #    #       ### ######     #    ####### #######
  #  #     #   # #   #        #  #     #   # #      #    #
  #  #     #  #   #  #        #  #     #  #   #     #    #
  #  #     # #     # #        #  #     # #     #    #    #####
  #   #   #  ####### #        #  #     # #######    #    #
  #    # #   #     # #        #  #     # #     #    #    #
  #     #    #     # ####### ### ######  #     #    #    #######
  #
  #################################################################

  # if the image is corrupt I need to warn
  # this checks/verifies sha1 hash if sha1sum.txt exists

  if test -e /var/tmp/upgrade_check_validate.txt ; then
    sudo rm -f /var/tmp/upgrade_check_validate.txt
  fi

  if test -e "$upgrade_dir/sha1sum.txt" ; then
    if test -e "$upgrade_dir/files.list" ; then
      (
        echo "0"
        yyz=`awk '{ print "'${upgrade_dir}'/" $0; }' < "$upgrade_dir/files.list" | xargs cat | sha1sum | awk '{ print $1; }'`
        echo "99"
        zzy=`cat "$upgrade_dir/sha1sum.txt"`

        if ! test -z "$zzy" ; then
          if test "$yyz" != "$zzy" ; then
            echo "ERROR" >/var/tmp/upgrade_check_validate.txt
          else
            echo "OK" >/var/tmp/upgrade_check_validate.txt
          fi
        fi
        echo "100"
      ) | zenity --progress --title "Validating Upgrade Image" --text "Validating the upgrade image - Please wait" \
                 --width 400 --height 80 --auto-close --no-cancel

      yyz="ERROR"
      if test -e /var/tmp/upgrade_check_validate.txt ; then
        yyz=`cat /var/tmp/upgrade_check_validate.txt`
      fi

      if test "$yyz" != "OK" ; then
        zenity --error --ok-label "OK" --width 400 --title "Upgrade Image Corrupt" \
               --text "SHA1 mismatch\n\n${yyz}\n${zzy}\n\nUpgrade Image is Corrupt"
        upgrade_dir=""
      fi
    fi
  fi

  if test -e /var/tmp/upgrade_check_validate.txt ; then
    sudo rm -f /var/tmp/upgrade_check_validate.txt
  fi

fi

#####################################################################################
#
#   #####                                 #     #
#  #     # #    # ######  ####  #    #    #     # #####  #####    ##   ##### ######
#  #       #    # #      #    # #   #     #     # #    # #    #  #  #    #   #
#  #       ###### #####  #      ####      #     # #    # #    # #    #   #   #####
#  #       #    # #      #      #  #      #     # #####  #    # ######   #   #
#  #     # #    # #      #    # #   #     #     # #      #    # #    #   #   #
#   #####  #    # ######  ####  #    #     #####  #      #####  #    #   #   ######
#
#   #####                                   #######
#  #     #  ####  #    # ###### #  ####     #       # #      ######
#  #       #    # ##   # #      # #    #    #       # #      #
#  #       #    # # #  # #####  # #         #####   # #      #####
#  #       #    # #  # # #      # #  ###    #       # #      #
#  #     # #    # #   ## #      # #    #    #       # #      #
#   #####   ####  #    # #      #  ####     #       # ###### ######
#
#####################################################################################

# first just check for wallpaper if there's no config nor upgrade...

if test -z "${upgrade_dir}${config_file}"; then

  # not upgrading, no config file
  if test -z "$wallpaper_file" ||
    # if files match, diff returns 'success' so test for "! diff -q"
    ! diff -q ${wallpaper_file} /home/pi/wallpaper.png ; then

    echo 'nothing found for upgrade, config file, or wallpaper.  exiting.'
    if ! test -z "$devdir" ; then
      sudo umount "$devdir"
    fi
    exit
  fi

  if zenity --question --ok-label "Yes" --cancel-label "No" --width 400 \
            --title "Wallpaper File Available" \
            --text 'Do you want to install the "wallpaper" image file from the removable drive?\n'"${wallpaper_file}" ; then

    echo 'Update Wallpaper'
  else
    echo 'Not gonna copy the wallpaper'
    if ! test -z "$devdir" ; then
      sudo umount "$devdir"
    fi
    exit
  fi

  sudo killall chromium-browser 2>&1 | cat >/dev/null
  sudo killall /usr/lib/chromium-browser/chromium-browser-v7 2>&1 | cat >/dev/null

  sudo killall -INT skyy

  while test -n "`ps ax | grep skyy | grep -- -D | awk '{ print $1; }'`" ; do
    sleep 1
    echo "waiting for skyy to end"
  done

  cp ${wallpaper_file} /home/pi/wallpaper.png

  sudo chown pi:pi /home/pi/wallpaper.png
  sudo chmod 664 /home/pi/wallpaper.png


  # unmount the USB drive, to prevent possible problems later
  if ! test -z "$devdir" ; then
    sudo umount "$devdir"
  fi

  # re-boot the system
  zenity --info --ok-label "OK" --width 400 \
         --title "Wallpaper Updated - Reboot" \
         --text 'Wallpaper has been updated.  Please remove the USB drive, and press "OK" to reboot'

  sudo reboot

  exit
fi


if test -z "$upgrade_dir" ; then
  echo 'no update directory.  check for config file load'

  if test -z "$config_file" ; then
    # this should never happen, but just in case I left it
    echo 'nothing found for config file either.  exiting.'
    if ! test -z "$devdir" ; then
      sudo umount "$devdir"
    fi
    exit
  fi

  ###########################################################
  #
  # PROMPT USER TO LOAD THE CONFIG FILE STORED ON THE DRIVE
  #
  ###########################################################

  if test -z "$wallpaper_file" ; then
    if zenity --question --ok-label "Yes" --cancel-label "No" --width 400 \
              --title "Configuration File Available" \
              --text 'Do you want to load the configuration file from the removable drive?\n'"${config_file}" ; then

      echo 'Update Configuration File'
    else
      echo 'Not gonna copy the config file'
      if ! test -z "$devdir" ; then
        sudo umount "$devdir"
      fi
      exit
    fi
  else
    if zenity --question --ok-label "Yes" --cancel-label "No" --width 400 \
              --title "Configuration File Available" \
              --text 'Do you want to load the configuration file and "wallpaper" file from the removable drive?\n'"${config_file}"'\n'"${wallpaper_file}" \
              ; then

      echo 'Update Configuration File and Wallpaper File'
    else
      echo 'Not gonna copy the config file and wallpaper file'
      if ! test -z "$devdir" ; then
        sudo umount "$devdir"
      fi
      exit
    fi
  fi

  # another zenity progress box starts here
  (
    echo "0"
    sudo killall chromium-browser 2>&1 | cat >/dev/null
    sudo killall /usr/lib/chromium-browser/chromium-browser-v7 2>&1 | cat >/dev/null

    sudo killall -INT skyy

    while test -n "`ps ax | grep skyy | grep -- -D | awk '{ print $1; }'`" ; do
      sleep 1
      echo "waiting for skyy to end"
    done

    cp ${config_file} /var/cache/skyy/configuration.conf

    sudo chown pi:www-data /var/cache/skyy/configuration.conf
    sudo chmod 664 /var/cache/skyy/configuration.conf

    echo "90"

    if ! test -z "$wallpaper_file" ; then
      cp ${wallpaper_file} /home/pi/wallpaper.png
      sudo chown pi:pi /home/pi/wallpaper.png
      sudo chmod 664 /home/pi/wallpaper.png
    fi

    echo "100"
    sleep 1
  ) | zenity --progress --title "Update Configuration" --text "Updating configuration..." \
             --width 400 --height 80 --auto-close --no-cancel

  # unmount the USB drive
  if ! test -z "$devdir" ; then
    sudo umount "$devdir"
  fi

  # re-start the skyy server
  sudo -u pi /home/pi/bin/skyy -D

  # re-run the browser but load the configuration wizard immediately when it starts
  sudo -u pi /usr/bin/chromium-browser \
                            -kiosk --incognito --no-touch-pinch --disable-extensions --disable-pinch \
                            --check-for-update-interval=999999999 \
                            http://localhost/config/initial-setup.php &

  exit
fi


###################################################################################################
#
#  #     #                                              ######
#  #     # #####   ####  #####    ##   #####  ######    #     # #####   ####  #    # #####  #####
#  #     # #    # #    # #    #  #  #  #    # #         #     # #    # #    # ##  ## #    #   #
#  #     # #    # #      #    # #    # #    # #####     ######  #    # #    # # ## # #    #   #
#  #     # #####  #  ### #####  ###### #    # #         #       #####  #    # #    # #####    #
#  #     # #      #    # #   #  #    # #    # #         #       #   #  #    # #    # #        #
#   #####  #       ####  #    # #    # #####  ######    #       #    #  ####  #    # #        #
#
###################################################################################################

# TODO:  do I always want this?

# recently fixed '-V' to work better, old code may have some issues though
# to prevent that I think I'll do it the hard way for now...

skyy_version=`/home/pi/bin/skyy -VQ`
upgrade_newer=`echo $skyy_version $version | /usr/bin/awk '{ if($1 < $2) print "Y"; }'`

updowngrade="upgrade"

if test -z "${upgrade_newer}" ; then

  # new feature, 're-install'
  rr=`/home/pi/bin/skyy -VQ`

  if test "x${rr}" = "x${version}"  ; then
    updowngrade="RE-Install"
  else
    updowngrade="DOWNgrade"
  fi
fi

# TODO:  is there an upgrade version that I want to store someplace??

if zenity --question --ok-label "Yes" --cancel-label "No" --width 400 \
          --title "Upgrade Available" \
          --text "Do you want to ${updowngrade}?\nCurrent Version indicates \"${skyy_version}\"\n${updowngrade} version indicates \"${version}\"" ; then

  echo Upgrade proceeding
else
  echo Upgrade canceled

  if zenity --question --ok-label "Yes" --cancel-label "No" --width 400 \
            --title "Wallpaper File Available" \
            --text 'Do you also want to install the "wallpaper" image file from the removable drive?\n'"${wallpaper_file}" ; then

    echo 'Update Wallpaper'

    cp ${wallpaper_file} /home/pi/wallpaper.png

    sudo chown pi:pi /home/pi/wallpaper.png
    sudo chmod 664 /home/pi/wallpaper.png
  fi

  if ! test -z "$devdir" ; then
    sudo umount "$devdir"
  fi

  exit
fi

# LAST MINUTE CHECK FOR WALLPAPER AND PROMPT

if ! test -z "$wallpaper_file" ; then

  if zenity --question --ok-label "Yes" --cancel-label "No" --width 400 \
            --title "Wallpaper File Available" \
            --text 'Do you also want to install the "wallpaper" image file from the removable drive?\n'"${wallpaper_file}" ; then

    echo 'Update Wallpaper'

    cp ${wallpaper_file} /home/pi/wallpaper.png

    sudo chown pi:pi /home/pi/wallpaper.png
    sudo chmod 664 /home/pi/wallpaper.png
  fi
fi





#############################
#
#  #     #
#  ##   ##   ##   # #    #
#  # # # #  #  #  # ##   #
#  #  #  # #    # # # #  #
#  #     # ###### # #  # #
#  #     # #    # # #   ##
#  #     # #    # # #    #
#
#############################

# this next section happens within the progress box, so it starts with '('
# any output will pipe into zenity progress bar, giving me an indication of progress
(
echo "0"

#############################################
#
# before all else, kill the browser and skyy
#
#############################################

sudo killall chromium-browser 2>&1 | cat >/dev/null
sudo killall /usr/lib/chromium-browser/chromium-browser-v7 2>&1 | cat >/dev/null

sudo killall -INT skyy

while test -n "`ps ax | grep skyy | grep -- -D | awk '{ print $1; }'`" ; do
  sleep 1
  echo "waiting for skyy to end"
done


echo "1"

#############################
#
# things in /home/pi/source
#
#############################

if test -d "$upgrade_dir/source" ; then
  rsync -acv --chown pi:pi "$upgrade_dir/source/"* /home/pi/source
  rsync -acv --chown pi:pi --delete "$upgrade_dir/source/Project-Skyy/"* /home/pi/source/Project-Skyy
fi

echo "5"

######################################################
#
# executable things must be chmod''d to be executable
# and symlinks from ~/bin need to be correct
#
######################################################

rm /home/pi/bin/skyy
ln -s /home/pi/source/skyy/skyy /home/pi/bin/skyy
rm /home/pi/bin/do_hmac
ln -s /home/pi/source/hmac/do_hmac /home/pi/bin/do_hmac
rm /home/pi/bin/json_parser
ln -s /home/pi/source/json_parser/json_parser /home/pi/bin/json_parser
chmod 755 /home/pi/source/skyy/skyy
chmod 755 /home/pi/source/hmac/do_hmac
chmod 755 /home/pi/source/json_parser/json_parser

echo "6"

##########################
#
# things in /home/pi/bin
#
##########################

if test -d "$upgrade_dir/bin" ; then
  rsync -ctv --chown pi:pi --chmod 755 "$upgrade_dir/bin/"* /home/pi/bin/
fi

echo "9"

##########################
#
# things in /etc
#
##########################

# rc.local
sudo rsync -cv --chown=root:root --chmod=755 "$upgrade_dir/etc/rc.local" /etc/rc.local

# update settings for vlc and networking, including sudoers.d files - this is important
sudo rsync -acv --chown=root:root --chmod=444 "$upgrade_dir/etc/sudoers.d/"* /etc/sudoers.d/

# apache config files that I might need to manage
sudo rsync -acv --chown=root:root --chmod=444 "$upgrade_dir/etc/apache2/"* /etc/apache2/

# apache config files that I might need to manage
#mkdir -p /etc/udev/rules.d
sudo rsync -acv --chown=root:root --chmod=644 "$upgrade_dir/etc/udev/rules.d/"* /etc/udev/rules.d/

# copy the X11 startup file
cp -p "$upgrade_dir/dot_xsessionrc" /home/pi/.xsessionrc

# now the VLC and desktop configs - wipe away old VLC ones, copy over with new
sudo rm -f /home/pi/.config/vlc/*
# this also copies other files in '.config'
cp -Rp "$upgrade_dir/dot_config/"* /home/pi/.config/

echo "10"

##########################
#
# video files (if present)
#
##########################

# now I copy the video files one at a time so I can show progress
sudo rsync -a --chown=pi:pi --chmod=644  "$upgrade_dir/Videos/"zc4_daily.mp4 /home/pi/Videos/
echo "25"
sudo rsync -a --chown=pi:pi --chmod=644  "$upgrade_dir/Videos/"zc4_weekly.mp4 /home/pi/Videos/
echo "35"
sudo rsync -a --chown=pi:pi --chmod=644  "$upgrade_dir/Videos/"zc4_monthly.mp4 /home/pi/Videos/
echo "70"
sudo rsync -a --chown=pi:pi --chmod=644  "$upgrade_dir/Videos/"*.avi /home/pi/Videos/
echo "90"

# TODO:  update system settings?  for now, not doing it...
#        This refers specifically to things like
#   /usr/share/plymouth/themes/cassida
#   /home/pi/.config/lxpanel
#   /home/pi/.config/pcmanfm
#   /home/pi/.config/chromium
#   /var/www <-- if I move the web site to reside here, for example
#
# for now, /etc has already been managed above


) | zenity --progress --title "Upgrading Split Recycler System" --text "Copying upgrade files" \
           --width 400 --height 80 --auto-close --no-cancel
# showing progress for all but the 'post-fix' stuff (that must do its own)

################################################################################################
#
#  ######                            #######              #####
#  #     #  ####   ####  #####       #       # #    #    #     #  ####  #####  # #####  #####
#  #     # #    # #        #         #       #  #  #     #       #    # #    # # #    #   #
#  ######  #    #  ####    #   ##### #####   #   ##       #####  #      #    # # #    #   #
#  #       #    #      #   #         #       #   ##            # #      #####  # #####    #
#  #       #    # #    #   #         #       #  #  #     #     # #    # #   #  # #        #
#  #        ####   ####    #         #       # #    #     #####   ####  #    # # #        #
#
################################################################################################

if test -e "$upgrade_dir/post-fix.source" ; then
# use 'source' to execute it, to avoid having it executable and to include
# the context of this file as well.  It could do lots of things, actually
  . "$upgrade_dir/post-fix.source"
fi

#################################################################
#
# re-setting the bootup wallpaper, now /home/pi/wallpaper.png
# (once this has been established, this section may be reemoved)
#
#################################################################

# TODO: make sure I include pi-img.home.pi/dot_config/pcmanfm/LXDE-pi/desktop-items-0.conf
#       in the upgrade image, but in case I did not...
if grep -q "wallpaper=/home/pi/source/Project-Skyy/ui/img/" \
     ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf ; then
  sed --in-place=bak 's/wallpaper=\/home\/pi\/source\/Project-Skyy\/ui\/img\/Loading.*\.png/wallpaper=\/home\/pi\/wallpaper.png/g' \
      ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
fi
sudo rm -f /usr/share/plymouth/themes/cassida/splash.png
sudo ln -s /home/pi/wallpaper.png /usr/share/plymouth/themes/cassida/splash.png
if ! test -e /home/pi/wallpaper.png ; then
  cp -p /home/pi/source/Project-Skyy/ui/img/Loading.black.png /home/pi/wallpaper.png
fi



####################################################################
#
#   ####   ####  #    # ###### #  ####     ###### # #      ######
#  #    # #    # ##   # #      # #    #    #      # #      #
#  #      #    # # #  # #####  # #         #####  # #      #####
#  #      #    # #  # # #      # #  ###    #      # #      #
#  #    # #    # #   ## #      # #    #    #      # #      #
#   ####   ####  #    # #      #  ####     #      # ###### ######
#
####################################################################

reconfig_flag=0

# if there is a configuration file, use it
# NOTE:  can't do this inside ()

if test -e "$upgrade_dir/configuration.conf" ; then

  echo "TEMPORARY:  FOUND CONFIG FILE ON USB DRIVE"

  # we want to use this new config file

  if test -e /var/cache/skyy/configuration.conf ; then

    echo "TEMPORARY:  FOUND EXISTING CONFIG FILE"

    # if files match, diff returns 'success' so test for "! diff -q"
    if ! diff -q $upgrade_dir/configuration.conf /var/cache/skyy/configuration.conf ; then

      if zenity --question --ok-label "Yes" --cancel-label "No" --width 400 \
                --title "Configuration File Available" \
                --text 'Do you want to replace your configuration file with the one from the removable drive?\n'"${config_file}" ; then

        # for now we preserve the old one, mostly for debug purposes
        if test -e /var/cache/skyy/configuration.old.conf ; then
          sudo rm -f /var/cache/skyy/configuration.old.conf
        fi
        sudo mv /var/cache/skyy/configuration.conf /var/cache/skyy/configuration.old.conf

        # copy the upgrade drive's config file on top of the existing one
        sudo cp $upgrade_dir/configuration.conf /var/cache/skyy/configuration.conf

        # At this point, the config file stored in /var/cache/skyy matches the new one
        # let me know later to run initial setup config

        reconfig_flag=1
      fi
    fi
  else
    sudo cp $upgrade_dir/configuration.conf /var/cache/skyy/configuration.conf
    reconfig_flag=1
  fi

  # make sure permissions are correct
  sudo chown pi:www-data /var/cache/skyy/configuration.conf
  sudo chmod 664 /var/cache/skyy/configuration.conf
elif ! test -e /var/cache/skyy/configuration.conf ; then

  echo "TEMPORARY:  DID NOT FIND CONFIG FILE"

  # there currently is not a config file, so I need to create one

  if test -e "$upgrade_dir/sample_configuration.conf" ; then
    echo "TEMPORARY:  COPYING DEFAULT CONFIG"

    cp -p "$upgrade_dir/sample_configuration.conf" /var/cache/skyy/configuration.conf
  else
    # this should never happen but I put this here anyway - it almost fixes things
    touch /var/cache/skyy/configuration.conf
    # note:  the permissions will be adjusted in the next section
  fi

  # run the config wizard right after upgrade (regardless)
  reconfig_flag=1
fi

# this next section happens within the progress box, so it starts with '('
(
# indicate progress of '5%' at the beginning
echo "5"

####################################################################
#
# CONFIGURATION FILE PERMISSIONS AND EXISTENCE
# if there are missing files for /var/cache/skyy then add them now
#
####################################################################

for xx in "ethernet" "configuration.conf" "wireless.conf" \
          "wifi_client_params" "equipment_stats.conf" "banking.conf" ; do
  if ! test -e /var/cache/skyy/$xx ; then
    touch /var/cache/skyy/$xx
  fi
  sudo chown pi:www-data /var/cache/skyy/$xx
  sudo chmod 664 /var/cache/skyy/$xx
done

# this where I test for the need to upgrade the 'persistent data' file
# if there are no 'preload' entries,

#if test -e /var/cache/skyy/persistent_data.conf ; then
#  if grep -q '^\[preload\]' /var/cache/skyy/persistent_data.conf ; then
#
#    # do a one-time conversion of the old persistent data
#
#    /home/pi/bin/skyy -XXX
#  fi
#fi

echo "10"

# if there are videos and images, put them in img/custom and Videos/custom
# in their appropriate locations

if test -e "$upgrade_dir/../Videos" ; then
  sudo mkdir -p /home/pi/Videos/custom
  sudo chown pi:pi /home/pi/Videos/custom
  sudo chmod 775 /home/pi/Videos/custom

  sudo rsync -a --chown=pi:pi --chmod=644  "$upgrade_dir/../Videos/"* /home/pi/Videos/custom/
fi

echo "90"

if test -e "$upgrade_dir/../Images" ; then
  sudo mkdir -p /home/pi/source/Project-Skyy/ui/img/custom
  sudo chown pi:pi /home/pi/source/Project-Skyy/ui/img/custom
  sudo chmod 775 /home/pi/source/Project-Skyy/ui/img/custom

  sudo rsync -a --chown=pi:pi --chmod=644  "$upgrade_dir/../Images/"* /home/pi/source/Project-Skyy/ui/img/custom/
fi

echo "99"

) | zenity --progress --title "Upgrading Split Recycler System" --text "Additional upgrade tasks" \
           --width 400 --height 80 --auto-close --no-cancel


# unmount the USB drive, to prevent possible problems later
if ! test -z "$devdir" ; then
  sudo umount "$devdir"
fi

# destroy the browser cache
rm -rf /home/pi/.cache/chromium/Default/*


# restart apache, the browser and skyy server

sudo service apache2 restart

sleep 1

sudo -u pi /home/pi/bin/skyy -D

#echo "TEMPORARY: reconfig_flag="'"'${reconfig_flag}'"'

if test "${reconfig_flag}" = "1" ; then
  sudo -u pi /usr/bin/chromium-browser \
                            -kiosk --incognito --no-touch-pinch --disable-extensions --disable-pinch \
                            --check-for-update-interval=999999999 \
                            http://localhost/config/initial-setup.php &

else
  sudo -u pi /usr/bin/chromium-browser \
                            -kiosk --incognito --no-touch-pinch --disable-extensions --disable-pinch \
                            --check-for-update-interval=999999999 \
                            http://localhost/ &

fi

