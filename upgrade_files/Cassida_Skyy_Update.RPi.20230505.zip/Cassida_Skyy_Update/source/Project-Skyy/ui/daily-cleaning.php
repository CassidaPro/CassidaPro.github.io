<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $Equipment = coin_counter_equipment();

  // where 'back' will lead me
  $back = empty($_GET['back'])
        ?  (empty($_SERVER['HTTP_REFERER']) ? "/cleaning.php" : $_SERVER['HTTP_REFERER'])
        : $_GET['back'];

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Note = make_singular(do_getconf($parseconf,"terms",'Notes','Notes'));
  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Coin = make_singular($Coins);

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
<?php
  if(coin_counter_is_recycler($Equipment))
  {
?>
    <title>Split Recycler - Daily Cleaning</title>
<?php
  }
  else
  {
?>
    <title>ZC4 - Daily Cleaning</title>
<?php
  }
?>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Daily Cleaning</a>
        <div class="area">Cleaning</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button">
          <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
               src="/img/poweroff.svg" />
        </a>
      </div>
    </nav>
    <center>
      <table style="width:85%;border:0">
        <tr style="margin:0 0.83 0 0rem;line-height: 1.2rem;border:0">
          <td style="padding:0;margin:0">
<?php
  if(coin_counter_is_recycler($Equipment))
  {
?>
            <span style="font-size:0.75rem;line-height:0.83rem;margin:0;margin-left:-0.8rem">
              <b>Zeus <?php print $Note; ?> Counter</b>
            </span>
<?php
  }
?>
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle"><b>Soft Bristle Brush Cleaning</b><!-- - see <a href="daily-cleaning-zeus.html">Figure 1A</a>-->
                  <LI style="list-style-type:circle">Grab the Soft Bristled Brush.</LI>
                  <LI style="list-style-type:circle">Locate the sensors on the front of the Zeus unit. Use the soft bristled brush to sweep away any loose particles/dust.</LI>
                  <LI style="list-style-type:circle">Clean Hopper Sensors, Reject Sensors, Stacker Sensors</LI>
                </UL>
              </LI>
<?php
  if(!coin_counter_is_recycler($Equipment))
  {
?>
              <LI style="list-style-type:disc;padding:0;margin:0 0 0 0px">
                <UL style="list-style-type:circle">C400 Cleaning<!-- - see <a href="daily-cleaning-c400.html">Figure 1B</a>-->
                  <LI style="list-style-type:circle">To clean the C400, locate the latch on the front of the C400.</LI>
                  <LI style="list-style-type:circle">Remove foreign debris such as rubber bands, currency straps, paper clips, etc.</LI>
                  <LI style="list-style-type:circle">Using the soft bristle brush, sweep away any dust or particles that may be in and around the coin feeder and circular coin plate.</LI>
                </UL>
              </LI>
<?php
  }
?>
              <!--LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle">Touch Screen and Printer
                  <LI style="list-style-type:circle">Wipe down with Microfiber cleaning cloth as needed</LI>
                </UL>
              </LI-->
            </UL>
          </td>
        </tr>
      </table>
    </center>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/cleaning.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/cleaning.svg" height=32 width=32 class="invertible-icon">
        <span style="vertical-align:middle">&nbsp; &nbsp;BACK</span>
      </a><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

