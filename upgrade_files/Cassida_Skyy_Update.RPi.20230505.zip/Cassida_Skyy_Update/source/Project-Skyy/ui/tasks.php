<?php
/*          Copyright 2019-2020 by Cassida          */
/* Use only in accordance with the supplied license */

  include "glue/common_utils.php";

  // TODO:  once working, put these functions into include files

  function do_arrayvar($the_array, $the_varname, $the_default)
  {
    if(empty($the_array) || empty($the_array[$the_varname]))
      return $the_default;
    else
      return $the_array[$the_varname];
  }

  function parse_eval_result($thingy)
  {
    // this function actually tests a concept, whether or not it is
    // reasonable to control 'eval()' parsing results from skyy or
    // from any other application for that matter.  Normally not a problem

    $rval = [];

    $pp = explode("\n", $thingy);//, -1, PREG_SPLIT_NOEMPTY);
    foreach($pp as $vv)
    {
      $vv = ltrim(rtrim($vv));
      if(substr($vv,0,1) == ';')
        continue;

      if(empty($vv))
        continue;

      $qq = explode('=', $vv);//, -1, PREG_SPLIT_NOEMPTY);
      if(empty($qq[1]))
        continue;

      // the results are supposed to be 'var=statement' for each line
      // so I'll still allow the right-half, but will assign the var myself.
      // this is not ideal and should probably be changed.  For now I'll mitigate
      // possible 'injection' problems by trimming ';'s and failing if any remain

      // trim any trailing ';'s
      $th3 = ltrim(rtrim($qq[1]));

      while(substr($th3,strlen($th3)-1,1) == ';')
        $th3 = substr($th3,0,strlen($th3)-1); // trim off any trailing ';'s

      // for now, if any ';'s remain, it's an error
      if(strchr($th3, ';') !== '') // can't find a ';'
      {
        $th2 = '$th=' . $th3 . ";";
        eval($th2); // this assigns '$th' to the evaluated '$qq[1]'
      }

      $aa=substr($qq[0], 1, 999);

      $rval[$aa] = $th;
    }

    return $rval;
  }

  // if I attempt to go to this page from outside of the system,
  // re-direct to the config page

  $ip_addr = $_SERVER["REMOTE_ADDR"];

  // some things go differently if we are using a Recycler for counting coins
  $Equipment = coin_counter_equipment(0);


  // get task info, similar to glue/taskinfo.php
  // TODO:  if this method is too cumersome, go back to using 'eval()'
  $thingy = skyyreq("count-entity");
  $thingy = parse_eval_result($thingy);

  $Entity                = do_arrayvar($thingy,"Entity","");
  $CountDate             = do_arrayvar($thingy,"CountDate","");
  $CountTick             = do_arrayvar($thingy,"CountTick",'0');
  $RegistersComplete     = do_arrayvar($thingy,"RegistersComplete",'0');
  $DrawerComplete        = do_arrayvar($thingy,"DrawerComplete",'0');
  $SafeComplete          = do_arrayvar($thingy,"SafeComplete",'0');
  $Class4Complete        = do_arrayvar($thingy,"Class4Complete",'0');
  $Class5Complete        = do_arrayvar($thingy,"Class5Complete",'0');
  $BuildTillsComplete    = do_arrayvar($thingy,"BuildTillsComplete",'0');
  $VerifyDepositComplete = do_arrayvar($thingy,"VerifyDepositComplete",'0');
//  $Safe                  = do_arrayvar($thingy,"Safe",'');
//  $Drawer                = do_arrayvar($thingy,"Drawer",'');
//  $Registers             = do_arrayvar($thingy,"Registers",'');
//  $BuildTills            = do_arrayvar($thingy,"BuildTills",'');
//  $VerifyDeposit         = do_arrayvar($thingy,"VerifyDeposit",'');

  // legacy; use '$SafeComplete' etc.
  if($SafeComplete != 0)
    $Safe = "complete";
  else
    $Safe = "incomplete";

  if($DrawerComplete != 0)
    $Drawer = "complete";
  else
    $Drawer = "incomplete";

  if($RegistersComplete != 0)
    $Registers = "complete";
  else
    $Registers = "incomplete";

  if($BuildTillsComplete != 0)
    $BuildTills = "complete";
  else
    $BuildTills = "incomplete";

  if($VerifyDepositComplete != 0)
    $VerifyDeposit = "complete";
  else
    $VerifyDeposit = "incomplete";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  $Process = do_getconf($parseconf,"terms",'Process','Daily Tasks');

  $BOrder       = do_getconf($parseconf,"vessels",'Order','1,2,3');
  $BOrder = explode(',', $BOrder . ',,,,,'); // note extra commas to make sure I have 5 of them
  $Button1Class = ltrim(rtrim($BOrder[0]));
  $Button2Class = ltrim(rtrim($BOrder[1]));
  $Button3Class = ltrim(rtrim($BOrder[2]));
  $Button4Class = ltrim(rtrim($BOrder[3]));
  $Button5Class = ltrim(rtrim($BOrder[4]));

  // next I need to know what each class really is
  // If blank, it's not being used.  The config UI needs to validate this

  $Class1       = do_getconf($parseconf,"vessels",'Class1','');
  $Class2       = do_getconf($parseconf,"vessels",'Class2','');
  $Class3       = do_getconf($parseconf,"vessels",'Class3','');

  $Class4 = "";
  $Class5 = "";

  $Build        = do_getconf($parseconf,"vessels",'Build','');
  $Verify       = do_getconf($parseconf,"vessels",'Verify','');

  // 'TaskButton#' moved to 'Class#Button'

  $TaskButton1 = do_getconf($parseconf,"terms","Class" . $Button1Class . "Button",
                            do_getconf($parseconf,"vessels",$Button1Class,$Button1Class));
  $TaskButton2 = do_getconf($parseconf,"terms","Class" . $Button2Class . "Button",
                            do_getconf($parseconf,"vessels",$Button2Class,$Button2Class));
  $TaskButton3 = do_getconf($parseconf,"terms","Class" . $Button3Class . "Button",
                            do_getconf($parseconf,"vessels",$Button3Class,$Button3Class));


  // slightly different method here for determining where to send things

  $Button1Link = "/glue/initiate-count-class.php?class=" . $Button1Class;
  $Button2Link = "/glue/initiate-count-class.php?class=" . $Button2Class;
  $Button3Link = "/glue/initiate-count-class.php?class=" . $Button3Class;

  $BuildIcon = do_getconf($parseconf,"icons",'Build','build_tills.png');
  $VerifyIcon = do_getconf($parseconf,"icons",'Verify','notes.svg');

  $BIcons = [];
  $BIcons[0] = "";
  $BIcons[1] = do_getconf($parseconf,"icons",'Class1','safe.svg');
  $BIcons[2] = do_getconf($parseconf,"icons",'Class2','drawer.svg');
  $BIcons[3] = do_getconf($parseconf,"icons",'Class3','register.svg');
  $BIcons[4] = do_getconf($parseconf,"icons",'Class4','');
  $BIcons[5] = do_getconf($parseconf,"icons",'Class5','');

//  // TEMPORARY
//  print $Button1Class . ", " . $Button2Class . ", " . $Button3Class . "<br>\n";
//  print $BIcons[$Button1Class] . ", " . $BIcons[$Button2Class] . ", " . $BIcons[$Button3Class] . "<br>\n";

  $Button1Icon = $BIcons[$Button1Class];
  $Button2Icon = $BIcons[$Button2Class];
  $Button3Icon = $BIcons[$Button3Class];

  $Button4Icon = "";
  $Button5Icon = "";

  // assigning class 4/5 buttons for Build/Verify or Class 4 / Class 5
  // process buttons 4 and 5 here.  depends on what's been selected

  if(empty($Build) || empty($Verify))
  {
    if($BOrder[0] != 4 && $BOrder[1] != 4 && $BOrder[2] != 4 && $BOrder[3] != 4 && $BOrder[4] != 4)
    {
      $Class4 = do_getconf($parseconf,"vessels",'Class4','');
      $TaskButton4 = do_getconf($parseconf,"terms","Class" . $Button4Class . "Button",
                                do_getconf($parseconf,"vessels",$Button4Class,$Button4Class));
      $Button4Link = "/glue/initiate-count-class.php?class=" . $Button4Class;

      if(empty($Button4Class) && !empty($Class4))
        $Button4Class = '4';

      $Button4Icon = $BIcons[$Button4Class];
    }
  }
  else
  {
    $Class4 = $Build;
    $TaskButton4 = do_getconf($parseconf,"terms","BuildButton", "BUILD TILLS");
    $Button4Class = $Build; // for later, to indicate button visibility
    $Button4Icon = $BuildIcon;

    if(coin_counter_is_recycler_twin($Equipment))
    {
      // NOTE: this is probably the easiest way to do it
      $Button4Link = "/dispense-coins.php?origin=" . urlencode("/tasks.php")
                   . "&entity=" . urlencode($TaskButton4) . "&next=/build_tills-strap-qty.php";
    }
    else if(coin_counter_is_recycler($Equipment))
    {
      $Button4Link = "/build_tills-make-baggies.php";
    }
    else
    {
      $Button4Link = "/build_tills-strap-qty.php";
    }
  }

  if(empty($Build) && empty($Verify))
  {
    $Class5 = do_getconf($parseconf,"vessels",'Class5', '');
    $TaskButton5 = do_getconf($parseconf,"terms","Class" . $Button5Class . "Button",
                              do_getconf($parseconf,"vessels",$Button5Class,$Button5Class));
    $Button5Link = "/glue/initiate-count-class.php?class=" . $Button5Class;

    if(empty($Button5Class) && !empty($Class5))
      $Button5Class = '5';

    $Button5Icon = $BIcons[$Button5Class];
  }
  else if(empty($Verify))
  {
    if($BOrder[0] != 5 && $BOrder[1] != 5 && $BOrder[2] != 5 && $BOrder[3] != 5 && $BOrder[4] != 5)
    {
      $Class5 = $Build;
      $TaskButton5 = do_getconf($parseconf,"terms","BuildButton", "BUILD TILLS");
      $Button5Class = $Build;
      $Button5Icon = $BuildIcon;

      if(coin_counter_is_recycler_twin($Equipment))
      {
        // NOTE: this is probably the easiest way to do it
        $Button5Link = "/dispense-coins.php?origin=" . urlencode("/tasks.php")
                     . "&entity=" . urlencode($TaskButton5) . "&next=/build_tills-strap-qty.php";
      }
      else if(coin_counter_is_recycler($Equipment))
      {
        $Button5Link = "/build_tills-make-baggies.php";
      }
      else
      {
        $Button5Link = "/build_tills-strap-qty.php";
      }
    }
  }
  else
  {
    $Class5 = $Verify;
    $TaskButton5 = do_getconf($parseconf,"terms","VerifyButton", "VERIFY DEPOSIT");
    $Button5Class = $Verify;
    $Button5Icon = $VerifyIcon;
    $Button5Link = "/glue/initiate-verify_deposit.php";
  }

  if(!strlen($Button4Icon))
  {
    if(!empty($Class4))
    {
      $Button4Icon = !empty($Button4Class) ? $BIcons[$Button4Class] : "";
    }
  }

  if(empty($Button5Icon))
  {
    if(!empty($Class5))
    {
      $Button5Icon = !empty($Button5Class) ? $BIcons[$Button5Class] : "";
    }
  }


  // COMPLETIONS
  $Completed = [];
  $Completed[0] = 0;
  $Completed[1] = $SafeComplete != 0 ? 1 : 0; //($Safe == "complete" ? 1 : 0);
  $Completed[2] = $DrawerComplete != 0 ? 1 : 0; // ($Drawer == "complete" ? 1 : 0);
  $Completed[3] = $RegistersComplete != 0 ? 1 : 0; // ($Registers == "complete" ? 1 : 0);
  $Completed[4] = $Class4Complete != 0 ? 1 : 0; // for now; otherwise, extract status of class 4
  $Completed[5] = $Class5Complete != 0 ? 1 : 0; // for now; otherwise, extract status of class 5

  $CheckBox1 = $Completed[$Button1Class];
  $CheckBox2 = $Completed[$Button2Class];
  $CheckBox3 = $Completed[$Button3Class];

  // special case - if there is only a single button:
  // I will not be displaying this screen.  Instead the function of that
  // one button will happen automatically

  if(strlen($Button1Class) && !strlen($Button2Class))
  {
    $back = do_getvar("back","");
    header("HTTP/1.0 302 Moved Temporarily");

    if($back == "Y")
      header("Location: /index.php");
    else if($CheckBox1) // task is now completed
      header("Location: /glue/all-tasks-complete.php");
    else
      header("Location: " . $Button1Link);

    exit;
  }

  if($Class4 == $Build)
    $CheckBox4 = ($BuildTillsComplete != 0 ? 1 : 0);
  else
    $CheckBox4 = $Completed[4];

  if($Class5 == $Verify)
    $CheckBox5 = ($VerifyDepositComplete != 0 ? 1 : 0);
  else if($Class5 == $Build)
    $CheckBox5 = ($BuildTillsComplete != 0 ? 1 : 0);
  else
    $CheckBox5 = $Completed[5];

  // TODO:  if button is not enabled, don't include it here
  $AllComplete = ((strlen($Button1Class) ? $CheckBox1 : 1)
                  && (strlen($Button2Class) ? $CheckBox2 : 1)
                  && (strlen($Button3Class) ? $CheckBox3 : 1)
                  && (strlen($Button4Class) ? $CheckBox4 : 1)
                  && (strlen($Button5Class) ? $CheckBox5 : 1))
               ? 1 : 0;

  if($CustomerMod == 2) // swap 3 and 5
  {
    $xx = $TaskButton3;
    $TaskButton3 = $TaskButton5;
    $TaskButton5 = $xx;

    $xx = $Button3Class;
    $Button3Class = $Button5Class;
    $Button5Class = $xx;

    $xx = $Button3Icon;
    $Button3Icon = $Button5Icon;
    $Button5Icon = $xx;

    $xx = $Button3Link;
    $Button3Link = $Button5Link;
    $Button5Link = $xx;

    $xx = $CheckBox3;
    $CheckBox3 = $CheckBox5;
    $CheckBox5 = $xx;

    $xx = $Completed[3];
    $Completed[3] = $Completed[5];
    $Completed[5] = $xx;
  }


/*
  // TEMPORARY
  print "Build: " . $Build . "&nbsp;&nbsp;Verify: " . $Verify . "<br>\n";

  print "Classes:<br>\n";
  print "&nbsp;&nbsp;Class 1 = " . $Class1 . "<br>\n";
  print "&nbsp;&nbsp;Class 2 = " . $Class2 . "<br>\n";
  print "&nbsp;&nbsp;Class 3 = " . $Class3 . "<br>\n";
  print "&nbsp;&nbsp;Class 4 = " . $Class4 . "<br>\n";
  print "&nbsp;&nbsp;Class 5 = " . $Class5 . "<br>\n";

  print "Button Classs:<br>\n";
  print "&nbsp;&nbsp;Button 1 Class = " . $Button1Class . "<br>\n";
  print "&nbsp;&nbsp;Button 2 Class = " . $Button2Class . "<br>\n";
  print "&nbsp;&nbsp;Button 3 Class = " . $Button3Class . "<br>\n";
  print "&nbsp;&nbsp;Button 4 Class = " . $Button4Class . "<br>\n";
  print "&nbsp;&nbsp;Button 5 Class = " . $Button5Class . "<br>\n";

  print "Button Labels:<br>\n";
  print "&nbsp;&nbsp;Button 1 Text = " . $TaskButton1 . "<br>\n";
  print "&nbsp;&nbsp;Button 2 Text = " . $TaskButton2 . "<br>\n";
  print "&nbsp;&nbsp;Button 3 Text = " . $TaskButton3 . "<br>\n";
  print "&nbsp;&nbsp;Button 4 Text = " . $TaskButton4 . "<br>\n";
  print "&nbsp;&nbsp;Button 5 Text = " . $TaskButton5 . "<br>\n";

  print "Button Links:<br>\n";
  print "&nbsp;&nbsp;Button 1 Link = " . $Button1Link . "<br>\n";
  print "&nbsp;&nbsp;Button 2 Link = " . $Button2Link . "<br>\n";
  print "&nbsp;&nbsp;Button 3 Link = " . $Button3Link . "<br>\n";
  print "&nbsp;&nbsp;Button 4 Link = " . $Button4Link . "<br>\n";
  print "&nbsp;&nbsp;Button 5 Link = " . $Button5Link . "<br>\n";

  print "Icons:<br>\n";
  print "&nbsp;&nbsp;Button 1 Icon = " . $Button1Icon . "<br>\n";
  print "&nbsp;&nbsp;Button 2 Icon = " . $Button2Icon . "<br>\n";
  print "&nbsp;&nbsp;Button 3 Icon = " . $Button3Icon . "<br>\n";
  print "&nbsp;&nbsp;Button 4 Icon = " . $Button4Icon . "<br>\n";
  print "&nbsp;&nbsp;Button 5 Icon = " . $Button5Icon . "<br>\n";

  print "Checkboxes:<br>\n";
  print "&nbsp;&nbsp;Button 1 check = " . $CheckBox1 . "<br>\n";
  print "&nbsp;&nbsp;Button 2 check = " . $CheckBox2 . "<br>\n";
  print "&nbsp;&nbsp;Button 3 check = " . $CheckBox3 . "<br>\n";
  print "&nbsp;&nbsp;Button 4 check = " . $CheckBox4 . "<br>\n";
  print "&nbsp;&nbsp;Button 5 check = " . $CheckBox5 . "<br>\n";

  exit;
*/
  // TODO:  create vars for ANY OTHER config params I'm interested in

/*
  print "banking: " . do_getconf($parseconf, "banking", "type", "") . "<br>\n";

  foreach($parseconf as $kk => $xx)
  {
    print "Key=" . $kk . "<br>\n";
    foreach($xx as $k => $x)
    {
      print "&nbsp;&nbsp;&nbsp;&nbsp;" . $k . "=" . $x . "<br>\n";
    }
    print "<br>\n";
  }

  exit;
*/

?>
<!--          Copyright 2019-2020 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
  <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
  <title>Daily Tasks</title>

  <!-- CSS  -->
  <!--link href="/css/style.css?version=newest" type="text/css" rel="stylesheet" media="screen,projection"/-->
  <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link rel="shortcut icon" href="/img/favicon.ico">

  <style>
<?php
  set_ideal_font_height();
?>
  /* styles moved out of style.css because ONLY used HERE */
  .task
  {
    width:16.1rem; /*380px*/
  }

  .checked-tasks
  {
    margin-top: 44px;
  }

  .checked-tasks div
  {
    background-repeat: no-repeat;
    background-position: bottom left;
    height:74px;
    width:74px;
    padding-left: 16px;
    margin: 0 0 38px 16px;
  }
  /* not being used any more, remove if no effect of NOT having them there
  .complete
  {
    background-image: url('../img/complete-task.png');
  }

  .incomplete
  {
    background-image: url('../img/incomplete-task.png');
  }
  */

  </style>

</head>

<body>
  <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
    <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar"><?php print $Process; ?></a>
      <div class="area">START</div>
      <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button">
        <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
             src="/img/poweroff.svg" />
      </a>
    </div>
  </nav>
  <div class="container">
    <div class="row center" style="margin-top:-6px">
      <div class="col s8 light">
<?php
  if(strlen($Button1Class))
  {
?>
        <a href=<?php print '"' . $Button1Link . '"'; ?>
           style="margin-top:1rem;margin-bottom:-0.67rem;" class="btn btn-med task waves-effect primary-fill btn-shadow">
          <img src=<?php print '"img/' . $Button1Icon . '"'; ?> alt="" class="invertible-icon">
          &nbsp;&nbsp;<?php print $TaskButton1; ?></a>
        <br style="font-size:2px;">
<?php
  }
  if(strlen($Button2Class))
  {
?>
        <a href=<?php print '"' . $Button2Link . '"'; ?>
           style="margin-top:1rem;margin-bottom:-0.67rem;" class="btn btn-med task waves-effect primary-fill btn-shadow">
          <img src=<?php print '"img/' . $Button2Icon . '"'; ?> alt="" class="invertible-icon">
          &nbsp;&nbsp;<?php print $TaskButton2; ?></a>
        <br style="font-size:2px">
<?php
  }
  if(strlen($Button3Class))
  {
?>
        <a href=<?php print '"' . $Button3Link . '"'; ?>
           style="margin-top:1rem;margin-bottom:-0.67rem;" class="btn btn-med task waves-effect primary-fill btn-shadow">
          <img src=<?php print '"img/' . $Button3Icon . '"'; ?> alt="" class="invertible-icon">
          &nbsp;&nbsp;<?php print $TaskButton3; ?></a>
        <br style="font-size:2px">
<?php
  }
  if(strlen($Button4Class))
  {
?>
        <a href=<?php print '"' . $Button4Link . '"'; ?>
           style="margin-top:1rem;margin-bottom:-0.67rem;" class="btn btn-med task waves-effect primary-fill btn-shadow">
          <img src=<?php print '"img/' . $Button4Icon . '"'; ?> alt="" class="invertible-icon">
          &nbsp;&nbsp;<?php print $TaskButton4; ?></a>
        <br style="font-size:2px">
<?php
  }
  if(strlen($Button5Class))
  {
?>
        <a href=<?php print '"' . $Button5Link . '"'; ?>
           style="margin-top:1rem;margin-bottom:-0.67rem;" class="btn btn-med task waves-effect primary-fill btn-shadow">
          <img src=<?php print '"img/' . $Button5Icon . '"'; ?> alt="" class="invertible-icon">
          &nbsp;&nbsp;<?php print $TaskButton5; ?></a>
<?php
  }
?>
      </div>
      <div class="col s4 light">
        <div class="checked-tasks left" style="padding:0;border:0;margin-top:0.62rem;margin-left:0px;margin-right:0px;margin-bottom:0px;">
          <!--div id="safe-status" style="display:none;margin-top:-4px;margin-bottom:0px;" class="left incomplete"></div-->
<?php
  if(strlen($Button1Class))
  {
?>
          <img height=<?php print cached_font_size() * 3; ?>px style="margin-top:0px;margin-bottom:0px;" src=
               <?php if($CheckBox1) print '"/img/complete-task.png"' ; else print '"/img/incomplete-task.png"'; ?> ><!--<?php print $CheckBox1; ?>-->
          <br>
<?php
  }
  if(strlen($Button2Class))
  {
?>
          <img height=<?php print cached_font_size() * 3; ?>px style="margin-top:0px;margin-bottom:0px;" src=
               <?php if($CheckBox2) print '"/img/complete-task.png"' ; else print '"/img/incomplete-task.png"'; ?> ><!--<?php print $CheckBox2; ?>-->
          <br>
<?php
  }
  if(strlen($Button3Class))
  {
?>
          <img height=<?php print cached_font_size() * 3; ?>px style="margin-top:0px;margin-bottom:0px;" src=
               <?php if($CheckBox3) print '"/img/complete-task.png"' ; else print '"/img/incomplete-task.png"'; ?> ><!--<?php print $CheckBox3; ?>-->
          <br>
<?php
  }
  if(strlen($Button4Class))
  {
?>
          <img height=<?php print cached_font_size() * 3; ?>px style="margin-top:0px;margin-bottom:0px;" src=
               <?php if($CheckBox4) print '"/img/complete-task.png"' ; else print '"/img/incomplete-task.png"'; ?> ><!--<?php print $CheckBox4; ?>-->
          <br>
<?php
  }
  if(strlen($Button5Class))
  {
?>
          <img height=<?php print cached_font_size() * 3; ?>px style="margin-top:0px;margin-bottom:0px;" src=
               <?php if($CheckBox5) print '"/img/complete-task.png"' ; else print '"/img/incomplete-task.png"'; ?> ><!--<?php print $CheckBox5; ?>-->
          <br>
<?php
  }
?>
        </div>
      </div>
    </div>
    <div class="next-button" style="bottom:16px">
      <form>
        <button formaction="/" class="waves-effect btn-flat primary-text">EXIT<!--CANCEL--></button>
        <button formaction="/glue/all-tasks-complete.php" class="btn waves-effect primary-fill btn-shadow"
                <?php if(!$AllComplete) print "disabled" ?> >DONE</button>
      </form>
    </div>
  </div>

  <!--  Scripts-->
  <script src="/js/UserFeedback.js"></script>

</body>
</html>

