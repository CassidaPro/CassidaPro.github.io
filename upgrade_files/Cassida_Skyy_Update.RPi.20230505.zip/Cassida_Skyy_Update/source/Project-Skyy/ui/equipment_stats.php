<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  header("Content-Type: application/x-unknown");
  header('Content-Disposition: attachment; filename="equipment_stats.conf"');
  header("Content-Location: /equipment_stats.conf");

  print shell_exec("cat /var/cache/skyy/equipment_stats.conf");
?>


