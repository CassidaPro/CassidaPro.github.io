<?php
/*           Copyright 2019-2023 by Cassida           */
/*  Use only in accordance with the supplied license  */

  include "glue/common_utils.php";

  // TODO:  settings determine what I see on this page
?>
<!DOCTYPE html5>
<HTML><HEAD>
<TITLE>Test Interface for ZC4 System</TITLE>
  <style>
  @font-face
  {
   font-family: Lato;
   src: url(/fonts/lato-v15-latin-regular.woff);
  }
  h2
  {
    font-size: 20px;
  }
  input
  {
    font-weight: bold;
  }
  html
  {
    font-size: 8px;
  }
  </style>
<!--script>  THIS DOES NOT WORK - it disables ALL touch events!
document.addEventListener('touchstart',
                          function(event) {event.preventDefault();},
                          {passive: false});
</script-->
</HEAD>
<BODY bgcolor="#003018" text="#ffffe0">
  <center>
    <b>
      <H2><?php print skyyreq("version" ); ?></H1>
    </b>
  </center>
  <!--center>
    <form action="/testpage" method="GET">
      <input type=submit value="test page" style="font-size:22px;height:48"/>
    </form>
  </center-->
  <center>
    <form method="GET">
      <input type=submit value="Reset" formaction="/glue/reset.php" style="width:150px;font-size:22px;height:44"/>&nbsp;&nbsp;&nbsp;&nbsp;
      <input type=submit value="Reboot" formaction="/glue/reboot.php" style="width:150px;font-size:22px;height:44"/>&nbsp;&nbsp;&nbsp;&nbsp;
      <input type=submit value="Power Off" formaction="/glue/poweroff.php" style="width:150px;font-size:22px;height:44"/>
    </form>
  </center>
  <br>
  <center>
    <H2>SETUP</H2>
    <form action="/c400-batch-qty.php" method="GET">
      <input type=submit value="C400 Batch" style="font-size:22px;height:44"/>
    </form>
    <br>
    <form action="/networking.php" method="GET">
      <input type=submit value="Network Setup" style="font-size:22px;height:44"/>
    </form>
    <br>
    <br>
    <form action="/serial_zeus.php" method="GET">
      <input type=submit value="Zeus Serial Num" style="font-size:22px;height:44"/>
    </form>

  </center>


  <!-- 'zc4 system' button at the bottom -->
  <form action="/" method="GET">
    <input type=submit value="ZC4 System" style="position:absolute;bottom:18px;width:160px;left:320px;font-size:22px;height:48"/>
  </form>

  <script>
    // This special script is not documented
    // must be defined before any 'onClick' field refers to it
    // 'Semprini' is a Monty Python joke

    var nTimes=0;
    var nLastTime=Date.now();

    function Semprini()
    {
      var nNow = Date.now();

      if(!nTimes)
      {
        nTimes = 1;
        nLastTime = nNow;
        return;
      }

      if((nNow - nLastTime) < 500 || // less than half sec
         (nNow - nLastTime) > 1500) // more than 1.5 sec
      {
        nTimes = 0;
        nLastTime = nNow;
        return;
      }

      nTimes = nTimes + 1;
      nLastTime = nNow;

      if(nTimes > 5)
      {
        // change this according to the need
        window.location.assign("/testpage/");
        return;
      }
    }
  </script>

  <div style="font-size:10px;position: absolute;bottom:2px;right:2px;">
    <!-- this feature is undocumented.  Again -->
    <div onClick="Semprini();" style="height:20px;width:30px">&nbsp;&nbsp;&nbsp;&nbsp;</div>
  </div>

</BODY></HTML>

