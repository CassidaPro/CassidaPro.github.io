<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */


  // This file handles two web pages in several modes.
  // The first mode is "Harvest Rolls" from the coin count screen
  // The second mode is Maint code 644 which allows individual coins and dollar coins
  // The third mode is 'Verify Deposit' which allows you to pay a specific amount
  //
  // On entry the page for determining the payout amount is shown.  This is managed
  // in the upper half of the code.
  // The 'Actual Payout' page is managed in the lower half
  //
  // (A very large banner makes it easy to find the lower half by visual scan)
  //
  // Both pages share some common code, and this one source file helps to
  // encapsulate the entire funcstionality into one place


  include "glue/common_utils.php";

//  setup_screen_res(); // TEMPORARY (while I am working on it)

  $check_recycler_coin_tray = 1; // set to 1 to enable, 0 to disable check

  // find out the 'origin' parameter (if assigned)
  // this is often assigned via a 'GET' parameter in the URL, but might
  // be assigned via 'POST' if I am paying out coins

  $next = do_getvar("next", "");
  if(!strlen($next))
    $next = do_postvar("next","");

  if(!strlen($next))
    $class = "";
  else
  {
    $class = do_getvar("class", "");
    if(!strlen($class))
      $class = do_postvar("class","");
  }

  $Origin = do_getvar("origin", "");
  if(!strlen($Origin))
    $Origin = do_postvar("origin","");

  if(strlen($Origin) > 0 && substr($Origin,0,1) != "/")
    $Origin = "/" . $Origin;
  else if(!strlen($Origin))
    $Origin = "/"; // default it to the main index (for now)

  $IsVerifyDeposit = false;

  $Entity = do_getvar("entity", "");
  if(!strlen($Entity))
    $Entity = do_postvar("entity", "");

  if(!strlen($Entity))
    $Entity = "HARVEST";
  else if(!strcmp($Entity, "VERIFY"))
    $IsVerifyDeposit = true;

  // NOTE:  glue/initiate-verify_deposit.php assigns 'entity' to 'VERIFY, which for
  //        now is hard coded [legacy reasons until refactor].  Verify Deposit now
  //        has a completely different look, that is why
  // It is either THAT or gerrymander the returned entity num from /count-entity that is -300
  // or re-write a bunch of code that is already working...


  // rolls only - see if I want to do coins and not just rolls
  $RollsOnly = do_getvar("rolls_only", "");
  if(!strlen($RollsOnly))
    $RollsOnly = do_postvar("rolls_only", "Y"); // default is rolls only

  $Equipment = coin_counter_equipment(0);

  if(!coin_counter_is_recycler($Equipment) || // for now include check for both here
     !coin_counter_is_recycler_twin($Equipment))
  {
?>
      <HTML>
        <HEAD>
          <TITLE>re-direct</TITLE>
          <meta http-equiv="refresh" content="15;url=<?php
                if(strlen($next) > 0) print $next; else print $Origin;
                if(strlen($class) > 0) print "?class=" . urlencode($class); ?>">
<?php set_inbetween_style(); ?>
        </HEAD>
        <BODY>
          <br>
          <center>
            <H1>
              Internal Error
            </H1>
            <br>
            <br>
            <span style="font-size:1.7rem">
              This page currently does not support<br>anything except twin recycler
            </span>
          </center>
        </BODY>
      </HTML>
<?php
    exit;
  }

  // see if I need to authenticate
  $auth = ltrim(rtrim(skyyreq("fobkey-auth-required-payout")));

  if(!strlen($auth) || $auth > 0)
  {
    if(is_authenticated(true) != "OK")
    {
      $authenticate = do_getvar("authenticate","");

      if($authenticate != "Y")
      {
        // display the authenticate prompt then jump back to myself
        // with the parameters set properly including 'authenticate=Y'

        if(strlen($next) > 0)
        {
          if(strlen($class) > 0)
            authenticate_prompt("/dispense-coins.php?authenticate=Y&origin=" . urlencode($Origin)
                                . "&rolls_only=" . urlencode($RollsOnly)
                                . "&next=" . urlencode($next) . "&class=" . urlencode($class), true);
          else
            authenticate_prompt("/dispense-coins.php?authenticate=Y&origin=" . urlencode($Origin)
                                . "&rolls_only=" . urlencode($RollsOnly)
                                . "&next=" . urlencode($next), true);
        }
        else
          authenticate_prompt("/dispense-coins.php?authenticate=Y"
                              . "&rolls_only=" . urlencode($RollsOnly)
                              . "&origin=" . urlencode($Origin), true);
      }
      else if(do_authenticate(strlen($next) > 0 ? $next . "?origin=" . $Origin
                                                : $Origin, true) == "OK")
      {
        // NOTE:  on login fail it will jump to $next if it was specified, otherwise $Origin
        //        This way it behaves like 'skip'
?>
        <HTML>
          <HEAD>
            <TITLE>Authenticated</TITLE>
            <meta http-equiv="refresh" content="0.5;url=/dispense-coins.php?origin=<?php
                  print urlencode($Origin);
                  print "&rolls_only=" . urlencode($RollsOnly);
                  if(strlen($next) > 0) print "&next=" . urlencode($next);
                  if(strlen($class) > 0) print "&class=" . urlencode($class); ?>">
<?php set_inbetween_style(); ?>
          </HEAD>
          <BODY>
            <center>
              <br><br>
              <H1>Authenticated</H1>
            </center>
          </BODY>
        </HTML>
<?php
      }

      exit;
    }
  }
  else
  {
    skyyreq("fobkey-deauth");
  }

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Rolls = do_getconf($parseconf,"terms",'Rolls','Rolls');

  $async_payout = do_getconf($parseconf,"settings", "PayoutAsync",
                             do_getconf($parseconf,"settings", "PayoutBatch", "1")); // in case old config name is in use

  // coin bag threshold - the level above which the 'dispense coins' screen appears after till count
  // also the level above which the coin level indicator changes color
  $coin_bag_threshold = 10 * intval(do_getconf($parseconf, "settings", "CoinBagThresholdPercent", "50"));

  // get the batch amounts

  $pennies_batch = '0';
  $nickels_batch = '0';
  $dimes_batch = '0';
  $quarters_batch = '0';
  $dollars_batch = '0';

  $min_pennies = '';
  $min_nickels = '';
  $min_dimes = '';
  $min_quarters = '';
  $min_dollars = '';

  $Solution = skyyreq("batch-quantity");
  eval($Solution); // note var names match coin counting, below

  $Solution = skyyreq("min-coin-quantity");
  eval($Solution); // similar to getting batch qty but it's min qty

  $batch1 = $pennies_batch ? $pennies_batch : 1;     // store batch qty in different vars - easier to edit below
  $batch5 = $nickels_batch ? $nickels_batch : 1;
  $batch10 = $dimes_batch ? $dimes_batch : 1;
  $batch25 = $quarters_batch ? $quarters_batch : 1;
  $batch100 = $dollars_batch ? $dollars_batch : 1;

  $min1 = strlen($min_pennies) > 0 ? $min_pennies : 10;  // similasr to abopve
  $min5 = strlen($min_nickels) > 0 ? $min_nickels : 10;
  $min10 = strlen($min_dimes) > 0 ? $min_dimes : 10;
  $min25 = strlen($min_quarters) > 0 ? $min_quarters : 10;
  $min100 = strlen($min_dollars) > 0 ? $min_dollars : 0;


  $rval = "";
  $rval = skyyreq("snapshot-recycler");
  if(!strlen(rtrim(ltrim($rval))))
    $rval = skyyreq("snapshot-recycler"); // attempt to get it again

  if(!strlen(rtrim(ltrim($rval))))
  {
?>
      <HTML>
        <HEAD>
          <TITLE>re-direct</TITLE>
          <meta http-equiv="refresh" content="15;url=/">
<?php set_inbetween_style(); ?>
        </HEAD>
        <BODY>
          <br>
          <center>
            <H1>
              Internal Error
            </H1>
            <br>
            <br>
            <span style="font-size:1.7rem">
              Unable to get <?php print make_singular($Coins); ?> levels from Recycler
            </span>
          </center>
        </BODY>
      </HTML>
<?php
    exit;
  }

  eval($rval); // this gets the actual coin counts

  // only use available quantities to calculate things (and make sure they never go below zero)
  $avail1   = $count1c > $min1     ? $count1c - $min1 : 0;
  $avail5   = $count5c > $min5     ? $count5c - $min5 : 0;
  $avail10  = $count10c > $min10   ? $count10c - $min10 : 0;
  $avail25  = $count25c > $min25   ? $count25c - $min25 : 0;
  $avail100 = $count100c > $min100 ? $count100c - $min100 : 0;


// TODO:  do I need to track the starting count??
//  if(!strlen($StartCount)) // was there a start count?
//  {
//    // assign the start count using the current snapshot
//
//    $StartCount = $count1c . "/" . $count5c . "/"
//                . $count10c . "/" . $count25c . "/"
//                . $count100c;
//  }


  // POST transactions are used not only for security (FOB support) but to
  // help enxure that actual payout is ONLY activated from within this code.

  $is_rolls = do_postvar("rolls","");

  if($is_rolls == "") // not sent in the POST or a GET transaction was used
  {

  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //                                                                                                             //
  //    ____        _     ____                              _        _                                     _     //
  //   / ___|  ___ | |_  |  _ \  __ _  _   _   ___   _   _ | |_     / \    _ __ ___    ___   _   _  _ __  | |_   //
  //  | |  _  / _ \| __| | |_) |/ _` || | | | / _ \ | | | || __|   / _ \  | '_ ` _ \  / _ \ | | | || '_ \ | __|  //
  //  | |_| ||  __/| |_  |  __/| (_| || |_| || (_) || |_| || |_   / ___ \ | | | | | || (_) || |_| || | | || |_   //
  //   \____| \___| \__| |_|    \__,_| \__, | \___/  \__,_| \__| /_/   \_\|_| |_| |_| \___/  \__,_||_| |_| \__|  //
  //                                   |___/                                                                     //
  //                                                                                                             //
  /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>ZC4 Harvest <?php print $Coins; ?></title>

    <!-- CSS  -->
    <!--link rel="stylesheet" href="css/material.css"-->
    <!--link href="/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/-->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
    /* temporarily must un-do effects of style.css on checkboxes */
    input [type="checkbox"]
    {
      height: inherit !important;
    }

    [type="checkbox"],
    [type="checkbox"]:not(:checked),
    [type="checkbox"]:checked
    {
      all: revert !important;
      position: relative;
      top: 6px;
      opacity: 255;
      pointer-events: all;
      /*height: 24 !important;*/
      font-size: 1rem !important;
      padding: 0 !important;
      margin: 0 !important;
      transform: scale(1.5) !important;
    }

    .btn-plus
    {
      font-size:1rem;
      border-radius:2px;
      margin-left:0.5rem; /* 12 px */
      min-height: 1.75rem; /* 42px - necessary for increased button size */

      border: none;
      border-radius: 2px;
      display: inline-block;
      height: 1.5rem;
      line-height: 1.5rem;
      padding: 0 0.67rem;
      text-transform: uppercase;
      vertical-align: middle;
      outline: 0;
      text-decoration: none;
      color: #fff;
      background-color: #26a69a;
      text-align: center;
      letter-spacing: .5px;
      cursor: pointer;
      box-shadow: 2px 3px 7px 3px rgba(0,0,0,0.30) !important;
    }

    .narrower
    {
      width: 4.79rem !important;
      padding: 0.41rem 0 0.41rem 0 !important;
    }
    .shorter
    {
      padding: 0 0 0 0 !important;  /* 0.41rem 0 0.41rem 0 */
    }
    </style>

    <script>
      // global state
<?php
    if($RollsOnly != "Y" || $IsVerifyDeposit)
    {
?>
      var column = "0", output="v0";
      var mode = "amount"; // amount quantity rolls or rolls-amount
<?php
    }
    else
    {
?>
      var column = "1", output="rv1";
      var mode = "rolls-amount"; // amount quantity rolls or rolls-amount
<?php
    }
?>
      var first = true;

      function OnChangeEntryMode()
      {
<?php
    if(!$IsVerifyDeposit)
    {
?>
        //
        if(document.getElementById("quantity_select").checked)
        {
          if(document.getElementById("rolls_select").checked)
          {
            if(column < 1)
            {
              column = 1;
              OnChangeColumn(false);
            }

            mode = "rolls";
            output = 'r' + column;

<?php
      if($RollsOnly != "Y")
      {
?>
            document.getElementById("enter_total").style.display="none";
            document.getElementById("enter_total").style.visibility="hidden";
<?php
      }
?>
            document.getElementById("rolls").style.display="block";
            document.getElementById("rolls").style.visibility="visible";
            document.getElementById("quantity").style.display="none";
            document.getElementById("quantity").style.visibility="hidden";
            document.getElementById("amount").style.display="none";
            document.getElementById("amount").style.visibility="hidden";
            document.getElementById("rolls_amount").style.display="none";
            document.getElementById("rolls_amount").style.visibility="hidden";

            document.getElementById("dollar_coins").style.display="none";
            document.getElementById("dollar_coins").style.visibility="hidden";
            document.getElementById("dispense_all").style.display="block";
            document.getElementById("dispense_all").style.visibility="visible";
            document.getElementById("keypad").style.display="none";
            document.getElementById("keypad").style.visibility="hidden";

            document.getElementById("c100").value = "0";
            document.getElementById("is_rolls").value = "Y";
          }
          else
          {
            if(column < 1)
            {
              column = 1;
              OnChangeColumn(false);
            }

            mode = "quantity";
            output = 'c' + column;

<?php
      if($RollsOnly != "Y")
      {
?>
            document.getElementById("enter_total").style.display="none";
            document.getElementById("enter_total").style.visibility="hidden";
<?php
      }
?>
            document.getElementById("quantity").style.display="block";
            document.getElementById("quantity").style.visibility="visible";
            document.getElementById("rolls").style.display="none";
            document.getElementById("rolls").style.visibility="hidden";
            document.getElementById("amount").style.display="none";
            document.getElementById("amount").style.visibility="hidden";
            document.getElementById("rolls_amount").style.display="none";
            document.getElementById("rolls_amount").style.visibility="hidden";

            document.getElementById("dispense_all").style.display="none";
            document.getElementById("dispense_all").style.visibility="hidden";
            document.getElementById("dollar_coins").style.display="block";
            document.getElementById("dollar_coins").style.visibility="visible";
            document.getElementById("keypad").style.display="block";
            document.getElementById("keypad").style.visibility="visible";

            document.getElementById("is_rolls").value = "N";
          }
        }
        else
        {
          if(document.getElementById("rolls_select").checked)
          {
            if(column < 1)
            {
              column = 1;
              OnChangeColumn(false);
            }

            mode = "rolls-amount";
            output = 'rv' + column;

<?php
      if($RollsOnly != "Y")
      {
?>
            document.getElementById("enter_total").style.display="none";
            document.getElementById("enter_total").style.visibility="hidden";
<?php
      }
?>
            document.getElementById("rolls_amount").style.display="block";
            document.getElementById("rolls_amount").style.visibility="visible";
            document.getElementById("rolls").style.display="none";
            document.getElementById("rolls").style.visibility="hidden";
            document.getElementById("amount").style.display="none";
            document.getElementById("amount").style.visibility="hidden";
            document.getElementById("quantity").style.display="none";
            document.getElementById("quantity").style.visibility="hidden";

            document.getElementById("dollar_coins").style.display="none";
            document.getElementById("dollar_coins").style.visibility="hidden";
            document.getElementById("dispense_all").style.display="block";
            document.getElementById("dispense_all").style.visibility="visible";
            document.getElementById("keypad").style.display="none";
            document.getElementById("keypad").style.visibility="hidden";

            document.getElementById("c100").value = "0";

            document.getElementById("is_rolls").value = "Y";
          }
          else
          {
            mode = "amount";
            output = 'v' + column;

<?php
      if($RollsOnly != "Y")
      {
?>
            document.getElementById("enter_total").style.display="block";
            document.getElementById("enter_total").style.visibility="visible";
<?php
      }
?>
            document.getElementById("amount").style.display="block";
            document.getElementById("amount").style.visibility="visible";
            document.getElementById("rolls_amount").style.display="none";
            document.getElementById("rolls_amount").style.visibility="hidden";
            document.getElementById("quantity").style.display="none";
            document.getElementById("quantity").style.visibility="hidden";
            document.getElementById("rolls").style.display="none";
            document.getElementById("rolls").style.visibility="hidden";

            document.getElementById("dispense_all").style.display="none";
            document.getElementById("dispense_all").style.visibility="hidden";
            document.getElementById("dollar_coins").style.display="block";
            document.getElementById("dollar_coins").style.visibility="visible";
            document.getElementById("keypad").style.display="block";
            document.getElementById("keypad").style.visibility="visible";

            document.getElementById("is_rolls").value = "N";
          }
        }
<?php
    }
?>
        DoCalcTotal();
      }

      function DoClick(key) // keypad click number key
      {
        var ww = document.getElementById(output);
        var strText = ww.value;

        if(first)
        {
//          console.log("first is true");

          first = false;
          if(ww.id.substr(0,2) == "rv" || ww.id.substr(0,1) == "v")
          {
            strText = "0.00";
          }
          else
          {
            strText = ""; // make sure I clear it on the first keystroke
          }
        }

        if(ww.id.substr(0,2) == "rv" || ww.id.substr(0,1) == "v")
        {
          var vv = Math.floor(strText * 100 + 0.25);

          vv = (vv * 10 + Math.floor(key)) / 100;

          ww.value = vv.toFixed(2);
        }
        else
        {
          ww.value = strText * 10 + Math.floor(key);
        }

        DoCalcTotal();
      }

      function DoClickClr() // keyboard click clear
      {
        document.getElementById(output).value = '0';
        DoFixTotal();
      }

      function DoClickEntor() // keyboard click 'entor' which is like 'enter' but more epic
      {
        console.log('Entor');
<?php
    if($IsVerifyDeposit)
    {
?>
        OnChangeColumn();
<?php
    }
    else
    {
?>
        NextColumn();
<?php
    }
?>
      }

      function DoDollarPlus()
      {
        var vv = Math.floor(document.getElementById("c100").value); // as integer

        document.getElementById("c100").value = (vv + 1);
        DoFixTotal();
      }

      function DoDollarMinus()
      {
        var vv = Math.floor(document.getElementById("c100").value);

        if(vv > 0)
          document.getElementById("c100").value = (vv - 1);
        else
          document.getElementById("c100").value = 0;

        DoFixTotal();
      }

      function __DispenseAllSub(coin)
      {
        var vv;

        if(coin == 1)
        {
          batch_amt = <?php print $batch1;?>;
          count = <?php print $avail1;?>;
        }
        else if(coin == 5)
        {
          batch_amt = <?php print $batch5;?>;
          count = <?php print $avail5;?>;
        }
        else if(coin == 10)
        {
          batch_amt = <?php print $batch10;?>;
          count = <?php print $avail10;?>;
        }
        else if(coin == 25)
        {
          batch_amt = <?php print $batch25;?>;
          count = <?php print $avail25;?>;
        }
        else
        {
          batch_amt = 1;
          count = 0;
        }

        if(batch_amt == 0)
          batch_amt = 1;

        vv = Math.floor(count / batch_amt);

        document.getElementById("r" + coin).value = vv;
        document.getElementById("rv" + coin).value = (vv * batch_amt * coin / 100).toFixed(2);
      }

      function DoDispenseAll()
      {
        __DispenseAllSub(1);
        __DispenseAllSub(5);
        __DispenseAllSub(10);
        __DispenseAllSub(25);

        DoFixTotal();
      }


      function DoPlus(coin)
      {
        var vv = Math.floor(document.getElementById("r" + coin).value);
        var batch_amt, count;

        if(coin == 1)
          batch_amt = <?php print $batch1;?>;
        else if(coin == 5)
          batch_amt = <?php print $batch5;?>;
        else if(coin == 10)
          batch_amt = <?php print $batch10;?>;
        else if(coin == 25)
          batch_amt = <?php print $batch25;?>;
        else
          batch_amt = 1;

        if(batch_amt == 0)
          batch_amt = 1;

        if(coin == 1)
          count = <?php print $avail1;?>;
        else if(coin == 5)
          count = <?php print $avail5;?>;
        else if(coin == 10)
          count = <?php print $avail10;?>;
        else if(coin == 25)
          count = <?php print $avail25;?>;
        else
          count = 0;

        if(vv < Math.floor(count / batch_amt)) // do not exceed max possible  number of rolls
          vv ++;

        document.getElementById("r" + coin).value = vv;

        if(coin == 1)
          document.getElementById("rv1").value = (vv * <?php print $batch1;?> * 0.01).toFixed(2);
        else if(coin == 5)
          document.getElementById("rv5").value = (vv * <?php print $batch5;?> * 0.05).toFixed(2);
        else if(coin == 10)
          document.getElementById("rv10").value = (vv * <?php print $batch10;?> * 0.10).toFixed(2);
        else if(coin == 25)
          document.getElementById("rv25").value = (vv * <?php print $batch25;?> * 0.25).toFixed(2);

        DoFixTotal();
      }

      function DoMinus(coin)
      {
        var vv = Math.floor(document.getElementById("r" + coin).value);

        if(vv > 0)
          vv --;

        document.getElementById("r" + coin).value = vv;

        if(coin == 1)
          document.getElementById("rv1").value = (vv * <?php print $batch1;?> * 0.01).toFixed(2);
        else if(coin == 5)
          document.getElementById("rv5").value = (vv * <?php print $batch5;?> * 0.05).toFixed(2);
        else if(coin == 10)
          document.getElementById("rv10").value = (vv * <?php print $batch10;?> * 0.10).toFixed(2);
        else if(coin == 25)
          document.getElementById("rv25").value = (vv * <?php print $batch25;?> * 0.25).toFixed(2);

        DoFixTotal();
      }

      // NOTE:  must be defined here
      function DoFixTotal ()
      {
        DoCalcTotal(true);
      }

      function OnClickExit()
      {
        document.getElementById("exit_form").submit();
      }

    </script>

  </head>
  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">
<?php
    if($RollsOnly == "Y")
    {
?>
          Harvest <?php print $Rolls; ?> <img src="img/rolls.svg"></a></a>
<?php
    }
    else
    {
?>
          Harvest <?php print $Coins; ?> <img src="img/coins.svg"><img src="img/rolls.svg"></a></a>
<?php
    }
?>
        <div class="area" style="font-size:1rem"><?php print strtoupper($Entity);?></div>
      </div>
    </nav>
      <form name="payout_coins" id="payout_coins" action="/dispense-coins.php" method="POST">
        <!-- send data to myself, process via 'complete=Y', must use GET so other redirs work -->
        <input type="hidden" id=is_rolls name="rolls" value="N" style="visibility:hidden" />
<?php
    if(strlen($Origin) > 0)
    {
?>
        <input  type="hidden" name="Origin" value="<?php print $Origin; ?>" style="visibility:hidden" />
<?php
    }
?>
        <input  type="hidden" name="rolls_only" value="<?php print $RollsOnly; ?>" style="visibility:hidden" />
<?php
    if(strlen($next) > 0)
    {
?>
        <input  type="hidden" name="next" value="<?php print $next; ?>" style="visibility:hidden" />
<?php
      if(strlen($class) > 0)
      {
?>
        <input  type="hidden" name="class" value="<?php print $class; ?>" style="visibility:hidden" />
<?php
      }
    }
?>
      <input  type="hidden" name="entity" value="<?php print $Entity; ?>" style="visibility:hidden" />
    </form>

<?php
    if(!$IsVerifyDeposit)
    {
?>
    <div id="mode-selector" class="left-align">
      <h6> Entry mode</h6>
      <p style="line-height:1.2em;margin-top:0;margin-bottom:0.4rem">
        <label>
        <input id=quantity_select onClick="DoFixTotal();" onChange="OnChangeEntryMode();" class="with-gap"
               value="quantity" name="entrymode" type="radio" />
        <span style="color:#000000"># quantity</span>
        </label>
      </p>
      <p style="line-height:1.2em;margin-top:0;margin-bottom:0">
        <label>
        <input id=amount_select onClick="DoFixTotal();" onChange="OnChangeEntryMode();" class="with-gap"
               value="amount" name="entrymode" type="radio" checked />
        <span style="color:#000000">$ value</span>
        </label>
      </p>
      <p style="line-height:1.2em;margin-top:0.2rem;margin-bottom:0<?php
         if($RollsOnly == "Y") print "visibility:hidden;display:none"; ?>" >
        <label>
        <input id=rolls_select onClick="DoFixTotal();" onChange="OnChangeEntryMode();" type="checkbox"
               <?php if($RollsOnly == "Y") print "checked"; ?> />
        <span style="color:#000000;margin-left:0.5rem;font-size:0.9rem">
          <?php print make_proper($Rolls); ?>/Bags</span>
        </label>
      </p>

<?php
      if($RollsOnly != "Y")
      {
?>
      <div style="min-height:1em">&nbsp;</div>

      <!-- enter total amount -->

      <div id=enter_total class="row button-row selector-buttons right-align">
        <div class="selector-button" id="b0" style="margin:0;padding:0">
          <a id="ba0" href="#" class="selector-button-button btn btn-shadow multi-click waves-effect primary-fill secondary-fill selected-button"
             style="margin-left:0;padding-left:0.25rem;padding-right:0.25rem;width:auto">
            Enter Total
          </a>
        </div>
        <div style="width:auto;text-align:center">
          <label style="min-width:0.7rem">$</label>
          <div class="mdl-textfield denom shorter narrower">
            <input id="v0" class="special-text-input tweek-inactive inactive" type="text"
                   value="0.00"
                   maxlength="5" disabled />
            </div>
            <br>
            <center style="font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                ($<?php printf("%0.2f", $count1c * 0.01 + $count5c * 0.05 + $count10c * 0.10 + $count25c * 0.25); ?>)
              </span>
            </center>
          </div>
        </div>
      </div>
<?php
      }
?>
    </div>
<?php
    }
?>

<?php
    if($IsVerifyDeposit)
    {
?>
    <div class="container center">
      <input form="payout_coins" name="c1" id="c1" type="hidden"
             value="0" styl4="visibility:hidden;display:none" />
      <input form="payout_coins" name="c5" id="c5" type="hidden"
             value="0" styl4="visibility:hidden;display:none" />
      <input form="payout_coins" name="c10" id="c10" type="hidden"
             value="0" styl4="visibility:hidden;display:none" />
      <input form="payout_coins" name="c25" id="c25" type="hidden"
             value="0" styl4="visibility:hidden;display:none" />

      <!-- enter total amount -->

      <div id=enter_total class="row button-row selector-buttons">
        <span style="line-height:1.5rem;font-size1.2rem">Enter Total</pan>
        <div style="width:auto;text-align:center">
          <label style="min-width:0.7rem">$</label>
          <div class="mdl-textfield denom shorter narrower">
            <input id="v0" class="special-text-input tweek-inactive inactive" type="text"
                   value="0.00"
                   maxlength="5" disabled />
            </div>
            <br>
            <center style="font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                ($<?php printf("%0.2f", $count1c * 0.01 + $count5c * 0.05 + $count10c * 0.10 + $count25c * 0.25); ?>)
              </span>
            </center>
          </div>
        </div>
      </div>

      <!-- dollar coins -->
      <div id=dollar_coins style="display:block">
        <div style="position:absolute;width:5.8rem;top:8.8rem;right:2rem;white-space:nowrap;line-height:0.83rem;font-size:0.75rem">
            <a href="#" onClick="DoDollarPlus();" class="btn-plus waves-effect secondary-fill multi-click"
               style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
            <span href="#" id="b100" onClick="DoDollar();"
               style="width:3.33rem;margin:0;margin-left:10px;margin-right:10px;padding:0;font-size:1rem">$1</span>
            <a href="#" onClick="DoDollarMinus();" class="btn-plus waves-effect secondary-fill multi-click"
               style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
        </div>
        <div style="position:absolute;width:7.8rem;top:10.1rem;right:0.9rem;white-space:nowrap;line-height:0.83rem;font-size:0.75rem">
          <div>
            <label>$</label>
            <div class="mdl-textfield" style="width:5rem;padding-bottom:0 !important">
              <input form="payout_coins" name="c100" id="c100" class="special-text-input tweek-inactive" type="text"
               value="0"
               maxlength="5" style="width:4.1rem" disabled />
            </div>
            <center>
              <span style="font-size:0.83rem;margin:0">
                ($<?php print $avail100;?>)
              </span>
            </center>
          </div>
        </div>
      </div>
      <!--font style="font-size:0.3rem;line-height:0.3rem;margin:0;padding:0;">&nbsp;<br /></font-->
<?php
    }
    else
    {
?>
    <div class="container center">
      <div class="row button-row selector-buttons right-align">

       <table style="width:auto">
        <tr class="row"> <!--class="row button-row"-->
          <td style="min-width:7rem">
             &nbsp;
          </td>
          <td style="min-width:6rem !important">
            <div class="selector-button" id="b1">
              <a id="ba1" href="#"
<?php
      if($RollsOnly == "Y")
      {
?>
                 class="btn btn-shadow multi-click waves-effect primary-fill secondary-fill selected-button"
<?php
      }
      else
      {
?>
                 class="btn multi-click waves-effect primary-fill btn-shadow"
<?php
      }
?>
              >1 ¢ </a>
            </div>
          </td>
          <td style="min-width:6rem !important">
            <div class="selector-button" id="b5">
              <a id="ba5" href="#" class="btn multi-click waves-effect primary-fill btn-shadow">5 ¢ </a>
            </div>
          </td>
          <td style="min-width:6rem !important">
            <div class="selector-button" id="b10">
              <a id="ba10" href="#" class="btn multi-click waves-effect primary-fill btn-shadow">10 ¢ </a>
            </div>
          </td>
          <td style="min-width:6rem !important">
            <div class="selector-button" id="b25">
              <a id="ba25" href="#" class="btn multi-click waves-effect primary-fill btn-shadow">25 ¢ </a>
            </div>
          </td>
        </tr>
       </table>
      </div>

      <!-- quantity -->
      <div id="quantity" class="right-align" style="display:none">
       <table style="width:auto">
        <tr class="row"> <!--class="row button-row"-->
          <td style="min-width:7rem">
             &nbsp;
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">#</label>
            <div class="mdl-textfield denom shorter narrower">
              <input form="payout_coins" name="c1" id="c1" class="special-text-input tweek-inactive inactive" type="text"
                     value="0"
                     maxlength="3" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                (<?php print $count1c;?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">#</label>
            <div class="mdl-textfield denom shorter narrower">
              <input form="payout_coins" name="c5" id="c5" class="special-text-input tweek-inactive inactive" type="text"
                     value="0"
                     maxlength="3" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                (<?php print $count5c;?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">#</label>
            <div class="mdl-textfield shorter narrower">
              <input form="payout_coins" name="c10" id="c10" class="special-text-input tweek-inactive inactive" type="text"
                     value="0"
                     maxlength="3" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                (<?php print $count10c;?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">#</label>
            <div class="mdl-textfield shorter narrower">
              <input form="payout_coins" name="c25" id="c25" class="special-text-input tweek-inactive inactive" type="text"
                     value="0"
                     maxlength="3" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                (<?php print $count25c;?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
        </row>
       </table>
      </div>

      <!-- rolls -->
      <div id="rolls" class="right-align" style="display:none">
       <table style="width:auto">
        <tr class="row"> <!--class="row button-row"-->
          <td style="min-width:7rem">
             &nbsp;
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">#</label>
            <div class="mdl-textfield denom shorter narrower">
              <input name="r1" id="r1" class="special-text-input tweek-inactive inactive" type="text"
                     value="0"
                     maxlength="3" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                (<?php print floor($avail1 / $batch1);?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">#</label>
            <div class="mdl-textfield denom shorter narrower">
              <input name="r5" id="r5" class="special-text-input tweek-inactive inactive" type="text"
                     value="0"
                     maxlength="3" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                (<?php print floor($avail5 / $batch5);?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">#</label>
            <div class="mdl-textfield shorter narrower">
              <input name="r10" id="r10" class="special-text-input tweek-inactive inactive" type="text"
                     value="0"
                     maxlength="3" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                (<?php print floor($avail10 / $batch10);?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">#</label>
            <div class="mdl-textfield shorter narrower">
              <input name="r25" id="r25" class="special-text-input tweek-inactive inactive" type="text"
                     value="0"
                     maxlength="3" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                (<?php print floor($avail25 / $batch25);?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
        </tr>
        <tr>
          <td style="min-width:7rem">
             &nbsp;
          </td>
          <td style="min-width:6rem !important">
            <center>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoPlus(1);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoMinus(1);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <center>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoPlus(5);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoMinus(5);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <center>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoPlus(10);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoMinus(10);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <center>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoPlus(25);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoMinus(25);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
            </center>
          </td>
        </tr>
       </table>
      </div>

      <!-- amount -->
      <div id="amount" class="right-align" style="display:block">
       <table style="width:auto">
        <tr class="row"> <!--class="row button-row"-->
          <td style="min-width:7rem">
             &nbsp;
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">$</label>
            <div class="mdl-textfield denom shorter narrower">
              <input id="v1" class="special-text-input tweek-inactive" type="text"
                     value='0.00'
                     maxlength="4" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                ($<?php print sprintf("%0.2f", ($count1c * 0.01));?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">$</label>
            <div class="mdl-textfield denom shorter narrower">
              <input id="v5" class="special-text-input tweek-inactive inactive" type="text"
                     value='0.00'
                     maxlength="4" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                ($<?php print sprintf("%0.2f", ($count5c * 0.05));?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">$</label>
            <div class="mdl-textfield shorter narrower">
              <input id="v10" class="special-text-input tweek-inactive inactive" type="text"
                     value='0.00'
                     maxlength="4" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                ($<?php print sprintf("%0.2f", ($count10c * 0.10));?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">$</label>
            <div class="mdl-textfield shorter narrower">
              <input id="v25" class="special-text-input tweek-inactive inactive" type="text"
                     value='0.00'
                     maxlength="4" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                ($<?php print sprintf("%0.2f", ($count25c * 0.25));?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
        </tr>
       </table>
      </div>

      <!-- rolls amount -->
      <div id="rolls_amount" class="right-align" style="display:none">
       <table style="width:auto">
        <tr class="row"> <!--class="row button-row"-->
          <td style="min-width:7rem">
             &nbsp;
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">$</label>
            <div class="mdl-textfield denom shorter narrower">
              <input id="rv1" class="special-text-input tweek-inactive" type="text"
                     value='0.00'
                     maxlength="4" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                ($<?php print sprintf("%0.2f", (floor(($avail1) / $batch1) * $batch1 * 0.01));?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">$</label>
            <div class="mdl-textfield denom shorter narrower">
              <input id="rv5" class="special-text-input tweek-inactive inactive" type="text"
                     value='0.00'
                     maxlength="4" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                ($<?php print sprintf("%0.2f", (floor(($avail5) / $batch5) * $batch5 * 0.05));?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">$</label>
            <div class="mdl-textfield shorter narrower">
              <input id="rv10" class="special-text-input tweek-inactive inactive" type="text"
                     value='0.00'
                     maxlength="4" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                ($<?php print sprintf("%0.2f", (floor(($avail10) / $batch10) * $batch10 * 0.10));?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <label style="min-width:0.7rem">$</label>
            <div class="mdl-textfield shorter narrower">
              <input id="rv25" class="special-text-input tweek-inactive inactive" type="text"
                     value='0.00'
                     maxlength="4" disabled />
            </div>
            <br>
            <center style="text-align:right;font-size:0.83rem;line-height:1em !important">
              <span style="margin:0">
                ($<?php print sprintf("%0.2f", (floor(($avail25) / $batch25) * $batch25 * 0.25));?>)&nbsp;&nbsp;
              </span>
            </center>
          </td>
        </tr>
        <tr>
          <td style="min-width:7rem">
             &nbsp;
          </td>
          <td style="min-width:6rem !important">
            <center>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoPlus(1);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoMinus(1);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <center>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoPlus(5);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoMinus(5);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <center>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoPlus(10);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoMinus(10);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
            </center>
          </td>
          <td style="min-width:6rem !important">
            <center>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoPlus(25);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
              <span>&nbsp;&nbsp;&nbsp;&nbsp</span>
              <a href="#" onClick="DoMinus(25);" class="btn-plus waves-effect secondary-fill multi-click"
                 style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
            </center>
          </td>
        </tr>
       </table>
      </div>

      <!-- dollar coins -->
      <div id=dollar_coins style="display:block">
        <div style="position:absolute;width:5.8rem;top:8.8rem;right:2rem;white-space:nowrap;line-height:0.83rem;font-size:0.75rem">
            <a href="#" onClick="DoDollarPlus();" class="btn-plus waves-effect secondary-fill multi-click"
               style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">+</a>
            <span href="#" id="b100" onClick="DoDollar();"
               style="width:3.33rem;margin:0;margin-left:10px;margin-right:10px;padding:0;font-size:1rem">$1</span>
            <a href="#" onClick="DoDollarMinus();" class="btn-plus waves-effect secondary-fill multi-click"
               style="min-width:1.67rem;margin:0;margin-right:15;margin-left:15;padding:0">-</a>
        </div>

        <div style="position:absolute;width:7.8rem;top:10.1rem;right:0.9rem;white-space:nowrap;line-height:0.83rem;font-size:0.75rem">
          <div>
            <label>$</label>
            <div class="mdl-textfield" style="width:5rem;padding-bottom:0 !important">
              <input form="payout_coins" name="c100" id="c100" class="special-text-input tweek-inactive" type="text"
               value="0"
               maxlength="5" style="width:4.1rem" disabled />
            </div>
            <center>
              <span style="font-size:0.83rem;margin:0">
                ($<?php print $avail100;?>)
              </span>
            </center>
          </div>
        </div>
      </div>
    </div>

    <!-- dispense all -->
    <div id="dispense_all" class="center" style="position:absolute;margin:0;padding:0;bottom:24px;width:30%;right:35%;visibility:hidden">
      <button type="button" onclick="DoDispenseAll();" class="btn multi-click waves-effect primary-fill btn-shadow">
        Harvest&nbsp;All
      </button>
    </div>
<?php
    }
?>

    <!-- Calculator Keypad -->

    <div id="keypad" class="row">
      <div class=" calc-card mdl-card mdl-shadow--2dp" style="margin-left:30%;margin-right:0">
        <div class="buttons" id="wrapper">
          <button onClick="DoClick('7');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">7</button>
          <button onClick="DoClick('8');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">8</button>
          <button onClick="DoClick('9');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">9</button>
          <button onClick="DoClickClr();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent">
            <span style="display:none">backspace</span>
            <img src="img/baseline-backspace-24px.svg" style="color:white">
          </button>

          <button onClick="DoClick('4');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">4</button>
          <button onClick="DoClick('5');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">5</button>
          <button onClick="DoClick('6');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">6</button>
          <button class="mdl-button">&nbsp;</button>

          <button onClick="DoClick('1');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">1</button>
          <button onClick="DoClick('2');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">2</button>
          <button onClick="DoClick('3');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">3</button>
          <button onClick="DoClickEntor();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent tall"
                  style="line-height:1em;height:">
            E<br/>n<br/>t<br/>e<br/>r
          </button>

          <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide">0</button>
        </div>
      </div>
    </div>

    <div class="page-total">
      <span>$</span>
      <div class="mdl-textfield" style="line-height:0.83rem">
        <input id="pageTotal" class="special-text-input" type="text" value="0.00" maxlength="9" disabled />
      </div>
    </div>

    <form id="none" name="none" method="GET"></form>
<?php
    if(strlen($next) > 0) // the skip_form only applies when $next was specified
    {
?>
    <form id="skip_form" method="GET" action="<?php print $next; ?>">
<?php
      if(strlen($class) > 0)
      {
?>
      <input name="class" type="hidden" value="<?php print $class; ?>" style="visibility:hidden" />
<?php
      }
?>
    </form>
<?php
    }
?>
    <form id="exit_form" method="GET" action="<?php print $Origin; ?>">
<?php
    if(strlen($next) > 0 && strlen($class) > 0)
    {
?>
      <input name="class" type="hidden" value="<?php print $class; ?>" style="visibility:hidden" />
<?php
    }
?>
    </form>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:24px;left:12px;">
      <button type=button onclick="OnClickExit();"
              form="exit_form" class="btn waves-effect primary-fill btn-shadow">
<?php
    if($Origin != "/" && $Origin != "/tasks.php") // I have a place to go 'back' to that is not tasks nor index
    {
      print "        Back";
    }
    else
    {
      print "        Exit";
    }
?>
      </button>
    </div>
    <div class="next-button">
<?php
    if(strlen($next) > 0) // the skip button only applies when $next was specified
    {
?>
      <button id="skip_button" class="btn-flat waves-effect primary-text" type="submit"
              form="skip_form" style="visibility:hidden">
        SKIP
      </button>
<?php
    }
?>
      <button id="next" class="btn waves-effect primary-fill btn-shadow" type="submit"
              form="payout_coins">
        NEXT &gt;
      </button>
    </div>

    <script  src="js/custom.js"></script>

    <script>

      function MyRemoveClassW(ww, removal)
      {
        if(ww != null)
          ww.classList.remove(removal);
      }

      function MyRemoveClass(classname, removal)
      {
        var ii, ww = document.getElementsByClassName(classname);

        if(ww != null)
        {
          for(ii=0; ii < ww.length; ii++)
          {
            MyRemoveClassW(ww[ii], removal);
          }
        }
        ii = null;
        ww = null;
      }

      function MyAddClass(classname, addit)
      {
        var ii, ww = document.getElementsByClassName(classname);

        if(ww != null)
        {
          for(ii=0; ii < ww.length; ii++)
          {
            ww[ii].classList.add(addit);
          }
        }
        ii = null;
        ww = null;
      }

      function DoClickSelector(evt)
      {
        var ww = evt.currentTarget;

        if(ww != null)
        {
          column = ww.id.substr(1); // column ID matches that of denom
          OnChangeColumn();
        }
      }

      function NextColumn()
      {
//        console.log('column was ' + column);

        if(column == 1)
          column = 5;
        else if(column == 5)
          column = 10;
        else if(column == 10)
          column = 25;
        else if(column == 25) // do not wrap
        {
          DoFixTotal();
          return;
        }
        else if(column > 0)
        {
          column = 1;
        }

        OnChangeColumn();
      }

      function OnChangeColumn(fix_totals = true)
      {
<?php
    if($IsVerifyDeposit)
    {
?>
        output = 'v0';
<?php
    }
    else
    {
?>
//        console.log('column is now ' + column);

        // this is how the other one worked, so retaining basic functionality and method
        MyRemoveClass("btn", 'selected-button');
        MyRemoveClass("btn", 'secondary-fill');
        MyAddClass("btn", 'primary-fill');
        MyAddClass("tweek-inactive", 'inactive');

        MyAddClass("input", 'inactive');

        if(mode == "quantity")
        {
          output = 'c' + column;
        }
        else if(mode == "rolls")
        {
          output = 'r' + column;
        }
        else if(mode == "amount")
        {
          output = 'v' + column;
        }
        else // rolls-amount
        {
          output = 'rv' + column;
        }

//        console.log(output);
        MyRemoveClassW(document.getElementById(output), 'inactive');

        document.getElementById("ba" + column).classList.add('selected-button');
        document.getElementById("ba" + column).classList.add('secondary-fill');

        first = true; // new behavior

        if(fix_totals)
<?php
    }
?>
          DoFixTotal();
      }

      // iterate through each td based on class and add the values

      function DoCalcTotal(fix_it = false)
      {
        var tval, c1, c5, c10, c25, c100, oldsum;

        // this function is intended to be called whenever you hit 'enter'
        // and it will fix the totals so they're "even"

<?php
    if(!$IsVerifyDeposit)
    {
?>
        if(mode == "rolls-amount")
        {
          c1 = 1.0 * (document.getElementById("rv1").value);
          c5 = 1.0 * (document.getElementById("rv5").value);
          c10 = 1.0 * (document.getElementById("rv10").value);
          c25 = 1.0 * (document.getElementById("rv25").value);

          // add 0.25 to correct for roundoff in a sane way
          c1 = Math.floor(c1 / <?php print $batch1;?> * 100 + 0.25);  // * 100 -> div by 0.01
          c5 = Math.floor(c5 / <?php print $batch5;?> * 20 + 0.25);   // * 20 -> div by 0.05
          c10 = Math.floor(c10 / <?php print $batch10;?> * 10 + 0.25); // * 10 -> div by 0.10
          c25 = Math.floor(c25 / <?php print $batch25;?> * 4 + 0.25);   // * 4 -> div by 0.25

          document.getElementById("r1").value = c1.toFixed(0);  // assign as 'rolls'
          document.getElementById("r5").value = c5.toFixed(0);
          document.getElementById("r10").value = c10.toFixed(0);
          document.getElementById("r25").value = c25.toFixed(0);

          c1  = c1.toFixed(0) * <?php print $batch1; ?>;  // convert back to 'coins'
          c5  = c5.toFixed(0) * <?php print $batch5; ?>;
          c10 = c10.toFixed(0) * <?php print $batch10; ?>;
          c25 = c25.toFixed(0) * <?php print $batch25; ?>;
        }
        else if(mode == "amount")
        {
          if(column == 0 && fix_it) // special case, entering the amount directly
<?php
    }
?>
          {
            var a0 = (100.0 * (document.getElementById("v0").value) + 0.25).toFixed(0);
              // a0 is total in cents to avoid floating point roundoff problems

            c1 = c5 = c10 = c25 = 0;

            while(a0 >= 25 && c25 < <?php print $avail25; ?>)
            {
              a0 -= 25;
              c25++;
            }

            while(a0 >= 10 && c10 < <?php print $avail10; ?>)
            {
              a0 -= 10;
              c10++;
            }

            while(a0 >= 5 && c5 < <?php print $avail5; ?>)
            {
              a0 -= 5;
              c5++;
            }

            while(a0 > 0 && c1 < <?php print $avail1; ?>)
            {
              a0 -= 1;
              c1++;
            }

            // if needed go below reserve amounts

            while(a0 >= 25 && c25 < <?php print $count25c; ?>)
            {
              a0 -= 25;
              c25++;
            }

            while(a0 >= 10 && c10 < <?php print $count10c; ?>)
            {
              a0 -= 10;
              c10++;
            }

            while(a0 >= 5 && c5 < <?php print $count5c; ?>)
            {
              a0 -= 5;
              c5++;
            }

            while(a0 > 0 && c1 < <?php print $count1c; ?>)
            {
              a0 -= 1;
              c1++;
            }
          }
<?php
    if(!$IsVerifyDeposit)
    {
?>
          else
          {
            c1 = 1.0 * (document.getElementById("v1").value);
            c5 = 1.0 * (document.getElementById("v5").value);
            c10 = 1.0 * (document.getElementById("v10").value);
            c25 = 1.0 * (document.getElementById("v25").value);

            // add 0.25 to correct for roundoff in a sane way
            c1 = Math.floor(c1 * 100 + 0.25);  // * 100 -> div by 0.01
            c5 = Math.floor(c5 * 20 + 0.25);   // * 20 -> div by 0.05
            c10 = Math.floor(c10 * 10 + 0.25); // * 10 -> div by 0.10
            c25 = Math.floor(c25 * 4 + 0.25);   // * 4 -> div by 0.25
          }

<?php
    }
?>
          document.getElementById("c1").value = c1.toFixed(0);
          document.getElementById("c5").value = c5.toFixed(0);
          document.getElementById("c10").value = c10.toFixed(0);
          document.getElementById("c25").value = c25.toFixed(0);
<?php
    if(!$IsVerifyDeposit)
    {
?>
        }
        else if(mode == "rolls")
        {
          c1 = Math.floor(document.getElementById("r1").value) * <?php print $batch1; ?>;  // convert to 'coins'
          c5 = Math.floor(document.getElementById("r5").value) * <?php print $batch5; ?>;
          c10 = Math.floor(document.getElementById("r10").value) * <?php print $batch10; ?>;
          c25 = Math.floor(document.getElementById("r25").value) * <?php print $batch25; ?>;

          document.getElementById("rv1").value = (c1 *  0.01).toFixed(2);
          document.getElementById("rv5").value = (c5 *  0.05).toFixed(2);
          document.getElementById("rv10").value = (c10 * 0.10).toFixed(2);
          document.getElementById("rv25").value = (c25 * 0.25).toFixed(2);
        }
        else // quantity
        {
          c1 = Math.floor(document.getElementById("c1").value);
          c5 = Math.floor(document.getElementById("c5").value);
          c10 = Math.floor(document.getElementById("c10").value);
          c25 = Math.floor(document.getElementById("c25").value);

          document.getElementById("v1").value = (c1 * 0.01).toFixed(2);
          document.getElementById("v5").value = (c5 * 0.05).toFixed(2);
          document.getElementById("v10").value = (c10 * 0.10).toFixed(2);
          document.getElementById("v25").value = (c25 * 0.25).toFixed(2);
        }
<?php
    }
?>
        oldsum = c1 * 0.01
               + c5 * 0.05
               + c10 * 0.10
               + c25 * 0.25;

<?php
    if(!$IsVerifyDeposit)
    {
?>
        if(fix_it) // fix the sums
        {
//          console.log('c1=' + c1 + '  c5=' + c5 + '  c10=' + c10 + '  c25=' + c25);

          // always calc roll values based on quantities
          document.getElementById("rv1").value = ((c1 / <?php print $batch1; ?>).toFixed(0) * <?php print $batch1; ?> * 0.01 + 0.0025).toFixed(2);
          document.getElementById("rv5").value = ((c5 / <?php print $batch5; ?>).toFixed(0) * <?php print $batch5; ?> * 0.05 + 0.0025).toFixed(2);
          document.getElementById("rv10").value = ((c10 / <?php print $batch10; ?>).toFixed(0) * <?php print $batch10; ?> * 0.10 + 0.0025).toFixed(2);
          document.getElementById("rv25").value = ((c25 / <?php print $batch25; ?>).toFixed(0) * <?php print $batch25; ?> * 0.25 + 0.0025).toFixed(2);

          if(mode == "rolls" || mode == "rolls-amount")
          {
            // sync up qty values with rolls
            document.getElementById("v1").value = (document.getElementById("rv1").value * 1).toFixed(2);
            document.getElementById("v5").value = (document.getElementById("rv5").value * 1).toFixed(2);
            document.getElementById("v10").value = (document.getElementById("rv10").value * 1).toFixed(2);
            document.getElementById("v25").value = (document.getElementById("rv25").value * 1).toFixed(2);

            document.getElementById("c1").value = c1.toFixed(0);
            document.getElementById("c5").value = c5.toFixed(0);
            document.getElementById("c10").value = c10.toFixed(0);
            document.getElementById("c25").value = c25.toFixed(0);
          }
          else
          {
            // re-calculate values
            document.getElementById("v1").value = (c1.toFixed(0) * 0.01 + 0.0025).toFixed(2);
            document.getElementById("v5").value = (c5.toFixed(0) * 0.05 + 0.0025).toFixed(2);
            document.getElementById("v10").value = (c10.toFixed(0) * 0.10 + 0.0025).toFixed(2);
            document.getElementById("v25").value = (c25.toFixed(0) * 0.25 + 0.0025).toFixed(2);

            // sync up roll values with qty

            document.getElementById("r1").value = (c1 / <?php print $batch1; ?> + 0.0025).toFixed(0);
            document.getElementById("r5").value = (c5 / <?php print $batch5; ?> + 0.0025).toFixed(0);
            document.getElementById("r10").value = (c10 / <?php print $batch10; ?> + 0.0025).toFixed(0);
            document.getElementById("r25").value = (c25 / <?php print $batch25; ?> + 0.0025).toFixed(0);
          }

          sum = oldsum;
        }
        else if(mode == "rolls-amount")
        {
          // calc actual sum based on entry
          sum = parseFloat(document.getElementById("rv1").value);
          sum += parseFloat(document.getElementById("rv5").value);
          sum += parseFloat(document.getElementById("rv10").value);
          sum += parseFloat(document.getElementById("rv25").value);
        }
        else if(mode == "amount")
        {
          // calc actual sum based on entry
          sum = parseFloat(document.getElementById("v1").value);
          sum += parseFloat(document.getElementById("v5").value);
          sum += parseFloat(document.getElementById("v10").value);
          sum += parseFloat(document.getElementById("v25").value);
        }
        else // one of the quantities
<?php
    }
?>
        {
          sum = oldsum;
        }

<?php
    if(!$IsVerifyDeposit)
    {
?>
        if(mode == "rolls" || mode == "rolls-amount")
        {
          document.getElementById("c100").value = "0"; // dollars always zero when doing rolls
          c100 = 0;
        }
        else
<?php
    }
?>
        {
          c100 = Math.floor(document.getElementById("c100").value);
          sum += c100;
          oldsum += c100;
        }

//        console.log('sum ' + sum + ' ' + currency_form(sum) + '  oldsum=' + oldsum + '  c100=' + c100);
        document.getElementById("pageTotal").value = currency_form(sum);

        // make sure coin levels are below the coin inventory in the Recycler
        if(
<?php
    if($RollsOnly != "Y" && !$IsVerifyDeposit)
    {
?>
           ((mode == "rolls" || mode == "rolls-amount") &&
            (c1 > <?php print $avail1; ?> ||
             c5 > <?php print $avail5; ?> ||
             c10 > <?php print $avail10; ?> ||
             c25 > <?php print $avail25; ?> ||
             c100 > <?php print $avail100; ?> )) ||
<?php
    }
?>

           c1 > <?php if($RollsOnly == "Y") print $avail1; else print $count1c; ?> ||
           c5 > <?php if($RollsOnly == "Y") print $avail5; else print $count5c; ?> ||
           c10 > <?php if($RollsOnly == "Y") print $avail10; else print $count10c; ?> ||
           c25 > <?php if($RollsOnly == "Y") print $avail25; else print $count25c; ?> ||
           c100 > <?php if($RollsOnly == "Y") print $avail100; else print $count100c; ?> ||
           sum == 0) // do not advance if sum is zero
        {
          document.getElementById("next").disabled = true;
<?php
    if(strlen($next) > 0) // the skip button only applies when $next was specified
    {
?>
          if(sum == 0) // allow skipping the form if the sum is zero
          {
            document.getElementById("skip_button").style.visibility = "visible";
            document.getElementById("skip_button").style.display = "inline";
            document.getElementById("skip_button").disabled = false;

            document.getElementById("next").style.visibility = none;
            document.getElementById("next").style.display = "none";
          }
          else
          {
            document.getElementById("skip_button").style.visibility = none;
            document.getElementById("skip_button").style.display = "none";
            document.getElementById("skip_button").disabled = false;

            document.getElementById("next").style.visibility = "visible";
            document.getElementById("next").style.display = "inline";
          }
<?php
    }
?>
        }
        else
        {
<?php
    if(strlen($next) > 0) // the skip button only applies when $next was specified
    {
?>
          document.getElementById("skip_button").style.visibility = none;
          document.getElementById("skip_button").style.display = "none";
          document.getElementById("skip_button").disabled = false;

          document.getElementById("next").style.visibility = "visible";
          document.getElementById("next").style.display = "inline";
<?php
    }
?>
          if(!fix_it && (mode == "amount" || mode == "rolls-amount"))
          {
            if(sum.toFixed(2) == oldsum.toFixed(2))
            {
              document.getElementById("next").disabled = false;
            }
            else
            {
              document.getElementById("next").disabled = true;
            }
          }
          else
          {
            document.getElementById("next").disabled = false;
          }
        }
      }

      document.getElementById("payout_coins").onsubmit = function()
      {
        DoFixTotal(); // make sure totals are good

        document.getElementById("c1").disabled = false;
        document.getElementById("c5").disabled = false;
        document.getElementById("c10").disabled = false;
        document.getElementById("c25").disabled = false;
        document.getElementById("c100").disabled = false;
      };

      // selector button needs click event listener
      {
        var ii, ww = document.getElementsByClassName("selector-button");
        if(ww != null)
        {
          for(ii=0; ii < ww.length; ii++)
          {
            ww[ii].addEventListener('click', DoClickSelector, false);
          }
        }
        ii = null;
        ww = null;
      }

//      DoFixTotal();
      OnChangeEntryMode();
      OnChangeColumn(false);

    </script>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>
<?php
    exit;

    // --------------------------
    // END OF PAYOUT AMOUNT PAGE
    // --------------------------
  } // '$is_rolls' is BLANK

  /////////////////////////////////////////////////////////////////////////////////////////////////////////
  //                                                                                                     //
  //   _____  _                _          _                  _   ____                              _     //
  //  |_   _|| |__    ___     / \    ___ | |_  _   _   __ _ | | |  _ \  __ _  _   _   ___   _   _ | |_   //
  //    | |  | '_ \  / _ \   / _ \  / __|| __|| | | | / _` || | | |_) |/ _` || | | | / _ \ | | | || __|  //
  //    | |  | | | ||  __/  / ___ \| (__ | |_ | |_| || (_| || | |  __/| (_| || |_| || (_) || |_| || |_   //
  //    |_|  |_| |_| \___| /_/   \_\\___| \__| \__,_| \__,_||_| |_|    \__,_| \__, | \___/  \__,_| \__|  //
  //                                                                          |___/                      //
  //                                                                                                     //
  /////////////////////////////////////////////////////////////////////////////////////////////////////////

  // TWO - TWO - TWO web pages in ONE !!!

  // NOTE:  for now this only pays out for twin recycler

  /************************/
  /* COIN DISPENSE SCREEN */
  /************************/

  if(!strlen($count1c) || !strlen($count5c) ||
     !strlen($count10c) || !strlen($count25c) ||
     !strlen($count100c))
  {
?>
      <HTML>
        <HEAD>
          <TITLE>Internal Error</TITLE>
          <meta http-equiv="refresh" content="15;url=<?php
                if(strlen($next) > 0) print $next; else print $Origin;
                if(strlen($class) > 0) print "?class=" . urlencode($class); ?>">
<?php set_inbetween_style(); ?>
        </HEAD>
        <BODY>
          <br>
          <center>
            <H1>
              Internal Error - invalid coin counts
            </H1>
            <br>
            <br>
            <span style="font-size:1.7rem">
              <?php print $count1c . "," . $count5c . "," . $count10c . "," . $count25c . "," . $count100c; ?>
            </span>
          </center>
        </BODY>
      </HTML>
<?php
    exit;
  }

  $c1   = do_postvar("c1","0");
  $c5   = do_postvar("c5","0");
  $c10  = do_postvar("c10","0");
  $c25  = do_postvar("c25","0");
  $c100 = do_postvar("c100","0");

  $count_total = $count1c * 0.01
               + $count5c * 0.05
               + $count10c * 0.1
               + $count25c * 0.25
               + $count100c;

  if(($RollsOnly == "Y" &&
      ($c1 > ($avail1) ||     // for rolls only must be below 'avail' amounts
       $c5 > ($avail5) ||
       $c10 > ($avail10) ||
       $c25 > ($avail25) ||
       $c100 > ($avail100))) ||
      $c1 > ($count1c) ||     // if qty payout ok, allow amounts to go to zero
      $c5 > ($count5c) ||
      $c10 > ($count10c) ||
      $c25 > ($count25c) ||
      $c100 > ($count100c))
  {
?>
      <HTML>
        <HEAD>
          <TITLE>Internal Error</TITLE>
          <meta http-equiv="refresh" content="15;url=<?php
                if(strlen($next) > 0) print $next; else print $Origin;
                if(strlen($class) > 0) print "?class=" . urlencode($class); ?>">
<?php set_inbetween_style(); ?>
        </HEAD>
        <BODY>
          <br>
          <center>
            <H1>
              Internal Error - payout amounts exceed coin inventory
            </H1>
            <br>
            <br>
            <span style="font-size:1.7rem">
              <?php print $c1 . "," . $c5 . "," . $c10 . "," . $c25 . "," . $c100; ?><br>
              <?php print $min1 . "," . $min5 . "," . $min10 . "," . $min25 . "," . $min100; ?><br>
              <?php print $count1c . "," . $count5c . "," . $count10c . "," . $count25c . "," . $count100c; ?><br>
            </span>
          </center>
        </BODY>
      </HTML>
<?php
    exit;
  }

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>ZC4 Harvest <?php print $Coins; ?></title>

    <!-- CSS  -->
    <!--link rel="stylesheet" href="css/material.css"-->
    <!--link href="/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/-->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
    </style>
    <script>
      var MD_font_size = '<?php print cached_font_size(); ?>';

      // assign global variables at the start of the process
      // from PHP variables based on POST parameters
      var is_rolls = <?php if($is_rolls == "Y") print "true"; else print "false"; ?>;
      var nPennies = <?php print $c1; ?>;
      var nNickels = <?php print $c5; ?>;
      var nDimes = <?php print $c10; ?>;
      var nQuarters = <?php print $c25; ?>;
      var nDollars = <?php print $c100; ?>;

      // vars used by progress indicator
      var nTotalCoinsRequested = nPennies + nNickels + nDimes + nQuarters + nDollars;
      var nTotalCoinsPaidSoFar = 0;  // total coins paid so far
      var nTotalCoinsToPay = 0;       // total coins to be paid this run

      var start1, start5, start10, start25, start100;  // starting coin amounts
      var count1, count5, count10, count25, count100;  // current coin count amounts
      var last1, last5, last10, last25, last100;       // last coin count amounts
<?php
  print "      start1   = " . $count1c . ";\n";
  print "      start5   = " . $count5c . ";\n";
  print "      start10  = " . $count10c . ";\n";
  print "      start25  = " . $count25c . ";\n";
  print "      start100 = " . $count100c . ";\n";
?>
      // 'start' is the starting coin inventory. 'count' is the current coin inventory
      // 'last' is the previous value for 'count' (to see what I paid out this time around)
      last1   = count1   = start1;
      last5   = count5   = start5;
      last10  = count10  = start10;
      last25  = count25  = start25;
      last100 = count100 = start100;

      function OnClickExitOrNext(form_name)
      {
        var count1 = 0, count5 = 0, count10 = 0, count25 = 0, count100 = 0;

        var szStartCount = start1.toFixed(0) + '/'
                         + start5.toFixed(0) + '/'
                         + start10.toFixed(0) + '/'
                         + start25.toFixed(0) + '/'
                         + start100.toFixed(0);

        var myRequest = new Request("/glue/snapshot_coins.php");

        document.getElementById("messagething").innerHTML = "Get Remaining Coin Count";

        fetch(myRequest)
        .then(
            function(response)
            {
              myRequest = null;

              if (!response.ok)
              {
                console.log("count_coins", response.status); // debug only (TODO: remove?)
              }

              return  response.text();
            })
        .then(
            function(text)
            {
                    // xx will be a DOM Parser type of object from which to parse XML
              var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
              var coin = xx.getElementsByTagName("coin");
              var type, qty;
              var subCoin=0.0;
              var szEndCount;
              var myRequest2;

              if(coin != null)
              {
                for (var i1 = 0; i1 < coin.length; i1++)
                {
                  var cc = coin[i1].children;

                  if(cc.length > 0)
                  {
                    for ( var i2 = 0; i2 < cc.length; i2++)
                    {
                      if(cc[i2].nodeName == "type")
                        type = cc[i2].childNodes[0].nodeValue;

                      if(cc[i2].nodeName == "qty")
                        qty = cc[i2].childNodes[0].nodeValue;
                    }

                    if(type == 1)
                      count1 = qty;
                    else if(type == 5)
                      count5 = qty;
                    else if(type == 10)
                      count10 = qty;
                    else if(type == 25)
                      count25 = qty;
                    else if(type == 100)
                      count100 = qty;
                  }

                  cc = null;
                }
              }

              szEndCount = count1 + '/'
                         + count5 + '/'
                         + count10 + '/'
                         + count25 + '/'
                         + count100;

              myRequest2 = new Request("/glue/print-baggie-receipt.php?StartCount="
                                       + encodeURIComponent(szStartCount)
                                       + "&EndCount=" + encodeURIComponent(szEndCount));


              document.getElementById("messagething").innerHTML = "Printing Receipt";

              fetch(myRequest2)
                .then(function(response)
                      {
                        if (!response.ok)
                        {
                          console.log("OnClickExitOrNext() print receipt", response.status); // debug only (TODO: remove?  this is actually an error condition...)
                          return "ERROR";
                        }
                        return  response.text();
                      })
                .then(function(text)
                      {
<?php
  if(!strlen($auth) || $auth > 0) // i.e. authentication is required
  {
?>
                        if(form_name == "next") // I may need to clear the authentication
                        {

                          var myRequest3 = new Request("/glue/deauthenticate.php");
                          // will request de-authentication since I was authenticated

                          fetch(myRequest3)
                            .then(function(response)
                                  {
                                    if (!response.ok)
                                    {
                                      console.log("OnClickNext() print receipt", response.status); // debug only (TODO: remove?  this is actually an error condition...)
                                      return "ERROR";
                                    }
                                    return  response.text();
                                  })
                            .then(function(text)
                                  {
                                    document.getElementById(form_name).submit(); // must wait until I am here
                                    myRequest3 = null;
                                  });
                        }
                        else
                        {
<?php
  }
?>
                          document.getElementById(form_name).submit(); // must wait until I am here
<?php
  if(!strlen($auth) || $auth > 0)
  {
?>
                        }
<?php
  }
?>
                        myRequest2 = null;
                      });

              type = null;
              qty = null;
              coin = null;
              xx = null;
              myRequest = null;
            })
        .catch(
            function(err)
            {
              console.log("Error detected in getCount_C()");
              console.error(err);
              myRequest = null;
            });
      }

      function OnClickExit()
      {
        OnClickExitOrNext("back");
      }

      function OnClickNext()
      {
        OnClickExitOrNext("next");
      }

    </script>
  </head>
  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">
<?php
  if($is_rolls == "Y")
  {
?>
        Harvest <?php print $Rolls; ?><img src="/img/rolls.svg"></a>
<?php
  }
  else
  {
?>
        Harvest <?php print $Coins; ?><img src="/img/coins.svg"></a>
<?php
  }
?>
        <div id="entity" class="area"><?php print strtoupper($Entity); ?></div>
      </div>
    </nav>

    <form id=back method=GET action="./dispense-coins.php">
      <input type="hidden" name="origin" value="<?php print $Origin; ?>" style="visibility:hidden" />
      <input  type="hidden" name="rolls_only" value="<?php print $RollsOnly; ?>" style="visibility:hidden" />
<?php
  if(strlen($next) > 0)
  {
?>
      <input  type="hidden" name="next" value="<?php print $next; ?>" style="visibility:hidden" />
<?php
    if(strlen($class) > 0)
    {
?>
      <input  type="hidden" name="class" value="<?php print $class; ?>" style="visibility:hidden" />
<?php
    }
  }
?>
      <input  type="hidden" name="entity" value="<?php print $Entity; ?>" style="visibility:hidden" />
    </form>
    <form id=next method=GET action="<?php if(strlen($next) > 0) print $next; else print $Origin; ?>">
      <input type="hidden" name="origin" value="<?php print $Origin; ?>" style="visibility:hidden" />
      <input  type="hidden" name="rolls_only" value="<?php print $RollsOnly; ?>" style="visibility:hidden" />
<?php
  if(strlen($next) > 0 && strlen($class) > 0)
  {
?>
      <input  type="hidden" name="class" value="<?php print $class; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <div class="container">
      <div class="section" style="padding:0;margin:0">
        <div class="row center">
        <img src="/img/srb-system-recycler.png" width=<?php print round(cached_font_size() * 347 / 24); ?>px
             height=<?php print round(cached_font_size() * 260 / 24); ?>px style="background-color:transparent">
          <!-- width=240 height=180 -->
        </div>
        <!-- script builds the 'div' tag(s), below -->
        <div id=thermometer
<?php
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //                                                                                                                                              //
  //   _   _                                    _____        _  _   _____  _                                                     _                //
  //  | | | |  ___   _ __   _ __    ___  _ __  |  ___|_   _ | || | |_   _|| |__    ___  _ __  _ __ ___    ___   _ __ ___    ___ | |_  ___  _ __   //
  //  | |_| | / _ \ | '_ \ | '_ \  / _ \| '__| | |_  | | | || || |   | |  | '_ \  / _ \| '__|| '_ ` _ \  / _ \ | '_ ` _ \  / _ \| __|/ _ \| '__|  //
  //  |  _  || (_) || |_) || |_) ||  __/| |    |  _| | |_| || || |   | |  | | | ||  __/| |   | | | | | || (_) || | | | | ||  __/| |_|  __/| |     //
  //  |_| |_| \___/ | .__/ | .__/  \___||_|    |_|    \__,_||_||_|   |_|  |_| |_| \___||_|   |_| |_| |_| \___/ |_| |_| |_| \___| \__|\___||_|     //
  //                |_|    |_|                                                                                                                    //
  //                                                                                                                                              //
  //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//  $emfactor = 1.0 / 24.0; // convert to em (height)
//  $emfactorW = 1.0 / cached_font_size();
//  $pos = 302; // 220;   // bottom of thermometer bar
//  $scale = 188; // 130; // scale (height) of thermometer bar at 100%

  // thermometer at y=133 to y=308 scaled for cached font size
  // top is at around 5.54 rem
  // center is 7 em from right of screen

  $emfactor = 1.0 / 24.0; // convert to em (height)
  $emfactorW = 1.0 / cached_font_size();
  $pos=298;   // bottom of thermometer bar
  $scale=175; // scale (height) of thermometer bar at 100%

  $coinz = coin_count_and_relative_volume(true);
  $vol0 = floor($coinz["volume"] * $scale / 1000 + 0.5); // 1000 -> 'scale' px

  if($coin_bag_threshold <= 0 || $coin_bag_threshold > 1000)
    $coin_bag_threshold = $scale / 2;
  else
    $coin_bag_threshold = $coin_bag_threshold * $scale / 1000;

  if($vol0 >= $coin_bag_threshold)
    $vol = $coin_bag_threshold;
  else
    $vol = $vol0;

  // bottom at specific point below the top of the screen
  $bottomedge = $pos * $emfactor + 0.125;
  // left edge is 4 rem from right of screen minus 0.125 em, with 3 pixel border width
  $leftedge = (cached_screen_width() * $emfactorW - 4 - 0.125);

  // draw bounding rectangle2
  print 'style="background-color:#000000;margin:0;padding:0;'
      . ';position:absolute;left:' . ($leftedge - 0.1)
      . 'rem;width:' . (14 * $emfactor + 0.2) . 'rem;';
  print 'top:' . ($bottomedge - $scale * $emfactor - 0.1) . 'rem;';
  print 'height:' . ($scale * $emfactor + 0.2) . 'rem;"' . "><!--" . $leftedge . "-->\n";
  print "        </div>\n        <div id=thermometer_white ";

  print 'style="background-color:#ffffff;margin:0;padding:0;'
      . ';position:absolute;left:' . $leftedge
      . 'rem;width:' . (14 * $emfactor) . 'rem;';
  print 'top:' . ($bottomedge - $scale * $emfactor) . 'rem;';
  print 'height:' . ($scale * $emfactor) . 'rem;"' . ">\n";
  print "        </div>\n        <div id=thermometer_green ";

  print 'style="background-color:#00ff00;margin:0;padding:0;'
      . ';position:absolute;left:' . $leftedge
      . 'rem;width:' . 14 * $emfactor . 'rem;';
  print 'top:' . (($pos - $vol) * $emfactor + 0.125). 'rem;';
  print 'height:' . $vol * $emfactor . 'rem;"' . ">\n";

  if($vol0 > $coin_bag_threshold)
  {
    if($vol0 > $scale) // handle overflows
      $vol0 = $scale;

    $scale2 = $scale - $coin_bag_threshold; // the remaining amount

    $vol = $vol0 - $coin_bag_threshold;
    $the_color = "#ffa000"; // light orange

    if($vol > $scale2 / 2)
    {
      if($vol < $scale2 * 3 / 4)
        $the_color = "#ff4040"; // darker orange
      else
        $the_color = "#ff0000"; // red
    }

    print "        </div>\n";

    print "        <div id=thermometer_red\n";
    print 'style="background-color:' . $the_color
        . ';position:absolute;left:'. $leftedge
        . 'rem;width:' . 14 * $emfactor . 'rem;';
    print 'top:' . (($pos - ($scale - $scale2) - $vol) * $emfactor + 0.125) . 'rem;';
    print 'height:' . $vol * $emfactor. 'rem;"' . ">\n";
  }
?>
        </div>
        <div class="row center" style="position:absolute;right:0;top:3rem;width:8rem;line-height:1.1rem">
          <center>
            <table style="width:80%">
<?php
    // text above the thermometer
    print '<tr>'
          . '<td style="padding:0px !important;margin:0px !important;line-height:1rem !important;font-size:0.8rem;text-align:right">'
          . "Coins:&nbsp;&nbsp;</td>"
          . '<td style="padding:0px !important;margin:0px !important;line-height:1rem !important;font-size:0.8rem;text-align:right">'
          . '<span id=thermometer_coins>'
          . $coinz["coins"] . "&nbsp;"
          . "</span>"
          . "</td>"
          . '</tr><tr>'
          . '<td style="padding:0px !important;margin:0px !important;line-height:1rem !important;font-size:0.8rem;text-align:right">'
          . "Rel Vol:&nbsp;&nbsp;</td>"
          . '<td style="padding:0px !important;margin:0px !important;line-height:1rem !important;font-size:0.8rem;text-align:right">'
          . '<span id=thermometer_volume>'
          . sprintf("%0.1f%%", $coinz["volume"] / 10.0)
          . "</span>"
          . "</td>"
          . "</tr>\n";
?>
            </table>
          </center>
        </div>

        <div>
          <center>
            <table style="max-width:85%;">
              <tr style="font-size:0.7rem;line-height:1.1em">
                <th width="9%" style="text-align:right">&nbsp;</th>
<?php
  if($is_rolls == "Y")
  {
?>
                <th width="13%" style="text-align:right">Quarters&nbsp;&nbsp;</th>
                <th width="13%" style="text-align:right">Nickels&nbsp;&nbsp;</th>
                <th width="13%" style="text-align:right">Pennies&nbsp;&nbsp;</th>
                <th width="13%" style="text-align:right">Dimes&nbsp;&nbsp;</th>
<?php
  }
  else
  {
?>
                <th width="13%" style="text-align:right">Pennies&nbsp;&nbsp;</th>
                <th width="13%" style="text-align:right">Nickels&nbsp;&nbsp;</th>
                <th width="13%" style="text-align:right">Dimes&nbsp;&nbsp;</th>
                <th width="13%" style="text-align:right">Quarters&nbsp;&nbsp;</th>
<?php
  }
?>
                <th width="13%" style="text-align:right">Dollars&nbsp;&nbsp;</th>
                <th width="15%" style="text-align:right">Total</th>
              </tr>
              <tr style="font-size:0.7rem;line-height:1.1em">
                <td style="width:9%;text-align:right">Payout</td>
<?php
  if($is_rolls == "Y")
  {
?>
                <td style="width:13%;text-align:right">
                  <span id=pay25 style="margin:0;padding:0;border:0">0</span>
                  <img id=pay25a src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=pay5 style="margin:0;padding:0;border:0">0</span>
                  <img id=pay5a src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=pay1 style="margin:0;padding:0;border:0">0</span>
                  <img id=pay1a src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=pay10 style="margin:0;padding:0;border:0">0</span>
                  <img id=pay10a src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
<?php
  }
  else
  {
?>
                <td style="width:13%;text-align:right">
                  <span id=pay1 style="margin:0;padding:0;border:0">0</span>
                  <img id=pay1a src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=pay5 style="margin:0;padding:0;border:0">0</span>
                  <img id=pay5a src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=pay10 style="margin:0;padding:0;border:0">0</span>
                  <img id=pay10a src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=pay25 style="margin:0;padding:0;border:0">0</span>
                  <img id=pay25a src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
<?php
  }
?>
                <td style="width:13%;text-align:right">
                  <span id=pay100 style="margin:0;padding:0;border:0">0</span>
                  <img id=pay100a src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td id=pay_total style="width:15%;text-align:right">$ 0.00</td>
              </tr>
              <tr style="font-size:0.7rem;line-height:1.1em">
                <td style="width:9%;text-align:right">Inventory</td>
<?php
  if($is_rolls == "Y")
  {
?>
                <td style="width:13%;text-align:right">
                  <span id=count25 style="margin:0;padding:0;border:0"><?php print $count25c; ?></span>
                  <img src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=count5 style="margin:0;padding:0;border:0"><?php print $count5c; ?></span>
                  <img src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=count1 style="margin:0;padding:0;border:0"><?php print $count1c; ?></span>
                  <img src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=count10 style="margin:0;padding:0;border:0"><?php print $count10c; ?></span>
                  <img src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
<?php
  }
  else
  {
?>
                <td style="width:13%;text-align:right">
                  <span id=count1 style="margin:0;padding:0;border:0"><?php print $count1c; ?></span>
                  <img src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=count5 style="margin:0;padding:0;border:0"><?php print $count5c; ?></span>
                  <img src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=count10 style="margin:0;padding:0;border:0"><?php print $count10c; ?></span>
                  <img src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td style="width:13%;text-align:right">
                  <span id=count25 style="margin:0;padding:0;border:0"><?php print $count25c; ?></span>
                  <img src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
<?php
  }
?>
                <td style="width:13%;text-align:right">
                  <span id=count100 style="margin:0;padding:0;border:0"><?php print $count100c; ?></span>
                  <img src="/img/blank.png" style="width:0.7rem;height:0.7rem;margin:0;padding:0;border:0" />
                </td>
                <td id=count_total style="width:15%;text-align:right">
                  $ <?php printf("%0.2f", $count_total); ?>
                </td>
              </tr>
            </table>
          </center>
        </div>

        <!-- progress -->
        <div id="ProgressBar" style="position:absolute;border:1px;border-style:solid;left:25%;bottom:4.0rem;text-align:left;width:50%;min-height:0.3rem;max-height:0.3rem;line-height:0.3rem;padding:0;margin:0">
          <!--div style="position:absolute;background-color:#ff0000;min-width:100%">&nbsp;</div-->
        </div>

        <!-- message thing -->
        <div style="position:absolute;left:20%;bottom:0.3rem;text-align:center;width:60%;height:3.5rem;padding:0;margin:0">
          <p id=messagething style="padding:0;margin:0;font-size:0.8rem;line-height:0.8rem">Preparing...</p>
        </div>
      </div>
    </div>

    <div class="next-button" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <button id=start type=button onClick="OnClickStart();" class="btn multi-click waves-effect primary-fill btn-shadow" disabled>
        Start
      </button>
      <button id="next_button" type=button class="btn waves-effect primary-fill btn-shadow"
              onClick="OnClickNext();" style="visibility:hidden;display:none" disabled>
        NEXT &gt;
      </button>
    </div>

    <div class="next-button" style="position:absolute;margin:0px;padding:0;bottom:18px;left:12px">
      <button id=exit type=button onClick="OnClickExit();" class="btn waves-effect primary-fill btn-shadow">
        Back
      </button>
    </div>


    <!-- coin tray warning -->
    <div id=coin_tray_warning class="medium-modal me-and-my-shadow"
         style="visibility:hidden;display:none;position:absolute;left:35%;width:30%;top:5.5rem;height:20%;z-order:99">
      <center>
        <span id=alert_title style="font-size:0.91rem;line-height:0.91rem;margin:0;padding:0;visibility:inherit">
          Coin Tray
        </span>
      </center>
      <div id=coin_tray_warning_text style="position:relative;font-size:0.75rem;line-height:0.83rem;top:4px;height:4.16rem;text-align:center;margin:0;padding:0;visibility:inherit">
        Please move Coin Tray<br>to the <?php if($is_rolls == "Y") print "ROLLS"; else print "TRAY"; ?> position
      </div>
      <img height=<?php print round(cached_font_size() * 3); ?>px
<?php
      if($is_rolls == "Y")
      {
?>
           src="img/coin_drawer_rotate_cw.png"
<?php
      }
      else
      {
?>
           src="img/coin_drawer_rotate_ccw.png"
<?php
      }
?>
           style="visibility:inherit;position:absolute;left:10rem;top:3.3rem" />
    </div>

    <!-- popup alerts -->
    <div id=popup_alert class="modal-container"
         style="position:absolute;top:0px;visibility:hidden">
      <div id=alert_dlg class="medium-modal me-and-my-shadow"
           style="visibility:inherit;position:relative;left:30%;width:40%;top:6.67rem">
        <center>
          <span id=alert_title style="font-size:0.91rem;line-height:0.91rem;margin:0;padding:0;visibility:inherit">
            PAYOUT ERROR
          </span>
        </center>
        <div id=alert_dlg_text style="position:relative;font-size:0.75rem;line-height:0.83rem;top:4px;height:4.16rem;text-align:center;margin:0;padding:0;visibility:inherit">
          The Message
        </div>
        <div class="next-button" style="position:relative;margin:0px;padding:0;top:20px;visibility:inherit">
          <button id=alert_exit type=button onClick="do_alert_exit();" class="btn multi-click waves-effect primary-fill btn-shadow"
                  style="visibility:inherit;position:relative;width:30%;left:40%">
            Exit
          </button>
        </div>
      </div>
    </div>

    <div id=popup_batch class="modal-container"
         style="position:absolute;top:0px;visibility:hidden">
      <div id=batch_dlg class="medium-modal me-and-my-shadow"
           style="visibility:inherit;position:relative;left:29%;width:48%;top:15%;height:13.1rem">
        <center>
          <span id=batch_title style="font-size:1.2rem;line-height:1.2rem;font-weight:bold;margin:0;padding:0;visibility:inherit">
            ROLL COMPLETE<!-- TODO term for ROLL -->
          </span>
          <br />
          <img id="batch_coin_image" src=""
               width="<?php print cached_font_size() * 110 / 24; ?>px"
               height="<?php print cached_font_size() * 110 / 24; ?>px">
          <br />
          <span id="batch_coin_text" style="font-size:2.5rem;line-height:2.7rem;font-weight: bold;font-family:Liberation Sans;color:#000000">
            the text (assign style.color)
          </span>
          <br /><br />
          <button id=batch_resume type=button onClick="do_batch_resume();" class="btn multi-click waves-effect primary-fill btn-shadow">
            Resume
          </button>
        </center>
        <input type=hidden id="batch_denom" value="0" style="visibility:hidden;display:none" />
      </div>
    </div>

    <script>

      var thing = null;
      var first_time = true;
      var async_payout = <?php if($async_payout > "0") print 'true'; else print 'false'; ?>;

      function do_alert(text)
      {
        if(thing != null)
        {
          clearInterval(thing);
          thing = null;
        }

//        console.log("setting text to " + text);
        document.getElementById("alert_title").innerHTML = "PAYOUT ERROR";
        document.getElementById("alert_dlg_text").innerHTML = text;
        document.getElementById("popup_alert").style.visibility="visible";
        document.getElementById("popup_alert").style.display="block";

//        console.log("returning");
      }

      function do_alertW(text)
      {
        if(thing != null)
        {
          clearInterval(thing);
          thing = null;
        }

//        console.log("setting text to " + text);
        document.getElementById("alert_title").innerHTML = "PAYOUT WARNING";
        document.getElementById("alert_dlg_text").innerHTML = text;
        document.getElementById("popup_alert").style.visibility="visible";
        document.getElementById("popup_alert").style.display="block";

//        console.log("returning");
      }

      function do_alert_exit()
      {
        document.getElementById("popup_alert").style.visibility="hidden";
        document.getElementById("popup_alert").style.display="none";

//        console.log("resetting event interval");
        thing = setInterval(GetRecyclerStatus, 500); // when dialog closes, continue status polling
      }

      function do_batch(denom)
      {
        document.getElementById("popup_batch").style.visibility="visible";
        document.getElementById("popup_batch").style.display="block";

        if(denom == "1")
        {
          document.getElementById("batch_coin_image").src = '/img/penny.png';
          document.getElementById("batch_coin_text").style.color = '#ae1900';
          document.getElementById("batch_coin_text").innerHTML = 'PENNIES';
        }
        else if(denom == "5")
        {
          document.getElementById("batch_coin_image").src = '/img/nickel.png';
          document.getElementById("batch_coin_text").style.color = '#006b93';
          document.getElementById("batch_coin_text").innerHTML = 'NICKELS';
        }
        else if(denom == "10")
        {
          document.getElementById("batch_coin_image").src = '/img/dime.png';
          document.getElementById("batch_coin_text").style.color = '#327100';
          document.getElementById("batch_coin_text").innerHTML = 'DIMES';
        }
        else if(denom == "25")
        {
          document.getElementById("batch_coin_image").src = '/img/quarter.png';
          document.getElementById("batch_coin_text").style.color = '#dd6300';
          document.getElementById("batch_coin_text").innerHTML = 'QUARTERS';
        }

        document.getElementById("batch_denom").value = denom;
      }

      function do_resume_status_poll()
      {
        thing = setInterval(GetRecyclerStatus, 500); // when dialog closes, continue status polling
      }

      function do_batch_resume()
      {
        var denom = document.getElementById("batch_denom").value;

        document.getElementById("popup_batch").style.visibility="hidden";
        document.getElementById("popup_batch").style.display="none";

        myRequest = new Request("/glue/payout-resume.php?Denom=" + denom);

        console.log("resume payout for denom ");

        // async request to resume payout for denom
        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("OnClickStart(" + nPennies + "," + nNickels + ","
                                              + nDimes + "," + nQuarters + ")", response.status); // debug only (TODO: remove?  this is actually an error condition...)
                    return "ERROR";
                  }
                  return  response.text();
                })
          .then(function(text)
                {
                  console.log("resetting event interval");
//                  thing = setInterval(GetRecyclerStatus, 500); // when dialog closes, continue status polling
                  setTimeout(do_resume_status_poll, 500); // delays polling for status for 1/2 sec
                });

        denom = null;
      }

      function OnClickStart()
      {
        var mm = "1", n1 = nPennies, n5 = nNickels, n10 = nDimes, n25 = nQuarters, n100 = nDollars;

        if(is_rolls)
        {
          if(async_payout)
          {
            mm = "2";
          }
          else
          {
            if(n1 > <?php print $batch1; ?>)
              n1 = <?php print $batch1; ?>;
            if(n5 > <?php print $batch5; ?>)
              n5 = <?php print $batch5; ?>;
            if(n10 > <?php print $batch10; ?>)
              n10 = <?php print $batch10; ?>;
            if(n25 > <?php print $batch25; ?>)
              n25 = <?php print $batch25; ?>;
          }

          if(n100 > 0) // do not pay out dollars
          {
            nDollars = 0;
            n100 = 0;
          }

          nTotalCoinsToPay = n1 + n5 + n10 + n25;

          myRequest = new Request("/glue/payout-coin.php?Multi=" + mm
                                  + "&Denom=1&Amount=" + n1
                                  + "&Denom2=5&Amount2=" + n5
                                  + "&Denom3=10&Amount3=" + n10
                                  + "&Denom4=25&Amount4=" + n25);
        }
        else
        {
          // limit total coin payout to 100 coins

          nTotalCoinsToPay = n1 + n5 + n10 + n25 + n100;

          if(nTotalCoinsToPay > 100)
          {
            n1   = Math.floor(n1 * 100 / nTotalCoinsToPay + 0.25);
            n5   = Math.floor(n5 * 100 / nTotalCoinsToPay + 0.25);
            n10  = Math.floor(n10 * 100 / nTotalCoinsToPay + 0.25);
            n25  = Math.floor(n25 * 100 / nTotalCoinsToPay + 0.25);
            n100 = Math.floor(n100 * 100 / nTotalCoinsToPay + 0.5); // these qtys probably low

            nTotalCoinsToPay = n1 + n5 + n10 + n25 + n100;
          }

          myRequest = new Request("/glue/payout-coin.php?Multi=1&Denom=1&Amount=" + n1
                                  + "&Denom2=5&Amount2=" + n5
                                  + "&Denom3=10&Amount3=" + n10
                                  + "&Denom4=25&Amount4=" + n25
                                  + "&Denom5=100&Amount5=" + n100);
        }

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("OnClickStart(" + nPennies + "," + nNickels + ","
                                              + nDimes + "," + nQuarters + ")", response.status); // debug only (TODO: remove?  this is actually an error condition...)
                    return "ERROR";
                  }
                  return  response.text();
                })
          .then(function(text)
                {
                  // TODO:  anything?
                  myRequest = null;
                  thing = null;

                  if(text == "ERROR")
                    return;

//                  console.log("request returns " + text);

                  document.getElementById("start").disabled = true;
                  document.getElementById("exit").disabled = true;

                  document.getElementById("messagething").innerHTML = text + " (Starting)";
                  thing = setInterval(GetRecyclerStatus, 500); // assume 1/2 sec enough to get non-zero status
                })
      }

      function do_progress_bar(status_text)
      {
        // if i am counting, status_text should end with "[xx%]"
        var iTail = status_text.indexOf("[");
        if(iTail >= 0)
        {
          var szTail = status_text.substr(iTail + 1,status_text.length).trim();

          if(szTail.length > 0 && szTail.charAt(szTail.length - 1) == ']') // sanity test
          {
            szTail = szTail.substr(0, szTail.length - 1);


            if(szTail.length > 0 && szTail.charAt(szTail.length - 1) == '%') // sanity test 2
            {
              szTail = szTail.substr(0, szTail.length - 1);

              var nTotal = nTotalCoinsPaidSoFar * 100
                         + nTotalCoinsToPay * Math.floor(szTail);

              var nPercentage = Math.floor(nTotal / nTotalCoinsRequested);

               document.getElementById("ProgressBar").innerHTML =
                 '<div style="position:absolute;background-color:#00c030;min-width:'
                 + + nPercentage + '%">&nbsp;</div>';
              // TODO:  update a progress indicator

//              console.log("Percent done: " + nPercentage);
            }
          }
        }
      }

      function GetRecyclerStatus()
      {
        // NOTE:  this glue page also works for C300 - it will check installed equipment
        var myRequest = new Request("/glue/status-c400.php");

        fetch(myRequest)
          .then(function(response)
                {
                  myRequest = null;

                  if(!response.ok)
                  {
                    console.log("status-c400", response.status); // debug only (TODO: remove?)
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                  // xx will be a DOM Parser type of object from which to parse XML
                  var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                  var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
                  var the_date = xx.getElementsByTagName("date")[0];
                  var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
                  var st = xx.getElementsByTagName("status")[0].children;
                  var the_volume = null;
                  var ba = null;
                  var coin = null;
                  var status_code = "";
                  var status_subcode = "";
                  var status_text = "";
                  var batch_denom = "";
                  var today = "";
                  var volume = -1;

                  try
                  {
                    ba = xx.getElementsByTagName("batch");
                  }
                  catch(err)
                  {
                    ba = null;
                  }

                  try
                  {
                    the_volume = xx.getElementsByTagName("volume")[0];
                  }
                  catch(err)
                  {
                    the_volume = null;
                  }

                  if(ba != null && ba.length > 0)
                    ba = ba[0].children;

                  try
                  {
                    coin = xx.getElementsByTagName("coin");
                  }
                  catch(err)
                  {
                    coin = null;
                  }

                  if(the_date && the_date.childNodes.length > 0)
                  {
                    today = the_date.childNodes[0].nodeValue;
                  }
                  else
                  {
                    today = "unknown date";
                  }

                  if(the_volume && the_volume.childNodes.length > 0)
                  {
                    volume = the_volume.childNodes[0].nodeValue;
                    console.log("volume is " + volume);
                  }
                  else
                  {
                    volume = 0;
                  }


                  for (var i1 = 0; i1 < st.length; i1++)
                  {
                    if(st[i1].nodeName == "code")
                      status_code = st[i1].childNodes[0].nodeValue;
                    else if(st[i1].nodeName == "text")
                      status_text = st[i1].childNodes[0].nodeValue;
                    else if(st[i1].nodeName == "subcode")
                      status_subcode = st[i1].childNodes[0].nodeValue;
                  }

                  if(ba != null)
                  {
                    for (var i1 = 0; i1 < ba.length; i1++)
                    {
                      if(ba[i1].nodeName == "denom")
                        batch_denom = ba[i1].childNodes[0].nodeValue;
                    }
                  }

                  if(coin != null)
                  {
                    // latest coin counter inventory snapshot

                    for (var i1 = 0; i1 < coin.length; i1++)
                    {
                      var cc = coin[i1].children;

                      if(cc.length > 0)
                      {
                        var type, qty;

                        for ( var i2 = 0; i2 < cc.length; i2++)
                        {
                          if(cc[i2].nodeName == "type")
                            type = cc[i2].childNodes[0].nodeValue;

                          if(cc[i2].nodeName == "qty")
                            qty = cc[i2].childNodes[0].nodeValue;
                        }

                        if(type == 1)
                          count1 = qty;
                        else if(type == 5)
                          count5 = qty;
                        else if(type == 10)
                          count10 = qty;
                        else if(type == 25)
                          count25 = qty;
                        else if(type == 100)
                          count100 = qty;

                        type=null;
                        qty=null;
                      }

                      cc = null;
                    }

//                    console.log("STATUS:  Pennies " + count1 + "  Nickels " + count5
//                                + "  Dimes " + count10 + "  Quarters " + count25
//                                + "  Dollars " + count100);
                    // display the total paid out coins

                    // to avoid glitches do not update if the counts are zero
                    if(count1 > 0 || count5 > 0 || count10 > 0 || count25 > 0)
                    { // scoping to help with memory management
                      var p1 = start1 - count1;
                      var p5 = start5 - count5;
                      var p10 = start10 - count10;
                      var p25 = start25 - count25;
                      var p100 = start100 - count100;

                      document.getElementById("pay1").innerHTML = p1;
                      document.getElementById("pay5").innerHTML = p5;
                      document.getElementById("pay10").innerHTML = p10;
                      document.getElementById("pay25").innerHTML = p25;
                      document.getElementById("pay100").innerHTML = p100;

                      if(p1 >= <?php print $c1; ?> && <?php print $c1; ?> > 0)
                        document.getElementById("pay1a").src = "/img/greencheck.png";
                      if(p5 >= <?php print $c5; ?> && <?php print $c5; ?> > 0)
                        document.getElementById("pay5a").src = "/img/greencheck.png";
                      if(p10 >= <?php print $c10; ?> && <?php print $c10; ?> > 0)
                        document.getElementById("pay10a").src = "/img/greencheck.png";
                      if(p25 >= <?php print $c25; ?> && <?php print $c25; ?> > 0)
                        document.getElementById("pay25a").src = "/img/greencheck.png";
                      if(p100 >= <?php print $c100; ?> && <?php print $c100; ?> > 0)
                        document.getElementById("pay100a").src = "/img/greencheck.png";

                      document.getElementById("pay_total").innerHTML = "$ " +
                        (p1 * 0.01 + p5 * 0.05 + p10 * 0.1 + p25 * 0.25 + p100).toFixed(2);

                      document.getElementById("count1").innerHTML = count1;
                      document.getElementById("count5").innerHTML = count5;
                      document.getElementById("count10").innerHTML = count10;
                      document.getElementById("count25").innerHTML = count25;
                      document.getElementById("count100").innerHTML = count100;

                      document.getElementById("count_total").innerHTML = "$ " +
                        (count1 * 0.01 + count5 * 0.05 + count10 * 0.1 + count25 * 0.25 + count100 * 1).toFixed(2);

                      p1 = p5 = p10 = p25 = p100 = null;

                      document.getElementById("thermometer_coins").innerHTML =
                        (count1 * 1 + count5 * 1 + count10 * 1 + count25 * 1 + count100 * 1).toFixed(0) + "&nbsp;";

                      if(volume >= 0)
                      {
                        document.getElementById("thermometer_volume").innerHTML = (volume / 10.0).toFixed(1) + '%';

                        // TODO:  update thermometer
                        var vol0 = volume * <?php print $scale / 1000 + 0.5; ?>;
                        var vol = (vol0 >= <?php print $coin_bag_threshold; ?>) ? <?php print $coin_bag_threshold; ?> : vol0;

                        var htmlBar = "        <div id=thermometer_white "
                                    + 'style="background-color:#ffffff;margin:0;padding:0;'
                                    + ';position:absolute;left:<?php print $leftedge; ?>'
                                    + 'rem;width:<?php print 14 * $emfactor; ?>rem;'
                                    + 'top:<?php print ($bottomedge - $scale * $emfactor);?>rem;';
                                    + 'height:<?php print ($scale * $emfactor); ?>rem;"' + ">\n";
                                    + "        </div>\n        <div id=thermometer_green ";
                                    + 'style="background-color:#00ff00;margin:0;padding:0;'
                                    + ';position:absolute;left:<?php print $leftedge; ?>'
                                    + 'rem;width:<?php print 14 * $emfactor; ?>rem;'
                                    + 'top:<?php print (($pos - $vol) * $emfactor + 0.125);?>rem;';
                                    + 'height:' + (vol * <?php print $emfactor; ?>).toFixed(3) + 'rem;"' + ">\n";

                        if(vol0 > <?php print $coin_bag_threshold; ?>)
                        {
                          if(vol0 > <?php print $scale; ?>) // handle overflows
                            vol0 = <?php print $scale; ?>;

                          var scale2 = <?php print $scale - $coin_bag_threshold; ?>; // the remaining amount

                          vol = vol0 - <?php print $coin_bag_threshold; ?>;
                          var the_color = "#ffa000"; // light orange

                          if(vol > scale2 / 2)
                          {
                            if(vol < scale2 * 3 / 4)
                              the_color = "#ff4040"; // darker orange
                            else
                              the_color = "#ff0000"; // red
                          }

                          htmlBar = htmlBar
                                  + "        </div>\n"
                                  + "        <div id=thermometer_red\n"
                                  + 'style="background-color:' . the_color
                                  + ';position:absolute;left:<?php print $leftedge; ?>rem;'
                                  + 'width:<?php print 14 * $emfactor; ?>rem;'
                                  + 'top:'
                                  + ((<?php print $pos; ?> - (<?php print $scale; ?> - scale2) - vol)
                                    * <?php print $emfactor; ?> + 0.125).toFixed(3) + 'rem;';
                                  + 'height:' + (vol * <?php print $emfactor; ?>).toFixed(3) + 'rem;"' + ">\n";
                        }

                        htmlBar = htmlBar + "        </div>\n";

                        document.getElementById("thermometer").innerHTML = htmlBar;
                      }
                    }
                  }

                  if(status_code == 0) // this happens at the end
                  {
                    //   ____                              _      ____                          _        _
                    //  |  _ \  __ _  _   _   ___   _   _ | |_   / ___| ___   _ __ ___   _ __  | |  ___ | |_  ___
                    //  | |_) |/ _` || | | | / _ \ | | | || __| | |    / _ \ | '_ ` _ \ | '_ \ | | / _ \| __|/ _ \
                    //  |  __/| (_| || |_| || (_) || |_| || |_  | |___| (_) || | | | | || |_) || ||  __/| |_|  __/
                    //  |_|    \__,_| \__, | \___/  \__,_| \__|  \____|\___/ |_| |_| |_|| .__/ |_| \___| \__|\___|
                    //                |___/                                             |_|

                    if(thing != null)
                      clearInterval(thing);

                    thing = null;

                    document.getElementById("messagething").innerHTML = "Update Coin Count";
                    var myRequest2 = new Request("/glue/snapshot_coins.php");

                    document.getElementById("messagething").innerHTML = "Get Remaining Coin Count";

                    fetch(myRequest2)
                    .then(
                        function(response)
                        {
                          myRequest = null;

                          if (!response.ok)
                          {
                            console.log("count_coins", response.status); // debug only (TODO: remove?)
                          }

                          return  response.text();
                        })
                    .then(
                        function(text)
                        {
                                // xx will be a DOM Parser type of object from which to parse XML
                          var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                          var coin2 = xx.getElementsByTagName("coin");
                          var type, qty;

                          if(coin2 != null)
                          {
                            for (var i1 = 0; i1 < coin2.length; i1++)
                            {
                              var cc = coin2[i1].children;

                              if(cc.length > 0)
                              {
                                for ( var i2 = 0; i2 < cc.length; i2++)
                                {
                                  if(cc[i2].nodeName == "type")
                                    type = cc[i2].childNodes[0].nodeValue;

                                  if(cc[i2].nodeName == "qty")
                                    qty = cc[i2].childNodes[0].nodeValue;
                                }

                                if(type == 1)
                                  count1 = qty;
                                else if(type == 5)
                                  count5 = qty;
                                else if(type == 10)
                                  count10 = qty;
                                else if(type == 25)
                                  count25 = qty;
                                else if(type == 100)
                                  count100 = qty;
                              }

                              cc = null;
                            }
                          }

//                          console.log("END PAYOUT:  Pennies " + count1 + "  Nickels " + count5
//                                      + "  Dimes " + count10 + "  Quarters " + count25
//                                      + "  Dollars " + count100);

                          // display the total paid out coins

                          { // scoping to help with memory management
                            var p1 = start1 - count1;
                            var p5 = start5 - count5;
                            var p10 = start10 - count10;
                            var p25 = start25 - count25;
                            var p100 = start100 - count100;

                            document.getElementById("pay1").innerHTML = p1;
                            document.getElementById("pay5").innerHTML = p5;
                            document.getElementById("pay10").innerHTML = p10;
                            document.getElementById("pay25").innerHTML = p25;
                            document.getElementById("pay100").innerHTML = p100;

                            document.getElementById("pay_total").innerHTML = "$ " +
                              (p1 * 0.01 + p5 * 0.05 + p10 * 0.1 + p25 * 0.25 + p100).toFixed(2);

                            document.getElementById("count1").innerHTML = count1;
                            document.getElementById("count5").innerHTML = count5;
                            document.getElementById("count10").innerHTML = count10;
                            document.getElementById("count25").innerHTML = count25;
                            document.getElementById("count100").innerHTML = count100;

                            document.getElementById("count_total").innerHTML = "$ " +
                              (count1 * 0.01 + count5 * 0.05 + count10 * 0.1 + count25 * 0.25 + count100 * 1).toFixed(2);

                            p1 = p5 = p10 = p25 = p100 = null;
                          }

                          // TODO:  if I am paying out rolls, make sure it is COMPLETED for each
                          //        roll, and if not, prompt differently to complete the incom0lete
                          //        rolls, and continue automatically (?)

                          // subtract paid out coins from desired payouts
                          nPennies  -= last1 - count1;
                          nNickels  -= last5 - count5;
                          nDimes    -= last10 - count10;
                          nQuarters -= last25 - count25;
                          nDollars  -= last100 - count100;

                          nTotalCoinsPaidSoFar += (last1 - count1)
                                                + (last5 - count5)
                                                + (last10 - count10)
                                                + (last25 - count25)
                                                + (last100 - count100);

                          // new count is current 'last' count
                          last1   = count1;
                          last5   = count5;
                          last10  = count10;
                          last25  = count25;
                          last100 = count100;

                          document.getElementById("exit").disabled = false;

                          if(nPennies > 0 || nNickels > 0 || nDimes > 0 || nQuarters > 0 || nDollars > 0)
                          {
                            document.getElementById("messagething").innerHTML = "Continuing...";
                            setTimeout(BeginPayout, 1000);
                          }
                          else
                          {
                            //  show a 'next' button when complete and enable it
                            //  and have this button go to the next screen and print
                            //  the payout receipt

                            document.getElementById("start").disabled = true;
                            document.getElementById("start").style.display = "none";
                            document.getElementById("start").style.visibility = "hidden";

                            document.getElementById("next_button").disabled = false;
                            document.getElementById("next_button").style.display = "block";
                            document.getElementById("next_button").style.visibility = "visible";

                            document.getElementById("messagething").innerHTML = "Complete";
                          }

                          type = null;
                          qty = null;
                          coin2 = null;
                          xx = null;
                        })
                    .catch(
                        function(err)
                        {
                          console.log("Error detected in getCount_C()");
                          console.error(err);
                        });

                    // TODO: get coin count so I can print a receipt later
                  }
                  else if(status_code == 21) // coin roll / batch
                  {
                    if(batch_denom == "1" || batch_denom == "5" ||
                       batch_denom == "10" || batch_denom == "25")
                    {
                      if(thing != null)
                        clearInterval(thing);

                      thing = null;

                      do_progress_bar(status_text);
                      do_batch(batch_denom);
//                    thing = setInterval(GetRecyclerStatus, 500); // when dialog closes, continue status polling
                    }
                  }
                  else // if(status_code != 0, != 21)
                  {
                    document.getElementById("messagething").innerHTML = status_text;

                    if(status_code == 31 /* || status_code == 29 || status_code == 28 */)
                    {
                      do_alert(status_text);
                    }
                    else if(status_code == 17)
                    {
                      do_progress_bar(status_text);
                    }
                  }

                  xx = null;
                  entity = null;
                  the_date = null;
                  tick = null;
                  st = null;
                  ba = null;
                  coin = null;
                  status_code = null;
                  status_subcode = null;
                  status_text = null;
                  batch_denom = null;
                  today = null;
                  myRequest = null;
                });

      }

<?php
  if($check_recycler_coin_tray != 0)
  {
?>
      function DoCheckDrawerState()
      {
        var myRequest = new Request("/glue/status_recycler_drawer.php");

        fetch(myRequest)
          .then(function(response)
                {
                  myRequest = null;

                  if(!response.ok)
                  {
                    console.log("status_recycler_drawer", response.status); // debug only (TODO: remove?)
                  }

                  return  response.text();
                })
          .then(function(text)
                {
//                  console.log("drawer state: " + text);

                  if(text.length > 0 &&
                     (text.substr(0,1) === '*' || Math.floor(text) == <?php if($is_rolls == "Y") print "1" ; else print "0"; ?> ))
                  {
                    // correct position - 1 for rolls, 0 for coin tray (anything else is non-valid)

                    document.getElementById("coin_tray_warning").style.display = "none";
                    document.getElementById("coin_tray_warning").style.visibility = "hidden";

                    document.getElementById("start").disabled = false;
                  }
                  else
                  {
                    // TODOL pop up an alert box to re-position the drawer?

                    document.getElementById("coin_tray_warning").style.display = "block";
                    document.getElementById("coin_tray_warning").style.visibility = "visible";

                    document.getElementById("start").disabled = true;

                    setTimeout(DoCheckDrawerState, 250);
                  }
                });
      }
<?php
  }
?>

      function BeginPayout()
      {
        var szMessage;
<?php
  if($is_rolls == "Y")
  {
?>
        var xx;

//        if(first_time)
//        {
//          szMessage = "P";
//          first_time = false;
//        }
//        else
//        {
        szMessage = "Please remove any existing coin rolls, and<br>";
//        }

        szMessage = szMessage + "place empty rolls in the correct slots for<br>";

        xx = ""; // initially blank

        if(nPennies > 0)
          xx = "pennies";

        if(nNickels > 0)
        {
          if(xx.length > 0)
            xx = xx + ", ";
          xx = xx + "nickels";
        }
        if(nDimes > 0)
        {
          if(xx.length > 0)
            xx = xx + ", ";
          xx = xx + "dimes";
        }
        if(nQuarters > 0)
        {
          if(xx.length > 0)
            xx = xx + ", ";
          xx = xx + "quarters";
        }

        szMessage = szMessage + '<font style="padding:0;margin:0;font-size:1.3em;line-height:1.1em;vertical-align:middle">' + xx + "</font><br>";
<?php
  }
  else
  {
?>
        if(first_time)
        {
          szMessage = "P";
          first_time = false;
        }
        else
        {
          szMessage = "Please check the coin tray level and empty as needed,<br>then p"
        }

        szMessage = szMessage + "repare the coin tray to collect loose coins,<br>";
<?php
  }
?>
        szMessage = szMessage + "and press 'Start' to continue";

        document.getElementById("messagething").innerHTML = szMessage;

<?php
  if($check_recycler_coin_tray != 0)
  {
?>
        setTimeout(DoCheckDrawerState, 250);
<?php
  }
  else
  {
?>
        document.getElementById("start").disabled = false;
<?php
  }
?>
      }

      setTimeout(BeginPayout, 1000);
    </script>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>

