<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // get the origin (if assigned) (support it anyway, even though it's not currently used)

  $Origin = empty($_GET) || empty($_GET["origin"]) ? "" : $_GET["origin"];
  if(strlen($Origin) > 0 && substr($Origin,0,1) != "/")
    $Origin = "/" . $Origin;

  $redo = empty($_GET) || empty($_GET["redo"]) ? "" : $_GET["redo"];
  $start = empty($_GET) || empty($_GET["start"]) ? "" : $_GET["start"];

  // find out the entity name, and the 'origin' parameter (if assigned)

  $Entity="";
  $EntityNum=0;
  $AutoStart=0; // these are assigned by the results from '/count-entity'

  $Solution = skyyreq("count-entity");
  eval($Solution);


  // parse config file for things I need
  $parseconf = load_parseconf();

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');

  $Equipment = coin_counter_equipment();


  if($start == 'Y')
  {
?>
    <HTML><HEAD><TITLE>Starting <?php if(substr($Equipment,0,4)=="C400") print "C400"; else print $Equipment; ?></TITLE>
    <meta http-equiv="refresh"
          content=
<?php
    if(strlen($origin) > 0 && strlen($redo) > 0)
      print '"0.2;url=/count-coins.php?start=YY&origin=' . urlencode($Origin) . "&redo=" . urlencode($redo) . '"';
    else if(strlen($origin) > 0)
      print '"0.2;url=/count-coins.php?start=YY&origin=' . urlencode($Origin) . '"';
    else if(strlen($redo) > 0)
      print '"0.2;url=/count-coins.php?start=YY&redo=' . urlencode($redo) . '"';
    else
      print '"0.2;url=/count-coins.php?start=YY"';

//    print "&EntityNum=" . urlencode($EntityNum);
?>
    >
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br>
      <H1>
        <center>
          <?php print $Entity; ?><br>
          Starting <?php if(substr($Equipment,0,4)=="C400") print "C400"; else print $Equipment; ?>
        </center>
      </H1>
    </BODY>
    </HTML>
<?php
    exit;
  }
  else if($start == "YY")
  {
    // for C300, invoke C300 commands
    if($Equipment == "C300")
      // TODO:  do I need a different command to start the C300 or can I just use this one?
      skyyreq("continue-c300"); // use 'continue-c300' to actually make the motor start
    else if(coin_counter_is_recycler($Equipment))
      skyyreq("continue-coin-recycler"); // use 'continue-coin-recycler' to actually make the motor start
    else
      skyyreq("continue-c400"); // use 'continue-c400' to actually make the motor start

    header("HTTP/1.0 302 Moved Temporarily");
    if(strlen($origin) > 0 && strlen($redo) > 0)
      header("Location: /coins-results.php?next=" . urlencode($Origina) . "&redo=" . urlencode($redo));
    else if(strlen($Origin) > 0)
      header("Location: /coins-results.php?next=" . urlencode($Origina));
    else if(strlen($redo) > 0)
      header("Location: /coins-results.php?redo=" . urlencode($redo));
    else
      header("Location: /coins-results.php");

    exit;
  }
  else if(strlen($start) > 0)
  {
?>
    <HTML><HEAD><TITLE>INTERNAL SYSTEM ERROR</TITLE>
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br>
      <H1>
        <center>
          <?php print $Entity; ?><br>
          INTERNAL SYSTEM ERROR
        </center>
      </H1>
    </BODY>
    </HTML>
<?php
    exit;
  }

  // if I'm not using '$start' I'll be using "$doohicky" to start the C400/C300 up

  $doohicky = do_getvar("doohicky", ""); // empty($_GET) || empty($_GET["doohicky"]) ? "" : $_GET["doohicky"];

  if($doohicky != "Y")
  {
    // do I have a C300 or a C400 installed??
    if($redo == "Y")
    {
      if($Equipment == "C300")
        $rval = skyyreq("add-count-c300"); // use 'continue-c300' to actually make the motor start - see the 'start' section, above
      else if(coin_counter_is_recycler($Equipment))
        $rval = skyyreq("add-count-coin-recycler"); // use 'continue-c300' to actually make the motor start - see the 'start' section, above
      else
        $rval = skyyreq("add-count-c400"); // use 'continue-c400' to actually make the motor start - see the 'start' section, above
    }
    else
    {
      if($Equipment == "C300")
        skyyreq("count-c300"); // use 'continue-c300' to actually make the motor start - see the 'start' section, above
      else if(coin_counter_is_recycler($Equipment))
        skyyreq("count-coin-recycler"); // use 'continue-recycler' to actually make the motor start - see the 'start' section, above
      else
        skyyreq("count-c400"); // use 'continue-c400' to actually make the motor start - see the 'start' section, above
    }
?>
      <HTML>
        <HEAD>
          <TITLE>Initializing <?php if(substr($Equipment,0,4)=="C400") print "C400"; else print $Equipment; ?></TITLE>
          <meta http-equiv="refresh" content="0.1;url=/count-coins.php?doohicky=Y<?php
                if($Origin != "") print "&origin=" . urlencode($Origin);
                if($redo != "") print "&redo=" . urlencode($redo); /*print "&EntityNum=" . urlencode($EntityNum);*/ ?>" >
<?php set_inbetween_style(); ?>
        </HEAD>
        <BODY>
          <br><br>
          <H1>
            <center>Initializing <?php if(substr($Equipment,0,4)=="C400") print "C400"; else print $Equipment; ?></center>
          </H1>
        </BODY>
      </HTML>
<?php

    exit;
  }


  // TODO  anything else?


?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title><?php print $Entity; ?> Count <?php print $Coins; ?></title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- CSS  -->

    <style>
<?php
  set_ideal_font_height();
?>
    .message-thing
    {
      color:#000000;/*#585858 works for bold font*/
      font-size: 1.17rem; /*28px*/
      font-weight:500; /* normal - 700 is bold */
      position:absolute;
      padding-left: 0.35em; /*10px*/
      padding-top: 0px;
      padding-bottom: 0px;
      height: 2.28em; /*64px;*/
      bottom: 2em; /*48px*/
      width: 15.7em /*440px*/
      left: 0.42em; /*12px*/
      line-height:110%;
      vertical-align:bottom;
      text-align:left;
    }
    </style>
  </head>
<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
    <a id="logo-container" href="#" class="brand-logo titlebar">Count <?php print $Coins; ?> <img src="img/count-coins.svg"></a>
      <div class="area"><?php print strtoupper($Entity); ?> </div>
    </div>
  </nav>

  <div class="container">
    <div class="section">
      <div class="row center">
<?php
  if(coin_counter_is_c300($Equipment))
  {
?>
        <img src="img/c300.png"
<?php
  }
  else if(coin_counter_is_recycler($Equipment))
  {
    /* <img src="img/recycler.png" */
?>
        <img src="img/srb-system-count-recycler.png"
<?php
  }
  else if(coin_counter_is_c400r($Equipment))
  {
?>
        <img src="img/cs400r.png"
<?php
  }
  else // if(coin_counter_is_c400($Equipment))
  {
?>
        <img src="img/cs400.svg"
<?php
  }
?>
             width=<?php print round(cached_font_size() * 320 / 24); ?>px
             height=<?php print round(cached_font_size() * 240 / 24); ?>px>
      </div>
<?php
  if(!coin_counter_is_recycler($Equipment))
  {
    // the "no coin rolls" graphic - do not show for recycler
?>
      <div style="position:absolute;top:6.67rem;left:8.33rem" >
        <img width=100 height=100 src="/img/norolledcoins.png">
      </div>
<?php
  }
?>

      <div class="message-thing"><br><span id="messagething"></span>
<?php
  if($AutoStart == 1 && $redo != "Y")
  {
?>
        <span id=autostart></span>
<?php
  }
?>
      </div>
      <div class="next-button">
        <form id=sukippu mode=GET>
<?php
  if(strlen($Origin) > 0)
  {
?>
          <input type=hidden name=next value="<?php print $Origin; ?>" style="visibility:hidden" />
<?php
  }
?>
          <input type=hidden name=complete value="Y" style="visibility:hidden" /><!-- this will shut it down without counting -->
        </form>
        <form id=startitup mode=GET>
<?php
  if(strlen($Origin) > 0)
  {
?>
          <input type=hidden name=origin value="<?php print $Origin; ?>" style="visibility:hidden" />
<?php
  }
?>
<?php
  if(strlen($redo) > 0)
  {
?>
          <input type=hidden name=redo value="<?php print $redo; ?>" style="visibility:hidden" />
<?php
  }
?>
          <input type=hidden name=start value="Y" style="visibility:hidden" />
        </form>
        <button form=sukippu formaction="/coins-results.php" class="waves-effect btn-flat primary-text">Skip</button>
<?php
  // for recyclers I keep the loop going
  if(coin_counter_is_recycler($Equipment))
  {
?>
          <input id=start type=hidden style="visibility:hidden" disabled>
<?php
  }
  else
  {
?>
          <button id=start form=startitup
                  formaction="/count-coins.php"
                  class="btn waves-effect primary-fill btn-shadow"
                  disabled>START</button>
<?php
  }
?>
      </div>
    </div>

<?php
  if(coin_counter_is_recycler($Equipment))
  {
?>
    <div id=coin_tray_warning
         style="visibility:hidden;display:none;position:absolute;right:9rem;top:10rem;width:20%;height:20%;z-order:99">
      <img height=<?php print round(cached_font_size() * 3); ?>px
           src="img/coin_drawer_rotate_ccw.png"
           style="visibility:inherit" />
    </div>

<?php
  }
?>

    <div id="modal1" class="modal">
      <div class="modal-content">
        <h6></h6>
        <p></p>
      </div>
    </div>
  </div>

  <!--  Scripts-->
  <script src="js/custom.js"></script>

  <script>

    var thing;
    var auto_start_secs;

    // TODO:  do I want auto-start or not?  What's the criteria?

    function AutoStartC400Timeout()
    {
  <?php
    if($AutoStart == 1 && $redo != "Y")
    {
  ?>
      document.getElementById("autostart").innerHTML = "<br>Auto-start in " + (5 - auto_start_secs);
      auto_start_secs += 1;

      if(auto_start_secs > 5)
      {
        window.location.href = "/count-coins.php?start=Y<?php if(strlen($Origin)>0) print '&Origin=' . urlencode($Origin);
                                                              if(strlen($redo)>0) print '&redo=' . urlencode($redo); ?>";
           // fast/dirty way to load next page (or in this case, reload same page with 'start=Y'
      }
  <?php
    }
  ?>
    }

    function getC400Status()
    {
      // NOTE:  this glue page also works for C300 - it will check installed equipment
      var myRequest = new Request("/glue/status-c400.php");

      fetch(myRequest)
        .then(function(response)
              {
                myRequest = null;

                if(!response.ok)
                {
                  console.log("status-c400", response.status); // debug only (TODO: remove?)
                }

                return  response.text();
              })
        .then(function(text)
              {
                // xx will be a DOM Parser type of object from which to parse XML
                var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                var tt = xx.getElementsByTagName("tick");
                var ee = xx.getElementsByTagName("entity");

                if(tt == null || tt[0] == null || tt[0].childNodes == null || tt[0].childNodes[0] == null ||
                   ee == null || ee[0] == null || ee[0].childNodes == null || ee[0].childNodes[0] == null)
                {
                  document.getElementById("messagething").innerHTML = "Server not responding";
                  if(thing != null)
                  {
                    clearInterval(thing); // status codes no longer needed
                    thing = null;
                  }

                  tt = null;
                  ee = null;
                  return;
                }

                var tick = tt[0].childNodes[0].nodeValue;
                var entity = ee[0].childNodes[0].nodeValue;
                var the_date = xx.getElementsByTagName("date")[0];
                var st = xx.getElementsByTagName("status")[0].children;
                var status_code = "";
                var status_text = "";
                var today = "";

                tt = null;
                ee = null;

                if(the_date && the_date.childNodes.length > 0)
                {
                  today = the_date.childNodes[0].nodeValue
                }
                else
                {
                  today = "unknown date";
                }

                for (var i1 = 0; i1 < st.length; i1++)
                {
                  if(st[i1].nodeName == "code")
                    status_code = st[i1].childNodes[0].nodeValue;
                  else if(st[i1].nodeName == "text")
                    status_text = st[i1].childNodes[0].nodeValue;
                }

  <?php
    if(coin_counter_is_recycler($Equipment))
    {
  ?>
                if(status_code == 30)
                {
                  document.getElementById("coin_tray_warning").style.visibility = "visible";
                  document.getElementById("coin_tray_warning").style.display = "block";
                }
                else
                {
                  document.getElementById("coin_tray_warning").style.visibility = "hidden";
                  document.getElementById("coin_tray_warning").style.display = "none";
                }
  <?php
    }
  ?>
                if(status_code == 16 || status_code == 19)
                {
  <?php
    if(!coin_counter_is_recycler($Equipment))
    {
  ?>
                  document.getElementById("messagething").innerHTML = "Please add <?php print $Coins; ?> to the hopper";
                  clearInterval(thing); // status codes no longer needed
                  thing = null;
                  document.getElementById("start").disabled = false;
  <?php
    }
    else
    {
      // for recyclers I will keep the loop going and display status as-is
  ?>
                  document.getElementById("messagething").innerHTML = status_text;
  <?php
    }
  ?>
  <?php
    if(!coin_counter_is_recycler($Equipment) &&
       $AutoStart == 1 && $redo != "Y")
    {
  ?>
                  auto_start_secs = 0;
                  thing = setInterval(AutoStartC400Timeout, 1000); // use this as my interval timer now
  <?php
    }
  ?>
                }
  <?php
    if(coin_counter_is_recycler($Equipment))
    {
  ?>
                else if(status_code == "22")
                {
                  xx = null;
                  entity = null;
                  the_date = null;
                  tick = null;
                  st = null;
                  status_code = null;
                  status_text = null;
                  today = null;

                  clearInterval(thing); // status codes no longer needed
                  thing = null;

                  // auto-start - machine begins counting
                  window.location.href = "/count-coins.php?start=Y<?php if(strlen($Origin)>0) print '&Origin=' . urlencode($Origin);
                                                                        if(strlen($redo)>0) print '&redo=' . urlencode($redo); ?>";
                }
  <?php
    }

    if(coin_counter_is_recycler($Equipment))
    {
  ?>
                else if(status_code == 30)
                {
                  document.getElementById("messagething").innerHTML = status_text;
                  // TODO:  something?
                }
  <?php
    }
  ?>
                else if(status_code != 0)
                {
  <?php
    if(coin_counter_is_recycler($Equipment))
    {
  ?>
                  if(document.getElementById("start").disabled) // only if I disabled it
  <?php
    }
  ?>
                  document.getElementById("messagething").innerHTML = status_text;
                }

                xx = null;
                entity = null;
                the_date = null;
                tick = null;
                st = null;
                status_code = null;
                status_text = null;
                today = null;
              });
    }

    thing = setInterval(getC400Status, 500);   // document is ready when I get to this point anyway (getting rid of JQuery)

  </script>

  <script src="/js/UserFeedback.js"></script>

</body>
</html>

