<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";


?>
<!DOCTYPE html5>
<HTML><HEAD><TITLE>Zeus Serial Numbers</TITLE>
<STYLE>
input
{
 font-size:24px;
 font-weight: bold;
 height : 42;
}
@font-face
{
 font-family: Lato;
 src: url(/fonts/lato-v15-latin-regular.woff);
}
</STYLE>
<SCRIPT>

  function getData()
  {
    var myRequest = new Request("/glue/status-zeus.php");
    var myRequest2 = new Request("/glue/count_notes.php");

    fetch(myRequest)
      .then(function(response)
            {
              if (!response.ok)
              {
                console.log("status", response.status);
              }
              return  response.text();
            })
      .then(function(text)
            {
              var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
              var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
              var the_date = xx.getElementsByTagName("date")[0];
              var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
              var st = xx.getElementsByTagName("status")[0].children;
              var status_code = "";
              var status_text = "";
              var today = "";

              if(the_date && the_date.childNodes.length > 0)
              {
                today = the_date.childNodes[0].nodeValue
              }
              else
              {
                today = "unknown date";
              }

              for (var i1 = 0; i1 < st.length; i1++)
              {
                if(st[i1].nodeName == "code")
                  status_code = st[i1].childNodes[0].nodeValue;
                else if(st[i1].nodeName == "text")
                  status_text = st[i1].childNodes[0].nodeValue;
              }

              document.getElementById("thing").innerHTML =
                "Count " + entity + "      " + today + "<br>"
                + "Tick: " + tick + "<br>"
                + "Code: " + status_code + "  " + status_text
               ;
            })
      .catch(function(error) { console.log(error);  });

    fetch(myRequest2)
      .then(function(response)
            {
              if (!response.ok)
              {
                console.log("status", response.status);
              }
              return  response.text();
            })
      .then(function(text)
            {
              var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
              var st0 = xx.getElementsByTagName("note");
              var ones = 0;
              var twos = 0;
              var fives = 0;
              var tens = 0;
              var twenties = 0;
              var fifties = 0;
              var hundreds = 0;

              for (var i0 = 0; i0 < st0.length; i0++)
              {
                var st = st0[i0].children;
                var type = 0;
                var qty = 0;

                for (var i1 = 0; i1 < st.length; i1++)
                {
                  if(st[i1].nodeName == "type")
                    type = st[i1].childNodes[0].nodeValue;
                  else if(st[i1].nodeName == "qty")
                    qty = st[i1].childNodes[0].nodeValue;
                }

                if(type == 1)
                  ones = qty;
                else if(type == 2)
                  twos = qty;
                else if(type == 5)
                  fives = qty;
                else if(type == 10)
                  tens = qty;
                else if(type == 20)
                  twenties = qty;
                else if(type == 50)
                  fifties = qty;
                else if(type == 100)
                  hundreds = qty;
              }
              document.getElementById("thang").innerHTML =
                "<table><th style=\"border-bottom:solid 1px\">Denomination</th><th></th>"
                + "<th style=\"border-bottom:solid 1px\">Quantity<th></th>"
                + "<tr><td>Ones</td><td>&nbsp;&nbsp;</td><td align=right>" + ones + "</td></tr>"
                + "<tr><td>Twos</td><td>&nbsp;&nbsp;</td><td align=right>" + twos + "</td></tr>"
                + "<tr><td>Fives</td><td>&nbsp;&nbsp;</td><td align=right>" + fives + "</td></tr>"
                + "<tr><td>Tens</td><td>&nbsp;&nbsp;</td><td align=right>" + tens + "</td></tr>"
                + "<tr><td>Twenties</td><td>&nbsp;&nbsp;</td><td align=right>" + twenties + "</td></tr>"
                + "<tr><td>Fifties</td><td>&nbsp;&nbsp;</td><td align=right>" + fifties + "</td></tr>"
                + "<tr><td>Hundreds</td><td>&nbsp;&nbsp;</td><td align=right>" + hundreds + "</td></tr>"
                + "</table><br>";
            })
      .catch(function(error) { console.log(error);  });
  }

  setInterval(getData, 200);

</SCRIPT>
</HEAD>
<?php
  skyyreq("serial-zeus");
?>
<BODY bgcolor="#003030" text="#ffffe0">
<H2>Begin Zeus (bill) Serial Capture, press 'Done' when done</H2>

<table align=center><tr><td width=300>
  <center><form action="/serial-complete.php" method="GET">
    <input type=submit value="Done" style="width:128;height:64">
  </form></center>
</td>
<td width=500 height=300>
<p style="height:100px;font-size:20px" name="thing" id="thing"></p>
<br>
<p style="font-size:16px" name="thang" id="thang"></p>
</td></tr>
</table>
</BODY></HTML>

