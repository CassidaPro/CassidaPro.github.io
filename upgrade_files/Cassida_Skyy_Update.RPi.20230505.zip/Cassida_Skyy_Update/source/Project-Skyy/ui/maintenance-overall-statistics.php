<?php
  /*            Copyright 2021 by Cassida               */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse stastics file for things I need
  $parsestats = load_parsestats();

  $Equipment = coin_counter_equipment();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Overall Statistics</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Overall Statistics
          <img width=42 height=42 src="/img/zeus-only.png">
          <img width=42 height=42 src="/img/<?php if(coin_counter_is_c400r($Equipment)) print 'c400r'; else print 'c400'; ?>-only.png">
        </a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <table style="width:55%;border:0;font-size:1rem;line-height:1.1em">
        <!--tr style="margin:0 20 0 0px;line-height:28px;border:0">
          <td style="padding:0;margin:0"-->

        <tr>
          <td style="width:20%;padding:0;margin:0;width:90px;text-align:center">
            <b>NOTES</b>
          </td>
          <td style="width:40%;padding:0;margin:0;width:180px;text-align:center">
            Process Total
          </td>
          <td style="width:40%;padding:0;margin:0;width:180px;text-align:center">
            Overall Total
          </td>
        </tr>
<?php

/*
  foreach ($parsestats as $xx => $yy)
  {
    foreach ($yy as $yx => $yz)
    {
      print '<tr><td style="padding:0;margin:0">'
            . $xx . '</td><td style="padding:0;margin:0">'
            . $yx . '</td><td style="padding:0;margin:0">'
            . $yz . "</td><tr>\n";
    }
  }
*/


  $aaa[0] = 1;
  $aaa[1] = 2;
  $aaa[2] = 5;
  $aaa[3] = 10;
  $aaa[4] = 20;
  $aaa[5] = 50;
  $aaa[6] = 100;

  foreach($aaa as $yy)
  {
    print '<tr><td style="padding:0;margin:0;width:90px;text-align:right">'
          . $yy . '&nbsp;&nbsp;</td>'
          . '<td style="padding:0;margin:0;width:180px;text-align:right">'
          . $parsestats["process notes"][$yy] . '&nbsp;&nbsp;&nbsp;&nbsp;</td>'
          . '<td style="padding:0;margin:0;width:180px;text-align:right">'
          . $parsestats["total notes"][$yy] . "&nbsp;&nbsp;&nbsp;&nbsp;</td><tr>\n";
  }
?>
        <tr style="line-height:0.5rem"><td>&nbsp;</td></tr>
        <tr>
          <td style="padding:0;margin:0;width:90px">
            <b>COINS</b>
          </td>
          <!--td style="padding:0;margin:0">
            Process Total
          </td>
          <td style="padding:0;margin:0">
            Overall Total
          </td-->
        </tr>
<?php

  $bbb[0] = 1;
  $bbb[1] = 5;
  $bbb[2] = 10;
  $bbb[3] = 25;
  $bbb[4] = 100;

  foreach($bbb as $yy)
  {
    print '<tr><td style="padding:0;margin:0;width:90px;text-align:right">'
          . $yy . '&nbsp;&nbsp;</td>'
          . '<td style="padding:0;margin:0;width:180px;text-align:right">'
          . $parsestats["process coins"][$yy] . '&nbsp;&nbsp;&nbsp;&nbsp;</td>'
          . '<td style="padding:0;margin:0;width:180px;text-align:right">'
          . $parsestats["total coins"][$yy] . "&nbsp;&nbsp;&nbsp;&nbsp;</td><tr>\n";
  }
?>
          <!--/td-->
        </tr>
      </table>
    </center>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;left:12px">
      <a href="/maintenance.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">BACK</span>
      </a><br/>
    </div>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/maintenance-overall-statistics2.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/wrench.png" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">&nbsp; &nbsp;NEXT</span>
      </a><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

