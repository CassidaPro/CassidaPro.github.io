<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/common_utils.php";

  function my_color($x)
  {
    return sprintf("#%06x", $x);
  }

  // parse config file for things I need
  $parseconf = load_parseconf();

  $ColorScheme = do_getconf($parseconf, "settings", "ColorScheme", "");
  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');


  // this is supposed to STOP cacheing this style sheet, to re-load every time
  header('Cache-Control: no-cache, no-store, must-revalidate');
  header('Pragma: no-cache');
  header('Expires: 0');
  // <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
  // <meta http-equiv="Pragma" content="no-cache" />
  // <meta http-equiv="Expires" content="0" />

  header('Content-type: text/css'); // necessary or it does not work

  // TODO:  functions to do RGB to HSV and back again, to create derived colors

  // TODO:  grab base colors from somewhere.  For now, just use these

  $BackgroundColor        = 0xffffff;

  // -------------------------------------------------------------------------------
  // COLORS:  acadamy, banana, cardena, energy, grey, industrial, padre, USA
  // These colors go into an array '$ColorList' defined in /glue/common_utils.php
  // (array is defined near the bottom of the file).  Must add new ones to that list
  // -------------------------------------------------------------------------------

//  if($ColorScheme == "academy")
//  {
//    $PrimaryFill            = 0xee1d23;
//    $SecondaryFill          = 0x1055a5;
//
////    $PrimaryFill            = 0xff0000;
////    $SecondaryFill          = 0x0f42fc;
//    $PrimaryText            = $PrimaryFill;
//    $SecondaryText          = $SecondaryFill;
//    $BtnTextColor           = 0xffffff;
//    $IconInvert             = 0;
//    $BackgroundColor        = 0xfefefe;
//  }
  if($ColorScheme == "academy1")
  {
    $PrimaryFill            = 0xee1d23;
    $SecondaryFill          = 0x1055a5;
    $PrimaryText            = $PrimaryFill;
    $SecondaryText          = $SecondaryFill;
    $BtnTextColor           = 0xffffff;
    $IconInvert             = 0;
    $BackgroundColor        = 0xfefefe;
  }
  else if($ColorScheme == "academy")
  {
    $PrimaryFill            = 0x1055a5; //0xee1d23;
    $SecondaryFill          = 0x1055a5; //0xee1d23;
//    $SecondaryFill          = 0xee1d23; //0x1055a5;
    $PrimaryText            = $PrimaryFill;
    $SecondaryText          = $SecondaryFill;
    $BtnTextColor           = 0xffffff;
    $IconInvert             = 0;
    $BackgroundColor        = 0xfefefe;
  }
  else if($ColorScheme == "banana")
  {
    $PrimaryFill            = 0xffe800;
    $SecondaryFill          = 0x606000;
    $PrimaryText            = 0x404000;
    $SecondaryText          = $SecondaryFill;
    $BtnTextColor           = 0x000000;
    $IconInvert             = 1;
  }
  else if($ColorScheme == "cardena")
  {
    $PrimaryFill            = 0xc0052f;
    $SecondaryFill          = 0x7f031f;
    $PrimaryText            = $PrimaryFill;
    $SecondaryText          = $SecondaryFill;
    $BtnTextColor           = 0xffffff;
    $IconInvert             = 0;
  }
  else if($ColorScheme == "energy")
  {
    $PrimaryFill            = 0x013a81;
    $SecondaryFill          = 0x8dc63f;
    $PrimaryText            = $PrimaryFill;
    $SecondaryText          = $SecondaryFill;
    $BtnTextColor           = 0xffffff;
    $IconInvert             = 0;
  }
  else if($ColorScheme == "grey")
  {
    $PrimaryFill            = 0x606068;
    $SecondaryFill          = 0x202030;
    $PrimaryText            = $PrimaryFill;
    $SecondaryText          = $SecondaryFill;
    $BtnTextColor           = 0xffffff;
    $IconInvert             = 0;
  }
  else if($ColorScheme == "industrial")
  {
    $PrimaryFill            = 0x408060;
    $SecondaryFill          = 0x404080;
    $PrimaryText            = $PrimaryFill;
    $SecondaryText          = $SecondaryFill;
    $BtnTextColor           = 0xffffff;
    $IconInvert             = 0;
  }
  else if($ColorScheme == "padre")
  {
    $PrimaryFill            = 0xffc425;//0xffa737;
    $SecondaryFill          = 0x2f241d;//0x7e5920;
    $PrimaryText            = 0x45462a;
    $SecondaryText          = $SecondaryFill;
    $BtnTextColor           = 0x000000;
    $IconInvert             = 1;
  }
  else if($ColorScheme == "USA")
  {
    $PrimaryFill            = 0xB42033;
    $SecondaryFill          = 0x3C3B6E;
    $PrimaryText            = $PrimaryFill;
    $SecondaryText          = $SecondaryFill;
    $BtnTextColor           = 0xffffff;
    $IconInvert             = 0;
    $BackgroundColor        = 0xfefefe;
  }

  else // default
  {
    $PrimaryFill            = 0xce3373;  // task button backgrounds
    $SecondaryFill          = 0x625cff;
    $PrimaryText            = $PrimaryFill;
    $SecondaryText          = $SecondaryFill;
    $BtnTextColor           = 0xffffff;
    $IconInvert             = 0;
  }

  $AccentFill             = 0x57b33b;
  $ButtonHover            = 0xce3373;
  $SubLabel               = 0xB3B3B3;
  $Straps                 = 0x909090;
  $InputColor             = 0x262626;
  $InactiveColor          = 0x707070;

  $TextColor              = 0x262626;
  $StripeColor            = "rgba(242, 242, 242, 0.5)";

  $CalcCardFrom           = 0x393993;
  $CalcCardTo             = 0x6161FF;
  $CalcButton             = $SecondaryFill;
  $MDLCard                = $SecondaryFill;

  $CalcCardOverrideFrom   = 0x393993;
  $CalcCardOverrideTo     = 0x6161FF;
  $CalcButtonOverride     = $PrimaryFill;
  $MDLCardOverride        = $PrimaryFill;

  $TableBackgroundColor   = 0xffffff;
  $TableBackStripColor    = 0xf2f2f2;

  $DatePickerBackground   = 0xce3373; // also cancel/done button and data/display text

  $OffButtonTextColor     = 0xffffff;
  $OffButtonBackground    = $SecondaryFill;
  $PrintButtonTextColor   = 0xffffff;
  $PrintButtonBackground  = $SecondaryFill;
?>
html
{
  background-color: <?php print my_color($BackgroundColor); ?>;
  color: <?php print my_color($TextColor); ?>;
}
.off-button
{
  background-color: <?php print my_color($OffButtonBackground); ?> !important;
  color: <?php print my_color($OffButtonTextColor); ?>;
}
.print-button
{
  background-color: <?php print my_color($PrintButtonBackground); ?> !important;
  color: <?php print my_color($PrintButtonTextColor); ?>;
}
.primary-fill
{
  background-color: <?php print my_color($PrimaryFill); ?>;
}
.primary-text
{
  color: <?php print my_color($PrimaryText); ?>;
}
.secondary-fill
{
  background-color: <?php print my_color($SecondaryFill); ?> !important;
}
.secondary-text
{
  color: <?php print my_color($SecondaryText); ?> !important;
}
.accent-fill
{
  background-color: <?php print my_color($AccentFill); ?>;
}
.btn, .btn-large, .btn-small
{
  color: <?php print my_color($BtnTextColor); ?>;
}
<?php
  if($IconInvert != 0)
  {
?>
.invertible-icon
{
  filter: invert(100%);
}
<?php
  }
?>
.selected-button
{
  background-color: <?php print my_color($SecondaryFill); ?> !important;
 	color: <?php print my_color($OffButtonTextColor); ?> !important;
}
[type="radio"]:checked+span:after,
  [type="radio"].with-gap:checked+span:after
{
<?php
  if($IconInvert != 0)
  {
?>
    background-color:<?php print my_color($SecondaryFill); ?>;
<?php
  }
  else
  {
?>
    background-color:<?php print my_color($PrimaryFill); ?>;
<?php
  }
?>
}
[type="radio"]:checked+span:after,
  [type="radio"].with-gap:checked+span:before,
  [type="radio"].with-gap:checked+span:after
{
<?php
  if($IconInvert != 0)
  {
?>
    border: 2px solid <?php print my_color($SecondaryFill); ?>;
<?php
  }
  else
  {
?>
    border: 2px solid <?php print my_color($PrimaryFill); ?>;
<?php
  }
?>
}

input
{
 	color: <?php print my_color($InputColor); ?> !important;
}
.inactive
{
 	color: <?php print my_color($InactiveColor); ?> !important;
}
.btn:hover, .btn-large:hover, .btn-small:hover
{
	background-color: <?php print my_color($PrimaryFill); ?>;
}
table.striped > tbody > tr:nth-child(even)
{
  background-color: <?php print $StripeColor; ?>;
}
table.striped > tbody > tr:nth-child(odd)
{
  background-color: <?php print my_color($BackgroundColor); ?> !important;
}
#straps span
{
  color: <?php print my_color($Straps); ?>;
}
.subrow
{
  background-color: <?php print my_color($BackgroundColor); ?> !important;
}
.subLabel
{
	color: <?php print my_color($SubLabel); ?>;
}
.btn-flat:focus
{
  background-color: <?php print my_color($BackgroundColor); ?> !important;
}
.datepicker-table td.is-selected
{
  background-color: <?php print my_color($PrimaryFill); ?>;
}
.datepicker-cancel, .datepicker-done
{
  color: <?php print my_color($PrimaryFill); ?>;
}
.datepicker-date-display
{
   background-color: <?php print my_color($PrimaryFill); ?>;
}
.calc-card
{
  background-image: linear-gradient(46deg, <?php print my_color($CalcCardFrom); ?> 0%, <?php print my_color($CalcCardTo); ?> 100%);
}
.calc-button
{
  background: <?php print my_color($CalcButton); ?>;
 	color: <?php print my_color($OffButtonTextColor); ?> !important;
}
.mdl-card
{
  background: <?php print my_color($MDLCard); ?>;
}
.calc-card-override
{
  background-image: linear-gradient(46deg, <?php print my_color($CalcCardOverrideFrom); ?> 0%, <?php print my_color($CalcCardOverrideTo); ?> 100%);
}
.calc-button-override
{
  background: <?php print my_color($CalcButtonOverride); ?>;
  color: <?php print my_color($BtnTextColor); ?>;
}
.mdl-card-override
{
  background: <?php print my_color($MDLCardOverride); ?>;
}
.mdl-button--accent-override
{
  color: <?php print my_color($BtnTextColor); ?> !important;
}

/* customized non-color things */
<?php
  if($CustomerMod == 2) // Academy
  {
    // requested that titles be hidden/removed
?>
.area
{
  visibility:hidden !important;
  display:none !important;
}
/*nav .brand-logo                 */
/*{                               */
/*  visibility:hidden !important; */
/*  display:none !important;      */
/*}                               */
<?php
  }
?>


