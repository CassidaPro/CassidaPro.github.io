<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";


  // find out the entity name, and the 'origin' parameter (if assigned)
  // these are assigned via 'GET' parameters in the URL

  $next = empty($_GET) || empty($_GET["next"]) ? "" : $_GET["next"];
  $complete = empty($_GET) || empty($_GET["complete"]) ? "" : $_GET["complete"];

  $Entity="";
  $EntityNum=-1; // default is 'ad hoc'
  $Solution = skyyreq("count-entity");
  eval($Solution);

  // parse config file for things I need
  $parseconf = load_parseconf();

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Pulls = do_getconf($parseconf,"terms",'Pulls','Pulls');

  // am I completing?  If so, display 'complete' page and move to next step or 'origin'

  if($complete == "Y")
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh"
          content=
<?php
  if(strlen($next) > 0)
    print '"0.2;url=/notes-results.php?complete=YY&next=' . urlencode($next) . '"';
  else
    print '"0.2;url=/notes-results.php?complete=YY"';
?>
    >
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br>
      <H1>
        <center>
          <?php print $Entity; ?><br>
<?php
    if(register_is_pull($EntityNum))
    {
?>
          <?php print make_singular($Pulls); ?> Count Complete
<?php
    }
    else
    {
?>
          <?php print $Notes; ?> Complete
<?php
    }
?>
        </center>
      </H1>
    </BODY>
    </HTML>
<?php
    exit;
  }
  else if($complete == "YY")
  {
    skyyreq("complete"); // completes the Zeus count
    header("HTTP/1.0 302 Moved Temporarily");

    if(register_is_pull($EntityNum))
    {
      header("Location: /entity-number.php?pull=Y&class=" . urlencode($Class));

      $count1 = '0';
      $count2 = '0';
      $count5 = '0';
      $count10 = '0';
      $count20 = '0';
      $count50 = '0';
      $count100 = '0';

      $Solution = skyyreq("result-zeus");
      eval($Solution);

      $totals = $count1 + $count2 + $count5 + $count10 + $count20 + $count50 + $count100;

      if($totals > 0) // only print receipt if total > 0
      {
        skyyreq("print-receipt" );
      }
    }
    else
    {
      header("Location: /glue/next-step-count-class.php");
    }

    exit;
  }

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title><?php print $Entity; ?> <?php print $Notes; ?> Results</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- CSS  -->

    <style>
<?php
  set_ideal_font_height();
?>
      .single tr td:last-child
      {
        text-align:right !important;
        padding-right:100px;
      }
      .message-thing
      {
        color:#000000;/*#585858 works for bold font*/
        font-size: 1.15rem /*28px*/;
        font-weight:500; /* normal - 700 is bold */
        position:absolute;
        padding-left: 10px;
        padding-top: 0px;
        padding-bottom: 0px;
        min-height: 2.67rem /* 64px*/;
        max-height: 3.5rem;
        bottom: 2rem /*24px, was 48px*/;
        width: 18.3rem /*440px*/;
        left:12px;
        line-height:110%;
        vertical-align:bottom;
        text-align:left;
      }
    </style>
  </head>
<body>
   <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">
<?php
    if(register_is_pull($EntityNum))
    {
?>
        <?php print make_singular($Pulls); ?> Count
<?php
    }
    else
    {
?>
        <?php print $Notes; ?> Count
<?php
    }
?>
        <img src="img/count-notes.svg">
      </a>
      <div class="area"><?php print strtoupper($Entity); ?></div>
    </div>
  </nav>

  <div class="container">
    <form id=complete method="GET">
<?php
  if(strlen($next) > 0)
  {
?>
      <input type=hidden style="visibility:hidden" name=next
             value=<?php print '"' . $next . '"'; ?> />
<?php
  }
?>
      <input type=hidden style="visibility:hidden" name=complete value="Y" />
    </form>
    <div class="section">
<?php
  if($CustomerMod == 1 && strlen($next) == 0 && $EntityNum != -1) // not when 'redo'ing or ad-hoc
  {
    // note: 'absolute' position should prevent the hidden 'div' from affecting the results
    //       when the count results are being displayed.
?>
      <div id=operator_messages style="border:0;position:absolute;visibility:hidden;font-size:28px;">
        <center><table width=85% style="border:0;"><tr style="border:0"><td align="center">
<?php
    if($EntityNum == -100) // SAFE
    {
?>
          <center><b>Remove</b> change drawer from safe and <b>place</b> on counter&nbsp;&nbsp;
          <br>
          <img height=210 src="/img/Drawer.gif"></center>
<?php
    }
    else if($EntityNum == -200) // change drawer
    {
?>
          <center><b>Ensure</b> all till bags are removed from the safe&nbsp;&nbsp;
          <br>
          <img height=210 src="/img/Bags.gif"></center>
<?php
    }
    else if($EntityNum > 0)
    {
      if(!register_is_pull($EntityNum))
      {
?>
          <center><b>Pour</b> Loose <?php print $Coins; ?> into Coin Counter&nbsp;&nbsp;
          <br>
          <img height=210 src="/img/Coins.gif"></center>
<?php
      }
    }
    else
    {
?>
          ERROR:  UNKNOWN ENTITY
<?php
    }
?>
        </td></tr></table></center>
      </div>
<?php
  }
?>
      <div id=results class="single-table-container" style="visibility:visible">
      <!--div class="single-table-container center"-->
        <p class="table-name"><?php print $Notes; ?></p>
        <table id="notes" class="striped single">
          <tbody>
            <tr>
              <th>$</th>
              <th>Qty</th>
              <th>Val&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
              <!--th>Val </th-->
            </tr>
            <tr>
              <td>$1</td><td id="qn1">0</td><td id="vn1">0</td></tr>
            <tr>
              <td>$2</td><td id="qn2">0</td><td id="vn2">0</td></tr>
            <tr>
              <td>$5</td><td id="qn5">0</td><td id="vn5">0</td></tr>
            <tr>
              <td>$10</td><td id="qn10">0</td><td id="vn10">0</td></tr>
            <tr>
              <td>$20</td><td id="qn20">0</td><td id="vn20">0</td></tr>
            <tr>
              <td>$50</td><td id="qn50">0</td><td id="vn50">0</td></tr>
            <tr>
              <td>$100</td><td id="qn100">0</td><td id="vn100">0</td></tr>
          </tbody>
        </table>
        <div class="subtotal" style="display:none" id="notesSubTotal">0</div>
      </div>
    </div>

    <div class="page-total  grand_total">
      <div class="page-total-textfield"><label>Total</label>
        <input id="page-total" class="mdl-textfield__input special-text-input" type="text" value="$0" maxlength="9" disabled />
      </div>

    </div>
    <div class="message-thing"><p id="zeus-message"></p></div>
    <div class="next-button"><!-- post back to myself but 'complete' form has complete=Y -->
      <button id=done form=complete formaction="/notes-results.php" class="btn waves-effect primary-fill btn-shadow">DONE</button>
    </div>
  </div>


  <!--  Scripts-->
  <script src="js/custom.js"></script>

  <script>
    var refreshTable = null; // use this to un-schedule and re-schedule updates
    var CustomerMod='<?php print $CustomerMod; ?>'; // not actually being used, for now - left for reference

    function DoSetZeusStatusInterval()
    {
      if(refreshTable != null)
      {
        clearInterval(refreshTable); // so that these messages don't interfere
      }

      refreshTable= setInterval(getZeusStatus, 500);
    }

    function getZeusStatus()
    {
        var myRequest = new Request("/glue/status-zeus.php");

        fetch(myRequest)
          .then(function(response)
                {
                  myRequest = null;

                  if (!response.ok)
                  {
                    console.log("status-zeus", response.status);
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                  var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                  var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
                  var the_date = xx.getElementsByTagName("date")[0];
                  var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
                  var st = xx.getElementsByTagName("status")[0].children;
                  var status_code = "";
                  var status_text = "";
                  var today = "";

                  if(the_date && the_date.childNodes.length > 0)
                  {
                    today = the_date.childNodes[0].nodeValue
                  }
                  else
                  {
                    today = "unknown date";
                  }

                  for (var i1 = 0; i1 < st.length; i1++)
                  {
                    if(st[i1].nodeName == "code")
                      status_code = st[i1].childNodes[0].nodeValue;
                    else if(st[i1].nodeName == "text")
                      status_text = st[i1].childNodes[0].nodeValue;
                  }

                  document.getElementById("zeus-message").style.color="#000000"; // BLACK
                  document.getElementById("zeus-message").style.backgroundColor="#ffffff"; // WHITE

                  // at the first ';' or '.' insert a '<br>'
                  status_text = status_text.replace(/;/,";<br>").replace(/\./,".<br>");

                  if(status_code=="1")
                  {
                    document.getElementById("zeus-message").innerHTML = "Counting...";
                    document.getElementById("done").disabled=true;

  <?php
    if($CustomerMod == 1 && strlen($next) == 0 && $EntityNum != -1) // not when 'redo'ing or ad-hoc
    {
  ?>
                    document.getElementById("results").style.visibility="hidden";
                    document.getElementById("operator_messages").style.visibility="visible";
  <?php
    }
  ?>
                  }
                  else if(status_code != 0)
                  {
                    document.getElementById("zeus-message").innerHTML = status_text;

  <?php
    if($CustomerMod == 1 && strlen($next) == 0 && $EntityNum != -1) // not when 'redo'ing or ad-hoc
    {
  ?>
                    document.getElementById("results").style.visibility="visible";
                    document.getElementById("operator_messages").style.visibility="hidden";
  <?php
    }
  ?>
                    if(status_code == "15") // an error
                    {
                      document.getElementById("zeus-message").style.color="#800000"; // RED
                      document.getElementById("zeus-message").style.backgroundColor="#ffff00"; // YELLOW
                    }
                    else if(status_code == "6") // insufficient strap qty in stacker
                    {
                      document.getElementById("zeus-message").style.color="#802000"; // rededish-brown
                      document.getElementById("zeus-message").style.backgroundColor="#c0ffff"; // light cyan
                    }
                    else
                    {
                      document.getElementById("zeus-message").style.color="#000000"; // black
                      document.getElementById("zeus-message").style.backgroundColor="#ffffff"; // white
                    }

                    if(status_code == 15 // error
  //                     || status_code == 4  // hopper empty
                       || status_code == 8) // hopper and stacker empty
                    {
                      document.getElementById("done").disabled=false;
                    }
                    else
                    {
                      document.getElementById("done").disabled=true;
                    }
                  }
                  else
                  {
                    document.getElementById("zeus-message").innerHTML = "";
                    document.getElementById("done").disabled=false;

  <?php
    if($CustomerMod == 1 && strlen($next) == 0 && $EntityNum != -1) // not when 'redo'ing or ad-hoc
    {
  ?>
                    document.getElementById("results").style.visibility="visible";
                    document.getElementById("operator_messages").style.visibility="hidden";
  <?php
    }
  ?>
                  }

                  xx = null;
                  entity = null;
                  the_date = null;
                  tick = null;
                  st = null;
                  status_code = null;
                  status_text = null;
                  today = null;
                })
          .catch(function(error) { console.log(error);  });
    }

    DoSetZeusStatusInterval();

  <?php
    if($CustomerMod == 1 && strlen($next) == 0 && $EntityNum != -1) // not when 'redo'ing or ad-hoc
    {
  ?>
      // initially, do the operator messages on load [assume I'm counting]; will auto-fix if not
      document.getElementById("results").style.visibility="hidden";
      document.getElementById("operator_messages").style.visibility="visible";
  <?php
    }
  ?>

  //  $(document).ready(DoNoteResults());
    DoNoteResults();

  </script>

  <script src="/js/UserFeedback.js"></script>

</body>
</html>

