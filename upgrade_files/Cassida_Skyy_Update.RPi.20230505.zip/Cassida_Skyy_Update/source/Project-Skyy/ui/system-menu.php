<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  setup_screen_res();

  // parse config file for things I need
  $parseconf = load_parseconf();

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html5>
<html lang="en">
  <HEAD>
    <TITLE>System Menu for Split Recycler System</TITLE>
    <link href="/css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="/img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.8rem;
        line-height: 1em;
      }
      input
      {
        font-size: 0.82rem;
        line-height: 1em;
      }
      td
      {
        font-size: 0.82rem;
        line-height: 1em;
      }
    </style>
  </HEAD>
  <BODY>
    <form id=none></form>
    <form id=initial_setup>
      <input type=hidden name="LocalConfig" value="*" style="visibility:hidden;display:none" />
    </form>
    <center>
      <b>
        <H1>
          Split Recycler - System Menu
        </H1>
        <H4>
          <?php print skyyreq("version" ); ?>
        </H4>
      </b>
    </center>
    <center>
      <table width="75%">
        <tr style="margin:0">
          <td width="35%"><center><input type=submit form=none formaction="/config/index.php" value="Config Main" style="min-width:7.2rem" /></center></td>
          <td width="65%" style="margin-left:0.41rem">Editing, Backup, and Restoration of the current system configuration.</td>
        </tr>
        <tr style="margin:0;padding:0;font-size:0.175rem;line-height:1em"><td style="font-size:inherit">&nbsp;</td></tr>
        <tr style="margin:0">
          <td><center><input type=submit form=none formaction="/networking.php" value="Network" style="min-width:7.2rem" /></center></td>
          <td style="margin-left:0.41rem">Network configuration (required for Banking).</td>
        </tr>
        <tr style="margin:0;padding:0;font-size:0.175rem;line-height:1em"><td style="font-size:inherit">&nbsp;</td></tr>
        <tr style="margin:0">
          <td><center><input type=submit form=none formaction="/banking.php" value="Banking" style="min-width:7.2rem" /></center></td>
          <td style="margin-left:0.41rem">Banking Transaction Configuration.</td>
        </tr>
      </table>
      <br style="font-size:0.7rem;line-height:1em;min-height:0.7rem;margin:0;padding:0" />
      <table width="75%">
        <tr style="margin:0">
          <td width="35%"><center><input type=submit form=initial_setup formaction="/config/initial-setup.php"
              value="Initial Setup" style="min-width:7.2rem" /></center></td>
          <td width="65%" style="margin-left:0.41rem">Initial configuration setup utility.  Use once to build the system configuration.</td>
        </tr>
        <tr style="margin:0;padding:0;font-size:0.175rem;line-height:1em"><td style="font-size:inherit">&nbsp;</td></tr>
        <tr style="margin:0">
          <td><center><input type=submit form=none formaction="/config/factory-reset.php" value="Factory Reset" style="min-width:7.2rem" /></center></td>
          <td style="margin-left:0.41rem">Reset configuration to 'Factory Default', then re-run 'Initial Setup'</td>
        </tr>
      </table>
    </center>


    <form action="/" method="GET">
      <input type=submit value="Back to Main" style="position:absolute;bottom:18px;min-width:7.33rem;left:13rem"/>
    </form>

    <script>
      // This special script is not documented
      // must be defined before any 'onClick' field refers to it
      // 'Semprini' is a Monty Python joke

      var nTimes=0;
      var nLastTime=Date.now();

      function Semprini()
      {
        var nNow = Date.now();

        if(!nTimes)
        {
          nTimes = 1;
          nLastTime = nNow;
          return;
        }

        if((nNow - nLastTime) < 500 || // less than half sec
           (nNow - nLastTime) > 1500) // more than 1.5 sec
        {
          nTimes = 0;
          nLastTime = nNow;
          return;
        }

        nTimes = nTimes + 1;
        nLastTime = nNow;

        if(nTimes > 5)
        {
          // change this according to the need
          window.location.assign("/test-index.php");
          return;
        }
      }
    </script>

    <div style="font-size:10px;position: absolute;bottom:4px;right:4px;margin:0;padding:0">
      <!-- this feature is undocumented.  Again -->
      <div onClick="Semprini();" style="min-height:0.83rem;min-width:1.25rem">&nbsp;</div>
    </div>

  </BODY>
</HTML>

