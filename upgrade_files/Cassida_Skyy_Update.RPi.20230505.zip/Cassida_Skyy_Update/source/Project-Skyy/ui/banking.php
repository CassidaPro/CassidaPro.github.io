<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include 'glue/config_utils.php';


  // parse config file for things I need
  $parseconf = load_parseconf();

  $banking = do_parse_banking();

  $BankingType = do_bankingvar($banking, "system",
                               do_getconf($parseconf, "banking", "type", ""));

  $EnablePosting = do_bankingvar($banking, "enable_posting", "false"); // this is true or false
  $EndOfDay = do_getconf($parseconf, "banking", "end_of_day", "off"); // this is off or on

  $Currency0 = do_bankingvar($banking, "currency_code", "")
             . ":" . do_bankingvar($banking, "country", "");

  if($Currency0 == ":")
    $Currency = "USD:US"; // helps with selection - $Currency0 reflects what the file has
  else
    $Currency = $Currency0; // use what the file has in it

  $Save = do_getvar("Save", "");
  $Next = do_getvar("Next", "");

  if($Save == "Y")
  {
    $BankingTypeX  = do_getvar("BankingType", "none");
    $enable_posting  = do_getvar("enable_posting", "off");
    $end_of_day  = do_getvar("end_of_day", "off");
    $CurrencyX = do_getvar("Currency", "USD:US");

    // TODO:  sanitize user input data first?  go back and re-edit?
?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=banking.php?Save=YY<?php
            print "&Next=" . urlencode($Next);
            print "&enable_posting=" . urlencode($enable_posting);
            print "&end_of_day=" . urlencode($end_of_day);
            print "&Currency=" . urlencode($CurrencyX);
            print "&BankingType=" . urlencode($BankingTypeX); ?>" >
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($Save == "YY")
  {
    $BankingTypeX  = do_getvar("BankingType", "none");
    $enable_posting  = do_getvar("enable_posting", "off");
    $end_of_day  = do_getvar("end_of_day", "off");
    $CurrencyX = do_getvar("Currency", "USD:US");

    $changed = 0;
    if(($enable_posting == "on" && $EnablePosting != "true") ||
       ($enable_posting != "on" && $EnablePosting == "true") ||
       $end_of_day !== $EndOfDay ||
       $Currency0 != $CurrencyX || // compare it to $Currency0
       $BankingTypeX !== $BankingType)
    {
      $parseconf["banking"]["type"] = $BankingTypeX;
      $parseconf["banking"]["end_of_day"] = $end_of_day;

      $banking["system"] = $BankingTypeX;

      $aCurrency = explode(":", $CurrencyX);
      $banking["currency_code"] = $aCurrency[0];
      $banking["country"] = $aCurrency[1];

      if($enable_posting == "on" &&
         strlen($BankingTypeX) > 0 && $BankingTypeX != "none")
      {
        $banking["enable_posting"] = "true";
      }
      else
      {
        $banking["enable_posting"] = "false";
      }

      do_write_banking($banking);

      write_configuration_file($parseconf, "banking.php");
    }

    header("HTTP/1.0 302 Moved Temporarily");
    if(strlen($Next) > 0)
      header("Location: " . $Next);
    else
      header("Location: /system-menu.php");

    exit;
  }


?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Split Recycler System - Banking</TITLE>
    <link href="/css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="/img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
      }
    </style>
    <script>
      function TestBanking()
      {
        document.getElementById("banking_test").innerHTML = "Testing...";
        document.getElementById("test_banking_button").disabled = true;

        // this is where we check for maintenance items

        var myRequest = new Request("/glue/test-banking.php");

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("status", response.status);
                    return "ERROR";
                  }
                  return  response.text();
                })
          .then(function(text)
                {
                  text = text.trim();

                  // if I get a return code, invoke the maintenance prompt page using that code
                  // this will display a prompt for equipment arrival, and install as needed

                  if(text.length > 0)
                    document.getElementById("banking_test").innerHTML = text;
                  else
                    document.getElementById("banking_test").innerHTML = "No Response";

                  document.getElementById("test_banking_button").disabled = false;
                });
      }
    </script>
  </HEAD>
  <BODY>
    <form id=none method=GET></form>
    <center>
      <b>
        <H1 style="margin:0;padding:0;font-size:1.33rem">Split Recycler - Banking</H1>
        <H4 style="margin:0;padding:0;margin-bottom:0.67rem">
          <?php print skyyreq("version"); ?></H4>
      </b>
    </center>
    <br>
    <form id=Save method=GET>
      <input type=hidden name="Save" value="Y" style="visibility:hidden" />
      <input type=hidden id=Next name="Next" value="" style="visibility:hidden" />
      <center>
        <table>
          <tr>
            <td>
              Banking System:&nbsp;&nbsp;
            </td>
            <td>
              <select name=BankingType style="font-size:0.75rem;padding-left:4;padding-right:4;min-width:25%">
                <option value="none" <?php if($BankingType == "" || $BankingType == "none") print "selected"; ?> >
                  {none}
                </option>
                <option value="cirreon" <?php if($BankingType == "cirreon") print "selected"; ?> >
                  NAMSYS (Cirreon)
                </option>
                <option value="compass/vms" <?php if($BankingType == "compass/vms") print "selected"; ?> >
                  Compass/VMS
                </option>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              Currency:&nbsp;&nbsp;
            </td>
            <td>
              <select name=Currency style="font-size:0.75rem;padding-left:4;padding-right:4;min-width:25%">
                <!-- currency code : country code -->
                <option value="USD:US" <?php if($Currency == "USD:US") print "selected"; ?> >
                  $US (United States)
                </option>
              </select>
            </td>
          </tr>
        </table>
        <table>
          <tr>
            <td>
              <input id=enable_posting name=enable_posting type=checkbox <?php if($EnablePosting == "true") print "checked"; ?> >
                Enable Posting
              </input>
            </td>
          </tr>
          <tr>
            <td>
              <input id=end_of_day name=end_of_day type=checkbox <?php if($EndOfDay == "on") print "checked"; ?> >
                Requires End-Of-Day processing
              </input>
            </td>
          </tr>
        </table>
      </center>
    </form>

    <table width=75% style="position:absolute;bottom:3.5rem;left:12.5%;">
      <tr>
        <td>
          <center>
            <input id=test_banking_button type=button value="Test&nbsp;Banking" onclick="TestBanking();"
                   style="height:1.7rem;min-width:5rem;font-size:1rem" />
          </center>
        </td>
      </tr>
      <tr>
        <td>
          <center>
            <span id=banking_test style="min-height:1.5rem;max-height:4.5rem;font-size:0.75rem;display:inline-block;overflow:auto;">&nbsp;</span>
          </center>
        </td>
      </tr>
    </table>
    <table width=75% style="position:absolute;bottom:0.75rem;left:12.5%;">
      <tr>
        <td width=33%>
          <center>
            <input type=submit value="Back" form="none" formaction="/system-menu.php"
                   style="min-width:120px;" />
          </center>
        </td>
        <td width=34%>
          <center>
            <input type=submit value="Settings" form="Save" formaction="banking.php"
                   onclick='document.getElementById("Next").value="/glue/banking_edit.php";'
                   style="min-width:120px;" />
          </center>
        </td>
        <td width=33%>
          <center>
            <input type=submit value="Save" form="Save" formaction="banking.php"
                   style="min-width:120px;" />
          </center>
        </td>
      </tr>
    </table>
  </BODY>
</HTML>

