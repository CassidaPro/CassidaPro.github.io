<?php
/*          Copyright 2019-2020 by Cassida          */
/* Use only in accordance with the supplied license */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Straps = do_getconf($parseconf,"terms",'Straps','Straps');
  $BuildButton = do_getconf($parseconf,"terms",'BuildButton','Build Tills');

  $Equipment = coin_counter_equipment();
  $IsSRB = coin_counter_is_recycler($Equipment);

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title><?php print $BuildButton; ?> - <?php $Straps; ?></title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- CSS  -->

    <style>
<?php
  set_ideal_font_height();
?>
      .message-thing
      {
        color:#000000;/*#585858 works for bold font*/
        font-size:1.15rem /*28px*/;
        font-weight:500; /* normal - 700 is bold */
        position:absolute;
        padding-left: 10px;
        padding-top: 0px;
        padding-bottom: 0px;
        min-height: 2.67rem /* 64px*/;
        max-height: 3.5rem;
        bottom: 1rem /*24px*/; /* this page needs it at 24px, not 48px */
        width: 18.3rem /*440px*/;
        left:12px;
        line-height:120%;
        vertical-align:bottom;
        text-align:left;
      }
    </style>
  </head>
<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">Make <?php print $Straps; ?> <img src="img/count-notes.svg"></a>
      <div id="entity" class="area"><?php print strtoupper($BuildButton); ?></div>
    </div>
  </nav>

  <div class="container">
    <div class="section" style="margin-top:-20px">
      <div class="row center">
        <img src="<?php if($IsSRB) print "/img/srb-system-count-zeus.png"; else print "/img/zeus.svg"; ?>"
             id="load-zeus"
             width=<?php print round(cached_font_size() * 411 / 24); ?>px
             height=<?php print round(cached_font_size() * 290 / 24); ?>px>
      </div>
    </div>
    <div>
      <div id="zeus-message" class="message-thing">
      </div>
      <div class="next-button">
        <form method="GET">
          <button id=next_strap
                  formaction="/glue/complete-build_tills-straps.php"
                  class="btn waves-effect primary-fill btn-shadow">
            Next <?php print make_singular($Straps); ?>
          </button>
          <button id=finish_straps
                  formaction="/glue/finish-build_tills-straps.php"
                  class="btn waves-effect primary-fill btn-shadow">
            Finish
          </button>
        </form>
      </div>
    </div>
  </div>

  <!--  Scripts-->

<script>
  var code;

  function getZeusStatus()
  {
    var myRequest = new Request("/glue/status-zeus.php");

    fetch(myRequest)
      .then(function(response)
            {
              myRequest = null;

              if (!response.ok)
              {
                console.log("status-zeus", response.status);
              }

              return  response.text();
            })
      .then(function(text)
            {
              var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
              var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
              var the_date = xx.getElementsByTagName("date")[0];
              var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
              var st = xx.getElementsByTagName("status")[0].children;
              var status_code = "";
              var status_text = "";
              var today = "";

              if(the_date && the_date.childNodes.length > 0)
              {
                today = the_date.childNodes[0].nodeValue
              }
              else
              {
                today = "unknown date";
              }

              for (var i1 = 0; i1 < st.length; i1++)
              {
                if(st[i1].nodeName == "code")
                  status_code = st[i1].childNodes[0].nodeValue;
                else if(st[i1].nodeName == "text")
                  status_text = st[i1].childNodes[0].nodeValue;
              }

              // at the first ';' or '.' insert a '<br>'
              status_text = status_text.replace(/;/,";<br>").replace(/\./,".<br>");

              if(status_code != 0)
              {
                if(status_code == "15") // error
                {
                  document.getElementById("zeus-message").style.color="#800000"; // RED
                  document.getElementById("zeus-message").style.backgroundColor="#ffff00"; // YELLOW
                }
                else if(status_code == "6") // insufficient strap qty in stacker
                {
                  document.getElementById("zeus-message").style.color="#802000"; // rededish-brown
                  document.getElementById("zeus-message").style.backgroundColor="#c0ffff"; // light cyan
                }
                else
                {
                  document.getElementById("zeus-message").style.color="#000000"; // black
                  document.getElementById("zeus-message").style.backgroundColor="#ffffff"; // white
                }

                document.getElementById("zeus-message").innerHTML = status_text; // display text
                // TODO:  for error text, do I muck with colors? see adhoc-notes-results.php

                if(status_code == 15 // error
                   || status_code == 8 || status_code == 4) // reject exists, stacker full single
                {
                  document.getElementById("finish_straps").disabled=false;
                }
                else
                {
                  document.getElementById("finish_straps").disabled=true;
                }
              }
              else
              {
                document.getElementById("zeus-message").innerHTML = "";
              }

              xx = null;
              entity = null;
              the_date = null;
              tick = null;
              st = null;
              status_code = null;
              status_text = null;
              today = null;
            })
      .catch(function(error) { console.log(error);  });
  }

  setInterval(getZeusStatus, 500);

</script>
</body>
</html>

