<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $Equipment = coin_counter_equipment(0);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Receive Replacement Coin Recycler</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>

    <script>
      function ClickTest()
      {
          var myRequest = new Request("/glue/recycler-test.php");

          document.getElementById("recycler_test").disabled=true;
          document.getElementById("test_results").innerHTML = "waiting...";

          fetch(myRequest)
            .then(function(response)
                  {
                    if (!response.ok)
                    {
                      console.log("status", response.status);
                    }

                    return  response.text();
                  })
            .then(function(text)
                  {
                    document.getElementById("recycler_test").disabled=false;
                    document.getElementById("test_results").innerHTML = text.substring(0,8);
                  });
      }
    </script>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">
          Replace Coin Recycler
          <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
               src="/img/<?php if(coin_counter_is_recycler_twin($Equipment)) print "twin-recycler-only.png" ; else print "recycler-only.png"; ?>" >
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <table style="width:85%;border:0;line-height:1.1em">
        <tr>
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle">Unpack carton
                  <LI style="list-style-type:circle">Remove Recycler from carton.</LI>
                  <LI style="list-style-type:circle">Make sure it has new power and communications cables, in case you need them.</LI>
                </UL>
              </LI>
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle">Remove old Coin Recycler
                  <LI style="list-style-type:circle">Open the enclosure, power off the Coin Recycler and disconnect the cables.  Set aside.</LI>
                </UL>
              </LI>
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle">Install new Coin Recycler
                  <LI style="list-style-type:circle">Plug power and communicaion cables into the new Coin Recycler, and set in place</LI>
                  <LI style="list-style-type:circle">Energize the new Coin Recycler.  Wait about 15 seconds for it to power up.</LI
                  <LI style="list-style-type:circle">When the motors stop, press&nbsp;&nbsp;
                    <button id=recycler_test type=button onClick="ClickTest();" class="btn btn-small waves-effect primary-fill btn-shadow"
                            style="min-height:1.5rem;height:1.5rem;margin-left:-4px">
                      <span style="vertical-align:middle">TEST</span>
                    </button>&nbsp;&nbsp;
                    <span id=test_results style="font-size:18px"></span></LI>
                  <LI style="list-style-type:circle">If you have any problems, contact customer service immediately.</LI>
                  <LI style="list-style-type:circle">
                    Include the test output and RMA receipt along with the old Coin Recycler.
                    Re-pack them into the shipping carton with unused hardware.
                  </LI>
                </UL>
              </LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">Exit</span>
      </a>
      <a href="/glue/complete-replacement.php?code=600" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/wrench.png" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">DONE</span>
      </a><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

