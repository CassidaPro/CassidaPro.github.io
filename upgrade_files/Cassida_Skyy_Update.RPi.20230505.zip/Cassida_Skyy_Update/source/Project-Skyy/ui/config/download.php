<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/config_utils.php";

  // for people connecting from "not localhost" I just download the file

//  $ip_addr = $_SERVER["REMOTE_ADDR"];
  $ip_addr = empty($_SERVER) || empty($_SERVER["REMOTE_ADDR"])
           ? "" // unlikely, but here anyway
           : $_SERVER["REMOTE_ADDR"];

  if(strlen($ip_addr) > 4 && substr($ip_addr, 0, 4) != "127.")
  {
    header("Content-Type: application/x-unknown");
    header('Content-Disposition: attachment; filename="configuration.conf"');
    header("Content-Location: /config/configuration.conf");

    print shell_exec("cat /var/cache/skyy/configuration.conf");

    exit;
  }

  $parseconf = load_parseconf();

  $Submit=do_getvar("Submit", "");

  $SaveTo = do_getvar("SaveTo", "");

  if(strlen($SaveTo) > 0)
  {
    // for now just make a copy of it
    shell_exec("sudo -u pi /bin/cp -p /var/cache/skyy/configuration.conf '" . $SaveTo . "/configuration.conf'");

?>


<?php
    shell_exec("sync");

    // unmount the drive, now.
    shell_exec("sudo /usr/bin/eject '" . $SaveTo . "'");

//    header("HTTP/1.0 302 Moved Temporarily");
//    header("Location: /config/");
?>
    <HTML>
      <HEAD>
        <TITLE>Backup Configuration Info</TITLE>
        <meta http-equiv="refresh" content="3;url=/config/">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Backup Configuration Info</center></H1>
        <br><br><br>
        <H3><center>Save complete - you may remove the USB Drive</center></H3>
        <br>
      </BODY>
    </HTML>
<?php
    exit;
  }

  // NOTE:  need to run this at least once to stop popup dialog box on inserting a drive
  // (NO) gsettings set org.gnome.desktop.media-handling automount-open false
  //
  // edit /home/pi/.config/pcmanfm/LXDE-pi/pcmanfm.conf change 'autorun=1 to 'autorun=0'

  // step 1:  find out if there are mounted volumes.  if thre aren't, have the user insert a drive
  // and press the button [which will refresh this page]

  $Result = shell_exec("/bin/grep /dev/sd </proc/mounts | awk '{ print " . '$2' . "; }'");

  $aList = explode("\n", ltrim(rtrim($Result)));

  // NOTE:  /proc/mounts can convert chars into 4 char octal sequences, like '\040' for a space
  //        which is necessary to make columns work properly.  So this code will "fix it"
  foreach($aList as $jj => $xx)
  {
    $xxx = $xx;
    $newval = "";
    // look for '\040' and other escapes, convert back to normal ASCII
    while(true)
    {
      $yy = strpos($xxx, "\\");  // is there one?
      if($yy === false)
      {
        $newval = $newval . $xxx;
        break;
      }

//      print "yy=" . $yy . '  xxx="' . $xxx . '"  ' . octdec(substr($xxx,1,4)) . "<br>\n";

      if($yy > 0)
        $newval = $newval . substr($xxx, 0, $yy); // up to but not including the backslash

      $xxx = substr($xxx, $yy, strlen($xxx));

      $newval = $newval . chr(octdec(substr($xxx, 1, 4)));

      $xxx = substr($xxx, 4, strlen($xxx));
    }

    $aList[$jj] = $newval; // replace it
  }


  if(empty($aList) || empty($aList[0]))
  {
?>
    <HTML>
      <HEAD>
        <TITLE>Backup Configuration Info</TITLE>
        <meta http-equiv="refresh" content="2;url=/config/download.php">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Backup Configuration Info</center></H1>
        <br><br><br>
        <H3><center>Insert USB drive for configuration backup</center></H3>
        <br>
        <br>
        <form action="./" method=GET>
          <center>
            <input type=submit value="Cancel" />
          </center>
        </form,>
      </BODY>
    </HTML>
<?php
    exit;
  }
?>

<HTML>
  <HEAD>
    <TITLE>Backup Configuration Info</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </HEAD>
  <BODY>
    <H1><center>Backup Configuration Info</center></H1>
    <H3><center>Indicate which drive to save to</center></H3>
    <br>
    <br>
    <center>
      <table width="50%">
<?php
  foreach($aList as $vv)
  {
    $qq = ltrim(rtrim($vv));
    if(strlen($qq) > 0)
    {
      print "<tr style='font-size:0.9rem;line-height:1.2em;vertical-align:middle'>";
      print "<td width='70%'><span style='text-align:center'>" . $qq . "</span></td><td>&nbsp;</td>";
      print "<td width='30%' style='text-align:center'><form method=GET action='/config/download.php'>";
      print "<input type=hidden name=SaveTo style='visibility:hidden' value='" . $qq . "'>";
      print "<input type=submit value='Save' /></form></td></tr>\n";
    }
  }
?>
      </table>
      <br><br>
      <form action="./" method=GET>
        <center>
          <input type=submit value="Cancel" />
        </center>
      </form,>
    </center>
  </BODY>
</HTML>

