<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $CustomerMod = !empty($parseconf["settings"]) && !empty($parseconf["settings"]["CustomerMod"])
               ? $parseconf["settings"]["CustomerMod"] : "0";

  $Save = do_getvar("Save");

  if($Save == "Y")
  {
    if($CustomerMod == '0')
      shell_exec("cp factory_default_configuration.conf /var/cache/skyy/configuration.conf");
    else
      shell_exec("cp factory_default_configuration." . $CustomerMod . ".conf /var/cache/skyy/configuration.conf");

    skyyreq("factory-reset-additional-things"); // aanything that requires permissions of skyy and future development
    skyyreq("reload");

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /config/initial-setup.php");
    exit;
  }

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Split Recycler System - Factory Reset</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
      }
    </style>
  </HEAD>
  <BODY>
    <form id=none></form>
    <center>
      <b>
        <H1 style="margin:0;padding:0;font-size:32px">Split Recycler - Factory Reset</H1>
        <H4 style="margin:0;padding:0;margin-bottom:16px"><?php print shell_exec( "/usr/bin/curl http://localhost:3042/version" ); ?></H4>
      </b>
    </center>

    <form id=none method="GET"></form>
    <form id=save method="GET">
      <input type=hidden name="Save" value="Y" style="visibility:hidden" />
    </form>
    <br />
    <br />
    <center>
      <table width=80%>
        <tr><td><center>
          Press 'Save' to restore the factory default configuration.<br>
          (You should probably back up your existing<br>
          configuration first, if not already done)<br>
          <br>
          Press 'Back' to cancel the factory reset and leave things as-is.<br>
          <br>
          Once the configuration is reset, you will be sent to 'Initial Setup'.<br>
        </center></td></tr>
      </table>
      <table width="75%" style="position:absolute;left:100px;bottom:0.75rem;">
        <tr>
          <td>
            <center>
              <input type=submit form=none formaction="/system-menu.php" value="Back" style="width:165px" />
            </center>
          </td>
          <td>
            <center>
              <input type=submit form=save formaction="factory-reset.php" value="Save" style="width:165px" />
            </center>
          </td>
        </tr>
      </table>
    </center>
  </BODY>
</HTML>

