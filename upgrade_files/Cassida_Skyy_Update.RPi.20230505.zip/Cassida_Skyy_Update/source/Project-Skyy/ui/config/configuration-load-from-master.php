<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/config_utils.php";

  $parseconf = load_parseconf();

  $StoreID = do_getvar("StoreID", "");
  $doohickey = do_getvar("doohickey", "");


  if($doohickey == "Y" && strlen($StoreID) > 0)
  {

    $xx = shell_exec("curl http://localhost:3042/reload-from-master/" . $StoreID);

//    header("HTTP/1.0 302 Moved Temporarily");
//    header("Location: /config/");
    if(strlen($xx) < 5 || substr($xx,0,2) != "OK")
    {
      if(substr($xx,0,17) == "ERROR (NOT FOUND)")
      {
        // Specific special handling for this, where the store's
        // config was not in the master config file.
?>
        <HTML>
          <HEAD>
            <TITLE>Load Master Configuration</TITLE>
            <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
            <link rel="shortcut icon" href="../img/favicon.ico">
            <style>
<?php
  set_ideal_font_height();
?>
            </style>
          </HEAD>
          <BODY>
            <H1><center>Load Master Configuration</center></H1>
            <form id=do_it method=GET action="/config/initial-setup_reset_quickie.php">
              <input type=hidden id=Quickie name=Quickie style="visibility:none" value="Y" />
              <input type=hidden id=StoreID name=StoreID style="visibility:none" value=<?php print '"' . $StoreID . '"' ?> />
            </form>
            <form id=cancel method=GET action="/config/initial-setup_reset_quickie.php">
            </form>
            <br><br><br>
            <center>
              <H3>No configuration found for StoreID <?php print $StoreID; ?></H3>
              Was this store opened after January of 2022?<br>
              (pressing yes will reset the configuration to factory default<br>
               and automatically begin the initial setup process)
              <table width="60%">
                <tr>
                  <td width=30%><center><input type=submit value="No" form=cancel></center></td>
                  <td width=30%><center><input type=submit value="Yes" form=do_it style></center></td>
                </tr>
              </table>
            </center>
            <br>
          </BODY>
        </HTML>
<?php
      }
      else
      {
        header("HTTP/1.0 500 Server Error");
?>
        <HTML>
          <HEAD>
            <TITLE>Server Error</TITLE>
            <meta http-equiv="refresh" content="10;url=/maintenance.php">
            <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
            <link rel="shortcut icon" href="../img/favicon.ico">
          </HEAD>
          <BODY>
            <H1><center>SERVER ERROR</center></H1>
            <br><br><br>
            <H3>
              <center>unable to perform desired action. RESET in 10 seconds...<br>
                <?php print $xx; ?>
              </center>
            </H3>
            <br>
          </BODY>
        </HTML>
<?php
      }
    }
    else
    {
?>
      <HTML>
        <HEAD>
          <TITLE>Load Master Configuration</TITLE>
          <meta http-equiv="refresh" content="3;url=/maintenance.php">
          <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
          <link rel="shortcut icon" href="../img/favicon.ico">
            <style>
<?php
  set_ideal_font_height();
?>
            </style>
        </HEAD>
        <BODY>
          <H1><center>Load Master Configuration</center></H1>
          <br><br><br><br><br>
          <H3><center>Load complete - StoreID <?php print $StoreID . "\n<br><br>" . $xx; ?></center></H3>
          <br>
          <?php /* print "curl http://localhost:3042/reload-from-master/" . $StoreID; */ ?>
          <br>
        </BODY>
      </HTML>
<?php
    }

    exit;
  }


  if($doohickey == "N" && strlen($StoreID) > 0)
  {
?>
    <HTML>
      <HEAD>
        <TITLE>Load Master Configuration</TITLE>
        <meta http-equiv="refresh"
              content="0.1;url=/config/configuration-load-from-master.php?doohickey=Y&<?php print 'StoreID=' . urlencode($StoreID); ?>">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Load Master Configuration</center></H1>
        <br><br><br>
        <center>
          <H3>Loading master config for StoreID <?php print $StoreID; ?></H3>
          (this will take a short period of time)
        </center>
        <br>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($doohickey != "Y" && strlen($StoreID) > 0)
  {
?>
    <HTML>
      <HEAD>
        <TITLE>Load Master Configuration</TITLE>
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Load Master Configuration</center></H1>
        <form id=do_it method=GET action="/config/configuration-load-from-master.php">
          <input type=hidden id=doohickey name=doohickey style="visibility:none" value="N" />
          <input type=hidden id==StoreID name=StoreID style="visibility:none" value=<?php print '"' . $StoreID . '"'; ?>" />
        </form>
        <form id=cancel method=GET action="/config/configuration-load-from-master.php">
        </form>
        <br><br><br>
        <center>
          <H3>Confirm: load master config for StoreID <?php print $StoreID; ?>?</H3>
          <table width="60%">
            <tr>
              <td width=30%><center><input type=submit value="Cancel" form=cancel></center></td>
              <td width=30%><center><input type=submit value="Load" form=do_it style></center></td>
            </tr>
          </table>
        </center>
        <br>
      </BODY>
    </HTML>
<?php

    exit;
  }



?>
<HTML>
  <HEAD>
    <TITLE>Load Configuration Info</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
      <style>
<?php
  set_ideal_font_height();
?>
      </style>
  </HEAD>
  <BODY>
    <center><H1>Enter Store ID:</H1>

      <input type=numeric form=store_id id=StoreID name=StoreID style="font-size:0.75rem" value="" />
      <!--input type=submit onclick="SelectStoreID();" value="VK" /-->
      <a onClick='SelectStoreID();'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>

      <form id=store_id action="/config/configuration-load-from-master.php" method=GET style='margin:0'>
      </form>
      <form id=cancel action="/maintenance.php" method=GET  style='margin:0'>
      </form>
      <br>
      <br>
      <table width=16.6rem>
        <tr>
          <td width=8.3rem><center><input type=submit form=cancel value="Cancel" /></center></td>
          <td width=8.3rem><center><input type=submit form=store_id value="Load" /></center></td>
        </tr>
      </table>

    <!-- popup keypad -->
      <div id=popup_keypad class="modal-container">
        <div id=kb class="keyboard-container" style="visibility:visible;left:11.67rem;width:10rem">
            <button type=submit class="me-and-my-shadow"
                    onclick=on_vkey_click('1');
                    style="position:absolute;width:1.67rem;height:1.67rem;left:1.25rem;bottom:7.08rem" >
                    1</button>
            <button type=submit class="me-and-my-shadow"
                    onclick=on_vkey_click('2');
                    style="position:absolute;width:1.67rem;height:1.67rem;left:3.33rem;bottom:7.08rem" >
                    2</button>
            <button type=submit class="me-and-my-shadow"
                    onclick=on_vkey_click('3');
                    style="position:absolute;width:1.67rem;height:1.67rem;left:5.41rem;bottom:7.08rem" >
                    3</button>
            <button type=submit class="me-and-my-shadow"
                    onclick=on_bs_click();
                    style="position:absolute;width:1.67rem;height:1.67rem;left:7.5rem;bottom:7.08rem;padding:0" >
                    &lt=</button>

            <button type=submit class="me-and-my-shadow"
                    onclick=on_vkey_click('4');
                    style="position:absolute;width:1.67rem;height:1.67rem;left:1.25rem;bottom:5rem" >
                    4</button>
            <button type=submit class="me-and-my-shadow"
                    onclick=on_vkey_click('5');
                    style="position:absolute;width:1.67rem;height:1.67rem;left:3.33rem;bottom:5rem" >
                    5</button>
            <button type=submit class="me-and-my-shadow"
                    onclick=on_vkey_click('6');
                    style="position:absolute;width:1.67rem;height:1.67rem;left:5.41rem;bottom:5rem" >
                    6</button>

            <button type=submit class="me-and-my-shadow"
                    onclick=on_enter_click();
                    style="position:absolute;width:1.67rem;height:5.8rem;left:7.5rem;bottom:0.82rem;line-heigh:0.9rem" >
                    E<br>n<br>t<br>e<br>r</button>

            <button type=submit class="me-and-my-shadow"
                    onclick=on_vkey_click('7');
                    style="position:absolute;width:1.67rem;height:1.67rem;left:1.25rem;bottom:2.91rem" >
                    7</button>
            <button type=submit class="me-and-my-shadow"
                    onclick=on_vkey_click('8');
                    style="position:absolute;width:1.67rem;height:1.67rem;left:3.33rem;bottom:2.91rem" >
                    8</button>
            <button type=submit class="me-and-my-shadow"
                    onclick=on_vkey_click('9');
                    style="position:absolute;width:1.67rem;height:1.67rem;left:5.41rem;bottom:2.91rem" >
                    9</button>

            <button type=submit class="me-and-my-shadow"
                    onclick=on_vkey_click('0');
                    style="position:absolute;width:5.83rem;height:1.67rem;left:1.25rem;bottom:0.83rem" >
                    0</button>
        </div>
        <div id=numeric_container class="me-and-my-shadow"
           style="position:absolute;left:10.4rem;width:12.5rem;bottom:9.16rem;height:2.25rem;border-radius:20px;background-color:#ffffe0;visibility:hidden">
          <input type=text id=numeric style="position:relative;left:0px;top:0.42rem;min-width:8.33rem;height:1.25rem;" value="" />
        </div>
      </div>
    </center>
  </BODY>

  <SCRIPT>
    function SelectStoreID()
    {
      document.getElementById("numeric_container").style.visibility="visible";
      document.getElementById("popup_keypad").style.visibility="visible";
      document.getElementById("popup_keypad").style.display="block";
    }
    function on_vkey_click(kk)
    {
      document.getElementById("numeric").value = document.getElementById("numeric").value + kk;
    }

    function on_bs_click()
    {
      document.getElementById("numeric").value = "";
    }

    function on_enter_click(kk)
    {
      document.getElementById("StoreID").value = document.getElementById("numeric").value;

      document.getElementById("numeric_container").style.visibility="hidden";
      document.getElementById("popup_keypad").style.visibility="hidden";
      document.getElementById("popup_keypad").style.display="none";

//      document.forms["store_id"].submit();
    }

  </SCRIPT>
</HTML>

