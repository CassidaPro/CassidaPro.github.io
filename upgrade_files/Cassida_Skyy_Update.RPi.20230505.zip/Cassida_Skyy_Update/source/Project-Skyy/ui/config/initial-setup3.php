<?php

  include "../glue/config_utils.php";

  // use sessions for the wizard (always)
  session_start(); // using session control

  $back = do_getvar("back", "");

  $Quickie = do_getvar("Quickie", "N");

  if(strlen($back) > 0) // editing the global file
  {
    if(isset($_SESSION["LocalConfig"]))
      unset($_SESSION["LocalConfig"]);

    $LocalConfig = "";
  }
  else if(isset($_SESSION["LocalConfig"]))
  {
    $LocalConfig = $_SESSION["LocalConfig"];
  }
  else
  {
    $LocalConfig = "";
  }

  // first thing I check for is 'NoScan', and dislay "scanning hardware"
  // and scan things otherwise...

  $set_batch=do_getvar("set_batch", "");

  $NoScan=do_getvar("NoScan", "");

  if($set_batch != "Y") // NOT setting batch
  {
    if($NoScan == "") // not assigned yet
    {
?>
      <HTML><HEAD><TITLE>Scanning Equipment</TITLE>
<?php
      if($Quickie == "Y")
      {
?>
        <meta http-equiv="refresh" content="0.1;url=initial-setup3.php?NoScan=N&Quickie=Y" >
<?php
      }
      else
      {
?>
        <meta http-equiv="refresh" content="0.1;url=initial-setup3.php?NoScan=N" >
<?php
      }
?>
        </HEAD>
        <BODY bgcolor="#e0e0e0" text="#8068ff">
          <br><br><br><br>
          <H1><center>Scanning Installed Equipment</center></H1>
        </BODY>
      </HTML>
<?php
      exit;
    }
    else if($NoScan != "Y") // half way there
    {
      $Solution = skyyreq("equipment-scan");

      if(strlen($Solution) < 3 || substr($Solution,0,2) != "OK") // OK return
      {
?>
      <HTML><HEAD><TITLE>ERROR</TITLE>
        <meta http-equiv="refresh" content="10;url=/system-menu.php" >
        </HEAD>
        <BODY bgcolor="#e0e0e0" text="#8068ff">
          <br><br><br><br>
          <H1><center>ERROR:  Unable to Scan Equipment</center></H1>
          <?php print $Solution; ?>
        </BODY>
      </HTML>
<?php
        exit;
      }

      header("HTTP/1.0 302 Moved Temporarily");
      if($Quickie == "Y")
      {
        header("Location: initial-setup3.php?NoScan=Y&Quickie=Y");
      }
      else
      {
        header("Location: initial-setup3.php?NoScan=Y");
      }

      exit;
    }
  }


  // use skyy to parse the config file
  $parseconf = load_parseconf($LocalConfig);

  $AutoStart = empty($parseconf["settings"]["AutoStart"]) ? "off"
             : ($parseconf["settings"]["AutoStart"] == "1" ? "on" : "off");

  // Payout Batch is the old config term - remove this and make it the text "off" after all units update
  $PayoutBatch = empty($parseconf["settings"]["PayoutBatch"]) ? "off"
               : ($parseconf["settings"]["PayoutBatch"] == "1" ? "on" : "off");

  $PayoutAsync = empty($parseconf["settings"]["PayoutAsync"]) ? $PayoutBatch
               : ($parseconf["settings"]["PayoutAsync"] == "1" ? "on" : "off");

  // NOTE:  installed equipment is in the 'equipment_stats.conf' file
  $parsestats = load_parsestats(); // load that file into '$parsestats' array

//  print_r($parsestats);

  // enumerate the 'equipment' tag for keys, and populate '$NoteCounter' '$CoinCountr' '$Printer'

  $NoteCounter = "";
  $NoteCounterMAC = "";
  $NoteCounterSerial = "";

  $CoinCounter = "";
  $CoinCounterSerial = "";

  $Printer = "";
  $PrinterSerial = "";
  $PrinterInverted = "";

  foreach($parsestats["equipment"] as $kk => $vv)
  {
//    print "kk=" . $kk . ",  vv=" . $vv . "<br>\n";
    if($kk == "Zeus")
    {
      $NoteCounter = $kk;
      $NoteCounterMAC = $vv;
      $NoteCounterSerial = $parsestats[$kk . " " . $vv]["Serial"];
    }
    else if(coin_counter_is_c300($kk) || coin_counter_is_c400($kk) || coin_counter_is_recycler($kk))
    {
      $CoinCounter = $kk;
      $CoinCounterSerial = $vv;
    }
    else if($kk == "Printer")
    {
      $Printer = $parsestats[$kk . " " . $vv]["Model"];
      $PrinterInverted = empty($parsestats[$kk . " " . $vv]["Inverted"]) ? "off"
                       : ($parsestats[$kk . " " . $vv]["Inverted"] == "1" ? "on" : "off");
      $PrinterSerial = $vv;
    }
  }


  $Submit3 = do_getvar("Submit3", "");

  if($Submit3 == "Y")
  {
    $XNoteCounter       = do_getvar("NoteCounter", "");
    $XNoteCounterMAC    = do_getvar("NoteCounterMAC", "");
    $XNoteCounterSerial = do_getvar("NoteCounterSerial", "");

    $XCoinCounter       = do_getvar("CoinCounter", "");
    $XCoinCounterSerial = do_getvar("CoinCounterSerial", "");

    $XPrinter           = do_getvar("Printer", "");
    $XPrinterSerial     = do_getvar("PrinterSerial", "");
    $XPrinterInverted   = do_getvar("PrinterInverted", "off");

    $XAutoStart         = do_getvar("AutoStart", "");
    $XPayoutAsync       = do_getvar("PayoutAsync", "");


    // TODO:  sanitize user input data first?  go back and re-edit?
?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=initial-setup3.php?NoScan=Y&Submit3=YY<?php
            print "&NoteCounter=" . urlencode($XNoteCounter);
            print "&NoteCounterMAC=" . urlencode($XNoteCounterMAC);
            print "&NoteCounterSerial=" . urlencode($XNoteCounterSerial);
            print "&CoinCounter=" . urlencode($XCoinCounter);
            print "&CoinCounterSerial=" . urlencode($XCoinCounterSerial);
            print "&Printer=" . urlencode($XPrinter);
            print "&PrinterSerial=" . urlencode($XPrinterSerial);
            print "&PrinterInverted=" . urlencode($XPrinterInverted);
            print "&AutoStart=" . urlencode($XAutoStart);
            print "&PayoutAsync=" . urlencode($XPayoutAsync);
            print "&Quickie=" . urlencode($Quickie);
            if($set_batch == "Y")
              print "&set_batch=Y";
            ?>" >
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($Submit3 == "YY")
  {
    // the only entries under 'equipment' should match what I have installed

    $XNoteCounter       = do_getvar("NoteCounter", "");
    $XNoteCounterMAC    = do_getvar("NoteCounterMAC", "");
    $XNoteCounterSerial = do_getvar("NoteCounterSerial", "");

    $XCoinCounter       = do_getvar("CoinCounter", "");
    $XCoinCounterSerial = do_getvar("CoinCounterSerial", "");

    $XPrinter           = do_getvar("Printer", "");
    $XPrinterSerial     = do_getvar("PrinterSerial", "");
    $XPrinterInverted   = do_getvar("PrinterInverted", "off");

    $XAutoStart         = do_getvar("AutoStart", "");
    $XPayoutAsync       = do_getvar("PayoutAsync", "");

    $changed = $NoteCounter       !== $XNoteCounter       ||
               $NoteCounterMAC    !== $XNoteCounterMAC    ||
               $NoteCounterSerial !== $XNoteCounterSerial ||
               $CoinCounter       !== $XCoinCounter       ||
               $CoinCounterSerial !== $XCoinCounterSerial ||
               $Printer           !== $XPrinter           ||
               $PrinterInverted   !== $XPrinterInverted   ||
               $PrinterSerial     !== $XPrinterSerial;

    if($changed)
    {
      unset($parsestats["equipment"]["Zeus"]); // = false;
      unset($parsestats["equipment"]["C400"]); // = false;
      unset($parsestats["equipment"]["C400R"]); // = false;
      unset($parsestats["equipment"]["C300"]); // = false;
      unset($parsestats["equipment"]["SmartSystem"]); // = false;
      unset($parsestats["equipment"]["SmartSystem(dual)"]); // = false;
      unset($parsestats["equipment"]["SmartHopper"]); // = false;

      $parsestats["equipment"]["Zeus"] = $XNoteCounterMAC;
      $parsestats["Zeus " . $XNoteCounterMAC]["Serial"] = $XNoteCounterSerial;

      $parsestats["equipment"][$XCoinCounter] = $XCoinCounterSerial;
      // special section to switch betwen C400 and C400R
      if(($XCoinCounter === "C400" && $CoinCounter === "C400R") ||
         ($XCoinCounter === "C400R" && $CoinCounter === "C400"))
      {
        if($parsestats[$CoinCounter . " " . $XCoinCounterSerial] != null)
        {
          $parsestats[$XCoinCounter . " " . $XCoinCounterSerial] = $parsestats[$CoinCounter . " " . $XCoinCounterSerial];
          unset($parsestats[$CoinCounter . " " . $XCoinCounterSerial]);
        }
      }

      $parsestats["equipment"]["Printer"] = $XPrinterSerial;
      $parsestats["Printer " . $XPrinterSerial]["Model"] = $XPrinter;
      $parsestats["Printer " . $XPrinterSerial]["Inverted"] = ($XPrinterInverted == "on") ? "1" : "0";

      write_statistics_file($parsestats, "initial-setup3.php", $LocalConfig);
    }

    // this next section updates the config file with anything that changed there...

    if($AutoStart !== $XAutoStart || $PayoutAsync !== $XPayoutAsync)
    {
      if($XPayoutAsync == "on")
        $parseconf["settings"]["PayoutAsync"] = "1";
      else
        $parseconf["settings"]["PayoutAsync"] = "0";

      unset($parseconf["settings"]["PayoutBatch"]); // clean up old term

      if($XAutoStart == "on")
        $parseconf["settings"]["AutoStart"] = "1";
      else
        $parseconf["settings"]["AutoStart"] = "0";

      write_configuration_file($parseconf, "initial-setup3.php");
    }

    skyyreq("reload"); // must do this

    // flow through to the next page


    header("HTTP/1.0 302 Moved Temporarily");

    if($set_batch == "Y")
    {
      if($XCoinCounter == "C400R")
      {
        skyyreq("batch-quantity/1/50/5/40/10/50/25/40"); // always 50/40/50/40

        if($Quickie == "Y")
          header("Location: /c400-do-set-batch.php?next=" . urlencode("/config/initial-setup3_noscan_q.php?Quickie=Y"));
        else
          header("Location: /c400-do-set-batch.php?next=" . urlencode("/config/initial-setup3_noscan.php"));
      }
      else
      {
        if($Quickie == "Y")
          header("Location: /c400-batch-qty.php?auto=N&back=" . urlencode("/config/initial-setup3_noscan_q.php?Quickie=Y") . "&Quickie=Y");
        else
          header("Location: /c400-batch-qty.php?auto=N&back=" . urlencode("/config/initial-setup3_noscan.php"));
      }
    }
    else if($Quickie == "Y")
    {
      header("Location: initial-setup-Class3.php?Quickie=Y");
    }
    else
    {
      header("Location: initial-setup4.php");
    }

    exit;
  }


?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <!-- these next 3 lines are to stop ridiculous translate popups -->
  <meta charset="UTF-8">
  <meta name="google" content="notranslate">
  <meta http-equiv="Content-Language" content="en">
  <!-- end of hack to prevent translate popup -->
  <HEAD>
    <TITLE>Configuration for Split Recycler System</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }

      .equip_dropdown
      {
        font-size:0.7rem;
        padding-left:4;
        padding-right:4;
        width:94%/*7.5rem*/;
      }
    </style>
    <script>
      function doClickKB(strID)
      {
        do_vkey_single(strID, null);
      }
      function doClickClear(strID)
      {
        var xx = document.getElementById(strID);

        if(xx != null)
        {
          xx.value = "";
          xx.focus();
        }
      }
<?php DoJavaScriptCoinCounterIsRecycler(); ?>
      function doOnChangeCoinCounter()
      {
        var coin = document.getElementById("CoinCounter").value;
        if(coin == "C400" || coin == "C400R" || coin_counter_is_recycler(coin))
          document.getElementById("SetC400Batch").disabled = false;
        else
          document.getElementById("SetC400Batch").disabled = true;

        if(coin_counter_is_recycler(coin))
        {
          document.getElementById("AutoStartText").innerHTML = "Background Coin Count";
          document.getElementById("SetC400Batch").value = "Set Batch Amount";
          document.getElementById("PayoutAsyncContainer").style.display = "block";
          document.getElementById("PayoutAsyncContainer").style.visibility = "visible";
        }
        else
        {
          document.getElementById("AutoStartText").innerHTML = "Auto Start Coin Count";
          document.getElementById("SetC400Batch").value = "Set C400 Batch";
          document.getElementById("PayoutAsyncContainer").style.display = "none"
          document.getElementById("PayoutAsyncContainer").style.visibility = "hidden";
        }
      }
      function doSetC400Batch()
      {
        document.getElementById("set_batch").disabled = false;
        document.getElementById("the_form").action="initial-setup3.php";
        document.getElementById("the_form").submit();
      }
    </script>
  </HEAD>
  <BODY bgcolor="#101824" text="#ffffe0">
    <center>
      <b>
        <H1 style="margin:0;padding:0">Split Recycler - Initial Setup</H1>
        <H4 style="margin:0;margin-bottom:0.83rem !important;padding:0">Equipment Serial Numbers</H4>
      </b>
    </center>
    <form id=none method=GET>
<?php
  if($Quickie == "Y")
  {
?>
      <input type=hidden name="Quickie" value="Y" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <form id=noscan method=GET action="initial-setup3.php">
<?php
  if($Quickie == "Y")
  {
?>
      <input type=hidden name="Quickie" value="Y" style="visibility:hidden" />
<?php
  }
?>
      <input type=hidden name="NoScan" value="Y" style="visibility:hidden" />
    </form>
    <form id=the_form method=GET action="javascript:" >
<?php
  if($Quickie == "Y")
  {
?>
      <input type=hidden name="Quickie" value="Y" style="visibility:hidden" />
<?php
  }
?>
      <input type=hidden name="NoScan" value="Y" style="visibility:hidden" />
      <input type=hidden name="Submit3" value="Y" style="visibility:hidden" />
      <input type=hidden name="NoteCounterMAC" value="<?php print $NoteCounterMAC; ?>" style="visibility:hidden" />
      <input type=hidden id=set_batch name=set_batch value="Y" style="visibility:hidden" disabled />
      <center>
        <table border=1 width="95%">
          <thead><th>Equipment</th><th>Serial Number</th><th>MAC Address</th></thead>
          <tr>
            <td width="38%">
              <table width="100%">
                <tr>
                  <td width="26%">
                    Notes:&nbsp;
                  </td>
                  <td>
                    <select name=NoteCounter class=equip_dropdown>
                      <option value="" <?php if($NoteCounter == "") print "selected" . ' thingy="' . $NoteCounter . '"'; ?> >
                        {none}
                      </option>
                      <option value="Zeus" <?php if($NoteCounter == "Zeus") print "selected" . ' thingy="' . $NoteCounter . '"'; ?> >
                        Zeus
                      </option>
                    </select>
                  </td>
                </tr>
              </table>
            </td>
            <td width="38%" style="font-size:0.8rem;margin-right:10px">
              <div style="text-align:center">
                <input type=text size=20 id=NoteCounterSerial name=NoteCounterSerial style="width:7.2rem;"
                       value=<?php print '"' . sanitize_for_html($NoteCounterSerial) . '"'; ?> />
                <a onClick='doClickKB("NoteCounterSerial");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
                <a onClick='doClickClear("NoteCounterSerial");'><img src="../img/clear.svg" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
              </div>
            </td>
            <td width="25%">
              <div style="font-size:0.8rem;text-align:center;margin:0;padding:0;vertical-align:middle">
                <?php print $NoteCounterMAC; ?>
              </div>
            </td>
          </tr>

          <tr>
            <td>
              <table width="100%">
                <tr>
                  <td width="26%">
                    Coins:&nbsp;
                  </td>
                  <td>
                    <select id=CoinCounter name=CoinCounter onChange="doOnChangeCoinCounter();" class=equip_dropdown>
                      <option value="" <?php if($CoinCounter == "") print "selected" . ' thingy="' . $CoinCounter . '"'; ?> >
                        {none}
                      </option>
                      <option value="C400" <?php if($CoinCounter == "C400") print "selected" . ' thingy="' . $CoinCounter . '"'; ?> >
                        C400
                      </option>
                      <option value="C400R" <?php if($CoinCounter == "C400R") print "selected" . ' thingy="' . $CoinCounter . '"'; ?> >
                        C400 (rolls)
                      </option>
                      <option value="C300" <?php if($CoinCounter == "C300") print "selected" . ' thingy="' . $CoinCounter . '"'; ?> >
                        C300
                      </option>
                      <!--option value="SmartHopper" <?php if($CoinCounter == "SmartHopper") print "selected" . ' thingy="' . $CoinCounter . '"'; ?> >
                        SmartHopper
                      </option-->
                      <!--option value="SmartSystem" <?php if($CoinCounter == "SmartSystem") print "selected" . ' thingy="' . $CoinCounter . '"'; ?> >
                        Smart System
                      </option-->
                      <option value="SmartSystem(dual)" <?php if($CoinCounter == "SmartSystem(dual)") print "selected" . ' thingy="' . $CoinCounter . '"'; ?> >
                        Twin SmartSystem
                      </option>
                    </select>
                  </td>
                </tr>
              </table>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <div style="text-align:center">
                <input type=text size=20 id=CoinCounterSerial name=CoinCounterSerial style="width:7.2rem;"
                       value=<?php print '"' . sanitize_for_html($CoinCounterSerial) . '"'; ?> />
                <a onClick='doClickKB("CoinCounterSerial");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
                <a onClick='doClickClear("CoinCounterSerial");'><img src="../img/clear.svg" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
              </div>
            </td>
            <td>
              &nbsp;
            </td>
          </tr>

          <tr>
            <td>
              <table width="100%">
                <tr>
                  <td width="26%">
                    Printer:&nbsp;
                  </td>
                  <td>
                    <select name=Printer class=equip_dropdown>
                      <option value="" <?php if($Printer == "") print "selected" . ' thingy="' . $Printer . '"'; ?> >
                        {none}
                      </option>
                      <option value="Q300" <?php if($Printer == "Q300") print "selected" . ' thingy="' . $Printer . '"'; ?> >
                        Q300 (Bixolon)
                      </option>
                      <option value="Bixolon" <?php if($Printer == "Bixolon") print "selected" . ' thingy="' . $Printer . '"'; ?> >
                        Bixolon
                      </option>
                    </select>
                  </td>
                </tr>
              </table>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <div style="text-align:center">
                <input type=text size=20 id=PrinterSerial name=PrinterSerial style="width:7.2rem;"
                       value=<?php print '"' . sanitize_for_html($PrinterSerial) . '"'; ?> />
                <a onClick='doClickKB("PrinterSerial");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
                <a onClick='doClickClear("PrinterSerial");'><img src="../img/clear.svg" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
              </div>
            </td>
            <td>
              &nbsp;
            </td>
          </tr>
        </table>
        <input id=FakeSubmit type=submit actin="" style="visibility:hidden;font-size:1px;height:2px" /><br style="font-size:1px;height:2px">
        <input id=AutoStart name=AutoStart type=checkbox <?php if($AutoStart == "on") print "checked"; ?> >
          <span id=AutoStartText>
<?php
  if(coin_counter_is_recycler($CoinCounter))
  {
?>
            Background Coin Count
<?php
  }
  else
  {
?>
            Auto Start Coin Count
<?php
  }
?>
          </span>
        </input>&nbsp;&nbsp;&nbsp;&nbsp;
        <input id=PrinterInverted name=PrinterInverted type=checkbox <?php if($PrinterInverted == "on") print "checked"; ?> >
          <span id=PrinterInvertedText>
            Invert Printout
          </span>
        </input>
        <div id=PayoutAsyncContainer
<?php
  if(coin_counter_is_recycler($CoinCounter))
  {
?>
             style="margin:0;padding:0;border:0;visibility:visible;display:block"
<?php
  }
  else
  {
?>
             style="margin:0;padding:0;border:0;visibility:hidden;display:none"
<?php
  }
?>
        >
          <input id=PayoutAsync name=PayoutAsync type=checkbox <?php if($PayoutAsync == "on") print "checked"; ?> style="visibility:inherit;display:inline">
            <span>
              Asynchronous Payout
            </span>
        </input>
        </div>
      </center>
    </form>
    <center>
      <input id=SetC400Batch onclick="doSetC400Batch();" type=submit
             value=
<?php
  if(!coin_counter_is_c400($CoinCounter) && !coin_counter_is_recycler($CoinCounter))
  {
    print '"Set C400 Batch" disabled';
  }
  else if(coin_counter_is_c400($CoinCounter))
  {
    print '"Set C400 Batch"';
  }
  else // if(coin_counter_is_recycler($CoinCounter))
  {
    print '"Set Batch Amount"';
  }
?>
       />
    </center>

<?php
  if($Quickie == "Y")
  {
?>
    <input type=submit form=none formaction="initial-setup.php" value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem"/>
<?php
  }
  else
  {
?>
    <input type=submit form=none formaction="initial-setup2.php" value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem"/>
<?php
  }
?>
    <input type=submit form=none
           formaction="initial-setup3.php"
           value="Re-Scan" style="position:absolute;bottom:0.75rem;width:5rem;left:10.4rem"/>
    <input type=submit form=noscan
           formaction="initial-setup3.php"
           value="Re-load" style="position:absolute;bottom:0.75rem;width:5rem;right:10.4rem"/>
    <!-- calls DoNext() on click -->
    <input type=submit id=Next
           value="Next" style="position:absolute;bottom:0.75rem;width:3.33rem;right:3.33rem"/>

<?php

  include "../glue/virtual_keyboard.php";

?>

    <SCRIPT>
      function DoNext()
      {
        document.getElementById("the_form").action="initial-setup3.php";
        document.getElementById("the_form").submit();
      }

      function DoFakeSubmit()
      {
        var the_focus = document.activeElement;
        if(the_focus === document.getElementById("NoteCounterSerial"))
          document.getElementById("CoinCounterSerial").focus();
        if(the_focus === document.getElementById("CoinCounterSerial"))
          document.getElementById("PrinterSerial").focus();
//        if(the_focus === document.getElementById("PrinterSerial"))
//          document.getElementById("NoteCounterSerial").focus();
      }

      document.getElementById("Next").addEventListener('click', DoNext);
      document.getElementById("FakeSubmit").addEventListener('click', DoFakeSubmit);

    </SCRIPT>
  </BODY>
</HTML>

