<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $Equipment = coin_counter_equipment();

  $Origin = do_getvar("origin", "");

  if(strlen($Origin) > 0 && substr($Origin,0,1) != "/")
    $Origin = "/" . $Origin;

  if(!coin_counter_is_recycler($Equipment))
  {
?>
      <HTML>
        <HEAD>
          <TITLE>re-direct</TITLE>
          <meta http-equiv="refresh" content="15;url=/maintenance.php">
<?php set_inbetween_style(); ?>
        </HEAD>
        <BODY>
          <br>
          <center>
            <H1>
              Internal Error
            </H1>
            <br>
            <br>
            <span style="font-size:1.7rem">
              This page only tests a coin recycler
            </span>
          </center>
        </BODY>
      </HTML>
<?php
    exit;
  }


  $check_recycler_coin_tray = 1; // set to 1 to enable, 0 to disable check

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Empty Recycler</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">
          Empty <?php print $Equipment; ?>
          <img width=42 height=42 src="/img/<?php if(coin_counter_is_recycler_twin($Equipment)) print "twin-recycler-only.png" ; else print "recycler-only.png"; ?>">
        </a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <form id=main method="GET" action="/glue/initiate-adhoc-coins.php">
      <input type=hidden name=clear_first value="D" style="visibility:none">
    </form>
    <center>
      <table style="width:85%;border:0">
        <tr>
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle;margin:15 0 0 0px">Recycler Empty
                  <LI style="list-style-type:circle;margin:15 0 0 0px">To empty all coins from the recycler, ensure the Coin<br>
                  <!--LI style="list-style-type:circle;margin:15 0 0 0px"-->Tray is in the correct position, and press&nbsp;&nbsp;
                    <button id=recycler_empty type=submit form="main" class="btn btn-small waves-effect primary-fill btn-shadow"
<?php
  if($check_recycler_coin_tray != 0)
  {
?>
                            disabled
<?php
  }
?>
                            style="margin:-4px;margin-top:0;">
                      <span style="vertical-align:middle">Empty</span>
                    </button><br>
                    <span id=test_results style="font-size:18px">&nbsp;</span></LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">If you have any problems, contact customer service immediately.</LI>
                </UL>
              </LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
<?php
  if(strlen($Origin) > 0)
  {
?>
      <a href="<?php print $Origin; ?>" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">Back</span>
      </a>
<?php
  }
  else
  {
?>
      <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">Exit</span>
      </a>
<?php
  }
?>
      <br/>
    </div>

    <!-- coin tray warning -->
    <div id=coin_tray_warning class="medium-modal me-and-my-shadow"
         style="visibility:hidden;display:none;position:absolute;left:35%;width:30%;top:45%;height:20%;z-order:99">
      <center>
        <span id=alert_title style="font-size:0.91rem;line-height:0.91rem;margin:0;padding:0;visibility:inherit">
          Coin Tray
        </span>
      </center>
      <div id=coin_tray_warning_text style="position:relative;font-size:0.75rem;line-height:0.83rem;top:4px;height:4.16rem;text-align:center;margin:0;padding:0;visibility:inherit">
        Please move Coin Tray<br>to the TRAY position
      </div>
      <!--img height=<?php print round(cached_font_size() * 3); ?>px
           src="img/coin_drawer_rotate_ccw.png"
           style="visibility:inherit;position:absolute;left:10rem;top:3.3rem" /-->
    </div>


    <!--  Scripts-->

    <script>
<?php
  if($check_recycler_coin_tray != 0)
  {
?>
      function DoCheckDrawerState()
      {
        var myRequest = new Request("/glue/status_recycler_drawer.php");

        fetch(myRequest)
          .then(function(response)
                {
                  myRequest = null;

                  if(!response.ok)
                  {
                    console.log("status_recycler_drawer", response.status); // debug only (TODO: remove?)
                  }

                  return  response.text();
                })
          .then(function(text)
                {
//                  console.log("drawer state: " + text);

                  if(text.length > 0 &&
                     (text.substr(0,1) === '*' || Math.floor(text) == 0))
                  {
                    // correct position - 1 for rolls, 0 for coin tray (anything else is non-valid)

                    document.getElementById("coin_tray_warning").style.display = "none";
                    document.getElementById("coin_tray_warning").style.visibility = "hidden";

                    document.getElementById("recycler_empty").disabled = false;
                  }
                  else
                  {
                    // TODOL pop up an alert box to re-position the drawer?

                    document.getElementById("coin_tray_warning").style.display = "block";
                    document.getElementById("coin_tray_warning").style.visibility = "visible";

                    document.getElementById("recycler_empty").disabled = true;

                    setTimeout(DoCheckDrawerState, 250);
                  }
                });
      }

      /////////////////////////////////////////////////////////////////////////////////////////////////////////
      //                                                                                                     //
      //   ____                                               _     _                       _            _   //
      //  |  _ \   ___    ___  _   _  _ __ ___    ___  _ __  | |_  | |     ___    __ _   __| |  ___   __| |  //
      //  | | | | / _ \  / __|| | | || '_ ` _ \  / _ \| '_ \ | __| | |    / _ \  / _` | / _` | / _ \ / _` |  //
      //  | |_| || (_) || (__ | |_| || | | | | ||  __/| | | || |_  | |___| (_) || (_| || (_| ||  __/| (_| |  //
      //  |____/  \___/  \___| \__,_||_| |_| |_| \___||_| |_| \__| |_____|\___/  \__,_| \__,_| \___| \__,_|  //
      //                                                                                                     //
      //                                                                                                     //
      /////////////////////////////////////////////////////////////////////////////////////////////////////////

      function DocReadyCallback()
      {
        setTimeout(DoCheckDrawerState, 500);
      }

      // this solution was found online, to help get rid of JQuery
      if(document.readyState === "complete" ||
         (document.readyState !== "loading" && !document.documentElement.doScroll))
      {
        // if I'm done loading, or I'm still loading but I won't be scrolling,
        // it's "safe" to call the 'on doc ready' callback

        DocReadyCallback();
      }
      else
      {
        document.addEventListener("DOMContentLoaded", DocReadyCallback); // set up an event listener, fire when ready
      }
<?php
  }
?>
    </script>

  </body>
</html>

