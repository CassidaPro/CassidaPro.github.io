<?php
/*          Copyright 2019-2020 by Cassida          */
/* Use only in accordance with the supplied license */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');

  $VerifyDeposit = do_getconf($parseconf,"terms","VerifyButton", "VERIFY DEPOSIT");

  $Equipment = coin_counter_equipment();
  $IsSRB = coin_counter_is_recycler($Equipment);

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Verify Deposit</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
     <!-- CSS  -->


    <style>
<?php
  set_ideal_font_height();
?>
      .message-thing
      {
        color:#000000;/*#585858 works for bold font*/
        font-size:1.15rem /*28px*/;
        font-weight:500; /* normal - 700 is bold */
        position:absolute;
        padding-left: 10px;
        padding-top: 0px;
        padding-bottom: 0px;
        min-height: 2.67rem /* 64px*/;
        max-height: 3.5rem;
        bottom: 1rem /*24px*/; /* this page needs it at 24px, not 48px */
        width: 18.3rem /*440px*/;
        left:12px;
        line-height:120%;
        vertical-align:bottom;
        text-align:left;
      }
    </style>
  </head>
<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar"><?php print make_proper($VerifyDeposit); ?><img src="img/count-notes.svg"></a>
      <div id="entity" class="area">VERIFY</div>
    </div>
  </nav>

  <div class="container">
    <div class="section">
      <div class="row center">
        <img src="<?php if($IsSRB) print "/img/srb-system-count-zeus.png"; else print "/img/zeus.svg"; ?>"
             id="load-zeus"
             width=<?php print round(cached_font_size() * 440 / 24); ?>px
             height=<?php print round(cached_font_size() * 325 / 24); ?>px>
      </div>
    </div>
    <div>
      <div id="zeus-message" class="message-thing">
      </div>
      <div class="next-button">
        <form>
          <button formaction="/glue/complete-verify_deposit.php" class="waves-effect btn-flat primary-text">Skip</button>
        </form>
      </div>
    </div>
  </div>

  <script>
    var intervalID;

    function getZeusStatus()
    {
      var myRequest = new Request("/glue/status-zeus.php");

      fetch(myRequest)
        .then(function(response)
              {
                myRequest = null;

                if (!response.ok)
                {
                  console.log("status-zeus", response.status);
                }

                return  response.text();
              })
        .then(function(text)
              {
                var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
                var the_date = xx.getElementsByTagName("date")[0];
                var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
                var st = xx.getElementsByTagName("status")[0].children;
                var status_code = "";
                var status_text = "";
                var today = "";

                if(the_date && the_date.childNodes.length > 0)
                {
                  today = the_date.childNodes[0].nodeValue
                }
                else
                {
                  today = "unknown date";
                }

                for (var i1 = 0; i1 < st.length; i1++)
                {
                  if(st[i1].nodeName == "code")
                    status_code = st[i1].childNodes[0].nodeValue;
                  else if(st[i1].nodeName == "text")
                    status_text = st[i1].childNodes[0].nodeValue;
                }

                // at the first ';' or '.' insert a '<br>'
                status_text = status_text.replace(/;/,";<br>").replace(/\./,".<br>");

                if(status_code=="1")
                {
                  clearInterval(intervalID);

                  window.location.href = 'verify_deposit-notes-results.php'; // open up results page
                }
                else if(status_code != 0)
                {
                  if(status_code != 8)
                    console.log(status_code);
                  document.getElementById("zeus-message").innerHTML = status_text; // display text
                  // TODO:  for error text, do I muck with colors? see adhoc-notes-results.html
                }
                else
                {
                  document.getElementById("zeus-message").innerHTML = "";
                }

                xx = null;
                entity = null;
                the_date = null;
                tick = null;
                st = null;
                status_code = null;
                status_text = null;
                today = null;
              })
        .catch(function(error) { console.log(error);  });
    }

    intervalID = setInterval(getZeusStatus, 250);

  </script>
</body>
</html>

