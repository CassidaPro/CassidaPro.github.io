<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $Equipment = coin_counter_equipment(0);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Test C400</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>

  <script>
    var the_thing = null;
    var text_to_display = "";


    function ClickStir()
    {
      var myRequest = new Request("/glue/initiate-stir-recycler.php"); // done this way to avoid XSS warnings, etc.

      document.getElementById("recycler_stir").disabled=true;
      document.getElementById("message_thing").innerHTML = "waiting...";

      fetch(myRequest)
        .then(function(response)
              {
                if (!response.ok)
                {
                  console.log("status", response.status);
                  return "<b>*FAILED*</b> - " + response.status.toString();
                }

                return  response.text();
              })
        .then(function(text)
              {
                var txt2;

                clearInterval(the_thing);
                the_thing = null;

                the_thing = setInterval(GetRecyclerStatus, 200);

//                document.getElementById("recycler_stir").disabled=false;
                document.getElementById("message_thing").innerHTML = text;
              });
    }

    function GetRecyclerStatus()
    {
      var myRequest = new Request("/glue/status-c400.php"); // done this way to avoid XSS warnings, etc.

      fetch(myRequest)
        .then(function(response)
              {
                if(!response.ok)
                {
                  console.log("status", response.status);
                }

                return  response.text();
              })
        .then(function(text)
              {
                  // xx will be a DOM Parser type of object from which to parse XML
                  var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                  var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
                  var the_date = xx.getElementsByTagName("date")[0];
                  var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
                  var st = xx.getElementsByTagName("status")[0].children;
                  var status_code = "";
                  var status_text = "";
                  var today = "";

                  if(the_date && the_date.childNodes.length > 0)
                  {
                    today = the_date.childNodes[0].nodeValue
                  }
                  else
                  {
                    today = "unknown date";
                  }

                  for (var i1 = 0; i1 < st.length; i1++)
                  {
                    if(st[i1].nodeName == "code")
                      status_code = st[i1].childNodes[0].nodeValue;
                    else if(st[i1].nodeName == "text")
                      status_text = st[i1].childNodes[0].nodeValue;
                  }

                  if(status_code == 0 || status_code == 31) // "I am done" flag or error
                  {
                    if(status_code == 31)
                      document.getElementById("message_thing").innerHTML = status_text;
                    else
                      document.getElementById("message_thing").innerHTML = "OK";

                    clearInterval(the_thing);
                    document.getElementById("recycler_stir").disabled=false;
                  }
                  else
                  {
                    document.getElementById("message_thing").innerHTML = /*status_code.toString() + " " +*/ status_text;
                  }

              });
    }

  </script>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">
          JAM - Recycler
          <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
               src="/img/<?php if(coin_counter_is_recycler_twin($Equipment)) print "twin-recycler-only.png" ; else print "recycler-only.png"; ?>" >
        </a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <form id=blank></form>
    <center>
      <table style="width:85%;border:0">
        <tr>
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle;margin:15 0 0 0px">Clearing JAM from the Coin Recycler
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Check that the Recycler Coin Tray and Funnel are empty.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Open the system enclosure and power off the Coin Recycler.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Unlatch the Coin Feeder and tilt back.  Check for stuck coins.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">If a JAM condition exists in the Coin Feeder, press&nbsp;&nbsp;
                    <button id=feeder_jam type=submit form="blank" formaction="/maintenance-clear-jam-feeder-recycler.php"
                            class="btn btn-small waves-effect primary-fill btn-shadow"
                            style="margin:-4px;margin-bottom:4px">
                      <span style="vertical-align:middle">FEEDER JAM</span>
                    </button>
                  </LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">To check for a JAM condition in either Hopper, press&nbsp;
                    <button id=hopper_jam type=submit form="blank" formaction="/maintenance-clear-jam-hopper-recycler.php"
                            class="btn btn-small waves-effect primary-fill btn-shadow"
                            style="margin:-4px;margin-bottom:0">
                      <span style="vertical-align:middle">HOPPER JAM</span>
                    </button>
                  </LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Shut the inlet assembly.  Make sure everything is snug</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Power the Coin Recycler back on again, and shut the system enclosure</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">When the Recycler motors stop, press&nbsp;&nbsp;
                    <button id=recycler_stir type=button onClick="ClickStir();" class="btn btn-small waves-effect primary-fill btn-shadow"
                            style="margin:-4px">
                      <span style="vertical-align:middle">STIR</span>
                    </button>
                  </LI>
                  <span id=message_thing style="font-size:0.75rem">&nbsp;</span>
                </UL>
              </LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">If you have any problems, contact customer service immediately.</LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>
    <form id=set_batch method=GET action="/c400-do-set-batch.php"><input type=hidden name=next value="/maintenance-c400-received.php" /></form>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">Exit</span>
      </a>
      <br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

