<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $Equipment = coin_counter_equipment();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Test C400</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>

    <script>
      var the_thing = null;
      var text_to_display = "";


      function ClickTest()
      {
        var myRequest = new Request("/glue/c400-test-all.php"); // done this way to avoid XSS warnings, etc.

        document.getElementById("c400_test").disabled=true;
        document.getElementById("test_results").innerHTML = "waiting...";

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("status", response.status);
                    return "<b>*FAILED*</b> - " + response.status.toString();
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                  var txt2;

                  clearInterval(the_thing);
                  the_thing = null;

                  the_thing = setInterval(GetC400Status, 200);

//                  document.getElementById("c400_test").disabled=false;
                  document.getElementById("test_results").innerHTML = text;
                });
      }

      function GetC400Status()
      {
        var myRequest = new Request("/glue/status-c400.php"); // done this way to avoid XSS warnings, etc.

        fetch(myRequest)
          .then(function(response)
                {
                  if(!response.ok)
                  {
                    console.log("status", response.status);
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                    // xx will be a DOM Parser type of object from which to parse XML
                    var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                    var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
                    var the_date = xx.getElementsByTagName("date")[0];
                    var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
                    var st = xx.getElementsByTagName("status")[0].children;
                    var status_code = "";
                    var status_text = "";
                    var today = "";

                    if(the_date && the_date.childNodes.length > 0)
                    {
                      today = the_date.childNodes[0].nodeValue
                    }
                    else
                    {
                      today = "unknown date";
                    }

                    for (var i1 = 0; i1 < st.length; i1++)
                    {
                      if(st[i1].nodeName == "code")
                        status_code = st[i1].childNodes[0].nodeValue;
                      else if(st[i1].nodeName == "text")
                        status_text = st[i1].childNodes[0].nodeValue;
                    }

                    if(status_code == 0 || status_code == 31) // "I am done" flag or error
                    {
                      if(status_code == 31)
                        document.getElementById("test_results").innerHTML = status_text;
                      else
                        document.getElementById("test_results").innerHTML = "OK";

                      clearInterval(the_thing);
                      document.getElementById("c400_test").disabled=false;
                    }
                    else
                    {
                      document.getElementById("test_results").innerHTML = /*status_code.toString() + " " +*/ status_text;
                    }

                });
      }

    </script>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Test C400
          <img width=42 height=42 src="/img/<?php if(coin_counter_is_c400r($Equipment)) print 'c400r'; else print 'c400'; ?>-only.png">
        </a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <table style="width:85%;border:0">
        <tr>
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle;margin:15 0 0 0px">Make sure C400 is plugged in, all cables snug, power on
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Wait about 15 seconds for C400 to power up.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">When the C400 display indicates 'Ready', press&nbsp;&nbsp;
                    <button id=c400_test type=button onClick="ClickTest();" class="btn btn-small waves-effect primary-fill btn-shadow"
                            style="margin:-4px">
                      <span style="vertical-align:middle">TEST</span>
                    </button></LI><br>
                    <span id=test_results style="font-size:18px">&nbsp;</span>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">If you have any problems, contact customer service immediately.</LI>
                </UL>
              </LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>
    <form id=set_batch method=GET action="/c400-do-set-batch.php"><input type=hidden name=next value="/maintenance-c400-received.php" /></form>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">Exit</span>
      </a>
      <br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

