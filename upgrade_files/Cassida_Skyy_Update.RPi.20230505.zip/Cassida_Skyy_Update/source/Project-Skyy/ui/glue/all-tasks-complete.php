<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  // with all tasks complete comes the totals receipt print
  // this could be re-printed if you don't do any more counting
  // including ad hoc counts and straps...

// print totals has been moved to 'complete-all-registers.php'
//  skyyreq("print-totals");

  include "common_utils.php";

  $parseconf = load_parseconf();
  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  $doohicky = do_getvar("doohicky", ""); //empty($_GET) ? "" : empty($_GET["doohicky"]) ? "" : $_GET["doohicky"];

  if($doohicky == "")
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="0.5;url=/glue/all-tasks-complete.php?doohicky=Y">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br><br><br>
      <center>
        <H1>Reset Counters</H1>
      </center>
    </BODY></HTML>
<?php
    exit;
  }

  // added 9/16/2020 - let system know that 'all tasks' are complete
  skyyreq("complete-all-tasks");

  // clear the zeus - also takes it out of PC mode
  skyyreq("clear-zeus");

  // 'last clean date' on zeus
  $thingy = skyyreq("last-clean-date");

  eval($thingy);

  $days_eom_plus14 = $days_since_month_end + 14;


  if($days_since_clean > $days_eom_plus14 || // more than 2 weeks prior to end of month
     $days_since_clean > 45 ||               // more than 45 days total
     ($CustomerMod == 1 && $days_since_clean >= 7))    // always weekly reminder for CustomerMod == 1
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="30;url=/">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br><br><br>
      <center><table width=600><tr align=center><td>
        <H1>Cleaning Reminder</H1>
        <H3>It has been <u><b><?php print $days_since_clean; ?></b></u>
            days since you have performed a cleaning<br>
            process. Please review the cleaning requirements from the main page.
        </H3>
        <form method="GET" action="/">
          <button type=submit style="height:32px;width:72px;font-size:18px">&nbsp;&nbsp;OK&nbsp;&nbsp;</button></form>
      </td></tr></table></center>
    </BODY></HTML>
<?php
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /");
  }
?>

