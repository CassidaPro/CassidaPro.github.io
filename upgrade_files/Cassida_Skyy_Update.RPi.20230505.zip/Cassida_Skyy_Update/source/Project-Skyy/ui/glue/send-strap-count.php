<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php"; // things common to all

  if ($_SERVER['REQUEST_METHOD'] == 'POST')
  {
    $next = do_postvar("next", "");

    $c1 = do_postvar("c1", "0");
    $c5 = do_postvar("c5", "0");
    $c10 = do_postvar("c10", "0");
    $c25 = do_postvar("c25", "0"); // yes it's $c25

//    extract($_POST, EXTR_OVERWRITE);

    if($next == '')
    {
      header("HTTP/1.0 500 Server Error");
//      print_r $_POST;
    }
    else
    {
      header("HTTP/1.0 302 Moved Temporarily");
      header("Location: " . $next);
      header("Expires: 0");
      //header("Location: /counter.html");

      skyyreq("strap-quantity/1/" . $c1);
      skyyreq("strap-quantity/5/" . $c5);
      skyyreq("strap-quantity/10/" . $c10);
      skyyreq("strap-quantity/20/" . $c25); // yes it's $c25
    }
  }
  else
  {
      header("HTTP/1.0 500 Server Error");
  }
?>

