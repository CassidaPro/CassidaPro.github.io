<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $Equipment = coin_counter_equipment();

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/plain");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems

  if($Equipment == "C300")
    print skyyreq("continue-c300" );
  else if(coin_counter_is_recycler($Equipment))
  {
//    skyyreq("continue-recycler");
  }
  else
    print skyyreq("continue-c400" );


?>

