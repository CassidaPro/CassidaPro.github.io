<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

//  include 'common_utils.php';
//
//  // parse config file for things I need
//  $parseconf = load_parseconf();

  // TODO:  any settings affecting this?

  function px_to_rem($px)
  {
    return $px / 24; // TODO: round-off?
  }

  function do_row($bottom, $left, $keys)
  {
    $pos = $left;

    for($ii=0; $ii < strlen($keys); $ii++)
    {
      $xx = substr($keys, $ii, 1);
      if($xx == "'")
        $xxx = '"' . $xx . '"';
      else if($xx == ">")
        $xxx = "'&gt;'";
      else if($xx == "<")
        $xxx = "'&lt;'";
      else if($xx == "\\")
        $xxx = "'\\\\'";
      else
        $xxx = "'" . $xx . "'";
?>
        <button type=submit class="me-and-my-shadow"
                onclick=on_vkey_click(<?php print $xxx; ?>);
                style="position:absolute;width:1.67rem;height:1.67rem;left:<?php print px_to_rem($pos); ?>rem;bottom:<?php print px_to_rem($bottom); ?>rem" >
                <?php print $xx; ?></button>
<?php
      $pos += 50;
    }
  }

  function do_kb_type($keys, $shift=false)
  {
    do_row(180, 40, $keys[0]);
?>
        <button type=submit class="me-and-my-shadow"
                onclick='on_back_click();'
                style="position:absolute;width:2.5rem;left:28.75rem;bottom:7.5rem" >
                &lt;==</button>

        <button type=submit class="me-and-my-shadow"
                onclick='on_vkey_click("\x09");'
                style="position:absolute;width:2.5rem;left:1.67rem;bottom:5.83rem" >
                Tab</button>
<?php
    do_row(140, 110, $keys[1]);
?>
        <button type=submit class="me-and-my-shadow"
                onclick='on_capslock_click();'
                style="position:absolute;width:3.33rem;left:1.67rem;bottom:4.16rem" >
                Caps</button>
<?php
    do_row(100, 130, $keys[2]);
?>
        <button type=submit class="me-and-my-shadow"
                onclick='on_enter_click();'
                style="position:absolute;width:2.91rem;left:28.33rem;bottom:4.16rem" >
                <?php if($shift) print "Line"; else print "Enter"; ?></button>

        <button type=submit class="me-and-my-shadow"
                onclick='on_shift_click();'
                style="position:absolute;width:4.16rem;left:1.67rem;bottom:2.5rem" >
                Shift</button>
<?php
    do_row(60, 150, $keys[3]);
?>
        <button type=submit class="me-and-my-shadow"
                onclick='on_shift_click();'
                style="position:absolute;width:4.16rem;left:27.08rem;bottom:2.5rem" >
                Shift</button>


        <button type=submit class="me-and-my-shadow"
                onclick='on_esc_click();'
                style="position:absolute;width:2.08rem;left:1.67rem;bottom:0.833rem" >
                Esc</button>

        <button type=submit class="me-and-my-shadow"
                onclick='on_home_click();'
                style="position:absolute;width:2.91rem;left:4.16rem;bottom:0.833rem" >
                Home</button>

        <button type=submit class="me-and-my-shadow"
                onclick='on_end_click();'
                style="position:absolute;width:2.08rem;left:7.5rem;bottom:0.833rem" >
                End</button>

        <button type=submit class="me-and-my-shadow"
                onclick='on_vkey_click(" ");'
                style="position:absolute;width:12.08rem;left:10.41rem;bottom:0.833rem" >
                Space</button>

        <button type=submit class="me-and-my-shadow"
                onclick='on_left_click();'
                style="position:absolute;width:2.08rem;left:23.33rem;bottom:0.833rem" >
                &lt;&lt</button>

        <button type=submit class="me-and-my-shadow"
                onclick='on_del_click();'
                style="position:absolute;width:2.08rem;left:26.25rem;bottom:0.833rem" >
                Del</button>

        <button type=submit class="me-and-my-shadow"
                onclick='on_right_click();'
                style="position:absolute;width:2.08rem;left:29.16rem;bottom:0.833rem" >
                &gt;&gt</button>
<?php
  }

  $keys=[];
  $shiftkeys=[];
  $capskeys=[];

  $keys[0]="`1234567890-="; // right backspace
  $capskeys[0]=$keys[0];
  $shiftkeys[0]='~!@#$%^&*()_+';

  $keys[1]="qwertyuiop[]\\";  // left tab
  $shiftkeys[1]="QWERTYUIOP{}|";
  $capskeys[1]="QWERTYUIOP[]\\";

  $keys[2]="asdfghjkl;'"; // caps lock left, enter right
  $shiftkeys[2]='ASDFGHJKL:"';
  $capskeys[2]="ASDFGHJKL;'";

  $keys[3]="zxcvbnm,./";
  $shiftkeys[3]="ZXCVBNM<>?";
  $capskeys[3]="ZXCVBNM,./"; // shift left, shift right


?>
<!-- virtual keyboard - include this at the bottom of the HTML/BODY section -->
<!-- this requires the 'system.css' style sheet -->

    <script>
      var nMode = 0; // 0=normal, 1=caps, 2=shift
      var strTBox = "single_line"; // single_line, numeric, multi_line
      var fnSetTextCallback = null;
      var strControl = "";

      function do_vkey_single(strCtrl, fnCallback)
      {
        strControl = strCtrl;
        strTBox = "single_line";
        fnSetTextCallback=fnCallback;

        if(strControl.length > 0)
        {
          var ctrl=document.getElementById(strControl);

          if(ctrl.disabled)
            return; // do nothing if control is disabled

          document.getElementById("single_line").value = ctrl.value;
        }
        else
          document.getElementById("single_line").value = "";

        document.getElementById("single_line_container").style.visibility="visible";
        document.getElementById("multi_line_container").style.visibility="hidden";
        document.getElementById("numeric_container").style.visibility="hidden";

        document.getElementById("popup_keypad").style.visibility="hidden";
        document.getElementById("popup_keypad").style.display="none";
        document.getElementById("popup_keyboard").style.visibility="visible";
        document.getElementById("popup_keyboard").style.display="block";

        nMode = 0;
        switch_mode();
      }

      function do_vkey_numeric(strCtrl, fnCallback)
      {
        strControl = strCtrl;
        strTBox = "numeric";
        fnSetTextCallback=fnCallback;

        if(strControl.length > 0)
        {
          var ctrl=document.getElementById(strControl);

          if(ctrl.disabled)
            return; // do nothing if control is disabled

          document.getElementById("numeric").value = ctrl.value;
        }
        else
          document.getElementById("numeric").value = "";

        document.getElementById("single_line_container").style.visibility="hidden";
        document.getElementById("multi_line_container").style.visibility="hidden";
        document.getElementById("numeric_container").style.visibility="visible";

        document.getElementById("popup_keyboard").style.visibility="hidden";
        document.getElementById("popup_keyboard").style.display="none";
        document.getElementById("popup_keypad").style.visibility="visible";
        document.getElementById("popup_keypad").style.display="block";

        nMode = 0;
        switch_mode();
      }

      function do_vkey_multi(strCtrl, fnCallback)
      {
        strControl = strCtrl;
        strTBox = "multi_line";
        fnSetTextCallback=fnCallback;

        if(strControl.length > 0)
        {
          var ctrl=document.getElementById(strControl);

          if(ctrl.disabled)
            return; // do nothing if control is disabled

          document.getElementById("multi_line").innerHTML = ctrl.value;
        }
        else
          document.getElementById("multi_line").innerHTML = "";

        document.getElementById("single_line_container").style.visibility="hidden";
        document.getElementById("multi_line_container").style.visibility="visible";
        document.getElementById("numeric_container").style.visibility="hidden";

        document.getElementById("popup_keypad").style.visibility="hidden";
        document.getElementById("popup_keypad").style.display="none";
        document.getElementById("popup_keyboard").style.visibility="visible";
        document.getElementById("popup_keyboard").style.display="block";

        nMode = 0;
        switch_mode();
      }

      function on_esc_click()
      {
        document.getElementById("single_line_container").style.visibility="hidden";
        document.getElementById("multi_line_container").style.visibility="hidden";
        document.getElementById("numeric_container").style.visibility="hidden";

        document.getElementById("no_shift").style.visibility="hidden";
        document.getElementById("caps").style.visibility="hidden";
        document.getElementById("shift").style.visibility="hidden";

        document.getElementById("popup_keyboard").style.visibility="hidden";
        document.getElementById("popup_keyboard").style.display="none";
        document.getElementById("popup_keypad").style.visibility="hidden";
        document.getElementById("popup_keypad").style.display="none";

        if(strControl.length > 0)
          document.getElementById(strControl).focus();
      }

      function switch_mode()
      {
        if(nMode == 1)
        {
          document.getElementById("no_shift").style.visibility="hidden";
          document.getElementById("caps").style.visibility="visible";
          document.getElementById("shift").style.visibility="hidden";
        }
        else if(nMode == 2)
        {
          document.getElementById("no_shift").style.visibility="hidden";
          document.getElementById("caps").style.visibility="hidden";
          document.getElementById("shift").style.visibility="visible";
        }
        else
        {
          document.getElementById("no_shift").style.visibility="visible";
          document.getElementById("caps").style.visibility="hidden";
          document.getElementById("shift").style.visibility="hidden";
        }
      }

      function get_the_edit_text()
      {
        if(strTBox == "multi_line")
        {
          return document.getElementById(strTBox).innerHTML;
        }
        else
        {
          return document.getElementById(strTBox).value;
        }
      }

      function do_set_edit_text(strText)
      {
        if(strTBox == "multi_line")
        {
          document.getElementById(strTBox).innerHTML = strText;
        }
        else
        {
          document.getElementById(strTBox).value = strText;
        }
      }

      function do_set_cursor(iNewSel)
      {
        document.getElementById(strTBox).focus(); // this only works when I set focus first
        document.getElementById(strTBox).setSelectionRange(iNewSel, iNewSel);
      }

      function on_vkey_click(ch)
      {
        var strText, iNewSel=0;

        if(strTBox == "numeric")
        {
          if((ch < '0' || ch > '9') /*&& ch != '-' && ch != '.'*/)
          {
            return; // do not allow
          }
        }

        strText = get_the_edit_text();

        iNewSel = document.getElementById(strTBox).selectionStart;

        if(document.getElementById(strTBox).selectionStart != document.getElementById(strTBox).selectionEnd)
        {
          console.log("They Differ: " + iNewSel + ", " + document.getElementById(strTBox).selectionEnd);
          strText = strText.substr(0, iNewSel)
                  + ch
                  + strText.substr(document.getElementById(strTBox).selectionEnd, strText.length);
        }
        else
        {
          strText = strText.substr(0, iNewSel)
                  + ch
                  + strText.substr(iNewSel, strText.length);
        }

        iNewSel++;

        do_set_edit_text(strText);

        do_set_cursor(iNewSel);
      }

      function on_enter_click()
      {
        var strText;

        if(strTBox == "multi_line")
        {
          if(nMode == 2) // shift
          {
            on_vkey_click("\n");
            return;
          }

          strText = document.getElementById(strTBox).innerHTML;
        }
        else
        {
          strText = document.getElementById(strTBox).value;
        }

        if(fnSetTextCallback)
        {
          fnSetTextCallback(strControl, strText);
        }
        else if(strControl.length > 0)
        {
          if(strTBox == "multi_line")
          {
            document.getElementById(strControl).innerHTML = strText;
          }
          else
          {
            document.getElementById(strControl).value = strText;
          }
        }

        document.getElementById("single_line_container").style.visibility="hidden";
        document.getElementById("multi_line_container").style.visibility="hidden";
        document.getElementById("numeric_container").style.visibility="hidden";

        document.getElementById("no_shift").style.visibility="hidden";
        document.getElementById("caps").style.visibility="hidden";
        document.getElementById("shift").style.visibility="hidden";

        document.getElementById("popup_keyboard").style.visibility="hidden";
        document.getElementById("popup_keyboard").style.display="none";
        document.getElementById("popup_keypad").style.visibility="hidden";
        document.getElementById("popup_keypad").style.display="none";

        if(strControl.length > 0)
        {
          try
          {
            // make sure the function exists before I try to call it
            if(document.getElementById(strControl).onchange)
              document.getElementById(strControl).onchange();
          }
          finally {}

          document.getElementById(strControl).focus();
        }
      }

      function on_back_click()
      {
        var strText = get_the_edit_text();
        var iSel = document.getElementById(strTBox).selectionStart;

        if(strText.length > 0)
        {
          if(document.getElementById(strTBox).selectionEnd == iSel)
          {
            if(iSel >= strText.length)
            {
              iSel = strText.length - 1;
              strText = strText.substr(0,iSel);
            }
            else if(iSel > 0)
            {
              if(iSel > 1)
                strText = strText.substr(0, iSel - 1)
                        + strText.substr(iSel, strText.length);
              else
                strText = strText.substr(iSel, strText.length);

              iSel--;
            }
            else
            {
              return; // do nothing
            }
          }
          else
          {
            strText = strText.substr(0, iSel)
                    + strText.substr(document.getElementById(strTBox).selectionEnd, strText.length);
          }

          do_set_edit_text(strText);
          do_set_cursor(iSel);
        }
      }
      function on_del_click()
      {
        var strText = get_the_edit_text();
        var iSel = document.getElementById(strTBox).selectionStart;

        if(strText.length > 0)
        {
          if(document.getElementById(strTBox).selectionEnd == iSel)
          {
            if(iSel < strText.length)
            {
              if(iSel < strText.length - 1)
                strText = strText.substr(0, iSel)
                        + strText.substr(iSel + 1, strText.length);
              else
                strText = strText.substr(0,iSel);
            }
            else if(iSel > strText.length) // unlikely
            {
              iSel = strText.length;
            }
            else
            {
              return; // do nothing
            }
          }
          else
          {
            strText = strText.substr(0, iSel)
                    + strText.substr(document.getElementById(strTBox).selectionEnd, strText.length);
          }

          do_set_edit_text(strText);
          do_set_cursor(iSel);
        }
      }
      function on_home_click()
      {
        do_set_cursor(0);
      }
      function on_end_click()
      {
        var strText = get_the_edit_text();
        do_set_cursor(strText.length);
      }
      function on_left_click()
      {
        var iSel = document.getElementById(strTBox).selectionStart;

        if(iSel > 0)
          do_set_cursor(iSel - 1);
      }
      function on_right_click()
      {
        var strText = get_the_edit_text();
        var iSel = document.getElementById(strTBox).selectionStart;

        if(iSel < strText.length)
          do_set_cursor(iSel + 1);
      }
      function on_shift_click()
      {
        if(nMode != 2)
          nMode = 2;
        else
          nMode = 0;

        switch_mode();
      }
      function on_capslock_click()
      {
        if(nMode != 1)
          nMode = 1;
        else
          nMode = 0;

        switch_mode();
      }
    </script>

    <!-- popup keyboard dialog -->
    <div id=popup_keyboard class="modal-container">
      <div id=no_shift class="keyboard-container" style="visibility:visible">
<?php
  do_kb_type($keys);
?>
      </div>
      <div id=shift class="keyboard-container" style="visibility:hidden">
<?php
  do_kb_type($shiftkeys, true);
?>
      </div>
      <div id=caps class="keyboard-container" style="visibility:hidden">
<?php
  do_kb_type($capskeys);
?>
      </div>

      <div id=single_line_container class="me-and-my-shadow"
         style="position:absolute;left:4.16rem;width:25rem;bottom:9.16rem;height:2.25rem;border-radius:0.833rem;background-color:#ffffe0;visibility:hidden">
        <input type=text id=single_line style="position:relative;left:2.08rem;top:0.416rem;min-width:20.83rem;height:1.25rem;"/>
      </div>
      <!--div id=numeric_container class="me-and-my-shadow"
         style="position:absolute;left:10.41rem;width:12.5rem;bottom:9.16rem;height:2.25rem;border-radius:0.833rem;background-color:#ffffe0;visibility:hidden">
        <input type=text id=numeric style="position:relative;left:2.08rem;top:0.416rem;min-width:8.33rem;height:1.25rem;"/>
      </div-->
      <div id=multi_line_container class="me-and-my-shadow"
         style="position:absolute;left:4.16rem;width:25rem;bottom:9.16rem;height:6.5rem;border-radius:0.833rem;background-color:#ffffe0;visibility:hidden">
        <textarea type=text id=multi_line style="position:relative;left:2.08rem;top:0.416rem;min-width:20.83rem;height:5.41rem;">
        </textarea>
      </div>
    </div>

    <!-- popup keypad dialog -->
    <div id=popup_keypad class="modal-container">
      <div id=kb class="keyboard-container" style="visibility:visible;left:11.67rem;width:10rem">
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('1');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:1.25rem;bottom:7.08rem" >
                  1</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('2');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:3.33rem;bottom:7.08rem" >
                  2</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('3');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:5.41rem;bottom:7.08rem" >
                  3</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_back_click();
                  style="position:absolute;width:1.67rem;height:1.67rem;left:7.5rem;bottom:7.08rem;padding:0" >
                  <div style="font-height:0.5rem !important;line-height:0.583rem;text-align:center;margin:0;padding:0">&lt=</div></button>

          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('4');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:1.25rem;bottom:5rem" >
                  4</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('5');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:3.33rem;bottom:5rem" >
                  5</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('6');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:5.41rem;bottom:5rem" >
                  6</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_esc_click();
                  style="position:absolute;width:1.67rem;height:1.67rem;left:7.5rem;bottom:5rem;padding:0" >
                  <div style="font-height:0.4rem !important;line-height:0.5rem;text-align:center;margin:0;padding:0">Esc</div></button>

          <button type=submit class="me-and-my-shadow"
                  onclick=on_enter_click();
                  style="position:absolute;width:1.67rem;height:3.75rem;left:7.5rem;bottom:0.833rem" >
                  <div style="font-height:0.583rem;line-height:0.583rem;text-align:center;margin:0;padding:0">E<br>n<br>t<br>e<br>r</div></button>

          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('7');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:1.25rem;bottom:2.91rem" >
                  7</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('8');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:3.33rem;bottom:2.91rem" >
                  8</button>
          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('9');
                  style="position:absolute;width:1.67rem;height:1.67rem;left:5.41rem;bottom:2.91rem" >
                  9</button>

          <button type=submit class="me-and-my-shadow"
                  onclick=on_vkey_click('0');
                  style="position:absolute;width:5.83rem;height:1.67rem;left:1.25rem;bottom:0.833rem" >
                  0</button>
      </div>
      <div id=numeric_container class="me-and-my-shadow"
         style="position:absolute;left:11.67rem;width:10rem;bottom:9.16rem;height:2.25rem;border-radius:0.833rem;background-color:#ffffe0;visibility:hidden">
        <input type=text id=numeric style="position:relative;left:0.833rem;top:0.333rem;min-width:8.33rem;width:8.33rem;height:1.25rem;" value="" />
      </div>
    </div>

