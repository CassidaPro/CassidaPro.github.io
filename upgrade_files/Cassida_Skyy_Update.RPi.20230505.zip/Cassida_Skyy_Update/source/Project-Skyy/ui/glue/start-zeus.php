<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $Origin = empty($_GET) || empty($_GET["origin"]) ? "" : "?origin=" . urlencode($_GET["origin"]);

  header("HTTP/1.0 302 Moved Temporarily");
  header("Location: /count-notes.php" . $Origin);

  skyyreq("count-zeus");
?>
