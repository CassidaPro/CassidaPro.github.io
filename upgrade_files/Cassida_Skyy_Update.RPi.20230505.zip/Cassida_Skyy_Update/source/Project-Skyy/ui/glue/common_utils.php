<?php
/*            Copyright 2020 by Cassida             */
/* Use only in accordance with the supplied license */

  // set screen res as a cookie

  function getcookie($crunch)
  {
    if(empty($_COOKIE) || empty($_COOKIE[$crunch]))
      return "";

    return $_COOKIE[$crunch];
  }

  $profile_load_time = "";

  function profile_load_time($szMarker = "")
  {
    global $profile_load_time;

    $date = new DateTime();

    if(!strlen($profile_load_time))
    {
      $profile_load_time = $date->getTimestamp();
      print "<!-- timestamp " . $szMarker . "  " . $date->getTimestamp() . " -->\n";
    }
    else
    {
      print "<!-- timestamp " . $szMarker . "  " . ($date->getTimestamp() - $profile_load_time) . " -->\n";
    }

    $date = null;
  }

  function setup_screen_res()
  {
    if(empty($_COOKIE) || empty($_COOKIE["screen_res"]) ||
       (!empty($_GET) && !empty($_GET["screen_res"]) && $_GET["screen_res"] === "x"))
    {
      setcookie("screen_res","x", 0);

      $url=$_SERVER["REQUEST_URI"];

      $url = str_replace("?screen_res=x&","&",$url);
      $url = str_replace("?screen_res=x","",$url);
      $url = str_replace("&screen_res=x","",$url);

      header("HTTP/1.0 302 Moved Temporarily");
      header("Location: " . $url); // back to self (does this work with 'post' ?)
      exit; // forces page to flush and re-load
    }
    else if($_COOKIE["screen_res"] === "x") // get size of viewport and record it
    {
      if(empty($_GET) || empty($_GET["screen_res"]))
      {
        $url=$_SERVER["REQUEST_URI"];

        $url = str_replace("?screen_res=x&","&",$url);
        $url = str_replace("?screen_res=x","",$url);
        $url = str_replace("&screen_res=x","",$url);

        if(!empty($_GET) && !empty($_GET["screen_res"]))
        {
          $_GET["screen_res"] = null;
        }

        if(empty($_GET))
        {
          if(substr($url,strlen($url)-1,1) == '?')
            $url = $url . "screen_res=";
          else
            $url = $url . "?screen_res=";
        }
        else
          $url = $url . "&screen_res=";
?>
      <HTML>
        <BODY bgcolor="#fefefe">
          <center id="thingy">
            <H2></H2>
            <br><br>
            <H1>You need to enable scripting</H1>
            <H2>Enahle javascript and refresh</H2>
          </center>
          <SCRIPT>
            document.getElementById("thingy").innerHTML = "";
            location.href = '<?php print $url; ?>'
                          + window.innerWidth + "x" + window.innerHeight;
          </SCRIPT>
        </BODY>
      </HTML>
<?php
        exit;
      }
      else // must do one more time to get cookie to stick but without screen_res param
      {
        setcookie("screen_res",$_GET["screen_res"], 0);

        $url=$_SERVER["REQUEST_URI"];

        $url = str_replace("?screen_res=" . $_GET["screen_res"] . "&","&",$url);
        $url = str_replace("?screen_res=" . $_GET["screen_res"],"",$url);
        $url = str_replace("&screen_res=" . $_GET["screen_res"],"",$url);

        header("HTTP/1.0 302 Moved Temporarily");
        header("Location: " . $url); // back to self (does this work with 'post' ?)
        exit; // forces page to flush and re-load
      }
    }

    return getcookie("screen_res");
  }

  function cached_screen_width()
  {
    $crunch = getcookie("screen_res");
    if(empty($crunch) || !strlen($crunch))
      return 800;

    $aa = explode("x", $crunch);
    return $aa[0];
  }

  function cached_screen_height()
  {
    $crunch = getcookie("screen_res");
    if(empty($crunch) || !strlen($crunch) || strstr($crunch, "x") === false)
      return 600;

    $aa = explode("x", $crunch);
    return $aa[1];
  }

  function cached_font_size()
  {
    $ww = cached_screen_width();
    $hh = cached_screen_height();

    $ff = $hh * 24 / 480;
    $f2 = $ww * 24 / 800; // normalized to height pixels for 24 px font on 800x480 screen

    if($f2 < $ff)
      $ff = $f2;

    return round($ff);
  }

  // call this within the style section at the top
  function set_ideal_font_height()
  {
    skyyreq("nothing");  // kick the screensaver watchdog timer
?>
      html
      {
        font-size:<?php print cached_font_size(); ?>px !important; /* <?php $crunch = getcookie("screen_res"); if(!empty($crunch)) print $crunch; ?> */
      }
<?php
  }

  function set_inbetween_style() // this is for in-between screens, grey background, bluish-purple text
  {
    skyyreq("nothing");  // kick the screensaver watchdog timer
?>
    <style>
      html
      {
        font-size:<?php print round(cached_font_size() * 0.5); ?>px !important;
      }
      body
      {
        font-size: inherit;
        background-color: #e0e0e0;
        color: #8068ff;
      }
    </style>
<?php
  }

  function skyyreq($req)
  {
    $rval = shell_exec( "/usr/bin/curl http://localhost:3042/" . $req );

    return $rval;
  }

  function do_getvar($vname, $default="")
  {
    if(empty($_GET))
      return $default;

    if(!isset($_GET[$vname])) // use this, allows for blanks and 0
      return $default;

    return $_GET[$vname];
  }

  function do_postvar($vname, $default="")
  {
    if(empty($_POST))
      return $default;

    if(!isset($_POST[$vname])) // use this, allows for blanks and 0
      return $default;

    return $_POST[$vname];
  }


  function load_parseconf($LocalConfig = "")
  {
    // allow for a different file name to be specified.  The default is blank
    // which picks the system config file.  Anything else with a path in it fails.

    if(strlen($LocalConfig) > 0)
    {
      if($LocalConfig == "*")
      {
        $LocalConfig = "";
      }
      else if(strpos($LocalConfig, "/") !== false ||
              strpos($LocalConfig, "*") !== false ||
              strpos($LocalConfig, "\\") !== false ||
              strpos($LocalConfig, "?") !== false ||
              strpos($LocalConfig, "[") !== false ||
              strpos($LocalConfig, "]") !== false ||
              strpos($LocalConfig, "{") !== false ||
              strpos($LocalConfig, "}") !== false ||
              strpos($LocalConfig, "(") !== false ||
              strpos($LocalConfig, ")") !== false ||
              strpos($LocalConfig, "..") !== false)
      {
        header("HTTP/1.0 500 Server Error");
?>
        <HTML>
          <HEAD><TITLE>ERROR</TITLE>
            <meta http-equiv="refresh" content="30;url=<?php print $current_page; ?>" >
<?php set_inbetween_style(); ?>
          </HEAD>
          <BODY>
            <br><br><br><br>
            <center>
              <H1>Load Configuration Info</H1><br>
              <H1><b>ERROR:  Unable to load configuration info!</b></H1>
              <H3>Problem with configuration file name<br>
                  <?php print $LocalConfig; ?></H3>
            </center>
          </BODY>
        </HTML>
<?php
        exit;
      }

      $LocalConfig = "/var/tmp/" . $LocalConfig;
    }

    return do_load_parseconf($LocalConfig);
  }

  function do_load_parseconf($LocalConfig)
  {
    // for now use skyy to safely parse the file
    $Solution = shell_exec("/home/pi/bin/skyy -C" . rtrim($LocalConfig));

    $Status = "NO SERVER";
    $parseconf = ""; // to handle errors when server not running

    if(strlen(ltrim(rtrim($Solution))) > 0)
      eval($Solution);
    else
      $Solution = "";

    if($Status != 'OK')
    {
      header("HTTP/1.0 500 Server Error");

      if($Solution != "" && !strlen($LocalConfig))
      {
        print "Solution:<br>\r\n";
        print_r($Solution);
        print "<br><br>parsecon:<br>\r\n";
        print_r($parseconf);
        print "<br><br>\r\n";
      }
      else
      {
?>
        <HTML>
          <HEAD><TITLE>ERROR</TITLE>
            <meta http-equiv="refresh" content="30;url=<?php print $current_page; ?>" >
<?php set_inbetween_style(); ?>
          </HEAD>
          <BODY>
            <br><br><br><br>
            <center>
              <H1><b>ERROR:  Unable to load configuration info!</b></H1>
              <H3>Problem reading configuration file<br>
                  <?php print $LocalConfig; ?>
              </H3>
              <H3>
                If this problem persists, you should power-cycle the system
              </H3>
              <br>
<?php
        print "Status = " . $Status . "<br>\n";
        print_r($Solution);
        print "<br>\n";
        print_r($parseconf);
        print "<br>\n";
?>
            </center>
          </BODY>
        </HTML>
<?php
      }

      exit;
    }

    return $parseconf;
  }

  function load_parsestats()
  {
    return do_load_parseconf("/var/cache/skyy/equipment_stats.conf");
//    return parse_ini_file("/var/cache/skyy/equipment_stats.conf",
//                          TRUE, // to process sections
//                          INI_SCANNER_NORMAL); // process values normally
  }

  function do_getconf($parseconf, $section, $key, $default)
  {
    if($section === "")
    {
      if(empty($parseconf) || empty($parseconf[$key]))
        return $default;

      return $parseconf[$key];
    }

    if(empty($parseconf))
      return $default;

    if(!isset($parseconf[$section]) || !isset($parseconf[$section][$key]))
      return $default; // this allows for blanks and 0

    return $parseconf[$section][$key];
  }


  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////
  //                                                                                                           //
  //   _____  ___   ____       _           _    _                   _    _              _    _                 //
  //  |  ___|/ _ \ | __ )     / \   _   _ | |_ | |__    ___  _ __  | |_ (_)  ___  __ _ | |_ (_)  ___   _ __    //
  //  | |_  | | | ||  _ \    / _ \ | | | || __|| '_ \  / _ \| '_ \ | __|| | / __|/ _` || __|| | / _ \ | '_ \   //
  //  |  _| | |_| || |_) |  / ___ \| |_| || |_ | | | ||  __/| | | || |_ | || (__| (_| || |_ | || (_) || | | |  //
  //  |_|    \___/ |____/  /_/   \_\\__,_| \__||_| |_| \___||_| |_| \__||_| \___|\__,_| \__||_| \___/ |_| |_|  //
  //                                                                                                           //
  //                                                                                                           //
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

  // check if authenticated; also resets the timeout
  // returns 'OK' if authenticated, or error string
  function is_authenticated($user = false)
  {
    if($user)
      $auth = ltrim(rtrim(skyyreq("authenticated-user")));
    else
      $auth = ltrim(rtrim(skyyreq("authenticated")));

    return $auth; // 'OK' or an error string
  }

  // perform authentication, displays consistent error message if failed
  // returns 'OK' if authenticated, or error string
  // re-directs to specified URL on auth failure (caller should 'exit')
  // Function serializes authentication process, does not return until
  // success or failure.  Timeout is 15 seconds (from 'skyy')
  // caller should use 'authenticate_prompt' to generate a prompt screen
  // then re-direct to a page that calls this function.  If this function
  // does not return 'OK' then caller should 'exit'
  function do_authenticate($refresh_url, $user = false)
  {
    if($user)
      $auth = ltrim(rtrim(skyyreq("fobkey-auth-user")));
    else
      $auth = ltrim(rtrim(skyyreq("fobkey-auth")));

    if($auth != "OK")
    {
?>
      <HTML>
        <HEAD>
          <TITLE>re-direct</TITLE>
          <meta http-equiv="refresh" content="5;url=<?php print $refresh_url; ?>">
<?php set_inbetween_style(); ?>
        </HEAD>
        <BODY>
          <center>
            <br><br>
            <H1>Authentication FAILED</H1>
            <H2>(Return code:  <?php print $auth; ?>)</H2>
          </center>
        </BODY>
      </HTML>
<?php
    }

    return $auth;
  }

  // Provide a consistent prompt for authentication, then immediately
  // re-directs to the specified URL.  This function will exit
  // and NOT return.  (Authentication typically times out after 15 seconds)
  // The re-direct URL is expected to call 'do_authenticate()'
  function authenticate_prompt($refresh_url, $user=false)
  {
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
        <meta http-equiv="refresh" content="0.5;url=<?php print $refresh_url; ?>">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <center>
          <br><br>
          <H1>Please Authenticate</H1>
          <H2>Place <?php if($user) print "User"; else print "Admin"; ?> FOB key on reader</H2>
        </center>
      </BODY>
    </HTML>
<?php
    exit;
  }


  //   ____        _           ____                      _
  //  / ___| ___  (_) _ __    / ___| ___   _   _  _ __  | |_  ___  _ __
  // | |    / _ \ | || '_ \  | |    / _ \ | | | || '_ \ | __|/ _ \| '__|
  // | |___| (_) || || | | | | |___| (_) || |_| || | | || |_|  __/| |
  //  \____|\___/ |_||_| |_|  \____|\___/  \__,_||_| |_| \__|\___||_|
  //

  function coin_counter_is_c400($Equipment)
  {
    return $Equipment == "C400"
           || $Equipment == "C400R";
  }

  function coin_counter_is_c400r($Equipment)
  {
    return $Equipment == "C400R";
  }

  function coin_counter_is_c300($Equipment)
  {
    return $Equipment == "C300"
           || $Equipment == "C300B";
  }

  function coin_counter_is_recycler($Equipment)
  {
    return $Equipment == "SmartSystem"
           || $Equipment == "SmartSystem(dual)";
  }

  function coin_counter_is_recycler_twin($Equipment)
  {
    return $Equipment == "SmartSystem(dual)";
  }

  function DoJavaScriptCoinCounterIsRecycler() /* inject javascript function into the HTML code */
  {
    print "function coin_counter_is_recycler(cc)\r\n";
    print "{\r\n";
    print "  return cc == 'SmartSystem' || cc == 'SmartSystem(dual)' || cc == 'SmartHopper';\r\n";
    print "}\r\n";
  }

  // this returns an array, 'coins' being total # coins and 'volume' being
  // the relative volume percentage * 10 (scale 0-1000) where 1000 is 100%
  // For counters that are NOT recyclers, it returns zero as 'volume'
  function coin_count_and_relative_volume($bSnapshot = false)
  {
    $count1c = '0';
    $count5c = '0';
    $count10c = '0';
    $count25c = '0';
    $count100c = '0';

    $Equipment = ltrim(rtrim(skyyreq("coin-counter-equipment")));

    $can_roll = false;

    if($bSnapshot)
    {
      if($Equipment == "C300")
        $Solution = skyyreq("snapshot-c300");
      else if(coin_counter_is_recycler($Equipment))
        $Solution = skyyreq("snapshot-recycler");
      else
        $Solution = skyyreq("snapshot-c400");
    }
    else
    {
      if($Equipment == "C300")
        $Solution = skyyreq("result-c300");
      else if(coin_counter_is_recycler($Equipment))
        $Solution = skyyreq("result-recycler");
      else
        $Solution = skyyreq("result-c400");
    }

    eval($Solution);

    if(coin_counter_is_recycler($Equipment))
    {
      $pennies_batch = '0';
      $nickels_batch = '0';
      $dimes_batch = '0';
      $quarters_batch = '0';
      $dollars_batch = '0';

      $Solution = skyyreq("batch-quantity");
      eval($Solution); // note var names match coin counting, below

      $count1b = $pennies_batch;     // store batch qty in different vars - easier to edit below
      $count5b = $nickels_batch;
      $count10b = $dimes_batch;
      $count25b = $quarters_batch;
      $count100b = $dollars_batch;

      // TODO: use reserve quantity rather than 150% of batch amount

      if(($count1b > 0   && $count1c   >= $count1b * 1.5)  ||
         ($count5b > 0   && $count5c   >= $count5b * 1.5)  ||
         ($count10b > 0  && $count10c  >= $count10b * 1.5) ||
         ($count25b > 0  && $count25c  >= $count25b * 1.5) ||
         ($count100b > 0 && $count100c >= $count100b * 1.5))
      {
        $can_roll = true;
      }

      // aproximately (by volume)
      //   0.5 pennies per dime
      //   0.8 nickels per penny
      //   0.7 quarters per nickel
      //   1.1 dollars per quarter
//
//      $vol = 1.1 * intval($count100c)             // dollar coins to quarters
//           + 1.0 * intval($count25c)              // quarters
//           + 0.5 * 0.8 * 0.7 * intval($count10c)  // dimes to pennies to nickels to quarters
//           + 0.7 * intval($count5c)               // nickels to quarters
//           + 0.8 * 0.7 * intval($count1c);        // pennies to nickels to quarters
//
//      if($Equipment == "SmartSystem")
//      {
//        $vol = $vol * 1000
//             / 1600;       // estimated capacity of recycler, in quarters-equivalent
//      }
//      else if($Equipment == "SmartSystem(dual)")  // has two hoppers
//      {
//        $vol = $vol * 1000
//             / 3200;       // estimated capacity of recycler, in quarters-equivalent
//      }
//      else // is this correct for SmartHopper?
//      {
//        $vol = $vol * 1000
//             / 1600;       // estimated capacity of recycler, in quarters-equivalent
//      }
      $vol = $volume; // now done by skyy
    }
    else
    {
      $vol = 0; // not calculated
    }

    $rval = [];

    $rval["coins"] = intval($count1c) + intval($count5c) + intval($count10c)
                   + intval($count25c) + intval($count100c);
    $rval["volume"] = floor($vol + 0.5);

    $rval["can_roll"] = $can_roll;

    return $rval; // returns an array with 2 named elements
  }

  function coin_counter_equipment()
  {
    $Equipment = ltrim(rtrim(skyyreq("coin-counter-equipment")));

    if(!strlen($Equipment))
      $Equipment = "UNKNOWN";

    return $Equipment;
  }


  //  _      _                        _   _  _    _  _
  // | |    (_) _ __    __ _   ___   | | | || |_ (_)| | ___
  // | |    | || '_ \  / _` | / _ \  | | | || __|| || |/ __|
  // | |___ | || | | || (_| || (_) | | |_| || |_ | || |\__ \
  // |_____||_||_| |_| \__, | \___/   \___/  \__||_||_||___/
  //                   |___/

  function make_proper($chX)
  {
    $rval = "";
    $yy = explode(' ', $chX);

    foreach($yy as $zz)
    {
      $ww = ltrim(rtrim($zz));

      if(!strlen($ww))
        continue;

      if(strlen($rval))
        $rval = $rval . ' ';

      if(strlen($ww) == 1)
        $qq = strtoupper($ww);
      else
        $qq = strtoupper(substr($ww, 0, 1))
            . strtolower(substr($ww, 1, strlen($ww)));

      $rval = $rval . $qq;
    }

    return $rval;
  }

  function is_vowel($chX)
  {
    $cc = strtolower(substr($chX, 0, 1));
    if($cc == 'a' || $cc == 'e' || $cc == 'i' || $cc == 'o'
       || $cc == 'u' || $cc == 'y')
    {
      return true;
    }

    return false;
  }

  function make_participle($term)
  {
    // ends in vowel, consonant - double the consonant, add 'ed'
    // ends in cons, cons, add 'ed'
    // ends in cons 'e', add 'd'
    // ends in 'y' or 'i', change to 'ied'
    // ends in other vowel, add 'ed'

    $ii = strlen($term);

    if($ii > 1)
    {
      if(is_vowel(substr($term,$ii - 1, 1))) // ends in vowel
      {
        if(strtolower(substr($term,$ii - 1, 1)) == 'e')
          return $term . "d";

        if(strtolower(substr($term,$ii - 1, 1)) == 'y')
          return substr($term, 0, $ii - 1) . "ied";
      }
      else if(is_vowel(substr($term,$ii - 2, 1)) &&
              !is_vowel(substr($term,$ii - 1, 1)))
      {
        // double consonant or add 'k'?
//        if(strtolower(substr($term,$ii - 1, 1)) == 'c')
//        {
//          return $term . "ked"; // verify
//        }
//        else
        if(strtolower(substr($term,$ii - 1, 1)) != 'w') // do not double 'w' [bad pun]
        {
          return $term . substr($term,$ii - 1, 1) . "ed";
        }
      }

      return $term . "ed"; // for now assume this
    }

    return $term; // for now do this
  }

  function make_singular($term)
  {
    $ii = strlen($term);

    if($ii > 3 &&
       strtolower(substr($term,$ii - 2, 2)) == "es")
    {
      // check for consonant vowel cononant 'e', leave the 'e' if it is

      if(!is_vowel(substr($term, $ii - 3, 1)))
      {
        if(is_vowel(substr($term, $ii - 4, 1)))
        {
          if($ii == 4)
            return substr($term, 0, $ii - 1); // just drop the 's'

          if(!is_vowel(substr($term, $ii - 5, 1))) // cons vowel cons 'es' - drop teh 's' only
            return substr($term, 0, $ii - 1); // just drop the 's'

          // TODO:  common exceptions?
        }
        else
        {
          // 2 consonants and ends in 'es', keep the 'e' unless it's vowel [c,s] h es

          if($ii > 4)
          {
            if(strtolower(substr($term, $ii - 3, 1)) == 'h')
            {
              if(strtolower(substr($term, $ii - 4, 1)) == 'c' ||
                 strtolower(substr($term, $ii - 4, 1)) == 's')
              {
                if(is_vowel(substr($term, $ii - 5, 1)))
                {
                  return substr($term, 0, $ii - 2); // drop the 'es'
                }
              }
            }
          }

          if(!is_vowel(substr($term, $ii - 4, 1))) // cons cons 'es' - drop teh 's' only
            return substr($term, 0, $ii - 1); // just drop the 's'
        }
      }

      return substr($term, 0, $ii - 2);
    }
    else if($ii > 1 &&
            strtolower(substr($term,$ii - 1, 1)) == "s")
    {
      return substr($term, 0, $ii - 1);
    }

    return $term; // no change
  }

  /* this one is frequently used in summary screens */
  function currency_form($xx)
  {
    $yy = sprintf("%0.2f", $xx);
    $n = strlen($yy);

    $zz = "";

    if($xx >= 1000.00)
    {
      if($xx >= 1000000.00)
      {
        if($xx >= 1000000000.00)
        {
          $zz = substr($yy, 0, $n - 12)
              . ","
              . substr($yy, $n - 12, 3)
              . ","
              . substr($yy, $n - 9, 3)
              . ","
              . substr($yy, $n - 6, 6);
        }
        else
        {
          $zz = substr($yy, 0, $n - 9)
              . ","
              . substr($yy, $n - 9, 3)
              . ","
              . substr($yy, $n - 6, 6);
        }
      }
      else
      {
        $zz = substr($yy, 0, $n - 6)
            . ","
            . substr($yy, $n - 6, 6);
      }
    }
    else
    {
      $zz = $yy;
    }

    return $zz;
  }


  //  ____               _       _                _____  _
  // |  _ \  ___   __ _ (_) ___ | |_  ___  _ __  |  ___|| |  __ _   __ _  ___
  // | |_) |/ _ \ / _` || |/ __|| __|/ _ \| '__| | |_   | | / _` | / _` |/ __|
  // |  _ <|  __/| (_| || |\__ \| |_|  __/| |    |  _|  | || (_| || (_| |\__ \
  // |_| \_\\___| \__, ||_||___/ \__|\___||_|    |_|    |_| \__,_| \__, ||___/
  //              |___/                                            |___/

  // see SKYY_ENTITY_MAX_REGNUM and other flags in skyy.h - if that value changes, fix these utilities
  function register_max()
  {
    return 65535; // SKYY_ENTITY_MAX_REGNUM
  }

  function register_pull_bit_flag()
  {
    return 65536; // SKYY_ENTITY_PULL_FLAG
  }

  function register_multi_bit_flag()
  {
    return 131072; // SKYY_ENTITY_MULTI_FLAG
  }

  function register_is_pull($EntityNum)
  {
    return ($EntityNum > 0) &&
           (($EntityNum & register_pull_bit_flag()) != 0);
  }

  function class_is_register($Class)
  {
    return $Class == "3";
  }

  // bad geeky programmer joke in name.  Could have called it "register_desu" also.
  function register_is($EntityNum) /* consistent naming, and a little fun we are having - Yoda, heh */
  {
    return ($EntityNum > 0) && ($EntityNum <= register_max());
  }

  function register_multi_timestamp()
  {
    $tval = intval(Date("dHi"));
    $tval = $tval % 100000;  // day, hour, minute as 5 digit value
    // convert this to seconds
    $tvalM = intval($tval % 100);
    $tvalH = intval($tval / 100) % 100;
    $tvalD = intval($tval / 10000) % 4; // every 4 days it wraps around
    $tval = $tvalM + 60 * $tvalH + 24 * 60 * $tvalD;

//    return 16384 * $tval; // fits within a 32-bit signed integer's range
    $tval = 262144 * $tval; // fits in 32 bits still - TODO is this necessary??

//    print $tval . ", " . $tvalM . ", " . $tvalH . ", " . $tvalD . "    " . intval(Date("dHi"))  . "    " . Date("dHi");
    return $tval;
  }

  function register_entity_mask($EntityNum)
  {
    if($EntityNum > 0)
      return $EntityNum & 65535;
    else
      return $EntityNum;
  }


  //  ____         _         _
  // |  _ \  _ __ (_) _ __  | |_  ___  _ __
  // | |_) || '__|| || '_ \ | __|/ _ \| '__|
  // |  __/ | |   | || | | || |_|  __/| |
  // |_|    |_|   |_||_| |_| \__|\___||_|
  //

  // generic printer output
  function printer_output($data)
  {
    $equipstats = load_parsestats();

    $printer_serial = do_getconf($equipstats, "equipment", "Printer", "");
    $inverted = do_getconf($equipstats, "Printer " . $printer_serial, "Inverted", "0");

    if($inverted == "" || $inverted != "1")
      $inverted = false;
    else
      $inverted = true;

    $ptr="/dev/usb/lp0";

    // NOTE:  this always does a single page of output and there can
    //        be no control sequences in it or it may mess up

    $the_file = fopen($ptr, "w");
    if($the_file !== false)
    {
//      fsync($the_file);

      $dt = explode("\n", $data);
      $ok = 1;

      if($inverted)
      {
        $jj = sizeof($dt);

        $xx = "\x1b\x7b\x01";
        $ok = (fwrite($the_file, $xx) === false) // inverted
            ? 0 : 1;

        if($ok == 0) // error?  retry
        {
          usleep(200000); // 0.2 sec delay

          $ok = (fwrite($the_file, $xx) === false)
              ? 0 : 1;
        }

        usleep(100000); // 0.1 sec delay

        if($ok != 0)
        {
          for($ii=$jj - 1; $ii >= 0; $ii --)
          {
            $xx = $dt[$ii];
            $ok = (fwrite($the_file, $xx . "\n") === false)
                ? 0 : 1;

            if($ok == 0) // error?  retry
            {
              usleep(200000); // 0.2 sec delay

              $ok = (fwrite($the_file, $xx . "\n") === false)
                  ? 0 : 1;
            }

            if($ok == 0) // error
            {
              break;
            }

//          fsync($the_file);
          }
        }

        usleep(100000); // 0.1 sec delay
        fwrite($the_file, "\x1b\x7b\x00"); // non-inverted - do regardless of previous error
      }
      else
      {
        foreach($dt as $xx)
        {
          $ok = (fwrite($the_file, $xx . "\n") === false)
              ? 0 : 1;

          if($ok == 0) // error?  retry
          {
            usleep(200000); // 0.2 sec delay

            $ok = (fwrite($the_file, $xx . "\n") === false)
                ? 0 : 1;
          }

          if($ok == 0)
          {
            break;
          }

//          fsync($the_file);
        }
      }

      usleep(500000); // 0.5 sec delay

      if($ok != 0)
        $ok = (fwrite($the_file, "\n\n\n\n\n\n\x1bi\n") === false) // paper cut
            ? 0 : 1;

      usleep(500000); // 0.5 sec delay

      fclose($the_file);
      if($ok != 0)
      {
        return; // done
      }
    }

    // TODO:  error handline?
//    $the_file = fopen("/home/pi/fakeprinter.txt", "w");
//    fwrite($the_file, $data);
//    fclose($the_file);
  }


  // common globals and things

  $ColorList = [];
//  $ColorList[0] = "academy";
//  $ColorList[1] = "banana";
//  $ColorList[2] = "cardena";
//  $ColorList[3] = "energy";
//  $ColorList[4] = "grey";
//  $ColorList[5] = "industrial";
//  $ColorList[6] = "padre";
//  $ColorList[7] = "USA";
  $ColorList[0] = "academy";
  $ColorList[1] = "academy1";

  $ColorList[2] = "banana";
  $ColorList[3] = "cardena";
  $ColorList[4] = "energy";
  $ColorList[5] = "grey";
  $ColorList[6] = "industrial";
  $ColorList[7] = "padre";
  $ColorList[8] = "USA";


?>
