<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $parseconf = load_parseconf();
  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

//  if($CustomerMod == 1)
//  {
//    $video_list="/home/pi/Videos/customer_mod_1_weekly.mp4";
//  }
//  else
//  {
    $video_list="/home/pi/Videos/zc4_weekly.mp4";
//  }

  header("HTTP/1.0 302 Moved Temporarily");
  header("Location: /cleaning.php");

  // TODO:  validate '$complete', as it can only be 'safe' 'drawer' or 'register'

  shell_exec( "/usr/bin/sudo /home/pi/bin/play-video.sh " . $video_list);

?>

