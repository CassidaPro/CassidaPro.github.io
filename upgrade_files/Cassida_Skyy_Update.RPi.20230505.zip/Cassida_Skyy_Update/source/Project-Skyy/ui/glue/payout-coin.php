<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $Equipment = coin_counter_equipment();

  $Multi = do_getvar("Multi","0");
  $Denom = do_getvar("Denom","0");
  $Amount = do_getvar("Amount", 0);
  $Denom2 = do_getvar("Denom2",$Denom);
  $Amount2 = do_getvar("Amount2", 0);
  $Denom3 = do_getvar("Denom3","0");
  $Amount3 = do_getvar("Amount3", 0);
  $Denom4 = do_getvar("Denom4","0");
  $Amount4 = do_getvar("Amount4", 0);
  $Denom5 = do_getvar("Denom5","0");
  $Amount5 = do_getvar("Amount5", 0);

  if(!coin_counter_is_recycler($Equipment))
  {
    header("HTTP/1.0 500 Server Error");

    return; // for now just do this
  }

  if(($Denom == 0 || $Amount == 0) &&
     ($Denom2 == 0 || $Amount2 == 0) &&
     ($Denom3 == 0 || $Amount3 == 0) &&
     ($Denom4 == 0 || $Amount4 == 0) &&
     ($Denom5 == 0 || $Amount5 == 0))
  {
    header("HTTP/1.0 500 Server Error");

    print "ERROR - bad denom/amount\n";

    return; // for now just do this
  }
  else if($Denom == $Denom2 && $Denom != 0 && $Amount != 0
          && ($Denom3 == 0 || $Amount3 == 0)
          && ($Denom4 == 0 || $Amount4 == 0)
          && ($Denom5 == 0 || $Amount5 == 0)) // just one amount, really
  {
    header("HTTP/1.0 200 OK");
    header("Content-Type: text/plain");
    header("Access-Control-Allow-Origin: *"); // should prevent CORS problems

    print skyyreq( "payout-recycler/" . $Denom . "/" . $Amount );
  }
  else
  {
    $req = "";

    if($Denom != 0 && $Amount != 0)
      $req = $req . "/" . $Denom . "/" . $Amount;
    if($Denom2 != 0 && $Amount2 != 0)
      $req = $req . "/" . $Denom2 . "/" . $Amount2;
    if($Denom3 != 0 && $Amount3 != 0)
      $req = $req . "/" . $Denom3 . "/" . $Amount3;
    if($Denom4 != 0 & $Amount4 != 0)
      $req = $req . "/" . $Denom4 . "/" . $Amount4;
    if($Denom5 != 0 & $Amount5 != 0)
      $req = $req . "/" . $Denom5 . "/" . $Amount5;

    if($req == "")
    {
      header("HTTP/1.0 500 Server Error");

      print "ERROR - bad denom/amount\n";

      return; // for now just do this
    }

    if($Multi > 0)
    {
      if($Multi == "2")
        $req = '/%' . $req; // prepend with /. to idicate always multi-payout with batch
      else
        $req = '/*' . $req; // prepend with /* to idicate always multi-payout
    }

    print skyyreq( "payout-recycler" . $req );
  }

?>

