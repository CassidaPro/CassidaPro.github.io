<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $Equipment = coin_counter_equipment();

  $doohickey=do_getvar("doohickey", "");
  $next=do_getvar("next", "");

  if($doohickey=="")
  {
    if(strlen($next) > 0)
      $next = "&next=" . urlencode($next);

    $uri="/glue/complete-c400-set-batch.php";
//    $uri = $_SERVER['REQUEST_URI']; this only works if there's no GET vars
//
//    if(substr($uri, strlen($uri)-1, 1) == '?')
//      $uri = substr($uri, 0, strlen($uri)-1);
?>
    <HTML>
      <HEAD><TITLE>re-direct</TITLE>
        <meta http-equiv="refresh"
              <?php print 'content="0.2;url=' . $uri . '?doohickey=Y' . $next . '"' . "\n"; ?> >
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY><br><br><br><br><H1><center>Completed Configuring C400</center></H1>
      </BODY>
    </HTML>
<?php
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");

    if(strlen($next) > 0)
      header("Location:  " . $next);
    else
      header("Location: /c400-batch-qty.php");

    skyyreq("complete");
  }
?>

