<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php"; // things common to all

  $doohickey=do_getvar("doohickey", "");

//  extract($_GET, EXTR_OVERWRITE);

  if($doohickey=="")
  {
?>
    <HTML>
      <HEAD><TITLE>re-direct</TITLE>
        <meta http-equiv="refresh" content="0.2;url=/glue/initiate-verify_deposit.php?doohickey=Y">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br><br><br><H1><center>Initializing...</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }

  // first complete whatever is there... in case I'm re-starting
  skyyreq("complete");

  $Equipment = coin_counter_equipment(0);

  header("HTTP/1.0 302 Moved Temporarily");

  if(coin_counter_is_recycler_twin($Equipment))
  {
    header("Location: /dispense-coins.php?origin=/glue/cancel-task.php&rolls_only=N&entity=VERIFY&next=/glue/verify_deposit-start-zeus.php");
  }
  else
  {
    header("Location: /glue/verify_deposit-start-zeus.php");
  }

  skyyreq("verify-deposit");
?>

