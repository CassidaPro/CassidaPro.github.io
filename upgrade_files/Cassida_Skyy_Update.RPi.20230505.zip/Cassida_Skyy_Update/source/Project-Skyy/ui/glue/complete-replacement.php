<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $code = do_getvar("code");
  $serial = do_getvar("serial");
  $doohickey = do_getvar("doohickey");

  if($doohickey !== "Y")
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh"
          content="0.1;url=/glue/complete-replacement.php?doohickey=Y&code=<?php
              print urlencode($code) . "&serial=" . urlencode($serial); ?>" >
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY><br><br><br><br><H1><center>Scanning Equipment</center></H1>
    </BODY>
    </HTML>
<?php
    exit;
  }

  if(strlen($code) && $code > "0")
  {
    skyyreq("del-reminder/" . $code);  // it's done, remove it

    if($code == 100)
    {
      if(!strlen($serial))
        skyyreq("zeus-RMA");
      else
        skyyreq("zeus-RMA/" . $serial);
    }
    else if($code == 200)
    {
      if(!strlen($serial))
        skyyreq("printer-RMA");
      else
        skyyreq("printer-RMA/" . $serial);
    }
    else if($code == 400)
    {
      skyyreq("c400-RMA");
    }
    else if($code == 600)
    {
      skyyreq("recycler-RMA");
    }

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /");
  }
  else
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="5;url=/">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY><br><br><br><br><H1><center>Missing/Invalid Maintenance Code</center></H1>
    </BODY>
    </HTML>
<?php
    exit;
  }
?>

