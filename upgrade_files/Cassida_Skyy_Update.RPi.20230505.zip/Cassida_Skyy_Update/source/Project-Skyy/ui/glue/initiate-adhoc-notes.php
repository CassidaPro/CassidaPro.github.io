<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php"; // things common to all

  $doohickey=do_getvar("doohickey", "");

//  extract($_GET, EXTR_OVERWRITE);

  if($doohickey=="")
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="0.2;url=/glue/initiate-adhoc-notes.php?doohickey=Y">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY><br><br><br><br><H1><center>Initializing Zeus</center></H1>
    </BODY>
    </HTML>
<?php
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /glue/adhoc-start-zeus.php");

    // first complete whatever is there... in case I'm re-starting
    skyyreq("complete");
    skyyreq("count-ad-hoc");
  }
?>

