<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php"; // things common to all

  $doohickey=do_getvar("doohickey", "");
  $qty = do_getvar("qty", "50"); // default strap 50

//  extract($_GET, EXTR_OVERWRITE);

  if($doohickey=="")
  {
    $qty = do_postvar("qty", "50");
//    extract($_POST,  EXTR_OVERWRITE);
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="0.2;url=/glue/initiate-adhoc-straps.php?doohickey=Y&qty=<?php print $qty;?>">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY><br><br><br><br><H1><center>Configuring Zeus for Strap <?php print $qty; ?></center></H1>
    </BODY>
    </HTML>
<?php
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /adhoc-straps.php");

    // 'quantity' was assigned with the strap amount

    skyyreq("complete");

    skyyreq("strap/" . $qty);
  }
?>
