<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $doohicky = do_getvar("doohicky","");

  if($doohicky != "Y")
  {
?>
    <!DOCTYPE html>
    <HTML>
      <HEAD>
        <TITLE>Reset</TITLE>
        <meta http-equiv="refresh" content="0.2;url=/glue/reset.php?doohicky=Y">
        <STYLE>
          @font-face
          {
           font-family: Lato;
           src: url(/fonts/lato-v15-latin-regular.woff);
          }
          html
          {
            font-size:<?php print round(cached_font_size() * 0.5); ?>px !important;
          }
          body
          {
            font-size: inherit;
            background-color: #e0e0e0;
            color: #8068ff;
          }
        </STYLE>
      </HEAD>
      <BODY>
        <center>
          <H1>SYSTEM RESET</H1>
        </center>
      </BODY>
    </HTML>
<?php
  }
  else
  {
    skyyreq("reset");

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /");
  }
?>

