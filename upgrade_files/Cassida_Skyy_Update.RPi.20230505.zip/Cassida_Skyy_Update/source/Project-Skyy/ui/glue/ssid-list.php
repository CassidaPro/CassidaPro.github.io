<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include 'utility_functions.php';

?>
<!DOCTYPE html5>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php

//  $doohickey="";
//  $ssid="";
//  $passphrase="";
//  $dhcp="off";
//  $wpa="";
//  $fixed_ip="";
//  $subnet="";
//  $dns="";
//  $gateway="";
//  $wifi_enabled="off"; // this won't be in the param list if the checkbox isn't checked
//
//  extract($_GET, EXTR_OVERWRITE);

  $doohickey=my_get_var("doohickey");
  $ssid=my_get_var("ssid");
  $passphrase=my_get_var("passphrase");
  $dhcp=my_get_var("dhcp","off");
  $wpa=my_get_var("wpa");
  $fixed_ip=my_get_var("fixed_ip");
  $subnet=my_get_var("subnet");
  $dns=my_get_var("dns");
  $gateway=my_get_var("gateway");
  $wifi_enabled=my_get_var("wifi_enabled","off"); // this won't be in the param list if the checkbox isn't checked

  $original_ssid=$ssid; // keep track, I compare later

  $parameters="ssid=" . urlencode($ssid) . "&passphrase=" . urlencode($passphrase)
             . "&dhcp=" . urlencode($dhcp) . "&wpa=" . urlencode($wpa)
             . "&wifi_enabled=" . urlencode($wifi_enabled);

//  print "<pre>\n" . $parameters . "\n</pre>\n";

  if($dhcp == "off" || strlen($dhcp) == 0)
  {
    $parameters = $parameters . "&fixed_ip=" . urlencode($fixed_ip) . "&subnet=" . urlencode($subnet)
                . "&dns=" . urlencode($dns) . "&gateway=" . urlencode($gateway);
  }

  // get a list of ssid's from the wireless.conf file - will need it later

  $list_ssid = array();
  $count_ssid = 0;

//  $parseconf = parse_ini_file("/var/cache/skyy/wireless.conf",
//                              TRUE, // to process sections
//                              INI_SCANNER_NORMAL); // process values normally

  $parseconf = parse_conf("/var/cache/skyy/wireless.conf");

  if(!empty($parseconf))
  {
    foreach($parseconf as $kk => $xx)
    {
      if($kk == "___global_settings___")
        continue;

      $list_ssid[$count_ssid] = $kk;
      $count_ssid++;
    }
  }

  if($doohickey=="")
  {
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
        <meta http-equiv="refresh"
             content=<?php print '"0.2;url=/glue/ssid-list.php?doohickey=Y&' . $parameters . '"' ?> >
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br><br><br><H1><center>Scanning for wireless networks...</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }

  // build the actual SSID list

  shell_exec("/bin/rm /var/tmp/_ssid_list_php_.txt"); // remove file first

  // the '85' parameter limits RSS strength to -85 or higher
  shell_exec("/home/pi/bin/ssid_list.sh 85 >/var/tmp/ssid_list_php.txt");


  $scanned_ssid_list=shell_exec("sed 's/\\\\ /__!!__/g' </var/tmp/ssid_list_php.txt | awk '{ S=$1; "
                                . 'gsub(/__!!__/," ",S);' . " print S; }' | sort -u");

  // each line in '$scanned_ssid_list' is a unique scanned SSID

  $ll=$scanned_ssid_list;

  $HasScannedList = 0;

  while(strlen($ll) > 0)
  {
    $ln = strstr($ll, "\n", true);

    if($ln === false)
    {
      $ln = $ll;
      $ll = "";
    }
    else
    {
      $ll = substr($ll, strlen($ln)+1);
    }

    if(!empty($ln))
    {
      $HasScanList = 1;

      // if my list o' knon SSIDs has this entry in it, remove from list o' known SSIDs
      for($ii=0; $ii<$count_ssid; $ii++)
      {
        if($list_ssid[$ii] == $ln)
          $list_ssid[$ii] = "";
      }
    }
  }

  // this is a secondary check - must have at least one non-blank SSID in 'known' list
  // for me to display it at the end

  $HasSSIDList = 0;

  for($ii=0; $ii<$count_ssid; $ii++)
  {
    if(strlen($list_ssid[$ii]) > 0)
    {
      $HasSSIDList = 1;
      break;
    }
  }



?>
<!DOCTYPE html5>
<HTML lang=en>
<HEAD>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <TITLE>SSID List</TITLE>
  <link href="/css/networking.css" type="text/css" rel="stylesheet" media="screen,projection" />
  <STYLE>
    html
    {
      font-size:<?php print cached_font_size(); ?>px !important;
    }
    body
    {
      font-size: inherit;
      background-color: #e0e0d0;
      background: #e0e0d0;
      color: #5040c0;
    }
    .inner-table
    {
      background-color: #f4f0ec;
      color: #000000;
      font-size:0.5rem;
      width:12.5rem;
    }
    table /* special scrollable - from stack overflow */
    {
      display:inline-block; overflow:auto;
    }
    button
    {
     font-weight: bold;
     font-size: 0.75rem;
     height : 1.5rem /*36px*/;
     color: #000000;
    }
    a
    {
      color: #000080; font-size 0.58rem /*14px*/;
    }
    a:visited
    {
      color: #000040; font-size 0.58rem /*14px*/;
    }
    a:active
    {
      color: #000000; font-size 0.58rem /*14px*/;
    }
    a:hover
    {
      color: #000000; font-size 0.58rem /*14px*/;
    }
  </STYLE>
</HEAD>
<BODY>
  <center>
    <table>
      <tr>
        <td>
          <center>
            <p style="font-size 0.58rem /*14px*/">
            <table>
              <tr align=center>
                <td>
                  <H1 style="font-size:1rem;margin:0px;padding=0px;">Available Networks</H1>
                </td>
              </tr>
              <tr align=left style="font-size:0.6rem">
                <td>Click link in left-most column to load the settings for that network</td>
              </tr>
            </table>
            <form>
              <H3 style="font-size:0.8rem;margin:0">Scanned Networks</H3>
<?php
    if($HasScanList == 0)
    {
      print "<center>{ empty }</center><br>\n";
    }
    else
    {
?>
              <table border=1 class="inner-table"
                     style="height:<?php if($HasSSIDList != 0) print "6.25rem"; else print "11.67rem";
                       ?>;width:21rem;">
                <thead>
                  <tr>
                    <th style="width:9.58rem">SSID</th>
                    <th style="width:4.16rem">BSSID</th>
                    <th style="width:1.875rem">Q</th>
                    <th style="width:1.875rem">C</th>
                    <th style="width:1.9rem">WPA</th>
                  </tr>
                </thead>
                <tbody>
<?php

      $exec_str = "/bin/cat /var/tmp/ssid_list_php.txt | ";
      // first part, use this somewhat generic shell script to generate 5 columns for each SSID, which
      // converts embedded white space to '\ ' within the SSID name.  The other columns won't have that.

      $exec_str = $exec_str . "sed 's/\\\\ /__!!__/g' | ";
      // This will converted '\ ' to '__!!__' to handle embedded spaces - and yes I must
      // double the number of backslashes TWICE as 2 recursive parsers have to deal with this.
      // Now the white space (which awk expects between columns) separates columns, and not
      // parts of a name within a column.

      $exec_str = $exec_str . "awk '{ S=$1; " . 'gsub(/__!!__/," ",S); T=$1; gsub(/__!!__/,"%20",T); '
                . 'if(S=="' . $original_ssid . '") { yy="&passphrase=' . urlencode($passphrase) . '&dhcp='
                      . $dhcp . '&wpa=' . $wpa;
      if($dhcp == "off" || strlen($dhcp) == 0) // fixed IP, include those parameters also
      {
        $exec_str = $exec_str . "&fixed_ip=" . urlencode($fixed_ip) . "&subnet=" . urlencode($subnet)
                  . "&dns=" . urlencode($dns) . "&gateway=" . urlencode($gateway);
      }

      $exec_str = $exec_str . '&load=0"; } else { yy=""; } '
                . 'print "<tr><td style=\"width-max:9.16rem;word-break:break-all;white-space:wrap\">'
                . '<a href=\"/wireless-client.php?wifi_enabled=' . urlencode($wifi_enabled)
                . '&ssid=" T "&bssid=" $2 "&chan=" $3 yy "\">"'
                . ' S "</a></td><td style=\"font-size:0.5rem\">" $2 "</td><td>" $3 "</td><td>" $4 "</td><td>" $5 "</td></tr>"; }'
                . "'";

      // this last part uses 'awk' to output the 5 data columns as table columns, col 1 being an anchor
      // to supply 'that SSID' to the appropriate web page, and also with the first column converting
      // '__!!__' back into embedded white space for the 2 different contexts, one being GET parameters
      // for the anchor's URL (that has the ssid as a param), and the other being the name as displayed
      // in the HTML table.  This really is a big fat hack and relies on that particular string NEVER being
      // found in an SSID.  It's one of the down sides of having to deal with SSIDs that have embedded
      // white space in their names... and awk doesn't handle quoted strings well

      print shell_exec($exec_str);

?>
                </tbody>
              </table>
<?php
    }

    // loop through known SSIDs in wireless.conf and include all of the ones
    // from there that aren't already listed...

    if($HasSSIDList != 0)
    {
?>
              <br><br>
              <H3 style="margin:0;border:0;padding:0;">Other Known Networks</H3>
              <table border=1 class="inner-table" style="height:3.33rem;">
                <thead>
                  <tr>
                    <th style="width:9rem">SSID</th>
                    <th style="width:2.5rem">WPA</th>
                  </tr>
                </thead>
                <tbody>
<?php

      for($ii=0; $ii<$count_ssid; $ii++)
      {
        if(strlen($list_ssid[$ii]))
        {
  // <td style="width-max:72px;word-break:break-all;white-space:wrap"><a href="/wireless-client.php?ssid=691290&bssid=00:0a:99:85:eb:ef&chan=-84">691290</a></td>

          print '<tr><td width=200px style="width-min:200px;width-max:200px;word-break:break-all;white-space:wrap">';

          if($original_ssid == $list_ssid[$ii])
          {
            print '<a href="/wireless-client.php?' . $parameters . '&load=0">';
          }
          else
          {
            print '<a href="/wireless-client.php?wifi_enabled=' . urlencode($wifi_enabled)
                  . '&ssid=' . urlencode($list_ssid[$ii]) . '">';
          }

          print $list_ssid[$ii] . "</a></td>\n";

          if($original_ssid == $list_ssid[$ii])
          {
            print '<td>' . $wpa . "</td>\n";
          }
          else
          {
            print '<td>' . (empty($parseconf[$list_ssid[$ii]]["wpa"]) ? "&nbsp;" : $parseconf[$list_ssid[$ii]]["wpa"]) . "</td>\n";
          }

          print "</tr>\n";
        }
      }
?>
                </tbody>
              </table>
<?php
    }
?>
            </form>
          </center>
        </td>
      </tr>
    </table>
  </center>
  <center style="position:absolute;left:0;width:100%;bottom:0.8rem;margin:0;padding:0">
    <form mode=GET>
      <input type=hidden visibility=none name=wifi_enabled value=<?php print '"' . preg_replace('/"/', '""', $wifi_enabled) . '"'; ?> ></input>
      <input type=hidden visibility=none name=ssid value=<?php print '"' . preg_replace('/"/', '""', $ssid) . '"'; ?> ></input>
      <input type=hidden visibility=none name=passphrase value=<?php print '"' . preg_replace('/"/', '""', $passphrase) . '"'; ?> ></input>
      <input type=hidden visibility=none name=dhcp value=<?php print '"' . preg_replace('/"/', '""', $dhcp) . '"'; ?> ></input>
      <input type=hidden visibility=none name=wpa value=<?php print '"' . preg_replace('/"/', '""', $wpa) . '"'; ?> ></input>
      <input type=hidden visibility=none name=load value="0"></input>
<?php
    if($dhcp == "off" || strlen($dhcp) == 0) // fixed IP, include those parameters also
    {
?>
      <input type=hidden visibility=none name=fixed_ip value=<?php print '"' . preg_replace('/"/', '""', $fixed_ip) . '"'; ?> ></input>
      <input type=hidden visibility=none name=subnet value=<?php print '"' . preg_replace('/"/', '""', $subnet) . '"'; ?> ></input>
      <input type=hidden visibility=none name=dns value=<?php print '"' . preg_replace('/"/', '""', $dns) . '"'; ?> ></input>
      <input type=hidden visibility=none name=gateway value=<?php print '"' . preg_replace('/"/', '""', $gateway) . '"'; ?> ></input>
<?php
    }
?>
      <button formaction="/glue/ssid-list.php"
              type=submit style="height:1.6rem;font-size:0.8rem;margin:0px">Refresh</button>
      <span style="min-width:4rem">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
      <button formaction="/wireless-client.php"
              type=submit style="height:1.6rem;font-size:0.8rem;margin:0px">Back</button>
    </form>
  </center>
</BODY>
</HTML>


