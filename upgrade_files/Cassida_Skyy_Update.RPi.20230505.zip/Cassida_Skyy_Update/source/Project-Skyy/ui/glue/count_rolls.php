<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/xml");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE count SYSTEM "count.dtd">
<count>
<?php

$Entity = '';
$CountDate = '';

// rolled coin
$roll1 = '0';
$roll5 = '0';
$roll10 = '0';
$roll25 = '0';
$roll100 = '0';

  $Solution = skyyreq("count-entity");
  eval($Solution);

  $Solution = skyyreq("result-rolls");
  eval($Solution);
?>

<entity><?php print $Entity;?></entity>
<date><?php print $CountDate;?></date>
<roll><type>1</type><batch>50</batch><qty><?php print $roll1 / 50;?></qty></roll>
<roll><type>5</type><batch>40</batch><qty><?php print $roll5 / 40;?></qty></roll>
<roll><type>10</type><batch>50</batch><qty><?php print $roll10 / 50;?></qty></roll>
<roll><type>25</type><batch>40</batch><qty><?php print $roll25 / 40;?></qty></roll>

</count>

