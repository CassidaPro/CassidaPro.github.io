<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Straps = do_getconf($parseconf,"terms",'Straps','Straps');
  $BuildButton = do_getconf($parseconf,"terms",'BuildButton','Build Tills');

  $Register = do_getconf($parseconf,"vessels",'Class3','Tills');

  $doohickey = do_getvar("doohickey","");
  $qty = do_getvar("qty", "50"); // default strap 50

//  $qty = 50;
//  extract($_GET, EXTR_OVERWRITE);

  if($doohickey=="")
  {
    if(!empty($_POST))
      $qty = do_postvar("qty", "50");
//    extract($_POST,  EXTR_OVERWRITE);

    if($qty < 5) // quanitities less than 5, count by hand
    {
?>
      <HTML>
        <HEAD>
          <TITLE><?php print $BuildButton; ?> - Hand Count
          </TITLE>
          <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
          <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>

          <link href="/css/style.css" type="text/css" rel="stylesheet"/>
          <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
          <link rel="shortcut icon" href="/img/favicon.ico">
          <style>
<?php
      set_ideal_font_height();
?>
          </style>
        </HEAD>
      <BODY>
        <nav class="secondary-fill lighten-1" role="navigation">
          <div class="nav-wrapper container">
            <a id="logo-container" href="#" class="brand-logo titlebar">Make <?php print $Straps; ?> <img src="/img/count-notes.svg"></a>
            <div id="entity" class="area"><?php print strtoupper($BuildButton); ?></div>
          </div>
        </nav>
        <br>
        <br>
        <br>
        <div style="font-size:28px">
          <center>
            Please Hand Count for Quanitities of <?php print $qty; ?><br>
          </center>
        </div>

        <div class="next-button">
          <form method="GET">
            <button id=next_strap formaction="/build_tills-strap-qty.php" class="btn waves-effect primary-fill btn-shadow">Next <?php print make_singular($Straps); ?></button>
            <button id=finish_straps formaction="/glue/finish-build_tills-straps.php" class="btn waves-effect primary-fill btn-shadow">Finish <?php print $Straps; ?></button>
          </form>
        </div>

        <script src="/js/UserFeedback.js"></script>

      </BODY>
      </HTML>
<?php
    }
    else
    {
?>
      <HTML><HEAD><TITLE>re-direct</TITLE>
      <meta http-equiv="refresh" content="0.2;url=/glue/initiate-build_tills-straps.php?doohickey=Y&qty=<?php print $qty;?>">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY><br><br><br><br><H1><center><?php print $BuildButton; ?> - Configuring Zeus for <?php print make_singular($Straps); ?> <?php print $qty; ?></center></H1>      </BODY>
      </HTML>
<?php
    }
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /build_tills-straps.php");

    // 'quantity' was assigned with the strap amount

    skyyreq("complete");

    skyyreq("strap/" . $qty);
  }
?>

