<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/xml");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems
  header("Expires: 0");
  header("Cache-control: none");
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE zeus SYSTEM "zeus.dtd">
<zeus>
<?php
$Entity = '';
$CountDate = '';
$CountTick = '0';
$StatusCode = '15';
$StatusText = 'Server error; please re-start system';
$Batch = '';
$BatchStr = '';


  $thingy = skyyreq("count-entity" );
  eval($thingy);

  $thingy = skyyreq("status-zeus" );
  eval($thingy);

  print "<entity>" . $Entity . "</entity>\r\n";
  print "<date>" . $CountDate . "</date>\r\n";
  print "<tick>" . $CountTick . "</tick>\r\n";

  print "<status><code>" . $StatusCode . "</code>";
  print "<text>" . $StatusText . "</text></status>\r\n";

?>
</zeus>


