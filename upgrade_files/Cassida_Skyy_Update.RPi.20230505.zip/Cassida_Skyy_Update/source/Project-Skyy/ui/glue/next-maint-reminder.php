<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

    include "common_utils.php";

    header("Content-type: text/plain; charset=UTF-8");

    $num_reminders=0;

    $rval = skyyreq("reminders" );
    eval($rval);

    // for now we only do the first one
    if($num_reminders > 0)
    {
      print $reminder0 . "\n";
    }
    else
    {
      print "\n";
    }
?>

