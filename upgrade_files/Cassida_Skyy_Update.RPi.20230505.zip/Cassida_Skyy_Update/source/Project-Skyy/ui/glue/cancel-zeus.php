<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  skyyreq("cancel-count-zeus");

  print "0\n";
  exit;
?>
