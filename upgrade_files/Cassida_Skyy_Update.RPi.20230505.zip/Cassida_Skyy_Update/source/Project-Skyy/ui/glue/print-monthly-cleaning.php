<?php
/*          Copyright 2019-21 by Cassida            */
/* Use only in accordance with the supplied license */

  include "config_utils.php";

  $doohickey = do_getvar("doohickey","");

  if($doohickey != "Y")
  {
?>
  <HTML>
    <HEAD>
      <TITLE>Print Daily Cleaning Instructions</TITLE>
      <meta http-equiv="refresh" content="2;url=/glue/print-monthly-cleaning.php?doohickey=Y">
  <?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br><br><br>
      <H1>
        <center>
          Printing Cleaning Instructions
        </center>
      </H1>
    </BODY>
  </HTML>
<?php
    exit;
  }

  $Equipment = coin_counter_equipment();

  $parseconf = load_parseconf();

  $Note = make_singular(do_getconf($parseconf,"terms",'Notes','Notes'));
  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Coin = make_singular($Coins);

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  if($CustomerMod == 1)
  {
    // something?
  }

  $text = "            MONTHLY CLEANING\n"
        . "            ======= ========\n";

//  $text = $text . "0123456789012345678901234567890123456789\n";

  if(coin_counter_is_recycler($Equipment))
  {
//          "0123456789012345678901234567890123456789\n";
    $text = $text . "\n"
          . "Weekly Cleaning\n"
          . "* Perform Weekly Cleaning\n"
          . "\n"
          . $Coin . " Recycler Cleaning\n"
          . "* Remove " . $Coins . " from Recycler using\n"
          . " 'Make Rolls' and 'Empty' functions.\n"
          . "* Turn off the system from the power\n"
          . "  switch located on the front panel.\n"
          . "* From the bottom, lift the right-hand\n"
          . "  " . $Coin . " Counter access door.\n"
          . "* To clean the Recycler, locate the\n"
          . "  semi-circular latch on the lower\n"
          . "  front of each panel.\n"
          . "* Press up and slide each hopper\n"
          . "  assembly towards you to remove.\n"
          . "* For the right-hand hopper, press\n"
          . "  the front latch adjacent to the coin\n"
          . "  reject port and lift up.\n"
          . "  It is hinged in the back, and opens\n"
          . "  from the front.\n"
          . "* Inspect the inside of the Feeder, and\n"
          . "  remove any foreign debris.\n"
          . "* Using the soft bristle brush, sweep\n"
          . "  away any dust or particles that may\n"
          . "  be in the coin feeder, coin track,\n"
          . "  and coin wheel.\n"
          . "* To clean the coin sensor take the\n"
          . "  Canned Air Duster and dust the area\n"
          . "  as shown by the red arrow.\n"
          . "  Do not insert the nozzle more than\n"
          . "  half an inch into the opening.\n"
          . "\n"
          . "* Remove the feeder assembly from the\n"
          . "  right-hand hopper by lifting up the\n"
          . "  latch in the back, and sliding the\n"
          . "  assembly 1-2 inches away from you.\n"
          . "  The entire assembly can then be\n"
          . "  lifted up to expose the hopper.\n"
          . "* Inspect the inside of the right hand\n"
          . "  hopper, and remove any foreign debris.\n"
          . "* Take the Canned Air Duster and dust\n"
          . "  the inside of the hopper, with special\n"
          . "  attention to the coin elevator on the\n"
          . "  left side, and the payout port.\n"
          . "* Invert the hopper so that you can\n"
          . "  see the 2 ports underneath, and dust\n"
          . "  both ports.\n"
          . "* Replace the feeder assembly, placing\n"
          . "  it on top of the hopper so that it\n"
          . "  fits in the rails, then sliding\n"
          . "  towards you until it clicks into\n"
          . "  place.\n"
          . "* Close the Feeder by moving the\n"
          . "  funnel towards you, until the\n"
          . "  assembly latches.\n"
          . "* For the left-hand hopper, press the\n"
          . "  latch on top of the plastic cover,\n"
          . "  near the back,and sliding the assembly\n"
          . "  1-2 inches away from you.  The cover\n"
          . "  can then be lifted up to expose the\n"
          . "  hopper.\n"
          . "* Inspect the inside of the left hand\n"
          . "  hopper, and remove any foreign debris.\n"
          . "* Take the Canned Air Duster and dust\n"
          . "  the inside of the hopper, with special\n"
          . "  attention to the coin elevator on the\n"
          . "  left side, and the payout port.\n"
          . "* Invert the hopper so that you can\n"
          . "  see the 2 ports underneath, and dust\n"
          . "  both ports.\n"
          . "* Check for any dust or debris on the\n"
          . "  Recycler baseplate, and remove it with\n"
          . "  a cleaning cloth.\n"
          . "* Slide each hopper back onto the base,\n"
          . "  pushing all the way back until they\n"
          . "  latch.\n"
          . "* Lower the right-hand " . $Coin . " Counter\n"
          . "  access door, ensuring that the two\n"
          . "  hoppers and the Feeder easily mate up\n"
          . "  with the cover and coin ports.\n"
          . "* Re-energize the system using the front\n"
          . "  panel power switch.\n"
          . "\n"
          . "Zeus " . $Note . " Counter\n"
          . "* From the bottom, lift the left-hand\n"
          . "  " . $Note . " Counter access door.\n"
          . "* Locate the dust drawer, just below\n"
          . "  the lower cover. Over time dust can\n"
          . "  accumulate and will need to be\n"
          . "  cleaned.\n"
          . "\n"
          . "CleanBill Pro Cleaning Card\n"
          . "* Grab the CleanBill Pro Cleaning Card.\n"
          . "* If the system is off, use the front\n"
          . "  panel power switch to energize the\n"
          . "  system.\n"
          . "* Enable 'Cleaning Mode'\n"
          . "* The screen on the Zeus will then\n"
          . "  prompt you to run the CleanBill Pro\n"
          . "  Cleaning Card through the machine.\n"
          . "* You will need to run the card through\n"
          . "  the machine 10 times.\n"
          . "* Once the CleanBill Pro goes through\n"
          . "  the machine 10 times the Zeus will\n"
          . "  then return to the home screen.\n"
          . "* Close the left-hand " . $Note . " Counter\n"
          . "  access door and press 'Done'.\n";
  }
  else
  {
    $text = $text . "\n"
          . "Weekly Cleaning\n"
          . "  Perform Weekly Cleaning\n"
          . "  Locate the dust drawer, just below\n"
          . "  the lower cover. Over time dust can\n"
          . "  accumulate and will need to be\n"
          . "  cleaned.\n"
          . "\n"
          . "CleanBill Pro Cleaning Card\n"
          . "  Grab the CleanBill Pro Cleaning Card.\n"
          . "  Turn on the system from the power\n"
          . "  switch located behind the ZEUS.\n"
          . "  Enable 'Cleaning Mode'\n"
          . "  The screen on the Zeus will then\n"
          . "  prompt you to run the CleanBill Pro\n"
          . "  Cleaning Card through the machine.\n"
          . "  You will need to run the card through\n"
          . "  the machine 10 times.\n"
          . "  Once the CleanBill Pro goes through\n"
          . "  the machine 10 times the Zeus will\n"
          . "  then return to the home screen, you\n"
          . "  can then select Done on the ZC4.\n"
          . "\n";
  }

  printer_output($text);

//  print shell_exec("cat /home/pi/fakeprinter.txt");

//  header("HTTP/1.0 302 Moved Temporarily");
//  header("Location: /cleaning.php");

?>
<HTML>
  <HEAD>
    <TITLE>Starting <?php print $Equipment; ?></TITLE>
    <meta http-equiv="refresh" content="2;url=/cleaning.php">
<?php set_inbetween_style(); ?>
  </HEAD>
  <BODY>
    <br><br><br><br>
    <H1>
      <center>
        Printing Cleaning Instructions
      </center>
    </H1>
  </BODY>
</HTML>

