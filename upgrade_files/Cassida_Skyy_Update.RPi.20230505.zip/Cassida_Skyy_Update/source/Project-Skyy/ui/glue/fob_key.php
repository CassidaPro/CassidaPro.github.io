<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  // NOTE:  must put XML and doctype header up front

?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE c400 SYSTEM "fobkey.dtd">
<?php

  $Equipment = coin_counter_equipment();

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/xml");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems
  header("Expires: 0");
  header("Cache-control: none");

?>
<fobkey>
  <key><?php
  $fobkey = skyyreq("fobkey");

  if(strlen(rtrim(ltrim($fobkey))) > 0)
  {
    $xx = explode("\n", $fobkey);
    print rtrim(ltrim($xx[0]));
  }
?></key>
</fobkey>
