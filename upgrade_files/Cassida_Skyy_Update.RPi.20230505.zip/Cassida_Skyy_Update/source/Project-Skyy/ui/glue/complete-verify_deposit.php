<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');
  $CoinsName   = do_getconf($parseconf,"terms",'Coins','Coins');
  $RollsName   = do_getconf($parseconf,"terms",'Rolls','Rolls');
  $Icon = do_getconf($parseconf,"icons", "Verify", 'notes.svg');

  $doohickey=do_getvar("doohickey","");

  // here's a hacky way of grabbing the 'enable_posting' var out of 'banking.conf'
  $enable_posting=ltrim(rtrim(shell_exec("bash -c '" . 'source /var/cache/skyy/banking.conf; echo $enable_posting' . "'")));

  $Equipment = coin_counter_equipment();

  $Solution = skyyreq("count-entity");
  eval($Solution); // to figure out whicvh equipment I have


  // NOTE:  if banking transactions are enabled _AND_ if banking is enabled
  //        for 'Build Tills' then I need to confirm before proceeding

  if($doohickey=="")
  {
    $VerifyBanking = do_getconf($parseconf, "Verify", "Banking", "");

    if($enable_posting == "true" && // in this case I enable posting transactions
       ($VerifyBanking == "yes" || $VerifyBanking == "1") )  // allow either 'yes' or '1' for now
    {
      // loose coins
      $count1c = '0';
      $count5c = '0';
      $count10c = '0';
      $count25c = '0';
      $count100c = '0';

      if(coin_counter_is_recycler($Equipment))
      {
        $Solution = skyyreq("result-recycler");
        eval($Solution);

        $count1x = $count1c;
        $count5x = $count5c;
        $count10x = $count10c;
        $count25x = $count25c;
        $count100x = $count100c;

        // next get the current count
        $Solution = skyyreq("snapshot-recycler");
        eval($Solution);

        // calculate payout
        $count1c   = $count1x - $count1c;
        $count5c   = $count5x - $count5c;
        $count10c  = $count10x - $count10c;
        $count25c  = $count25x - $count25c;
        $count100c = $count100x - $count100c;
      }

      // loose bills
      $count1 = '0';
      $count2 = '0';
      $count5 = '0';
      $count10 = '0';
      $count20 = '0';
      $count50 = '0';
      $count100 = '0';

      $Solution = skyyreq("result-zeus");
      eval($Solution);

      $CountTotal = 100 * $count100 + 50 * $count50 + 20 * $count20
                  + 10 * $count10 + 5 * $count5 + 2 * $count2 + $count1
                  + $count100c + 0.25 * $count25c + 0.10 * $count10c
                  + 0.05 * $count5c + 0.01 * $count1c;
?>
    <HTML>
      <HEAD>
        <TITLE>Verify Deposit - Transaction Amount Verify</TITLE>
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br />
        <br />
        <br />
        <br />
        <H1>
          <center>
            Verify Deposit<br>
            Confirm Transaction Amount
          </center>
        </H1>
        <center>
          <span style="font-size:26px;color:black">
            <b>
              Total Deposit:&nbsp;&nbsp;$<?php print currency_form($CountTotal); ?>
            </b>
          </span>
          <br />
          <br />
          <br />
          <br />
          <form id=none method=GET></form>
          <form id=done method=GET>
            <input type=hidden name="doohickey" value="N" style="visibility:hidden" />
          </form>
          <table width=75% align=center>
            <tr>
              <td>
                <center>
                  <button type=submit form=none formaction="/verify_deposit-notes-results.php"
                          style="height:42px;width:100px;font-size:28px;color:white;background-color:#625cff">
                    Back
                  </button>
                </center>
              </td>
              <td>
                <center>
                  <button type=submit form=none formaction="/tasks.php"
                          style="height:42px;width:100px;font-size:28px;color:white;background-color:#625cff">
                    Exit
                  </button>
                </center>
              </td>
              <td>
                <center>
                  <button type=submit form=done formaction="/glue/complete-verify_deposit.php"
                          style="height:42px;width:100px;font-size:28px;color:white;background-color:#625cff">
                    Done
                  </button>
                </center>
              </td>
            </tr>
          </table>
      </BODY>
    </HTML>
<?php
    }
    else
    {
?>
    <HTML>
      <HEAD><TITLE>re-direct</TITLE>
        <meta http-equiv="refresh" content="0.2;url=/glue/complete-verify_deposit.php?doohickey=Y">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br><br><br><H1><center>Verify Deposit Complete</center></H1>
      </BODY>
    </HTML>
<?php
    }
  }
  else if($doohickey=="N")
  {
?>
    <HTML>
      <HEAD><TITLE>re-direct</TITLE>
        <meta http-equiv="refresh" content="0.2;url=/glue/complete-verify_deposit.php?doohickey=Y">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br><br><br><H1><center>Verify Deposit Complete<br>Posting Banking Transaction</center></H1>
      </BODY>
    </HTML>
<?php
  }
  else // $doohickey == "Y"
  {
    skyyreq("complete");

    skyyreq("complete-verify-deposit");

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /tasks.php");
  }
?>

