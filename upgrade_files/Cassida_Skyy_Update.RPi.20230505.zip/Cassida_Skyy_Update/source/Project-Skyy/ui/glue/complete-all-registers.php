<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  header("HTTP/1.0 302 Moved Temporarily");
  header("Location: /tasks.php");

  // TODO:  if this is not fast enough then put up a 'doohickey' page for user UI feedback

  skyyreq("complete-registers");

  skyyreq("print-totals");
?>

