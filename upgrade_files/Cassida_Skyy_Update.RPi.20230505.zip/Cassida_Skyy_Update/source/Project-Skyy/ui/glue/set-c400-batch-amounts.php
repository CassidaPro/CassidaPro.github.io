<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php"; // things common to all

  if ($_SERVER['REQUEST_METHOD'] == 'POST')
  {
    $next = do_postvar("next", "");

    // pre-assign with original defaults
    $c1  = do_postvar("c1",  "100");
    $c5  = do_postvar("c5",  "40");
    $c10 = do_postvar("c10", "50");
    $c25 = do_postvar("c25", "40");

//    extract($_POST, EXTR_OVERWRITE);

    header("HTTP/1.0 302 Moved Temporarily");
    if(strlen($next) > 0)
    {
      header("Location: " . $next);
    }
    else
    {
      header("Location: /");
    }

    header("Expires: 0");

    skyyreq("batch-quantity/1/" . $c1 . "/5/" . $c5
            . "/10/" . $c10 . "/25/" . $c25 );
  }
  else
  {
    header("HTTP/1.0 500 Server Error");
  }
?>

