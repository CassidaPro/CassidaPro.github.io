<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Straps = do_getconf($parseconf,"terms",'Straps','Straps');

  $BuildButton = do_getconf($parseconf,"terms",'BuildButton','Build Tills');
  $Register = do_getconf($parseconf,"vessels",'Class3','Tills');

  // some things go differently if we are using a Recycler for counting coins
  $Equipment = coin_counter_equipment(0);

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title><?php print $BuildButton; ?> <?php print make_singular($Straps); ?> Quantity</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
      table, th, td, tdata, tr
      {
        border: 0px;
        padding: 0;
      }
    </style>

    <script>
      var output = "qty";

      function DoClick(key) // keypad click number key
      {
        var ww = document.getElementById(output);
        var strText = ww.value;

        console.log(output + ' ' + ww.id + ' ' + ww.value + ' ' + key);

        if(ww.id == "rv1")
        {
          var vv = Math.floor(strText * 10);

          console.log(vv);

          vv = (vv * 10 + Math.floor(key)) / 10;

          console.log(vv);

          ww.value = vv.toFixed(2);
        }
        else
        {
          ww.value = ww.value * 10 + Math.floor(key);
        }
      }

      function DoClickClr() // keyboard click clear
      {
        document.getElementById(output).value = '0';
      }

      function DoClickEntor() // keyboard click 'entor' which is like 'enter' but more epic
      {
        console.log('Entor');
      }


      function doSelChange()
      {
        var vv;
        vv = document.forms["selector"]["entitynum"].value;
        //document.getElementById("entitynum"),value;
        if(vv > 0)
        {
          document.forms["submitTheNumber"]["qty"].value = vv;
        }

        DoCheckValidNumber();
      }
    </script>

  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">
          <?php print make_singular($Straps); ?> Quantity
          <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
               src="img/count-notes.svg"></a>
        <div id="entity" class="area">
          <?php print strtoupper($BuildButton); ?>
        </div>
      </div>
    </nav>

    <div style="margin-top:0.3rem">
      <center>
        <span style="font-size:0.9rem;line-height:1rem;">
          Create <?php print strtolower($Straps); ?>
          for all denominations<!--br-->
          with 5 or more
          <?php print strtolower($Notes); ?>
          per
          <?php print strtolower(make_singular($Register)); ?>
        </span>
      </center>
    </div>

    <form name="strap_qty" id="strap_qty"
          action="/glue/initiate-build_tills-straps.php"
          method="post"
          onsubmit="return DoOnSubmit">
    </form>
    <table width="100%" style="padding:0;margin:0;line-height:1.2rem">
      <tr style="padding:0;margin:0;line-height:1.2rem;max-height:1.4rem">
        <td width=30%>&nbsp;</td>
        <td width=30%>
          <div class="row button-row">
            <div class="input-selector" id="a1">
              <label><?php print $Straps; ?> Quantity</label>
              <div class="mdl-textfield denom" style="padding:0">
                <input name="qty" id="qty" form="strap_qty"
                       class="mdl-textfield__input special-text-input"
                       type="text" value="" maxlength="3" disabled />
              </div>
            </div>
          </div>
        </td>
        <td width=40%>
          <div id="value-warn" style="display:none;font-size:0.83rem">Must be between 1 and 100</div>
        </td>
      </tr>
    </table>

    <div id="quantity" class="center">
      <div class="row">
        <div id="registers-calc" class=" calc-card mdl-card mdl-shadow--2dp">
        <div class="buttons" id="wrapper">
          <button onClick="DoClick('7');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">7</button>
          <button onClick="DoClick('8');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">8</button>
          <button onClick="DoClick('9');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">9</button>
          <button onClick="DoClickClr();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent">
            <span style="display:none">backspace</span>
            <img src="img/baseline-backspace-24px.svg" style="color:white">
          </button>

          <button onClick="DoClick('4');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">4</button>
          <button onClick="DoClick('5');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">5</button>
          <button onClick="DoClick('6');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">6</button>
          <button class="mdl-button">&nbsp;</button>

          <button onClick="DoClick('1');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">1</button>
          <button onClick="DoClick('2');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">2</button>
          <button onClick="DoClick('3');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">3</button>
          <button onClick="DoClickEntor();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent tall"
                  style="line-height:1em;height:">
            E<br/>n<br/>t<br/>e<br/>r
          </button>

          <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide">0</button>
        </div>
      </div>
      <form>
        <div class="prev-button registers-done">
<?php
    $auth = ltrim(rtrim(skyyreq("fobkey-auth-required-payout"))); // needed for payout screen

    if(coin_counter_is_recycler($Equipment) // only do this check if auth not required or already authenticated
       && ((strlen($auth) && $auth == 0) || is_authenticated(true) == "OK"))
    {
      if(coin_counter_is_recycler_twin($Equipment))
      {
        // this is not perfect and if the screen goes stale y ou could still end up
        // being prompted to re-auth but then if you do not then exit should work correctly
        // and not put you into an inescapable condition
?>
          <input  type="hidden" name="origin" value="/tasks.php" style="visibility:hidden" />
          <input  type="hidden" name="next" value="/build_tills-strap-qty.php" style="visibility:hidden" />
          <button formaction="/dispense-coins.php" class="waves-effect btn-flat primary-text">
<?php
      }
      else
      {
?>
          <button formaction="/build_tills-make-baggies.php" class="waves-effect btn-flat primary-text">
<?php
      }
?>
            Back
<?php
    }
    else
    {
?>
          <button formaction="/tasks.php" class="waves-effect btn-flat primary-text">
            Cancel
<?php
    }
?>
          </button>
        </div>
        <div class="next-button registers-done">
          <button name="next" id="next" class="btn waves-effect primary-fill btn-shadow" type="button" onclick="OnClickNext();" disabled>
            NEXT &gt;
          </button>
        </div>
      </form>
    </div>

    <!--  Scripts-->
    <script>
    //-- Set Defaults  --//
      var nDisplayed = 10;

      function setTotal ()
      {
        // does nothing, presence required by some of the previously written scripts
      }

      function OnClickNext()
      {
        var x = document.getElementById("qty").value;
        if (x == "" || x < 1 || x > 100)
        {
          window.alert("Please select a valid strap quantity");
          return false;
        }

        document.getElementById("qty").disabled = false; // needs to be enabled
        document.forms["strap_qty"].submit();
      }

      function DoCheckValidNumber()
      {
        var x = document.getElementById("qty").value;
        if (x == "" || x < 1 || x > 100)
        {
          document.getElementById("next").disabled = true;
          if(nDisplayed < 10)
          {
            document.getElementById("value-warn").style = "font-size:20px";
            nDisplayed += 1;
          }
          else
          {
            document.getElementById("value-warn").style = "display:none;font-size:20px";
          }
        }
        else
        {
          document.getElementById("next").disabled = false;
          nDisplayed = 0;
          document.getElementById("value-warn").style = "display:none;font-size:20px";
        }
      }

      setInterval(DoCheckValidNumber, 200);

    </script>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>

