<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include 'glue/utility_functions.php';

  $ssh_running = ltrim(rtrim(shell_exec("ps ax | grep 'sshd -D' | grep -v grep | awk '{print $0;}'")));
    // note: should return blank string if NOT running...

  if(strlen($ssh_running) > 0)
  {
    $ssh_running = true;
  }
  else
  {
    $ssh_running = false;
  }

  $Info = my_get_var("info", "");
  if($Info == "YY")
  {
?>
  <!DOCTYPE html>
  <HTML lang="en">
    <HEAD>
      <meta http-equiv="refresh" content="30;url=/networking.php">
      <TITLE>Network Test</TITLE>
      <style>
        html
        {
          font-size:<?php print round(cached_font_size() * 0.5); ?>px !important;
        }
        body
        {
          font-size: inherit;
        }
      </style>
    </HEAD>
    <BODY>
      <iframe src="http://cassidapro.com/" style="position:absolute;width:100%;height:100%;left:0;top:0"/>
    </BODY>
  </HTML>
<?php
    exit;
  }
  else if($Info == "Y")
  {
?>
  <!DOCTYPE html>
  <HTML lang="en">
    <HEAD>
      <meta http-equiv="refresh" content="30;url=/networking.php">
      <TITLE>Network Status</TITLE>
      <style>
        html
        {
          font-size:<?php print round(cached_font_size() * 0.5); ?>px !important;
        }
        body
        {
          font-size: inherit;
        }
      </style>
    </HEAD>
    <BODY>
      <PRE>
<?php
  print "interfaces\n";
  print shell_exec("ifconfig -a");
  print "\n\n------------------------------------------------------------------\n";
  print "routing\n";
  print shell_exec("netstat -nr");
  print "\n\n------------------------------------------------------------------\n";
  print "resolv.conf\n";
  print shell_exec("cat /etc/resolv.conf");
?>
      </PRE>
      <form id=none method=GET>
        <input type=hidden name=info value="YY" style="visibility:hidden" />
      </form>
      <center><button type=submit" formaction="networking.php" form="none" style="font-size:2rem">Test</button></center>
    </BODY>
  </HTML>
<?php
    exit;
  }


  // see https://www.php.net/manual/en/function.parse-ini-file.php
  //
  // can store individual network paramas as INI file

  $ap_ssid="";
  $ap_pass="";
  $ap_ip="";
  $ap_channel="";
  $ap_mode="";
  $ap_subnet="";
  $ap_wpa="";
  $ap_wpa_key_mgmt="";
  $ap_wpa_pairwise="";
  $ap_hostname="";

  $xx=shell_exec("if test -e /var/cache/skyy/hostapd.conf ; then echo Y ; fi");

  if(ltrim(rtrim($xx)) == "Y")
  {
    // parse config for AP
    $parseconf = parse_ini_file("/var/cache/skyy/hostapd.conf",
                                FALSE, // to NOT process sections
                                INI_SCANNER_NORMAL); // process values normally

    if(empty($parseconf))
    {
      $parseconf = [];
    }

    foreach($parseconf as $kk => $xx)
    {
      if($kk == "ssid")
      {
        $ap_ssid = $xx;
      }
      else if($kk == "channel")
      {
        $ap_channel = $xx;
      }
      else if($kk == "hw_mode")
      {
        $ap_mode = $xx;
      }
      else if($kk == "wpa")
      {
        $ap_wpa = $xx;
      }
      else if($kk == "wpa_key_mgmt")
      {
        $ap_wpa_key_mgmt = $xx;
      }
      else if($kk == "wpa_pairwise")
      {
        $ap_wpa_pairwise = $xx;
      }
      else if($kk == "wpa_passphrase")
      {
        $ap_pass = $xx;
      }
//      else
//      {
//        print "key: " . $kk . "  -->  " . $xx;
//      }
    }

    // next, parse out the 'ap_wlan' config file with IP addresses
    $xx=shell_exec("if test -e /var/cache/skyy/ap_wlan ; then echo Y ; fi");
    if(ltrim(rtrim($xx)) == "Y")
    {
      $ap_ip=shell_exec("grep address /var/cache/skyy/ap_wlan | awk '{print $2;}'");
      $ap_gw=shell_exec("grep gateway /var/cache/skyy/ap_wlan | awk '{print $2;}'");
      $ap_mask=shell_exec("grep netmask /var/cache/skyy/ap_wlan | awk '{print $2;}'");

      if(strlen($ap_mask) == 0 && strpos($ap_ip, "/") !== false)
      {
        $ap_mask = strstr($ap_ip, "/");
        $ap_ip = strstr($ap_ip, "/", true); // the part before the '/'
      }

      // AP hostname is in ap_hosts
      $ap_hostname=ltrim(rtrim(shell_exec("grep '" . $ap_ip . "' /var/cache/skyy/ap_hosts | awk '{print $2;}'")));
    }
    else
    {
      $ap_ip="";
      $ap_gw="";
      $ap_mask="";
      $ap_hostname="";
    }
  }

  // next parse out information for wireless client

  $parseconf = parse_ini_file("/var/cache/skyy/wireless.conf",
                              TRUE, // to process sections
                              INI_SCANNER_NORMAL); // process values normally

  if(empty($parseconf))
  {
    $parseconf = [];
  }

  // I look for the one with 'default=1'

  $client_ssid="";
  $client_pass="";
  $client_dhcp="";
  $client_wpa="";
  $client_fixed_ip="";
  $client_subnet="";
  $client_dns="";
  $client_gateway="";

  $wifi_enabled="off";

  if(!empty($parseconf["___global_settings___"]))
  {
    $wifi_enabled = empty($parseconf["___global_settings___"]["wifi_enabled"]) ? "off" // 'off' translates into a blank
                    : $parseconf["___global_settings___"]["wifi_enabled"];

    if(strtoupper($wifi_enabled) == "ON" || $wifi_enabled == "1") // strangely this is a glitch in the parser
      $wifi_enabled = "on";
    else
      $wifi_enabled = "off";
  }

  foreach($parseconf as $kk => $xx)
  {
    $the_one = 0;

    foreach($xx as $k => $yy)
    {
      if($k == "default")
      {
        $the_one = $yy; // default=1 if it's the current one
      }
    }

    if($the_one > 0)
    {
      $client_ssid = $kk;
      foreach($xx as $k => $yy)
      {
        if($k == "dhcp")
        {
          if($yy == "1" || $yy == "on" || $yy == "ON")
            $client_dhcp = "on";
          else
            $client_dhcp = "off";
        }
        else if($k == "passphrase")
        {
          $client_pass=$yy;
        }
        else if($k == "fixed_ip")
        {
          $client_fixed_ip=$yy;
        }
        else if($k == "subnet" )
        {
          $client_subnet=$yy;
        }
        else if($k == "dns" )
        {
          $client_dns=$yy;
        }
        else if($k == "gateway" )
        {
          $client_gateway=$yy;
        }
        else if($k == "wpa")
        {
          $client_wpa=$yy;
        }
      }

      break;
    }
  }

  // NOTE:  if the ssid is blank, disable wifi
  if(strlen(ltrim(rtrim($client_ssid))) == 0)
  {
    $wifi_enabled="off";
  }

  // finally parse out information for ethernet

  $ethernet_dhcp="";
  $ethernet_fixed_ip="";
  $ethernet_subnet="";
  $ethernet_dns="";
  $ethernet_gateway="";

  $ethernet_enabled="";

  $tval=shell_exec("grep eth0 /var/cache/skyy/ethernet");
  if(strlen($tval) > 0)
  {
    if(substr($tval,0,1)=='#') // commented out
      $ethernet_enabled="off";
    else
      $ethernet_enabled="on";

    // next, parse out the 'ap_wlan' config file with IP addresses
    $ethernet_dhcp=shell_exec("grep dhcp /var/cache/skyy/ethernet | awk '{print $2;}'");
    if(strlen($ethernet_dhcp) == 0)
      $ethernet_dhcp = "off";
    else
      $ethernet_dhcp = "on";

    $ethernet_fixed_ip=ltrim(rtrim(shell_exec("grep address /var/cache/skyy/ethernet | awk '{print $2;}'")));
    $ethernet_gateway=ltrim(rtrim(shell_exec("grep gateway /var/cache/skyy/ethernet | awk '{print $2;}'")));
    $ethernet_subnet=ltrim(rtrim(shell_exec("grep netmask /var/cache/skyy/ethernet | awk '{print $2;}'")));
    $ethernet_dns=ltrim(rtrim(shell_exec("grep '$#' | grep nameserver /var/cache/skyy/ethernet | awk '{print $3;}'")));

    if(strlen($ethernet_subnet) == 0 && strpos($ethernet_fixed_ip, "/") !== false)
    {
      $ethernet_subnet = strstr($ethernet_fixed_ip, "/");
      $ethernet_fixed_ip = strstr($ethernet_fixed_ip, "/", true); // the part before the '/'
    }
  }
  else
  {
    $ethernet_enabled="off";
  }

?>

<!DOCTYPE html5>
<?php html_tag_with_lingo(); ?>
<HEAD>
  <!-- adjust for device width, particularly phones -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <TITLE>
    Split Recycler Network Setp
  </TITLE>
  <link href="/css/networking.css" type="text/css" rel="stylesheet" media="screen,projection" />
  <link rel="shortcut icon" href="/img/favicon.ico">
  <style>
<?php
  set_ideal_font_height();
?>
  </style>
</HEAD>
<BODY <?php print $BodyTagDefs; ?>>
<center>
  <H2 style="margin-top:-4px;margin-bottom:0px;padding=0px;">
    Network Configuration
  </H2>
  <H4 id=clock style="margin-top:4px;margin-bottom:8px;padding=0px;">
    <?php print shell_exec("/bin/date"); ?>
  </H4>
  <noscript>
    <span style="font-size:16px">
      WARNING - this web site requires<br>script in order to work properly
    </span>
  </noscript>
  <script>
    function OnClickPassVisibility()
    {
      var bViewPass = document.getElementById("viewpass").checked;

      if(bViewPass == true)
      {
        document.getElementById("disppass").innerHTML = document.getElementById("passphrase").value;
      }
      else
      {
        document.getElementById("disppass").innerHTML = "********";
      }
    }
    function OnClickPassVisibility2()
    {
      var bViewPass = document.getElementById("viewpass2").checked;

      if(bViewPass == true)
      {
        document.getElementById("disppass2").innerHTML = document.getElementById("passphrase2").value;
      }
      else
      {
        document.getElementById("disppass2").innerHTML = "********";
      }
    }
    function DoEnableSSH()
    {
      var myRequest;

      // NOTE:  this is called after assigning the new 'checked' value

      if(document.getElementById("ssh_running").checked == false)
      {
        console.log("disable ssh");
        myRequest = new Request("/glue/ssh-enable.php?Semprini=0");
      }
      else
      {
        console.log("enable ssh");
        myRequest = new Request("/glue/ssh-enable.php?Semprini=1");
      }

      fetch(myRequest)
        .then(function(response)
              {
                if (!response.ok)
                {
                  console.log("status", response.status);
                }
                return  response.text();
              })
        .then(function(text)
              {
                // for now does nothing.  later, verify it's on??
              });
    }

  </script>
<table width=100%><tr><td>
 <center>
<?php
  $xx = ltrim(rtrim(shell_exec("cat /etc/hostname")));
  if(strlen($xx) > 0)
  {
?>
      <div style="font-size:0.75rem;font-weight:bold">
        <?php print "Network ID" . ": " . $xx; ?>
      </div>
<?php
  }
?>

  <table><tr style="vertical-align:top"><td align=left width="50%">
    <center>
<?php
  if(0) // disable wireless AP
  {
?>
      <div style="font-size:0.75rem;font-weight:bold">
        Wireless Access Point (AP Mode)
      </div>
      <table border=1px width=370>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem;">
            SSID:&nbsp;&nbsp;
          </td>
          <td style="valign:top;text-align:left;">
            <span style="valign:top;text-align:left;font-size:0.75rem"><?php print $ap_ssid; ?></span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Pass:","Contr:"); ?>&nbsp;&nbsp;
          </td>
          <td>
            <table style="padding:0;border:0;margin:0">
              <tr style="padding:0;border:0;margin:0">
                <td style="width:6.5rem;padding:0;border:0;margin:0">
                  <span id=disppass style="font-size:0.65rem">********</span>
                </td>
                <td align=right style="font-size:0.45rem;white-space:nowrap">
                  <input id=viewpass type=checkbox onClick="OnClickPassVisibility()">
                    <?php do_multi_lingo_text("View&nbsp;Pass","Ver&nbsp;Contr"); ?>
                  </input>
                </td>
              </tr>
            </table>
            <input type=hidden id=passphrase style="visibility:hidden" <?php print 'value="' . $ap_pass . '"'; ?> ></input>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Mode","Moda"); ?>:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem"><?php print $ap_mode; ?></span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Channel","Canal"); ?>:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem"><?php print $ap_channel; ?></span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            WPA:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem">
              <?php print $ap_wpa . ", " . $ap_wpa_key_mgmt . ", " . $ap_wpa_pairwise; ?>
            </span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            URL:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem">http://<?php print $ap_hostname; ?>/</span>
          </td>
        </tr>
      </table>
      <br>
<?php
  }
?>
      <div style="font-size:0.75rem;font-weight:bold">
        <?php do_multi_lingo_text("Wireless Client","Cliente Inalámbrico"); ?>
        <?php if($wifi_enabled != "on" && $wifi_enabled != "ON" && $wifi_enabled != "1")
                do_multi_lingo_text("(wifi disabled)", "(wifi deshabilitado)"); ?>
      </div>
<?php
  if($wifi_enabled == "on" || $wifi_enabled == "ON" || $wifi_enabled == "1")
  {
?>
      <table border=1px width=370>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem;">
            SSID:&nbsp;&nbsp;
          </td>
          <td style="valign:top;text-align:left;">
            <span style="valign:top;text-align:left;font-size:0.75rem"><?php print $client_ssid; ?></span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Pass:","Contr:"); ?>&nbsp;&nbsp;
          </td>
          <td>
            <table style="padding:0;border:0;margin:0">
              <tr style="padding:0;border:0;margin:0">
                <td style="width:6.5rem;padding:0;border:0;margin:0">
                  <span id=disppass2 style="font-size:0.65rem">********</span>
                </td>
                <td align=right style="font-size:0.45rem;white-space:nowrap">
                  <input id=viewpass2 type=checkbox onClick="OnClickPassVisibility2()"
                         style="padding:0;margin:0" >
                    <?php do_multi_lingo_text("View&nbsp;Pass","Ver&nbsp;Contr"); ?>
                  </input>
                </td>
              </tr>
            </table>
            <input type=hidden id=passphrase2 style="visibility:hidden" <?php print 'value="' . $client_pass . '"'; ?> ></input>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem;">
            WPA:&nbsp;&nbsp;
          </td>
          <td style="valign:top;text-align:left;">
            <span style="valign:top;text-align:left;font-size:0.75rem"><?php print $client_wpa; ?></span>
          </td>
        </tr>
<?php
      if($client_dhcp == "off")
      {
?>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Fixed&nbsp;IP","IP Fija"); ?>:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem">
              <?php print $client_fixed_ip; ?>
            </span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Subnet","Subred"); ?>:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem">
              <?php print $client_subnet; ?>
            </span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            DNS:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem">
              <?php print $client_dns; ?>
            </span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Gateway","Puerta&nbsp;Enlace"); ?>:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem">
              <?php print $client_gateway; ?>
            </span>
          </td>
        </tr>
<?php
      }
      else
      {
?>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem;">
            DHCP:&nbsp;&nbsp;
          </td>
          <td style="valign:top;text-align:left;">
            <span style="valign:top;text-align:left;font-size:0.75rem"><?php print $client_dhcp; ?></span>
          </td>
        </tr>
<?php
      }
?>
      </table>
<?php
    }
?>
    </center>
  </td><td width="50%">
    <center>
      <div style="font-size:0.75rem;font-weight:bold">
        Ethernet <?php if($ethernet_enabled != "on" && $ethernet_enabled != "ON" && $ethernet_enabled != "1")
                         do_multi_lingo_text("(ethernet disabled)","(ethernet deshabilitado"); ?>
      </div>
<?php
    if($ethernet_enabled == "on" || $ethernet_enabled == "ON" || $ethernet_enabled == "1")
    {
?>
      <table border=1px width=370>
<?php
      if($ethernet_dhcp == "off")
      {
?>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Ethernet&nbsp;Fixed&nbsp;IP","IP&nbsp;Fija&nbsp;Ethernet"); ?>:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem">
              <?php print $ethernet_fixed_ip; ?>
            </span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Ethernet&nbsp;Subnet","Subred&nbsp;Ethernet"); ?>:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem">
              <?php print $ethernet_subnet; ?>
            </span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Ethernet&nbsp;DNS","DNS&nbsp;Ethernet"); ?>:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem">
              <?php print $ethernet_dns; ?>
            </span>
          </td>
        </tr>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem">
            <?php do_multi_lingo_text("Ethernet&nbsp;Gateway","Puerta&nbsp;Enlace&nbsp;Ethernet");?>:&nbsp;&nbsp;
          </td>
          <td>
            <span style="valign:top;text-align:left;font-size:0.75rem">
              <?php print $ethernet_gateway; ?>
            </span>
          </td>
        </tr>
<?php
      }
      else
      {
?>
        <tr>
          <td style="valign:top;text-align:right;font-size:0.75rem;">
            <?php do_multi_lingo_text("Ethernet&nbsp;DHCP","DHCP&nbsp;Ethernet"); ?>:&nbsp;&nbsp;
          </td>
          <td style="valign:top;text-align:left;min-width:220">
            <span style="valign:top;text-align:left;font-size:0.75rem"><?php print $ethernet_dhcp; ?></span>
          </td>
        </tr>
<?php
      }
?>
      </table>
<?php
    }
?>
    </center>
  </td></tr></table>

    <form id=info mode=GET><input type=hidden name="info" value="Y" style="visibility:hidden" /></form>
    <form id=blank mode=GET></form>
    <table width="85%" style="margin:0;margin-bottom:4px;padding:0;position:absolute;left:7.5%;bottom:2.67rem;">
      <tr>
        <td>
          <button form="blank" formaction="/glue/reboot.php" type=submit >
            Re-Boot System
          </button>
        </td>
        <td>
          <div style="font-size:0.75rem">A Re-Boot is necessary to<br>apply any network changes</div>
        </td>
        <td width="26.7%">
          <right>
            <input type=checkbox id=ssh_running onchange="DoEnableSSH();" <?php if($ssh_running) print "checked"; ?> >
              <span style="font-size:0.8rem">SSH Enable</span>
            </input>
          </right>
        </td>
      </tr>
    </table>
    <table width="75%" style="position:absolute;left:12.5%;bottom:14px;">
      <tr>
        <td width=12.5% align=center>
          <button form="blank" formaction="/system-menu.php" type=submit >
            <?php do_multi_lingo_text("Back","Atrás"); ?>
          </button>
        </td>
        <td width=12.5% align=center>
          <center>
            <button form="blank" formaction="/wireless-client.php" type=submit >
              <?php do_multi_lingo_text("Wireless","Inalámbrica"); ?>
            </button>
          </center>
        </td>
        <td width=12.5% align=center>
          <center>
            <button form="blank" formaction="/ethernet-client.php" type=submit >
              Ethernet
            </button>
          </center>
        </td>
        <td width=12.5% align=center>
          <center>
            <button form="info" formaction="/networking.php" type=submit >
              Net&nbsp;Info
            </button>
          </center>
        </td>
      </tr>
    </table>
  </td></tr></table>
</center>
<script>

/*
  function DoTimeUpdate()
  {
    var myRequest = new Request("/glue/get_system_date.php");

    fetch(myRequest)
      .then(function(response)
            {
              if (!response.ok)
              {
                console.log("status", response.status);
              }
              return  response.text();
            })
      .then(function(text)
            {
              document.getElementById("clock").innerHTML = text;
            });

  }

  setInterval(DoTimeUpdate, 1000);
*/
</script>
</BODY>
</HTML>

