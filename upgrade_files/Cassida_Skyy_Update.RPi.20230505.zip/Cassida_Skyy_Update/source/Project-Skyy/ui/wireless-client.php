<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include 'glue/utility_functions.php';

  // see https://www.php.net/manual/en/function.parse-ini-file.php
  //
  // can store individual network paramas as INI file


  $save = my_get_var("save", "");

  if($save == "") // that is, NOT saving
  {
    $ssid=my_get_var("ssid");
    $load=my_get_var("load","1");
    $passphrase=my_get_var("passphrase");
    $bssid=my_get_var("bssid"); // currently unused
    $chan=my_get_var("chan");  // currently unused
    $wpa=my_get_var("wpa","WPA-PSK");

  //  print '<H1>' . $wpa . "</H1><br><br>\n";

    $dhcp=my_get_var("dhcp");
    $fixed_ip=my_get_var("fixed_ip");
    $subnet=my_get_var("subnet");
    $dns=my_get_var("dns");
    $gateway=my_get_var("gateway");

    // IPv6 support?
    $dhcp6=my_get_var("dhcp6");
    $fixed_ip6=my_get_var("fixed_ip6");
    $subnet6=my_get_var("subnet6");
    $dns6=my_get_var("dns6");
    $gateway6=my_get_var("gateway6");

    $wifi_enabled=my_get_var("wifi_enabled");


//    $parseconf = parse_ini_file("/var/cache/skyy/wireless.conf",
//                                TRUE, // to process sections
//                                INI_SCANNER_NORMAL); // process values normally

    $parseconf = parse_conf("/var/cache/skyy/wireless.conf");

    if(empty($parseconf))
    {
      $parseconf = [];
    }

    if(strlen($wifi_enabled) == 0) // was not a parameter
    {
      if(!empty($parseconf["___global_settings___"]))
      {
        $wifi_enabled = empty($parseconf["___global_settings___"]["wifi_enabled"]) ? "off"
                        : $parseconf["___global_settings___"]["wifi_enabled"];

        if($wifi_enabled == "1" || strtoupper($wifi_enabled) == "ON") // strangely this is a glitch in the parser
          $wifi_enabled = "on";
        else
          $wifi_enabled = "off";
      }
      else
      {
        $parseconf["___global_settings___"]["wifi_enabled"]="on"; // default is 'on' when it wasn't there...
        $wifi_enabled = "on";
      }
    }

    // I look for the one with 'default=1'
    if(strlen($ssid) == 0)
    {
      foreach($parseconf as $kk => $xx)
      {
        if($kk != $ssid)
        {
          $the_one = 0;

          foreach($xx as $k => $yy)
          {
            if($k == "default")
            {
              $the_one = $yy;
            }
          }

          if($the_one > 0)
          {
            $ssid = $kk;
            break;
          }
        }
      }

      $load=1;
    }

    if($load != 0)
    {
      foreach($parseconf as $kk => $xx)
      {
        if($kk == $ssid)
        {
          foreach($xx as $k => $yy)
          {
            if($k == "dhcp")
            {
              if($yy == "1" || $yy == "on" || $yy == "ON")
                $dhcp = "on";
              else
                $dhcp = "off";
            }
            else
            {
              $zzz = "$" . $k . '="' . preg_replace('/"/', '\\"',$yy) . '";';
              eval($zzz);
            }
          }

          break;
        }
      }
    }

    // NOTE:  if the ssid is blank, disable wifi
    if(strlen(ltrim(rtrim($ssid))) == 0)
    {
      $wifi_enabled="off"; // force it [later I'll enable if I select an SSID]
    }




?>

<!DOCTYPE html5>
<?php html_tag_with_lingo(); ?>
  <HEAD>
    <!-- adjust for device width, particularly phones -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <TITLE>
      Split Recycler - Wireless Client
    </TITLE>
    <link href="/css/networking.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="/img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
    </style>
    <script>
      function DoClickDHCP()
      {
        if(document.getElementById("dhcp").checked == true)
        {
          document.getElementById("fixed_ip_table").style.visibility = "hidden";
    //      document.getElementById("dhcp").value = "on";
        }
        else
        {
          document.getElementById("fixed_ip_table").style.visibility = "visible";
    //      document.getElementById("dhcp").value = "off";
        }
      }
      function doClickKB(strID)
      {
        do_vkey_single(strID, null);
      }
    </script>
  </HEAD>
  <BODY <?php print $BodyTagDefs; ?> >
  <center>
    <H1 style="font-size:1.2rem;margin:0px;padding=0px;">
      Split Recycler - Wireless Client Configuration
    </H1>
    <H4 id=clock style="font-size:0.83rem;margin-top:8px;margin-bottom:6px;padding=0px;"><?php print shell_exec("/bin/date"); ?></H4>
    <noscript style="visibility:none">
      <span style="font-size:0.67rem">
        <?php do_multi_lingo_text("WARNING - this web site requires<br>script in order to work properly",
                                  "ADVERTENCIA: este sitio web requiere<br>'script' para funcionar correctamente"); ?>
      </span>
    </noscript>
    <table width=95%><tr><td align=left>
      <form id=normal mode=GET>
        <input type=hidden name=save value="Y" style="visibility:hidden" />
        <center>
        <table>
          <tr>
            <td style="valign:top;text-align:center;font-size:0.75rem;">
              <input id=wifi_enabled name=wifi_enabled type=checkbox <?php if($wifi_enabled == "on") print "checked"; ?> >
                <?php do_multi_lingo_text("Enable Wifi Client", "Habilitar el Cliente Wifi"); ?>
              </input>
            </td>
          </tr>
        </table>
        <table>
          <tr>
            <td style="valign:top;text-align:right;font-size:0.75rem;">
              SSID:&nbsp;&nbsp;
            </td>
            <td style="valign:top;text-align:left;border:0;padding:0;margin:0">
              <table width=100% style="border:0;padding:0;margin:0">
                <tr style="border:0;padding:0;margin:0">
                  <td style="valign:top;text-align:left;border:0;padding:0;margin:0">
                    <input type=text id=ssid name=ssid size=16 style="valign:top;text-align:left;font-size:0.75rem" value=<?php print '"' . $ssid . '"'; ?> />
                    <a onClick='doClickKB("ssid");'><img src="/img/keyboard.png" width=36 height=36 style="vertical-align:middle"></a>
                  </td>
                  <td style="valign:top;text-align:right;border:0;padding:0;margin:0">
                    <button formaction="/glue/ssid-list.php" >
                      <?php do_multi_lingo_text("List","Lista"); ?>
                    </button>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="valign:top;text-align:right;font-size:0.75rem">
              <?php do_multi_lingo_text("Pass:","Contr:"); ?>&nbsp;&nbsp;
            </td>
            <td>
              <input type=text id=passphrase name=passphrase size=22 style="valign:top;text-align:left;font-size:0.75rem;" value=<?php print '"' . $passphrase . '"'; ?> />
              <a onClick='doClickKB("passphrase");'><img src="/img/keyboard.png" width=36 height=36 style="vertical-align:middle"></a>
            </td>
          </tr>
        </table>
        <!--br style="font-size:4px" -->
        <table>
          <tr style="vertical-align:middle;font-size:0.83rem">
            <td>
              <table style="width:15rem;font-size:0.83rem;">
                <tr align=left style="vertical-align: top;">
                  <td align=left style="min-height:1.67rem;vertical-align:middle;">
                    <span style="font-size:0.75rem !important;white-space: nowrap;">
                      <input id=dhcp name=dhcp type=checkbox
                             <?php if($dhcp == "on") print "checked"; ?>
                             onClick="DoClickDHCP();">
                        <?php do_multi_lingo_text("Use DHCP","Usar DHCP"); ?>
                      </input>
                    </span>
                  </td>
                  <td align=right style="min-height:1.67rem;vertical-align:top;">
                    <span style="padding-top:0;font-size:0.83rem !important;">
                      &nbsp;&nbsp;<?php do_multi_lingo_text("Security:","Seguridad:"); ?>
                    </span>
                  </td>
                  <td>
                    &nbsp;
                  </td>
                  <td align=left style="vertical-align: top;">
                    <select name=wpa style="font-size:0.83rem;padding-left:4;padding-right:4">
                      <option value="WPA-PSK" <?php if($wpa == "WPA-PSK") print "selected" . ' thingy="' . $wpa . '"'; ?> >
                        WPA-PSK
                      </option>
                      <option value="AES-PSK" <?php if($wpa == "AES-PSK") print "selected"; ?> >
                        AES-PSK
                      </option>
                      <option value="NONE" <?php if($wpa == "" || $wpa == "none" || $wpa == "NONE") print "selected"; ?> >
                        <?php do_multi_lingo_text("NONE","NADA"); ?>
                      </option>
                    </select>
                    <!--span style="white-space: nowrap;">
                      <input id=wpa name=wpa type=radio value="WPA-PSK" <?php if($wpa == "WPA-PSK") print "checked";?>>
                        WPA-PSK
                      </input>
                    </span>
                    <span style="white-space: nowrap;">
                      <input id=wpa name=wpa type=radio value="AES-PSK" <?php if($wpa == "AES-PSK") print "checked"; ?>>
                        AES-PSK
                      </input>
                    </span>
                    <span style="white-space: nowrap;">
                      <input id=wpa name=wpa type=radio value="NONE" <?php if($wpa == "" || $wpa == "none") print "checked"; ?>>
                        NONE
                      </input>
                    </span-->
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td>
              <table id=fixed_ip_table style="visibility:hidden">
                <tr style="font-size:0.75rem">
                  <td align=right style="valign:center">
                    <?php do_multi_lingo_text("IP&nbsp;Address","Dirección&nbsp;IP"); ?>:
                  </td>
                  <td>
                    <input name=fixed_ip id=fixed_ip size=18 style="font-size:0.83rem"
                            value=<?php print '"' . preg_replace('/"/', '""', $fixed_ip) . '"'; ?>/>
                    <a onClick='doClickKB("fixed_ip");'><img src="/img/keyboard.png" width=36 height=36 style="vertical-align:middle"></a>
                  </td>
                </tr>
                <tr style="font-size:0.75rem">
                  <td align=right style="valign:center">
                    <?php do_multi_lingo_text("Subnet&nbsp;Mask","Máscara&nbsp;Subred"); ?>:
                  </td>
                  <td>
                    <input name=subnet id=subnet size=18 style="font-size:0.83rem"
                           value=<?php print '"' . preg_replace('/"/', '""', $subnet) . '"'; ?>/>
                    <a onClick='doClickKB("subnet");'><img src="/img/keyboard.png" width=36 height=36 style="vertical-align:middle"></a>
                  </td>
                </tr>
                <tr style="font-size:0.75rem">
                  <td align=right style="valign:center">
                    <?php do_multi_lingo_text("DNS&nbsp;Server","Servidor&nbsp;DNS"); ?>:
                  </td>
                  <td>
                    <input name=dns id=dns size=18 style="font-size:0.83rem"
                           value=<?php print '"' . preg_replace('/"/', '""', $dns) . '"'; ?>/>
                    <a onClick='doClickKB("dns");'><img src="/img/keyboard.png" width=36 height=36 style="vertical-align:middle"></a>
                  </td>
                </tr>
                <tr style="font-size:0.75rem">
                  <td align=right style="valign:center">
                    <?php do_multi_lingo_text("Gateway","Puerta&nbsp;Enlace"); ?>:
                  </td>
                  <td>
                    <input name=gateway id=gateway size=18 style="font-size:0.83rem"
                           value=<?php print '"' . preg_replace('/"/', '""', $gateway) . '"'; ?>/>
                    <a onClick='doClickKB("gateway");'><img src="/img/keyboard.png" width=36 height=36 style="vertical-align:middle"></a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table></center>
      </form>
    </td></tr></table>
    <form id=blank mode=GET></form>
    <div style="position:absolute;bottom:0.8rem;left:0px;width:100%;align:center">
      <table width=75%>
        <tr>
          <td width=12.5%>&nbsp;</td>
          <td width=25% align=center>
            <button form="normal" formaction="/wireless-client.php" type=submit >
              <?php do_multi_lingo_text("Save","Salvar"); ?>
            </button>
          </td>
          <td width=25% align=center>
            <button form="blank" formaction="/wireless-client.php" type=submit style="white-space:nowrap">
              <?php do_multi_lingo_text("Re-load","Volver&nbsp;a&nbsp;Cargar"); ?>
            </button>
          </td>
          <td width=25% align=center>
            <button form="blank" formaction="/networking.php" type=submit >
              <?php do_multi_lingo_text("Back","Atrás"); ?>
            </button>
          </td>
          <!--td width=25% align=center>
            <button form="blank" formaction="/glue/reboot.php" type=submit style="white-space:nowrap">
              Re-boot
            </button>
          </td-->
          <td width=12.5%>&nbsp;</td>
        </tr>
      </table>
    </div>
  </center>

<?php

  include "glue/virtual_keyboard.php";

?>

  <script>
  /*
    function DoTimeUpdate()
    {
      var myRequest = new Request("/glue/get_system_date.php");

      fetch(myRequest)
        .then(function(response)
              {
                if (!response.ok)
                {
                  console.log("status", response.status);
                }
                return  response.text();
              })
        .then(function(text)
              {
                document.getElementById("clock").innerHTML = text;
              });
    }

    setInterval(DoTimeUpdate, 1000);
  */
    DoClickDHCP();

  </script>
  </BODY>
</HTML>
<?php
  }
  else if($save == "Y")
  {
    $ssid=my_get_var("ssid");
    $passphrase=my_get_var("passphrase");
    $bssid=my_get_var("bssid"); // currently unused
    $chan=my_get_var("chan");  // currently unused
    $wpa=my_get_var("wpa");//,"WPA-PSK");

    $dhcp=my_get_var("dhcp");
    $fixed_ip=my_get_var("fixed_ip");
    $subnet=my_get_var("subnet");
    $dns=my_get_var("dns");
    $gateway=my_get_var("gateway");

    // IPv6 support?
    $dhcp6=my_get_var("dhcp6");
    $fixed_ip6=my_get_var("fixed_ip6");
    $subnet6=my_get_var("subnet6");
    $dns6=my_get_var("dns6");
    $gateway6=my_get_var("gateway6");

    $wifi_enabled=my_get_var("wifi_enabled");

    if(strlen($ssid) == 0)
    {
//      header("HTTP/1.0 500 Server Error");
//      exit;
      $wifi_enabled="off";
    }

    if(strlen($fixed_ip) == 0)
    {
      $dhcp="on"; // default DHCP if no IP address
    }
    if(strlen($fixed_ip6) == 0)
    {
      $dhcp6="on"; // same for IPv6 [when supported]
    }

    // save the configuration to a 'conf' style file with the following format
    //
    // [the_ssid]
    // passphrase="pass"
    // bssid="bssid"
    // chan="chan"
    // wpa="wpa"
    //
    // the one wih 'default=1' is the chosen SSID and is written to /var/cache/skyy/wifi_client_params

    $parseconf = parse_ini_file("/var/cache/skyy/wireless.conf",
                                TRUE, // to process sections
                                INI_SCANNER_NORMAL); // process values normally

    if(empty($parseconf))
    {
      $parseconf = [];
    }

    // make sure sections exist
    if(empty($parseconf["___global_settings___"]))
    {
      $parseconf["___global_settings___"]["wifi_enabled"] = $wifi_enabled;
    }

    $conf_out = "# generated by submit-wifi-settings.php - do not edit\n\n";

    foreach($parseconf as $kk => $xx)
    {
      if($kk == "___global_settings___")
      {
        $conf_out = $conf_out . "[" . $kk . "]\n";

        foreach($xx as $k => $yy)
        {
          if($k != "wifi_enabled")
          {
            $conf_out = $conf_out . $k . "=" . $yy . "\n";
          }
        }

        $conf_out = $conf_out . "wifi_enabled=" . $wifi_enabled . "\n\n";
      }
      else if($kk != $ssid)
      {
        $conf_out = $conf_out . "[" . $kk . "]\n";

        foreach($xx as $k => $yy)
        {
          if($k != "default")
          {
            $conf_out = $conf_out . $k . "=" . $yy . "\n";
          }
        }

        $conf_out = $conf_out . "\n";
      }
    }

    if(strlen($ssid) > 0)
    {
      $conf_out = $conf_out . "[" . $ssid . "]\n";
      $conf_out = $conf_out . "passphrase=" . $passphrase . "\n";
      $conf_out = $conf_out . "bssid=" . $bssid . "\n";
      $conf_out = $conf_out . "chan=" . $chan . "\n";
      $conf_out = $conf_out . "wpa=" . $wpa . "\n";

      $conf_out = $conf_out . "dhcp=" . $dhcp . "\n";
      if($dhcp != "on")
      {
        $conf_out = $conf_out . "fixed_ip=" . $fixed_ip . "\n";
        $conf_out = $conf_out . "subnet=" . $subnet . "\n";
        $conf_out = $conf_out . "dns=" . $dns . "\n";
        $conf_out = $conf_out . "gateway=" . $gateway . "\n";
      }

      $conf_out = $conf_out . "default=1\n" // the new default SSID
                . "\n\n"; // extra blank lines at the end
    }
//    // IPv6 support?
//    $dhcp6;
//    $fixed_ip6;
//    $subnet6;
//    $dns6;
//    $gateway6;

    // next write this to the conf file
    $the_file = fopen("/var/cache/skyy/wireless.conf", "w");

    if($the_file === false)
    {
      header("HTTP/1.0 500 Server Error");
      print ("<H1>Unable to write wireless.conf</H1>\n");
      exit;
    }

    fwrite($the_file, $conf_out);
    fclose($the_file);

    // now write to /var/cache/skyy/wifi_client_params if wifi is NOT disabled...

    if($wifi_enabled == "on" || $wifi_enabled == "1" || $wifi_enabled == "ON")
    {
      if(strlen($wpa) == 0)
        $wpa = "NONE";

      $ssid_sanized=preg_replace('/ /', "\\ ", $ssid);
      $passphrase_sanitized=preg_replace('/ /', "\\ ", $passphrase);
      $the_file = fopen("/var/cache/skyy/wifi_client_params", "w");

      if(strlen($passphrase_sanitized) > 0)
        $the_out = $ssid . " " . $passphrase . " " . $wpa . " ";
      else
        $the_out = $ssid . ' "" ' . $wpa . " ";

      if($dhcp == "on")
      {
        $the_out = $the_out . "DHCP";
      }
      else
      {
        $the_out = $the_out . $fixed_ip;

        // if subnet starts with a '/' then use it as-is
        // otherwise add a slash and possibly parse it later
        // so you'll see ip.ad.dr.ess/##
        //      or else  ip.ad.dr.ess/sub.net.ma.sk

        if(substr($subnet,0,1) != "/")
        {
          $the_out = $the_out . "/";
        }
        $the_out = $the_out . $subnet . " " . $gateway . " " . $dns;
      }

      fwrite($the_file, $the_out);
      fclose($the_file);
    }
    else
    {
      // TODO:  I think I'll need to truncate this instead - permissions...
//      unlink("/var/cache/skyy/wifi_client_params"); // remove the file - no wifi for YOU!
      $the_file = fopen("/var/cache/skyy/wifi_client_params", "w");
      fclose($the_file);
    }

?>
    <!DOCTYPE html5>
    <HTML>
      <HEAD>
        <!-- adjust for device width, particularly phones -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="refresh" content="3;url='/networking.php'">
        <TITLE>Split Recycler - Save Wireless Client Configuration</TITLE>
        <STYLE>
<?php
    set_ideal_font_height();
?>
          @font-face
          {
           font-family: Lato;
           src: url(/fonts/lato-v15-latin-regular.woff);
          }
          html
          {
            font-family: 'Lato';
          }
          body
          {
            font-size: inherit;
            background-color: #e0e0e0;
            color: #8068ff;
          }
        </STYLE>
      </HEAD>
      <BODY <?php print $BodyTagDefs; ?> >
      <center>
      <H1 style="margin:0px;padding=0px;font-size:1.5rem">Split Recycler</H1>
      <H2 style="margin-top:-4px;margin-bottom:4px;padding=0px;font-size:1rem">Wireless Configuration Saved</H2>
      <!--noscript><form mode=GET action="/"><button type="submit">OK</button></form></noscript-->
      </center>
      <!--script>
        function DelayThing()
        {
          window.location.replace("/"); // rather than using 'assign', no back button
        }

        setTimeout(DelayThing, 3000); // 3 seconds then exit
      </script-->
      </body>
    </html>
<?php
  }
?>

