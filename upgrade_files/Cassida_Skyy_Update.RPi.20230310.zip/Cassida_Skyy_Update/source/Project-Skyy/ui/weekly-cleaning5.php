<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */


  // ----------------------------------------------------------
  // Micro-fiber cleaning page - obsolete - left for reference
  // ----------------------------------------------------------


  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  // where 'back' will lead me
  $back = empty($_GET['back'])
        ?  empty($_SERVER['HTTP_REFERER']) ? "/cleaning.php" : $_SERVER['HTTP_REFERER']
        : $_GET['back'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>ZC4 - Weekly Cleaning</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Weekly Cleaning</a>
        <div class="area">Cleaning</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <br/>
    <center>
      <table style="width:85%;border:0">
        <tr style="margin:0 20 0 0px;line-height:28px;border:0">
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:none;padding:0;margin:0;margin-left:-20px">
                <b>Microfiber Cloth Cleaning</b>
              </LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">Grab the Microfiber Cloth.</LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">Locate the sensors on the front of the Zeus unit. Use the microfiber cloth to wipe away any loose particles/dust.</LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">Clean Hopper Sensors, Reject Sensors, Stacker Sensors</LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">Use the microfiber cloth to wipe down the screen and printer of the ZC4.</LI>
              <LI style="list-style-type:none;padding:0;margin:0;margin-left:-20px">
            </UL>
          </td>
        </tr>
      </table>
    </center>

    <form id=goback method=GET><input type=hidden name=back style="visibility:hidden" value=<?php print '"' . $back . '"';?> /></form>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;left:0px">
      <button type=submit form=goback formaction="/weekly-cleaning4.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/cleaning.svg" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">&nbsp; &nbsp;BACK</span>
      </button><br/>
    </div>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <button type=submit form=goback formaction="/weekly-cleaning6.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/cleaning.svg" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">&nbsp; &nbsp;NEXT</span>
      </button><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

