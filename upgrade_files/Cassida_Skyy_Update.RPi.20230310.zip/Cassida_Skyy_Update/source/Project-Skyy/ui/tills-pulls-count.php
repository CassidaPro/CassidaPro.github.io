<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $class = !empty($_GET) && !empty($_GET["class"]) ? $_GET["class"] : "";
  $thing = skyyreq("class-entity/" . $class);
  eval($thing); // todo, make this safer, see tasks.php

  if($Class != $class || $NumEntity == 0) // not valid
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="5;url=/tasks.php">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br>
      <H1>
        <center>
          Internal Error
        </center>
      </H1>
    </BODY>
    </HTML>
<?php
    exit;
  }

  // get terms and icons from config file
  // parse config file for things I need

  $TillIcon  = do_getconf($parseconf,"icons","Class3","register.svg");

  $PullTerm  = do_getconf($parseconf,"terms",'Pulls','Pulls');
  $PullIcon  = do_getconf($parseconf,"icons",'Pulls','straps.svg');


?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Count <?php print $Name; ?></title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Select Task</a>
        <div class="area">COUNT <?php print strtoupper($Name); ?></div>
      </div>
    </nav>
    <div class="container">
      <div class="row center">
        <div class="col s6 light">
          <a href="/entity-number.php?pull=Y&class=<?php print urlencode($class); ?>"
             style="line-height:1.7rem;"
             class="btn-large waves-effect primary-fill">COUNT <?php print strtoupper($PullTerm); ?>
             <br />
             <img style="width:<?php print round(cached_font_size() * 4); ?>px !important;height:<?php print round(cached_font_size() * 4); ?>px !important;"
                     src="img/<?php print $PullIcon; ?>" class="invertible-icon"></p></a>
        </div>
        <div class="col s6 light">
          <a href="/entity-number.php?class=<?php print urlencode($class); ?>"
             style="line-height:1.7rem;"
             class="btn-large waves-effect primary-fill">COUNT <?php print strtoupper($Name); ?>
             <br />
             <img style="width:<?php print round(cached_font_size() * 4); ?>px !important;height:<?php print round(cached_font_size() * 4); ?>px !important;"
                  src="img/<?php print $TillIcon; ?>" class="invertible-icon">
           </a>
        </div>
      </div>
    </div>
    <form id=none method="GET"></form>
    <div class="next-button">
      <a name="exit" id="exit" href="/tasks.php" class="btn waves-effect primary-fill btn-shadow">BACK</a>
    </div>

  </body>

  <script src="/js/UserFeedback.js"></script>

</html>

