<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');

  // coin bag threshold - the level above which the 'make baggies' screen appears after this one
  $coin_bag_threshold = 10 * intval(do_getconf($parseconf, "settings", "CoinBagThresholdPercent", "50"));

  $c400status=do_getvar("c400status","");

  $Equipment = coin_counter_equipment(0);

  $doohickey = do_getvar("doohickey", "");
  $TheMessage = do_getvar("TheMessage", "");

  $next=do_getvar("next","");   // needed when this page is part of a code flow
  $Class=do_getvar("class",""); // used along with 'next'

  $StartCount  = do_getvar("StartCount", "");

  if(strlen($next) > 0) // only in this case for now
  {
    $result = skyyreq("count-entity");
    eval($result); // this gives me a few nice things, $Entity, $EntitNum, $Class, and others
  }
  else
  {
    $Entity = "COUNT";
  }

  // for Recycler, grab the count again and display it

  if(!coin_counter_is_recycler($Equipment))
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /");

    return; // for now just do this
  }

  $pennies_batch = '0';
  $nickels_batch = '0';
  $dimes_batch = '0';
  $quarters_batch = '0';
  $dollars_batch = '0';

  $thingy = skyyreq("batch-quantity");
  eval($thingy); // note var names match coin counting, below

  $count1b = $pennies_batch;     // store batch qty in different vars
  $count5b = $nickels_batch;
  $count10b = $dimes_batch;
  $count25b = $quarters_batch;
  $count100b = $dollars_batch;

  $count1c = '0';
  $count5c = '0';
  $count10c = '0';
  $count25c = '0';
  $count100c = '0';

  $rval = "";
  $rval = skyyreq("snapshot-recycler");
  if(!strlen(rtrim(ltrim($rval))))
    $rval = skyyreq("snapshot-recycler"); // attempt to get it again

  if(!strlen(rtrim(ltrim($rval))))
  {
?>
      <HTML>
        <HEAD>
          <TITLE>re-direct</TITLE>
          <meta http-equiv="refresh" content="15;url="<?php print urlencode($_SERVER["REQUEST_URI"]); ?>">
<?php set_inbetween_style(); ?>
        </HEAD>
        <BODY>
          <br>
          <center>
            <H1>
              Internal Error
            </H1>
            <br>
            <span style="font-size:1.7rem">
              Page will attempt to reload and re-try automatically
            </span>
            <br>
            <span style="font-size:1.7rem">
              Press 'Cancel' to return to main screen
            </span>
            <br><br>
            <form method=GET action="/">
              <button type="Submit" value="Cancel" style="font-size:2rem;line-height:3rem">Cancel</button>
            </form>
          </center>
        </BODY>
      </HTML>
<?php
    exit;
  }

  eval($rval); // this gets the actual coin counts

  if(!strlen($StartCount)) // was there a start count?
  {
    // assign the start count using the current snapshot

    $StartCount = $count1c . "/" . $count5c . "/"
                . $count10c . "/" . $count25c . "/"
                . $count100c;
  }


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Make Baggies</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- CSS  -->

    <!-- taken from system.css -->
    <style>
<?php
  set_ideal_font_height();
?>
    </style>

  </head>
  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">Make Baggies <img src="/img/count-coins.svg"></a>
        <div id="entity" class="area"><?php print $Entity; ?></div>
      </div>
    </nav>

    <form id=none method=GET action="#">
      <input type=hidden name=doohickey value="Y" style="visibility:none" />
      <input type=hidden name=StartCount value="<?php print $StartCount; ?>" style="visibility:none" />
    </form>

    <div class="container">
      <div class="section" style="padding:0;margin:0">
        <div class="row center">
        <img src="/img/recycler.png" width=<?php print round(cached_font_size() * 240 / 24); ?>px
             height=<?php print round(cached_font_size() * 180 / 24); ?>px style="background-color:transparent">
          <!-- width=240 height=180 -->
        </div>
        <div
<?php
  $emfactor = 1.0 / 24.0; // convert to em (height)
  $emfactorW = 1.0 / cached_font_size();
  $pos=220;   // bottom of thermometer bar
  $scale=130; // scale (height) of thermometer bar at 100%

  $coinz = coin_count_and_relative_volume(true);
  $vol0 = floor($coinz["volume"] * $scale / 1000 + 0.5); // 1000 -> 'scale' px

  if($coin_bag_threshold <= 0 || $coin_bag_threshold > 1000)
    $coin_bag_threshold = $scale / 2;
  else
    $coin_bag_threshold = $coin_bag_threshold * $scale / 1000;

  if($vol0 >= $coin_bag_threshold)
    $vol = $coin_bag_threshold;
  else
    $vol = $vol0;

//  print 'style="background-color:#00ff00;position:absolute;left:393px;width:14px;';
  print 'style="background-color:#00ff00;margin:0;padding:0;'
      . ';position:absolute;left:' . (cached_screen_width() * $emfactorW / 2 - 7 * $emfactor - 0.125)
      . 'rem;width:' . 14 * $emfactor . 'rem;';
  print 'top:' . (($pos - $vol) * $emfactor + 0.125). 'rem;';
  print 'height:' . $vol * $emfactor . 'rem;"' . "><!--" . cached_screen_width() / 2 . "-->\n";

  if($vol0 > $coin_bag_threshold)
  {
    if($vol0 > $scale) // handle overflows
      $vol0 = $scale;

    $scale2 = $scale - $coin_bag_threshold; // the remaining amount

    $vol = $vol0 - $coin_bag_threshold;
    $the_color = "#ffa000"; // light orange

    if($vol > $scale2 / 2)
    {
      if($vol < $scale2 * 3 / 4)
        $the_color = "#ff4040"; // darker orange
      else
        $the_color = "#ff0000"; // red
    }

    print "        </div>\n";

    print "        <div\n";
    print 'style="background-color:' . $the_color
        . ';position:absolute;left:' . (cached_screen_width() * $emfactorW / 2 - 7 * $emfactor - 0.25)
        . 'rem;width:' . 14 * $emfactor . 'rem;';
    print 'top:' . (($pos - ($scale - $scale2) - $vol) * $emfactor + 0.125) . 'rem;';
    print 'height:' . $vol * $emfactor. 'rem;"' . ">\n";
  }
?>
        </div>

        <div class="row center" style="width:20.8rem"><!--500px-->
            <table width=100% style="font-size:1rem;line-height:1.2rem">
              <tr>
                <th style="padding:2px;text-align:center">pennies</th>
                <th style="padding:2px;text-align:center">nickels</th>
                <th style="padding:2px;text-align:center">dimes</th>
                <th style="padding:2px;text-align:center">quarters</th>
                <th style="padding:2px;text-align:center">dollars</th>
              </tr>
              <tr>
                <td style="padding:2px;text-align:right<?php if($count1c >= $count1b) { if($count1c < $count1b * 1.5) print ";background-color:#ffff80"; else if($count1b > 0) print ";background-color:#c0ffc0"; }?>">
                  <?php print $count1c; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:2px;text-align:right<?php if($count5c >= $count5b) { if($count5c < $count5b * 1.5) print ";background-color:#ffff80"; else if($count5b > 0) print ";background-color:#c0ffc0"; }?>">
                  <?php print $count5c; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:2px;text-align:right<?php if($count10c >= $count10b) { if($count10c < $count10b * 1.5) print ";background-color:#ffff80"; else if($count10b > 0) print ";background-color:#c0ffc0"; }?>">
                  <?php print $count10c; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:2px;text-align:right<?php if($count25c >= $count25b) { if($count25c < $count25b * 1.5) print ";background-color:#ffff80"; else if($count25b > 0) print ";background-color:#c0ffc0";} ?>">
                  <?php print $count25c; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:2px;text-align:right<?php if($count100c >= $count100b) { if($count100c < $count100b * 1.5) print ";background-color:#ffff80"; else if($count100b > 0) print ";background-color:#c0ffc0";} ?>">
                  <?php print $count100c; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
              </tr>
              <!--tr>
                <td style="padding:2px;text-align:right">( <?php print $count1b; ?> )&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:2px;text-align:right">( <?php print $count5b; ?> )&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:2px;text-align:right">( <?php print $count10b; ?> )&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:2px;text-align:right">( <?php print $count25b; ?> )&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
                <td style="padding:2px;text-align:right">( <?php print $count100b; ?> )&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
              </tr-->
              <tr>
                <td style="padding:2px;text-align:center">
                  <button id=bag1 onClick="do_bag(1);" form=none type=button class="btn waves-effect primary-fill btn-shadow"
                          <?php if($count1b == 0 || $count1b > $count1c) print "disabled\n"; ?>
                          style="height:2.67rem !important;line-height:1rem;min-width:3.3rem !important">
                    Bag<br/><?php print $count1b; ?>
                  </button>
                </td>
                <td style="padding:2px;text-align:center">
                  <button id=bag5 onClick="do_bag(5);" form=none type=button class="btn waves-effect primary-fill btn-shadow"
                          <?php if($count5b == 0 || $count5b > $count5c) print "disabled\n"; ?>
                          style="height:2.67rem !important;line-height:1rem;min-width:3.3rem !important">
                    Bag<br/><?php print $count5b; ?>
                  </button>
                </td>
                <td style="padding:2px;text-align:center">
                  <button id=bag10 onClick="do_bag(10);" form=none type=button class="btn waves-effect primary-fill btn-shadow"
                          <?php if($count10b == 0 || $count10b > $count10c) print "disabled\n"; ?>
                          style="height:2.67rem !important;line-height:1rem;min-width:3.3rem !important">
                    Bag<br/><?php print $count10b; ?>
                  </button>
                </td>
                <td style="padding:2px;text-align:center">
                  <button id=bag25 onClick="do_bag(25);" form=none type=button class="btn waves-effect primary-fill btn-shadow"
                          <?php if($count25b == 0 || $count25b > $count25c) print "disabled\n"; ?>
                          style="height:2.67rem !important;line-height:1rem;min-width:3.3rem !important">
                    Bag<br/><?php print $count25b; ?>
                  </button>
                </td>
                <td style="padding:2px;text-align:center">
                  <!-- dollars is special - if not bagging allow single coin dispensing here -->
                  <button id=bag100 onClick="do_bag(100);" form=none type=button class="btn waves-effect primary-fill btn-shadow"
                          <?php if($count100c == 0 || ($count100b != 0 && $count100b > $count100c)) print "disabled\n"; ?>
                          style="height:2.67rem !important;line-height:1rem;min-width:3.3rem !important">
                    <?php if($count100b > 0) print "Bag<br/>" . $count100b; else print "Pay<br/>" . "1"; ?>
                  </button>
                </td>
              </tr>
            </table>
        </div>
        <div style="position:absolute;left:8.3rem;bottom:0.4rem;text-align:center;width:16.6rem;height:2.5rem;padding:0;margin:0">
          <p id=messagething style="padding:0;margin:0;font-size:0.83rem;line-height:0.83rem"><?php print $TheMessage; ?></p>
        </div>
      </div>
    </div>

    <form id=multi method=GET action="/make-coin-baggies2.php">
<?php
  if(strlen($next) > 0)
  {
?>
      <input type=hidden name=next value=<?php print '"' . $next . '"'; ?> style="visibility:hidden" />
<?php
  }
?>
<?php
  if(strlen($StartCount) > 0)
  {
?>
      <input type=hidden name=StartCount value=<?php print '"' . $StartCount . '"'; ?> style="visibility:hidden" />
<?php
  }
?>
    </form>
<?php
  if(strlen($next) > 0)
  {
?>
    <form id=the_form action=<?php print '"' . $next . '"'; ?> method=GET>
      <!-- input type=hidden name=next value=<?php print '"' . $next . '"'; ?>l style="visibility:hidden" / -->
<?php
    if(strlen($Class) > 0)
    {
?>
      <input type=hidden name=class value=<?php print '"' . $Class . '"'; ?> style="visibility:hidden" />
<?php
    }
?>
<?php
  }
  else
  {
?>
    <form id=the_form action="/" method=GET>
<?php
  }
?>
      <div class="next-button" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
        <button id=exit type=button onClick="OnClickExit();" class="btn waves-effect primary-fill btn-shadow">
<?php
  if(strlen($next) > 0)
  {
    print "          Next\n";
  }
  else
  {
    print "          Exit\n";
  }
  ?>
        </button>
      </div>
    </form>
    <div class="next-button" style="position:absolute;margin:0px;padding:0;bottom:18px;left:12px">
      <button id=multi type=submit form=multi class="btn waves-effect primary-fill btn-shadow">Multi</button>
    </div>
  <!--/div-->

    <!-- popup alerts -->
    <div id=popup_alert class="modal-container"
         style="position:absolute;top:0px;visibility:hidden">
      <div id=alert_dlg class="medium-modal me-and-my-shadow"
           style="visibility:inherit;position:relative;left:30%;width:40%;top:6.67rem">
        <center>
          <span id=alert_title style="font-size:0.91rem;line-height:0.91rem;margin:0;padding:0;visibility:inherit">
            PAYOUT ERROR
          </span>
        </center>
        <div id=alert_dlg_text style="position:relative;font-size:0.75rem;line-height:0.83rem;top:4px;height:4.16rem;text-align:center;margin:0;padding:0;visibility:inherit">
          The Message
        </div>
        <div class="next-button" style="position:relative;margin:0px;padding:0;top:20px;visibility:inherit">
          <button id=start type=button onClick="do_alert_exit();" class="btn waves-effect primary-fill btn-shadow"
                  style="visibility:inherit;position:relative;width:30%;left:40%">
            Exit
          </button>
        </div>
      </div>
    </div>

    <script>
      var thing = null;

      function do_alert(text)
      {
        if(thing != null)
        {
          clearInterval(thing);
          thing = null;
        }

        console.log("setting text to " + text);
        document.getElementById("alert_dlg_text").innerHTML = text;
        document.getElementById("popup_alert").style.visibility="visible";
        document.getElementById("popup_alert").style.display="block";

        console.log("returning");
      }

      function do_alert_exit()
      {
        document.getElementById("popup_alert").style.visibility="hidden";
        document.getElementById("popup_alert").style.display="none";

        console.log("resetting event interval");
        thing = setInterval(getC400Status, 500); // when dialog closes, continue status polling
      }

      function OnClickExit()
      {
<?php
    print "        var szStartCount = '" . $StartCount . "';\n";
    print "        var szEndCount = '"
          . $count1c . "/" . $count5c . "/" . $count10c . "/" . $count25c . "/" . $count100c . "';\n";
?>
        var myRequest;

        document.getElementById("messagething").innerHTML = "";
        myRequest = new Request("/glue/print-baggie-receipt.php?StartCount=" + encodeURIComponent(szStartCount)
                                + "&EndCount=" + encodeURIComponent(szEndCount));

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("doBag(" + nCoin + ")", response.status); // debug only (TODO: remove?  this is actually an error condition...)
                    return "ERROR";
                  }
                  return  response.text();
                })
          .then(function(text)
                {
                  document.getElementById("the_form").submit();
                });
      }

      function do_bag(nCoin)
      {
        var nBatch = 0, nCount = 0;

        if(thing != null)
        {
          clearInterval(thing);
          thing = null;
        }

        document.getElementById("messagething").innerHTML = "";

        if(nCoin == 1)
        {
          nBatch = <?php print $count1b;?>;
          nCount = <?php print $count1c;?>;
        }
        else if(nCoin == 5)
        {
          nBatch = <?php print $count5b;?>;
          nCount = <?php print $count5c;?>;
        }
        else if(nCoin == 10)
        {
          nBatch = <?php print $count10b;?>;
          nCount = <?php print $count10c;?>;
        }
        else if(nCoin == 25)
        {
          nBatch = <?php print $count25b;?>;
          nCount = <?php print $count25c;?>;
        }
        else if(nCoin == 100)
        {
          // allow dollars to dispense 1 coin if batch qty is zero
          nBatch = <?php if($count100b > 0) print $count100b; else print "1"; ?>;
          nCount = <?php print $count100c;?>;
        }

        if(nCount < nBatch)
        {
          document.getElementById("messagething").innerHTML = "Insufficient coin for batch amount " + nBatch;
        }
        else if (nBatch == 0)
        {
          document.getElementById("messagething").innerHTML = "Batch amount is zero";
        }
        else
        {
          var myRequest;

          document.getElementById("messagething").innerHTML = "Requesting Payout...";
          myRequest = new Request("/glue/payout-coin.php?Denom=" + nCoin + "&Amount=" + nBatch);

          fetch(myRequest)
            .then(function(response)
                  {
                    if (!response.ok)
                    {
                      console.log("doBag(" + nCoin + ")", response.status); // debug only (TODO: remove?  this is actually an error condition...)
                      return "ERROR";
                    }
                    return  response.text();
                  })
            .then(function(text)
                  {
                    // TODO:  anything?
                    myRequest = null;
                    thing = null;

                    document.getElementById("bag1").disabled = true;
                    document.getElementById("bag5").disabled = true;
                    document.getElementById("bag10").disabled = true;
                    document.getElementById("bag25").disabled = true;
                    document.getElementById("bag100").disabled = true;

                    document.getElementById("messagething").innerHTML = text + " (Starting)";
                    thing = setInterval(getC400Status, 500); // assume 0.5 sec enough to get non-zero status
                  })
        }
      }

      function getC400Status()
      {
        // NOTE:  this glue page also works for C300 - it will check installed equipment
        var myRequest = new Request("/glue/status-c400.php");

        fetch(myRequest)
          .then(function(response)
                {
                  myRequest = null;

                  if(!response.ok)
                  {
                    console.log("status-c400", response.status); // debug only (TODO: remove?)
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                  // xx will be a DOM Parser type of object from which to parse XML
                  var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                  var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
                  var the_date = xx.getElementsByTagName("date")[0];
                  var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
                  var st = xx.getElementsByTagName("status")[0].children;
                  var status_code = "";
                  var status_text = "";
                  var today = "";

                  if(the_date && the_date.childNodes.length > 0)
                  {
                    today = the_date.childNodes[0].nodeValue
                  }
                  else
                  {
                    today = "unknown date";
                  }

                  for (var i1 = 0; i1 < st.length; i1++)
                  {
                    if(st[i1].nodeName == "code")
                      status_code = st[i1].childNodes[0].nodeValue;
                    else if(st[i1].nodeName == "text")
                      status_text = st[i1].childNodes[0].nodeValue;
                  }

                  if(status_code == 0) // this happens at the end
                  {
                    if(thing != null)
                      clearInterval(thing);

                    thing = null;

                    document.getElementById("bag1").disabled = true;
                    document.getElementById("bag5").disabled = true;
                    document.getElementById("bag10").disabled = true;
                    document.getElementById("bag25").disabled = true;
                    document.getElementById("bag100").disabled = true;

                    // auto-start - machine begins counting
                    document.location.href=document.location.href =
                      "/make-coin-baggies.php?TheMessage=" + encodeURIComponent("Complete!!!") // to refresh it
<?php
  print '                      + "&StartCount=' . urlencode($StartCount) . '"' . "\n";
  if(strlen($next) > 0)
  {
    print '                      + "&next=' . urlencode($next) . '"' . "\n";

    if(strlen($Class) > 0)
      print '                      + "&class=' . urlencode($Class) . '"' . "\n";
  }
?>
                      ;
                  }
                  else // if(status_code != 0)
                  {
                    document.getElementById("messagething").innerHTML = status_text;

                    if(status_code == 31 /* || status_code == 29 || status_code == 28 */)
                    {
                      do_alert(status_text);
                    }
                  }

                  xx = null;
                  entity = null;
                  the_date = null;
                  tick = null;
                  st = null;
                  status_code = null;
                  status_text = null;
                  today = null;
                });
      }

      function PlaceBaggieMessage()
      {
        clearInterval(thing);
        thing = null;

        document.getElementById("messagething").innerHTML =
<?php
  if(($count1b == 0 || $count1b > $count1c) &&
     ($count5b == 0 || $count5b > $count5c) &&
     ($count10b == 0 || $count10b > $count10c) &&
     ($count25b == 0 || $count25b > $count25c) &&
     ($count100b == 0 || $count100b > $count100c))
  {
    if(strlen($next) > 0)
    {
?>
          "Insufficient coins in coin counter for baggies.<br/>Press 'Next' to continue";
<?php
    }
    else
    {
?>
          "Insufficient coins in coin counter for baggies.<br/>Press 'Exit' to continue";
<?php
    }
  }
  else
  {
    if(strlen($next) > 0)
    {
?>
          "Place coin baggie onto coin counter payout and press 'Bag' button to dispense coins.  When finished, press 'Next'";
<?php
    }
    else
    {
?>
          "Place coin baggie onto coin counter payout and press 'Bag' button to dispense coins.  When finished, press 'Exit'";
<?php
    }
  }
?>
      }


      thing = setInterval(PlaceBaggieMessage, 2000);

    </script>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>


