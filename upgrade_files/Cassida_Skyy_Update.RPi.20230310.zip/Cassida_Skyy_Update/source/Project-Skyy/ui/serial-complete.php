<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";


?>
<!DOCTYPE html5>
<HTML><HEAD><TITLE>Count Complete</TITLE>
<STYLE>
input
{
 font-size:24px;
 font-weight: bold;
 height : 36;
}
@font-face
{
 font-family: Lato;
 src: url(/fonts/lato-v15-latin-regular.woff);
}
</STYLE>
</HEAD>
<!--meta http-equiv="refresh" content="15;url=/index.php"-->
<BODY bgcolor="#004020" text="#ffffe0">
<?php

  skyyreq("complete");

  $sort = "";
  extract($_POST,  EXTR_OVERWRITE);

  if($sort == "")
  {
    $Solution = skyyreq("serial-numbers");
  }
  else
  {
    $Solution = skyyreq("serial-numbers/" . $sort);
  }

?>
<center><font style="font-size:15px">Result for <?php echo $Entity ?>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $CountDate?></font></center><br>
<table align=center width=75% height=320 style="font-size:15px">
  <tr><td><pre style="font-height:16px"><?php print $Solution; ?></pre></td></tr>
</table>
<table width=75% align=center style="font-size:20px">
  <tr>
   <td align=center valign=top>
    <form action="/" method="GET" style="margin:1">
      <input value="Done" type="submit"/>
    </form>
   </td>
   <td align=center valign=top>
    <form action="/serial-complete.php" method="POST" style="margin:1">
      <input type="hidden" name="sort" value=""/>
      <input value="Default" type="submit"/>
    </form>
   </td>
   <td align=center valign=top>
    <form action="/serial-complete.php" method="POST" style="margin:1">
      <input type="hidden" name="sort" value="D"/>
      <input value="Denomination" type="submit"/>
    </form>
   </td>
   <td align=center valign=top>
    <form action="/serial-complete.php" method="POST" style="margin:1">
      <input type="hidden" name="sort" value="S"/>
      <input value="Serial" type="submit"/>
    </form>
   </td>
   <td align=center valign=top>
    <form action="/serial-print.php" method="GET" style="margin:1">
      <input value="Print" type="submit"/>
    </form>
   </td>
  </tr>
</form>

</body>
</html>

</BODY></HTML>

