<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "glue/common_utils.php";

  $Equipment = coin_counter_equipment();

  // where 'back' will lead me
  $back = empty($_GET['back'])
        ?  (empty($_SERVER['HTTP_REFERER']) ? "/cleaning.php" : $_SERVER['HTTP_REFERER'])
        : $_GET['back'];

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Note = make_singular(do_getconf($parseconf,"terms",'Notes','Notes'));
  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Coin = make_singular($Coins);

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
<?php
  if(0) // $CustomerMod == 1)
  {
?>
    <title>ZC4 - Weekly Cleaning</title>
<?php
  }
  else if(coin_counter_is_recycler($Equipment))
  {
?>
    <title>Split Recycler - Monthly Cleaning</title>
<?php
  }
  else
  {
?>
    <title>ZC4 - Monthly Cleaning</title>
<?php
  }
?>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
      .message-thing
      {
        color:#000000;/*#585858 works for bold font*/
        font-size:1rem;
        font-weight:500; /* normal - 700 is bold */
        position:absolute;
        padding-left: 0.41rem;
        padding-top: 0px;
        padding-bottom: 0px;
        height:2.67rem;
        bottom:0.17rem;
        width:18.3rem;
        left:0.5rem;
        line-height:120%;
        vertical-align:bottom;
        text-align:left;
      }

    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">
<?php
  if(0) // $CustomerMod == 1)
  {
?>
          Weekly Cleaning
<?php
  }
  else
  {
?>
          Monthly Cleaning
<?php
  }
?>
        </a>
        <div class="area">Cleaning</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <form id=goback0 method=GET><input type=hidden name="back" value="/monthly-cleaning.php" style="visibility:hidden" /></form>
    <form id=goback2 method=GET>
      <input type=hidden name="origin" value="/monthly-cleaning.php" style="visibility:hidden" />
    </form>
    <form id=none method=GET></form>
    <br/>
    <center>
      <table style="width:85%;border:0">
        <tr style="margin:0 20 0 0px;line-height:28px;border:0">
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
<?php
  if(coin_counter_is_recycler($Equipment))
  {
?>
              <LI style="list-style-type:disc;padding:0;margin:0;margin-left:0px;margin-top:-1rem;margin-bottom:0.25rem">
                Perform
                <button id=weekly type=submit formaction="/weekly-cleaning.php" form=goback0
                        class="btn btn-small btn-maint-test waves-effect primary-fill btn-shadow-thin">
                  <span>Weekly Cleaning</span>
                </button>
                &nbsp;&nbsp;and
                <button id=weekly type=submit formaction="/monthly-cleaning-recycler.php" form=goback0
                        class="btn btn-small btn-maint-test waves-effect primary-fill btn-shadow-thin">
                  <span>Recycler Cleaning</span>
                </button>
              </LI>
              <LI style="list-style-type:none;padding:0;margin:0;margin-left:-1rem">
                <b>Zeus <?php print $Note; ?> Counter</b>
              </LI>
              <LI style="list-style-type:disc;margin:0px;margin-top:0.15rem">From the bottom, lift the left-hand <?php print $Note; ?> Counter access door.</LI>
              <LI style="list-style-type:disc;margin:0px;margin-top:0.15rem;margin-bottom:0.25rem">Locate the dust drawer, just below the lower cover. Over time dust can accumulate and will need to be cleaned.</LI>
<?php
  }
  else // if($CustomerMod != 1)
  {
?>
              <LI style="list-style-type:disc;padding:0;margin:0;margin-left:0px;margin-top:-28px">
                Perform
                <button id=weekly type=submit formaction="/weekly-cleaning.php" form=goback0
                        class="btn btn-small btn-maint-test waves-effect primary-fill btn-shadow-thin">
                  <span>Weekly Cleaning</span>
                </button>
              </LI>
              <LI style="list-style-type:disc;margin:0px;margin-top:0.15rem">Locate the dust drawer, just below the lower cover. Over time dust can accumulate and will need to be cleaned.</LI>
              <div style="height:4px;line-height:4px" ></div>
<?php
  }
?>
              <LI style="list-style-type:none;padding:0;margin:0;margin-left:-20px">
                <b>CleanBill Pro Cleaning Card</b>
              </LI>
              <LI style="list-style-type:disc;margin:0px;margin-top:0.15rem">Grab the CleanBill Pro Cleaning Card.</LI>
<?php
  if(coin_counter_is_recycler($Equipment))
  {
?>
              <LI style="list-style-type:disc;margin:0px;margin-top:0.15rem">If the system is off, use the front panel power switch to energize the system.</LI>
<?php
  }
  else
  {
?>
              <LI style="list-style-type:disc;margin:0px;margin-top:0.15rem">Turn on the system from the power switch located behind the ZEUS.</LI>
<?php
  }
?>
              <LI style="list-style-type:disc;margin:0;margin-top:0.15rem;">
                Enable
                <button id=cleaning_mode type=submit formaction="/glue/start-cleaning.php" form=none
                        class="btn btn-small btn-maint-test waves-effect primary-fill btn-shadow-thin">
                  <span>Cleaning Mode</span>
                </button>
                <!-- this should get a 'last cleaned' date from someplace, UI or ?? display it? -->
              <LI style="list-style-type:disc;margin:0px">The screen on the Zeus will then prompt you to run the CleanBill Pro Cleaning Card through the machine. You will need to run the card through the machine 10 times.</LI>
              <LI style="list-style-type:disc;margin:0px;margin-top:0.15rem">Once the CleanBill Pro goes through the machine 10 times the Zeus will then return to the home screen.</LI>
<?php
  if(coin_counter_is_recycler($Equipment))
  {
?>
              <LI style="list-style-type:disc;margin:0px;margin-top:0.15rem">Close the left-hand <?php print $Note; ?> Counter access door, and press 'Done'.</LI>
<?php
  }
?>
            </UL>
          </td>
        </tr>
      </table>
    </center>

<?php
  if(0) // $CustomerMod == 1)
  {
?>
    <div id="zeus-message" class="message-thing" style="width:25rem; margin-bottom:1.67rem"></div>

    <form id=goback method=GET><input type=hidden name=back style="visibility:hidden" value=<?php print '"' . $back . '"';?> /></form>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;left:0px">
      <button type=submit form=goback formaction="/weekly-cleaning6.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/cleaning.svg" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">&nbsp; &nbsp;BACK</span>
      </button><br/>
    </div>
<?php
  }
  else
  {
?>
    <div id="zeus-message" class="message-thing"></div>
<?php
  }
?>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <!-- Should I add a 'skip' button and only enable this if you start cleaning??? -->
      <button type="submit" id="skip"
              formaction="/cleaning.php" form=none
              class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">SKIP</span> <!-- UI disables when not done? -->
      </button>&nbsp;&nbsp;
      <button type="submit" id="done"
              formaction="/glue/complete-cleaning.php" form=none
              class="btn btn-small waves-effect primary-fill btn-shadow" disabled>
        <img src="/img/cleaning.svg" class="invertible-icon" height=32 width=32>
        <span id=done_button_text style="vertical-align:middle">&nbsp;&nbsp;DONE</span> <!-- UI disables when not done? -->
      </button><br/>
    </div>

    <!--  Scripts-->

    <script>
      var code;
      function getZeusStatus()
      {
        var myRequest = new Request("/glue/status-zeus.php");

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("status", response.status);
                    document.getElementById("zeus-message").innerHTML = "no response";
                  }
                  return  response.text();
                })
          .then(function(txt)
                {
                  // hopefully doing this WITHOUT JQuery if for no other reason than to prove a point

                  parser = new DOMParser();
                  xml = parser.parseFromString(txt, "text/xml");

                  code = xml.getElementsByTagName("code")[0].childNodes[0].nodeValue;
                  text = xml.getElementsByTagName("text")[0].childNodes[0].nodeValue;

                  if(code == 15) // error
                  {
                    document.getElementById("zeus-message").innerHTML = text;

                    document.getElementById("done").disabled=false;
                    document.getElementById("done_button_text").innerHTML = "&nbsp;&nbsp;Cancel";

                    document.getElementById("skip").disabled=true;
                    document.getElementById("cleaning_mode").disabled=true;
                  }
                  else if(code != 0)
                  {
                    document.getElementById("zeus-message").innerHTML = text;
//                    if(code == 15)
//                    {
//                      document.getElementById("done").disabled=false;
//                    }
//                    else
//                    {
//                      document.getElementById("done").disabled=true;
//                    }

                    document.getElementById("done").disabled=false;
                    document.getElementById("done_button_text").innerHTML = "&nbsp;&nbsp;DONE";
                    document.getElementById("skip").disabled=true;
                    document.getElementById("cleaning_mode").disabled=true;
                  }
                  else
                  {
                    document.getElementById("zeus-message").innerHTML = "";
//                    document.getElementById("done").disabled=false;
                  }
                });
      }

      setInterval(getZeusStatus, 500);

    getZeusStatus(); // do this on load, too

    </script>

  </body>
</html>

