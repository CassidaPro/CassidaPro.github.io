<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/common_utils.php";

  // this is supposed to STOP cacheing this style sheet, to re-load every time
  header('Cache-Control: no-cache, no-store, must-revalidate');
  header('Pragma: no-cache');
  header('Expires: 0');

  header('Content-type: text/css'); // necessary or it does not work

  set_ideal_font_height();
?>

html, body
{
  overscroll-behavior-x: none;
}

img
{
  width:1.5rem;
  height:1.5rem;
}


