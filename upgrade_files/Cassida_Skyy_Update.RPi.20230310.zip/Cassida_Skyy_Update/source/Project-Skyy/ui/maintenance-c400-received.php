<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $Equipment = coin_counter_equipment();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Replace C400</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>

  <script>
    function ClickTest()
    {
        var myRequest = new Request("/glue/c400-test.php");

        document.getElementById("c400_test").disabled=true;
        document.getElementById("test_results").innerHTML = "waiting...";

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("status", response.status);
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                  document.getElementById("c400_test").disabled=false;
                  document.getElementById("test_results").innerHTML = text.substring(0,8);
                });
    }
  </script>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Replace C400
          <img width=42 height=42 src="/img/<?php if(coin_counter_is_c400r($Equipment)) print 'c400r'; else print 'c400'; ?>-only.png">
        </a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <table style="width:85%;border:0;line-height:1.1em">
        <tr>
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle">Unpack carton
                  <LI style="list-style-type:circle">Remove C400 from carton.</LI>
                  <LI style="list-style-type:circle">Make sure it has a new power cable, in case you need it.</LI>
                </UL>
              </LI>
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle">Remove old C400
                  <LI style="list-style-type:circle">Power off the C400 and disconnect the cables.  Set aside.</LI>
                </UL>
              </LI>
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle">Install new C400
                  <LI style="list-style-type:circle">Plug power and DB15 cables into the new C400, and set in place</LI>
                  <LI style="list-style-type:circle">Energize the new C400.  Wait about 15 seconds for C400 to power up.</LI
                  <LI style="list-style-type:circle">When the C400 display indicates 'Ready', press&nbsp;&nbsp;
                    <button id=c400_test type=button onClick="ClickTest();" class="btn btn-small waves-effect primary-fill btn-shadow"
                            style="min-height:1.5rem;height:1.5rem;margin-left:-4px">
                      <span style="vertical-align:middle">TEST</span>
                    </button>&nbsp;&nbsp;
                    <span id=test_results style="font-size:18px"></span></LI>
                  <LI style="list-style-type:circle">If test is good, press&nbsp;&nbsp;
                    <button id=batch type=submit form=set_batch class="btn btn-small waves-effect primary-fill btn-shadow"
                            style="min-height:1.5rem;height:1.5rem;margin-left:-4px">
                      <span style="vertical-align:middle">SET BATCH</span>
                    </button> &nbsp;&nbsp;to set batch (returns here)</LI>
                  <LI style="list-style-type:circle">If you have any problems, contact customer service immediately.</LI>
                  <LI style="list-style-type:circle">Include the test output and RMA receipt along with the old C400.
                                                                                  Re-pack them into the shipping carton with unused hardware.</LI>
                </UL>
              </LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>
    <form id=set_batch method=GET action="/c400-do-set-batch.php"><input type=hidden name=next value="/maintenance-c400-received.php" /></form>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">Exit</span>
      </a>
      <a href="/glue/complete-replacement.php?code=400" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/wrench.png" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">DONE</span>
      </a><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

