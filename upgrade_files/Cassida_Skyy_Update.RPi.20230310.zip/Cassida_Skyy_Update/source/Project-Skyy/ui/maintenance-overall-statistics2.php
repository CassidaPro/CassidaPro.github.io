<?php
  /*            Copyright 2021 by Cassida               */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse stastics file for things I need
  $parsestats = load_parsestats();

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Overall Statistics (Zeus)</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Overall Statistics (Zeus)<img width=42 height=42 src="/img/zeus-only.png"></a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <table style="width:60%;border:0;font-size:0.9rem;line-height:1.2em">
<?php

  $zz=$parsestats["equipment"]["Zeus"];
  $zzz="";
  $zza="";
  $zzs="";
  if(strlen($zz) > 0)
  {
    $zzs=$parsestats["Zeus " . $zz]["Serial"];
    $zza=$parsestats["Zeus Stats " . $zz];
  }

  if(strlen($zz) == 0 || !isset($zza["TotalNotesCounted"]))
  {
?>
        <tr>
          <td><center>No Zeus statistics available</center></td>
        </tr>
<?php
  }
  else
  {
?>
        <tr>
          <td style="padding:0;margin:0;width:100%">
            <center><b>Statistics for Zeus:</b>&nbsp;&nbsp;<?php print $zzs . "&nbsp;&nbsp;" . $zz; ?></center>
          </td>
        </tr>
        <tr style="line-height:0.5rem"><td>&nbsp;</td></tr>
      </table>
      <table style="width:60%;border:0;font-size:0.9rem;line-height:1.1em">
        <tr style="margin:0 20 0 0px;line-height:28px;border:2;border-color:#000000">
          <td style="padding:0;margin:0;text-align:right;width:55%">
            Total Notes Counted:&nbsp;&nbsp;
          </td>
          <td style="padding:0;margin:0;width:3%">&nbsp;</td>
          <td style="padding:0;margin:0;width:42%">
            <?php print $zza["TotalNotesCounted"];?>
          </td>
        </tr>

<?php

    $aaa[0]="Rejects";
    $aaa[1]="Double";
    $aaa[2]="Chain";
    $aaa[3]="HalfError";
    $aaa[4]="ReadError";
    $aaa[5]="IDError";
    $aaa[6]="SuspectNote";
    $aaa[7]="JAM1";
    $aaa[8]="JAM2";
    $aaa[9]="MotorError";
    $aaa[10]="DiverterError";
    $aaa[11]="FeedError";

    $aa[0]="Rejects";
    $aa[1]="Double";
    $aa[2]="Chain";
    $aa[3]="Half Error";
    $aa[4]="Read Error";
    $aa[5]="ID Error";
    $aa[6]="Suspect Note";
    $aa[7]="JAM1";
    $aa[8]="JAM2";
    $aa[9]="Motor Error";
    $aa[10]="Diverter Error";
    $aa[11]="Feed Error";

    foreach($aaa as $ii => $yy)
    {
      print '<tr>'
            . '<td style="padding:0;margin:0;text-align:right">'
            . $aa[$ii] . ':&nbsp;&nbsp;</td>'
            . '<td style="padding:0;margin:0;width:3%">&nbsp;</td>'
            . '<td style="padding:0;margin:0">'
            . $zza[$yy] . "</td><tr>\n";
    }
  }
?>
      </table>
    </center>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;left:12px">
      <a href="/maintenance-overall-statistics.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">BACK</span>
      </a><br/>
    </div>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/maintenance.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/wrench.png" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">&nbsp; &nbsp;DONE</span>
      </a><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

