<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Pulls = do_getconf($parseconf,"terms",'Pulls','Pulls');
  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Straps = do_getconf($parseconf,"terms",'Straps','Straps');
  $Rolls = do_getconf($parseconf,"terms",'Rolls','Rolls');

  $ChangeOrderName = "Change Order"; // temporary


  // handling "print and done" by re-directing back to myself

  $complete = empty($_GET) || empty($_GET["complete"]) ? "" : $_GET["complete"];

  if($complete=="Y")
  {
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
        <meta http-equiv="refresh" content="0.2;url=/count-summary.php?complete=YY">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Printing Receipt</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($complete=="YY")
  {
    $thing = skyyreq("count-entity");
    eval($thing); // all I really need is '$Class' though

    $thing = skyyreq("class-entity/" . $Class);
    eval($thing); // todo, make this safer, see tasks.php

    header("HTTP/1.0 302 Moved Temporarily");

    if($NumEntity > 1) // more than one entity?
    {
      header("Location: /entity-number.php?class=" . $Class);
    }
    else
    {
      header("Location: /tasks.php");
    }

    skyyreq("complete");
    skyyreq("print-receipt");
    skyyreq("complete-entity");

    exit;
  }


  // normal processing goes here

  $Status = "(NO RESPONSE)";
  $CountStraps = 0;
  $CountRolls = 0;
  $CountNotes = 0;
  $CountCoins = 0;
  $ChangeOrder = 0; // temporary

  // this tells the skyy server I've gotten to a 'count summary' page - issue #99
  $Solution = skyyreq("count-summary");
  eval($Solution);

  if($Status != "OK" || ($CountStraps + $CountRolls + $CountNotes + $CountCoins) == 0)
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="10;url=/tasks.php" >
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <center>
        <br><br>
        <H1>
            ERROR:  count data missing<br>
        </H1>
        <br>
        <form method=GET action="/tasks.php">
          <button type=submit style="font-size:28px;min-width:150px">OK</button>
        </form>
      </center>
    </BODY>
    </HTML>
<?php
    exit;
  }

//  print $Status . ":  " . $CountStraps . "," . $CountRolls . "," . $CountNotes . "," . $CountCoins . "\n";
//  exit;

  $Entity = '';
  $CountDate = '';

  // loose coin
  $count1c = '0';
  $count5c = '0';
  $count10c = '0';
  $count25c = '0';
  $count100c = '0';

  // loose notes
  $count1 = '0';
  $count2 = '0';
  $count5 = '0';
  $count10 = '0';
  $count20 = '0';
  $count50 = '0';
  $count100 = '0';

  // rolled coin
  $roll1 = '0';
  $roll5 = '0';
  $roll10 = '0';
  $roll25 = '0';
  $roll100 = '0';

  // strapped notes
  $strap1 = '0';
  $strap2 = '0';
  $strap5 = '0';
  $strap10 = '0';
  $strap20 = '0';
  $strap50 = '0';
  $strap100 = '0';

  $ChangeOrderAmt = '0';

  header("Content-Type: text/html; charset=UTF-8"); // it belongs here anyway

  $Solution = skyyreq("count-entity");
  eval($Solution);

  if($CountNotes)
  {
    $Solution = skyyreq("result-zeus");
    eval($Solution);
  }

  if($CountCoins)
  {
    $Solution = skyyreq("result-c400");
    eval($Solution);
  }

  if($CountStraps)
  {
    $Solution = skyyreq("result-strap");
    eval($Solution);
  }

  if($CountRolls)
  {
    $Solution = skyyreq("result-rolls");
    eval($Solution);
  }

  if($ChangeOrder != 0)
  {
    $Solution = skyyreq("result-change-order");
    eval($Solution);
  }

  // calculate totals
  $coinsSubTotal = $count1c * 0.01 + $count5c * 0.05 + $count10c * 0.10
                 + $count25c * 0.25 + $count100c;
  $rollsSubTotal = $roll1 * 0.01 + $roll5 * 0.05 + $roll10 * 0.10
                 + $roll25 * 0.25 + $roll100 * 0.10;
  $coinsPlusRolls = $coinsSubTotal + $rollsSubTotal;

  $notesSubTotal = $count1 + $count2 * 2 + $count5 * 5 + $count10 * 10
                 + $count20 * 20 + $count50 * 50 + $count100 * 100;

  $strapsSubTotal = $strap1 + $strap2 * 2 + $strap5 * 5 + $strap10 * 10
                  + $strap20 * 20 + $strap50 * 50 + $strap100;

  $pageTotal = currency_form($coinsPlusRolls + $notesSubTotal + $strapsSubTotal + $ChangeOrderAmt);

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!--meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/-->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title><?php print $Entity;?> Summary</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- CSS  -->

    <style>
<?php
  set_ideal_font_height();
?>
      tr
      {
        line-height:1rem /*24px*/;
      }
      table.striped td
      {
        padding-top: 0;
      }
    </style>
  </head>
  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">Summary</a>
        <div class="area"><?php print strtoupper($Entity);?></div>
      </div>
      <!--button id="print-button" class="btn waves-effect secondary-fill print-button btn-shadow" type="submit"><img src="img/printer.svg"> PRINT</button-->
    </nav>
    <form id=redo-form method=GET>
      <input type=hidden style="visibility:hidden" name="origin" value="count-summary.php" />
    </form>

    <div class="container">
<?php
  if($CountCoins || $CountRolls) // counted coins or rolls
  {
?>
      <div class="section" style="padding-top:0.5rem;padding-bottom:0"><!-- move up so I do not get a scroll bar on the right -->
        <div class="row">
          <div class="col s12 m4">
            <table style="line-height:1rem;font-size:inherit;min-width:100%;margin:0;padding:0">
              <tr style="line-height:1rem">
                <td style="width:15%">&nbsp;</td>
<?php
    if($CountCoins) // if I counted coins
    {
?>
                <td class="table-name" style="text-align:center;line-height:1rem;width:70%">
                  <?php print $Coins; ?>
                </td>
<?php
    }
    else
    {
?>
                <td class="table-name" style="text-align:center;line-height:1rem;width:70%">
                  <?php print $Rolls; ?>
                </td>
<?php
    }
?>
                <td>
<?php
    if($CountCoins) // if I counted coins
    {
?>
                  <button type=submit form=redo-form formaction="/count-coins.php"
<?php
    }
    else
    {
?>
                  <button type=submit form=redo-form formaction="/count-rolls.php"
<?php
    }
?>
                          class="btn waves-effect primary-fill btn-shadow"
                          style="min-height:0px;height:1rem;line-height:1rem;width:1rem;padding:0;margin:0">
<?php
    if($CountCoins) // if I counted coins
    {
?>
                    <img src="/img/add-coin-button.png" height=<?php print round(cached_font_size()); ?>px width=<?php print round(cached_font_size()); ?>px
<?php
    }
    else
    {
?>
                    <img src="/img/refresh.png" height=<?php print round(cached_font_size()); ?>px width=<?php print round(cached_font_size()); ?>px
<?php
    }
?>
                         class="invertible-icon" style="padding:-0.17rem;line-height:0.58rem;margin:-0.33rem;margin-top:-0.41rem;margin-bottom:-0.25rem;border:0">
                  </button>
                </td>
              </tr>
            </table>
            <table id="coins" class="striped">
              <tbody>
                <tr>
                  <th style="width:40%;text-align:right">¢&nbsp;&nbsp;</th>
                  <th style="width:23%;text-align:right">Qty&nbsp;</th>
                  <th style="width:37%">Val </th>
                </tr>
<?php
    if($CountCoins) // I counted coins
    {
?>
                <tr>
                  <td>1¢</td><td id="qc1"><?php print $count1c; ?></td><td id="vc1"><?php printf("%0.2f", $count1c * 0.01); ?></td></tr>
                <tr>
                  <td>5¢</td><td id="qc5"><?php print $count5c; ?></td><td id="vc5"><?php printf("%0.2f", $count5c * 0.05); ?></td></tr>
                <tr>
                  <td>10¢</td><td id="qc10"><?php print $count10c; ?></td><td id="vc10"><?php printf("%0.2f", $count10c * 0.10); ?></td></tr>
                <tr>
                  <td>25¢</td><td id="qc25"><?php print $count25c; ?></td><td id="vc25"><?php printf("%0.2f", $count25c * 0.25); ?></td></tr>
<?php
      if($count100c > 0)
      {
?>
                <tr>
                  <td>$1.00</td><td id="qc100"><?php print $count100c; ?></td><td id="vc100"><?php printf("%0.2f", $count100c); ?></td></tr>
<?php
      }
?>
<?php
      if($CountRolls) // counted rolls - with coins, the refresh button will be here
      {
?>
              <tr style="line-height:0.5em">
                <td>&nbsp;<td>
              </tr>
              </tbody>
            </table>
            <table style="line-height:1rem;font-size:inherit;min-width:100%;margin:0;padding:0">
              <tr style="line-height:1rem">
                <td style="width:15%">&nbsp;</td>
                <td class="table-name" style="text-align:center;line-height:1rem;width:70%">
                  <?php print $Rolls; ?>
                </td>
                <td>
                  <button type=submit form=redo-form formaction="/count-rolls.php"
                          class="btn waves-effect primary-fill btn-shadow"
                          style="min-height:0px;height:1rem;line-height:1rem;width:1rem;padding:0;margin:0">
                    <img src="/img/refresh.png" height=<?php print round(cached_font_size()); ?>px width=<?php print round(cached_font_size()); ?>px
                         class="invertible-icon" style="padding:-0.17rem;line-height:0.58rem;margin:-0.33rem;margin-top:-0.41rem;margin-bottom:-0.25rem;border:0">
                  </button>
                </td>
              </tr>
            </table>
            <table class="striped">
              <tbody>
<?php
      }
    }
    if($CountRolls) // counted rolls (refresh button already displayed)
    {
?>
                <tr>
                  <td style="width:40%">1¢ roll</td>
                  <td id="qr1" style="width:23%"><?php print $roll1 / 50; ?></td>
                  <td id="vr1" style="width:37%"><?php printf("%0.2f", $roll1 * 0.01); ?></td>
                </tr>
                <tr>
                  <td>5¢ roll</td><td id="qr5"><?php print $roll5 / 40; ?></td><td id="vr5"><?php printf("%0.2f", $roll5 * 0.05); ?></td></tr>
                <tr>
                  <td>10¢ roll</td><td id="qr10"><?php print $roll10 / 50; ?></td><td id="vr10"><?php printf("%0.2f", $roll10 * 0.10); ?></td></tr>
                <tr>
                  <td>25¢ roll</td><td id="qr25"><?php print $roll25 / 40; ?></td><td id="vr25"><?php printf("%0.2f", $roll25 * 0.25); ?></td></tr>
<?php
    }
?>
              </tbody>
            </table>
            <div class="subLabel">Subtotal $</div>
<?php
    if($CountCoins && $CountRolls) // counted coins and rolls
    {
?>
            <div class="subtotal" style="display:none" id="coinsSubTotal"><?php printf("%0.2f", $coinsSubTotal); ?></div>
            <div class="subtotal" style="display:none" id="rollsSubTotal"><?php printf("%0.2f", $rollsSubTotal); ?></div>
<?php
    }
?>
            <div class="subtotal"id="allCoinsSubTotal"><?php printf("%0.2f", $coinsPlusRolls); ?></div>
<?php
  }
?>
          </div>

          <div class="col s12 m4">
<?php
  if($CountNotes) // counted notes
  {
?>
            <table style="line-height:1rem;font-size:inherit;min-width:100%;margin:0;padding:0">
              <tr style="line-height:1rem">
                <td style="width:15%">&nbsp;</td>
                <td class="table-name" style="text-align:center;line-height:1rem;width:70%">
                  <?php print $Notes; ?>
                </td>
                <td>
                  <button type=submit form=redo-form formaction="/glue/start-zeus.php"
                          class="btn waves-effect primary-fill btn-shadow"
                          style="min-height:0px;height:1rem;line-height:1rem;width:1rem;padding:0;margin:0">
                    <img src="/img/refresh.png" height=<?php print round(cached_font_size()); ?>px width=<?php print round(cached_font_size()); ?>px
                         class="invertible-icon" style="padding:-0.17rem;line-height:0.58rem;margin:-0.33rem;margin-top:-0.41rem;margin-bottom:-0.25rem;border:0">
                  </button>
                </td>
              </tr>
            </table>
            <table id="notes" class="striped">
              <tbody>
                <tr>
                  <th style="width:30%;text-align:right">$&nbsp;&nbsp;</th>
                  <th style="width:30%;text-align:right">Qty&nbsp;</th>
                  <th style="width:40%">Val</th>
                </tr>
                <tr>
                  <td>$1</td><td id="qn1"><?php print $count1; ?></td><td id="vn1"><?php print $count1; ?></td></tr>
                <tr>
                  <td>$2</td><td id="qn2"><?php print $count2; ?></td><td id="vn2"><?php print $count2 * 2; ?></td></tr>
                <tr>
                  <td>$5</td><td id="qn5"><?php print $count5; ?></td><td id="vn5"><?php print $count5 * 5; ?></td></tr>
                <tr>
                  <td>$10</td><td id="qn10"><?php print $count10; ?></td><td id="vn10"><?php print $count10 * 10; ?></td></tr>
                <tr>
                  <td>$20</td><td id="qn20"><?php print $count20; ?></td><td id="vn20"><?php print $count20 * 20; ?></td></tr>
                <tr>
                  <td>$50</td><td id="qn50"><?php print $count50; ?></td><td id="vn50"><?php print $count50 * 50; ?></td></tr>
                <tr>
                  <td>$100</td><td id="qn100"><?php print $count100; ?></td><td id="vn100"><?php print $count100 * 100; ?></td></tr>
              </tbody>
            </table>
            <div class="subLabel">Subtotal $</div>
            <div class="subtotal"id="notesSubTotal"><?php print $notesSubTotal; ?></div>
<?php
    if($ChangeOrder != 0) // change order amount
    {
?>
            <div style="font-size:0.2rem;line-height:0.2rem;padding:0;margin:0;height:0.2rem"/>&nbsp;</div>
<?php
    }
  }
?>

<?php
  if($ChangeOrder != 0) // change order amount
  {
?>
            <table style="line-height:1rem;font-size:inherit;min-width:100%;margin:0;padding:0">
              <tr style="line-height:1rem">
                <td style="width:10%">&nbsp;</td>
                <td class="table-name" style="text-align:center;line-height:1rem;width:75%">
                  <?php print $ChangeOrderName; ?>
                </td>
                <td>
                  <button type=submit form=redo-form formaction="/change-order.php"
                          class="btn waves-effect primary-fill btn-shadow"
                          style="min-height:0px;height:1rem;line-height:1rem;width:1rem;padding:0;margin:0">
                    <img src="/img/refresh.png" height=<?php print round(cached_font_size()); ?>px width=<?php print round(cached_font_size()); ?>px
                         class="invertible-icon" style="padding:-0.17rem;line-height:0.58rem;margin:-0.33rem;margin-top:-0.41rem;margin-bottom:-0.25rem;border:0">
                  </button>
                </td>
              </tr>
            </table>
            <div class="subLabel">Subtotal $</div>
            <div class="subtotal" id="changeorderSubTotal">
              <?php print $ChangeOrderAmt; ?>
            </div>
<?php
  }
?>
          </div>

<?php
  if($CountStraps) // counted straps
  {
?>
          <div class="col s12 m4">
            <table style="line-height:1rem;font-size:inherit;min-width:100%;margin:0;padding:0">
              <tr style="line-height:1rem">
                <td style="width:15%">&nbsp;</td>
                <td class="table-name" style="text-align:center;line-height:1rem;width:70%">
                  <?php print $Straps; ?>
                </td>
                <td>
                  <button type=submit form=redo-form formaction="/count-straps.php"
                          class="btn waves-effect primary-fill btn-shadow"
                          style="min-height:0px;height:1rem;line-height:1rem;width:1rem;padding:0;margin:0">
                    <img src="/img/refresh.png" height=<?php print round(cached_font_size()); ?>px width=<?php print round(cached_font_size()); ?>px
                         class="invertible-icon" style="padding:-0.17rem;line-height:0.58rem;margin:-0.33rem;margin-top:-0.41rem;margin-bottom:-0.25rem;border:0">
                  </button>
                </td>
              </tr>
            </table>
            <table id="straps" class="striped">
              <tbody>
                <tr>
                  <th style="width:30%;text-align:right">$&nbsp;&nbsp;</th>
                  <th style="width:30%;text-align:right">Qty&nbsp;</th>
                  <th style="width:40%">Val</th>
                </tr>
                <tr>
                  <td>$1</td><td id="qs1"><?php print $strap1; ?></td><td id="vs1"><?php print $strap1; ?></td></tr>
                <tr>
                  <td>$5</td><td id="qs5"><?php print $strap5; ?></td><td id="vs5"><?php print $strap5 * 5; ?></td></tr>
                <tr>
                  <td>$10</td><td id="qs10"><?php print $strap10; ?></td><td id="vs10"><?php print $strap10 * 10; ?></td></tr>
                <tr>
                  <td>$20</td><td id="qs20"><?php print $strap20; ?></td><td id="vs20"><?php print $strap20 * 20; ?></td></tr>
              </tbody>
            </table>
            <div class="subLabel">Subtotal $</div>
            <div class="subtotal"id="strapsSubTotal"><?php print $strapsSubTotal; ?></div>
          </div>
        </div>
      </div>
<?php
  }
?>

      <div class="page-total  grand_total">
        <div class="page-total-textfield" style="display:block">
          <label class="sublabel">Grand Total</label>
          <input id="page-total" class="grandtotal" type="text" value="$<?php print $pageTotal; ?>" maxlength="10" disabled />
        </div>
      </div>
      <div class="next-button">
        <form method=GET>
          <input type=hidden name=complete value="Y" style="visibility:hidden" />
          <!-- post back to myself with 'complete=Y' and handle it -->
          <button formaction="/count-summary.php" class="btn waves-effect primary-fill btn-shadow">Print &amp; Done</button>
        </form>
      </div>
    </div>

    <!--  Scripts-->
    <script src="/js/UserFeedback.js"></script>

  </body>
</html>

