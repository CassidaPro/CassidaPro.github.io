<?php

  include "../glue/config_utils.php";

  // use sessions for the wizard (always)
  session_start(); // using session control

  $back = do_getvar("back", "");

  if(strlen($back) > 0) // editing the global file
  {
    if(isset($_SESSION["LocalConfig"]))
      unset($_SESSION["LocalConfig"]);

    $LocalConfig = "";
  }
  else if(isset($_SESSION["LocalConfig"]))
  {
    $LocalConfig = $_SESSION["LocalConfig"];
  }
  else
  {
    $LocalConfig = "";
  }

  if(strlen($LocalConfig) == 0) // normally, this
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /system-menu.php");
    exit;
  }

  if(strpos($LocalConfig, "/") !== false ||
     strpos($LocalConfig, "*") !== false ||
     strpos($LocalConfig, "\\") !== false ||
     strpos($LocalConfig, "?") !== false ||
     strpos($LocalConfig, "[") !== false ||
     strpos($LocalConfig, "]") !== false ||
     strpos($LocalConfig, "{") !== false ||
     strpos($LocalConfig, "}") !== false ||
     strpos($LocalConfig, "(") !== false ||
     strpos($LocalConfig, ")") !== false ||
     strpos($LocalConfig, "..") !== false)
  {
    header("HTTP/1.0 500 Server Error");
?>
    <HTML>
      <HEAD><TITLE>ERROR</TITLE>
        <meta http-equiv="refresh" content="30;url=/config/">
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <center>
          <H1>Saving Configuration Info</H1><br>
          <H1><b>ERROR:  Unable to save configuration info!</b></H1>
          <H3>Problem with configuration file name<br>
              <?php print $LocalConfig; ?></H3>
        </center>
      </BODY>
    </HTML>
<?php
    exit;
  }

  $doohicky = do_getvar("doohicky", "");
  if($doohicky == "")
  {
?>
    <HTML>
      <HEAD>
        <TITLE>Download Configuration File</TITLE>
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
          body
          {
            background-color:#0a240a;
            color:#ffffe0;
            font-size: 0.83rem;
          }
          input
          {
            font-size: 0.83rem;
          }
        </style>
      </HEAD>
      <BODY>
        <H1><center>Download Configuration File</center></H1>
        <H3><center>Press 'Download' to retrieve the config file<br>
                    Press 'Exit' to return to the Configuration system</center></H3>
        <br>
        <br>
        <br>
        <br>
        <form id=download action="initial-setup6.php" method=GET>
          <input type=hidden name=doohicky value="Y" style="visibility:hidden" />
        </form>
        <form id=none action="./" method=GET>
        </form>
        <center>
          <table width="400px">
            <tr>
              <td width="200px">
                <center>
                  <input type=submit form=none value="Exit" />
                </center>
              </td>
              <td width="200px">
                <center>
                  <input type=submit form=download value="Download" />
                </center>
              </td>
            </tr>
          </table>
        </center>
      </BODY>
    </HTML>
<?php
  }
  else
  {
    $LocalConfig = "/var/tmp/" . $LocalConfig;

    // I have a local config and I want to download it

    header("Content-Type: application/x-unknown");
    header('Content-Disposition: attachment; filename="configuration.conf"');
    header("Content-Location: /config/configuration.conf");

    print shell_exec("cat " . $LocalConfig );

    exit;
  }
?>

