<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/config_utils.php";

  $doohickey = do_getvar("doohickey", "");

  if($doohickey == "")
  {
    // load list of upgrade files - and provide a screen to indicate something happened
?>
    <!--          Copyright 2019-2023 by Cassida          -->
    <!-- Use only in accordance with the supplied license -->
    <!DOCTYPE html>
    <html lang="en">
      <HEAD>
        <TITLE>Downloading Configuration Info</TITLE>
        <meta http-equiv="refresh" content="0.1;url=/config/download.php?doohickey=N">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Downloading Configuration Info</center></H1>
        <br><br>
        <H3><center>Please be patient - this could take a minute</center></H3>
        <br>
        <center>
          <span id=dots></span>
        </center>
        <script>
          var dotty = ".";
          function do_dots()
          {
            document.getElementById("dots").innerHTML = dotty;
            dotty = dotty + ".";
          }
          setInterval(do_dots, 1000);
        </script>
      </BODY>
    </HTML>
<?php
    exit;
  }

  $upgrade_url = ltrim(rtrim(do_getvar("URL", "")));
  $upgrade_file = ltrim(rtrim(do_getvar("FILE", "")));

  $parseconf = load_parseconf();

  if($doohickey == "Y")
  {
    // validate
    if(strlen($upgrade_url) == 0 || strlen($upgrade_file) == 0
       || (substr($upgrade_url, 0, 7) != "http://" && substr($upgrade_url, 0, 8) != "https://")
       || strpos($upgrade_file, '.') == 0 || strpos($upgrade_file, '/') != false)
    {
      header("HTTP/1.0 500 Server Error");
      print $upgrade_url . "<br>" . $upgrade_file . "<br>";
      print strlen($upgrade_url) . ". "
          . strlen($upgrade_file) . ". "
          . substr($upgrade_url, 0, 7) . ". "
          . substr($upgrade_url, 0, 8) . ". "
          . strpos($upgrade_file, '.') . ", "
          . (strpos($upgrade_file, '/') == false ? "1" : "0");
?>
    <HTML>
      <HEAD>
        <TITLE>Internal Error</TITLE>
        <meta http-equiv="refresh" content="15;url=/">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Internal Error (y)</center></H1>
      </BODY>
    </HTML>
<?php
      exit;
    }

    // begin downloading upgrade file - and provide a screen to indicate something happened
?>
    <!--          Copyright 2019-2023 by Cassida          -->
    <!-- Use only in accordance with the supplied license -->
    <!DOCTYPE html>
    <html lang="en">
      <HEAD>
        <TITLE>Downloading Upgrade File</TITLE>
        <meta http-equiv="refresh" content="0.1;url=/config/download.php?doohickey=YY&FILE=<?php print urlencode($upgrade_file) . "&URL=" . urlencode($upgrade_url); ?>">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Downloading Upgrade File</center></H1>
        <br><br>
        <H3><center>The file download will begin shortly</center></H3>
        <br>
        <center>
          <span id=dots></span>
        </center>
        <script>
          var dotty = ".";
          function do_dots()
          {
            document.getElementById("dots").innerHTML = dotty;
            dotty = dotty + ".";
          }
          setInterval(do_dots, 1000);
        </script>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($doohickey == "YY")
  {
    // validate
    if(strlen($upgrade_url) == 0 || strlen($upgrade_file) == 0
       || (substr($upgrade_url, 0, 7) != "http://" && substr($upgrade_url, 0, 8) != "https://")
       || strpos($upgrade_file, '.') == 0 || strpos($upgrade_file, '/') != false)
    {
      header("HTTP/1.0 500 Server Error");
      print $upgrade_url . "<br>" . $upgrade_file . "<br>";
      print strlen($upgrade_url) . ". "
          . strlen($upgrade_file) . ". "
          . substr($upgrade_url, 0, 7) . ". "
          . substr($upgrade_url, 0, 8) . ". "
          . strpos($upgrade_file, '.') . ", "
          . (strpos($upgrade_file, '/') == false ? "1" : "0");
?>
    <HTML>
      <HEAD>
        <TITLE>Internal Error</TITLE>
        <meta http-equiv="refresh" content="15;url=/">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Internal Error (yy)</center></H1>
      </BODY>
    </HTML>
<?php
      exit;
    }

    shell_exec("/bin/rm -f " . get_upgrade_files_path() . "out.out");

//    print ("/usr/sbin/daemonize /usr/bin/curl -4 --stderr " . get_upgrade_files_path()
//               . "out.out --output " . get_upgrade_files_path() . $upgrade_file
//               . " " . $upgrade_url);
//    exit;
    shell_exec("/usr/sbin/daemonize /usr/bin/curl -4 --stderr " . get_upgrade_files_path()
               . "out.out --output " . get_upgrade_files_path() . $upgrade_file
               . " " . $upgrade_url);

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /config/download.php?doohickey=YYY&FILE=" . urlencode($upgrade_file));
    exit;

    // TODO:  write web pages that queries /glue/curl-download-status.php to get back
    //        an estimate of how much of the file has downloaded so far and when it hits
    //        100, move on to a process that actually does the upgrade

  }
  else if($doohickey == "N")
  {
    $index = shell_exec("/usr/bin/curl -4 -s https://CassidaPro.github.io/upgrade_files/index.txt");
//    $index = "RPi 20230505 0 Cassida_Skyy_Update.RPi.20230505.zip https://cassidapro.github.io/upgrade_files/Cassida_Skyy_Update.RPi.20230505.zip\n"
//           . "tinkerboard 20230505 0 Cassida_Skyy_Update.tinkerboard.20230505.zip https://cassidapro.github.io/upgrade_files/Cassida_Skyy_Update.tinkerboard.20230505.zip\n"
//           . "tinkerboard 20230509 0 Cassida_Skyy_Update.tinkerboard.20230509.zip https://cassidapro.github.io/upgrade_files/Cassida_Skyy_Update.tinkerboard.20230509.zip\n";

    $curver = ltrim(rtrim(shell_exec("/home/pi/bin/skyy -VQ")));
    if(strlen($curver) == 10)
      $curver = substr($curver,0,4) . substr($curver,5,2) . substr($curver,8,2);

    $model = ltrim(rtrim(shell_exec("/bin/cat /sys/firmware/devicetree/base/model")));
    $model_filter="";
    if(strtoupper($model) == "ASUS TINKER BOARD 2/2S")
      $model_filter = "tinkerboard";
    else if(substr(strtoupper($model),0,12) == "RASPBERRY PI")
      $model_filter = "RPi";
    else
      $model = $model . "<br>(Not Supported)\n";
?>
    <!--          Copyright 2019-2023 by Cassida          -->
    <!-- Use only in accordance with the supplied license -->
    <!DOCTYPE html>
    <html lang="en">
      <HEAD>
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
    set_ideal_font_height();
?>
          body
          {
            background-color:#0a240a;
            color:#ffffe0;
            font-size: 0.8rem;
          }
        </style>
        <script>
          function doClick(upgrade_file, upgrade_url)
          {
            location.href = "/config/download.php?doohickey=Y&FILE=" + encodeURIComponent(upgrade_file)
                          + "&URL=" + encodeURIComponent(upgrade_url);
          }
        </script>
      </HEAD>
      <BODY>
        <center>
          <H1>
            Available Upgrade Files
          </H1>
          <span style="font-size:0.6rem">for</span>
          <H4 style="font-size:0.67rem !important">
            <?php print $model; ?>
          </H4>
          <br />
          <H4 style="font-size:0.55rem !important">
            Installed Firmware Version: <?php print $curver; ?>
          </H4>
        </center>
        <form id=none method="GET" style="visibility:hidden;display:none"></form>
        <center>
          <table border=1 style="width:80%;max-width:85%;height:50%;font-size:0.75rem;display:inline-block;overflow:auto;">
            <!--th>Board</th--><th>Version</th><th>MOD</th><th>Click to download and install</th>
<?php
    $rr = explode("\n", $index);

    foreach($rr as $kk => $rrr)
    {
      if(strlen(ltrim($rrr)) > 0)
      {
        $cc = explode(" ", $rrr);

        if($model_filter == ltrim(rtrim($cc['0'])))
        {
          print "            <tr style='vertical-align:middle !important'>\n";

          foreach($cc as $k2 => $ccc)
          {
            if($k2 > 0 && $k2 < 3)
            {
              print "              <td style='padding:0";

              if($k2 == "2")
                print ";text-align:center";
              else
                print ";padding-right:0.4rem";

              print "'>" .  $ccc;

              if($k2 == "1")
              {
                if($curver < $ccc)
                  print "&nbsp;&nbsp;+";
                else if($curver == $ccc)
                  print "&nbsp;&nbsp;=";
                else if($curver == $ccc)
                  print "&nbsp;&nbsp;";
              }

              print "</td>\n";
            }
            else if($k2 == 3)
            {
              print "              <td style='min-width:80%'><center><input type='button' value='" . $ccc . "' onClick='doClick(\""
                  . $ccc . "\",\"" ;
            }
            else if($k2 == 4)
            {
              print $ccc . "\");' style='font-size:0.67rem'/></center></td>\n";
            }
          }

          print "            </tr>\n";
        }
      }
    }
?>
          </table>
        </center>

        <div style="position:absolute;left:0;bottom:0.75rem;width:100%;padding:0;margin:0;min-height:2rem">
          <center>
            <input type=submit form=none formaction="/config/" value="Back" style="position:relative;bottom:0"/>
          </center>
        </div>

      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($doohickey == "DONE")
  {
    // RE-DIRECT and commanding skyy with 'do-upgrade'

    skyyreq("do-upgrade/" . $upgrade_file);

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /");
    exit;
  }
  else if($doohickey != "YYY")
  {
    // DOWNLOADING status screen
?>
    <HTML>
      <HEAD>
        <TITLE>Internal Error</TITLE>
        <meta http-equiv="refresh" content="15;url=/">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Internal Error (<?php print $doohickey; ?>)</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
<HTML>
  <HEAD>
    <TITLE>Download Upgrade File</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
set_ideal_font_height();
?>
    </style>
  </HEAD>
  <BODY>
    <H1 style='font-size:1.2rem'><center>Upgrade File Download Progress</center></H1>
    <br><br>
    <H4 style='font-size:0.83rem'><center>Downloading <?php print $upgrade_file; ?></center></H4>
    <center>
      <span id=status_text></span>
    </center>
    <script>
      var theInterval = null;

      function do_dots()
      {
        var myRequest = new Request("/glue/curl-download-status.php");

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("continue-c400", response.status); // debug only (TODO: remove?  this is actually an error condition...)
                  }
                  return  response.text();
                })
          .then(function(text)
                {
                  if(text.length == 0)
                  {
                    document.getElementById("status_text").innerHTML = "UNRESPONSIVE";

                    setTimeout(function(){ location.href = "/config/"; }, 2000); // 2 secd dely and bail,
                  }
                  else if((text * 1) >= 100)
                  {
                    // finished
                    document.getElementById("status_text").innerHTML = "100%";

                    location.href = "/config/download.php?doohickey=DONE&FILE=<?php print urlencode($upgrade_file);?>"; // for now
                  }
                  else if((text * 1) < 0)
                  {
                    clearInterval(theInterval);

                    document.getElementById("status_text").innerHTML = "ERROR";
                    setTimeout(function(){ location.href = "/config/"; }, 2000); // 2 secd dely and bail,
                  }
                  else
                  {
                    document.getElementById("status_text").innerHTML = text + '%';
                  }
                })
         .catch(function(err)
                {
                  console.log("Error detected in Resume()");
                  console.error(err);
                });

          myRequest = null;
      }

      theInterval = setInterval(do_dots, 2000);
    </script>
  </BODY>
</HTML>

