<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/config_utils.php";

  setup_screen_res();

  $parseconf = load_parseconf();

  $CustomerMod = !empty($parseconf["settings"]) && !empty($parseconf["settings"]["CustomerMod"])
               ? $parseconf["settings"]["CustomerMod"] : "0";

  // for people connecting from "not localhost" I allow creating a new config file

//  $ip_addr = $_SERVER["REMOTE_ADDR"];
  $ip_addr = empty($_SERVER) || empty($_SERVER["REMOTE_ADDR"])
           ? "" // unlikely, but here anyway
           : $_SERVER["REMOTE_ADDR"];

  $doohicky=do_getvar("doohicky", "");

  $CustomerMod=do_getvar("CustomerMod", $CustomerMod);

  if($doohicky == "Y" &&
     strlen($ip_addr) > 4 && substr($ip_addr, 0, 4) != "127.")
  {
    // get me a random file name
    $LocalConfig = shell_exec("tempfile -p thing -d /var/tmp");
    if(!strlen(ltrim(rtrim($LocalConfig))))
    {
?>
    <HTML>
      <HEAD><TITLE>ERROR</TITLE>
        <meta http-equiv="refresh" content="10;url=/config/" >
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <center>
          <H1>Creating Configuration Info</H1><br>
          <H1><b>ERROR:  Unable to create configuration info!</b></H1>
        </center>
      </BODY>
    </HTML>
<?php
      exit;
    }

    // copy the default config in there
    if($CustomerMod == '0')
      shell_exec("cp /home/pi/source/Project-Skyy/ui/config/factory_default_configuration.conf " . $LocalConfig);
    else
      shell_exec("cp /home/pi/source/Project-Skyy/ui/config/factory_default_configuration." . $CustomerMod . ".conf " . $LocalConfig);

    // strip off the /var/tmp and submit that as a parameter to initial-config.php
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: initial-setup.php?LocalConfig=" . substr($LocalConfig, 9, strlen($LocalConfig)));
    // NOTE:  the parameter will only have the filename; that is, /var/tmp/ is strpped away
    //        when iniial-setup.php gets the file name it will sanitize it and fail if any wildards or paths are in it
    exit;
  }

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Split Recycler System - Configuration Maintenance</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }
    </style>
  </HEAD>
  <BODY>
    <center>
      <b>
        <H1 style="margin:0;padding:0;font-size:1rem">Split Recycler - Configuration</H1>
        <H4 style="margin:0;padding:0;margin-bottom:0.5rem !important;font-size:0.7rem">Updates and Configuration Maintenance</H4>
      </b>
    </center>
    <form id=none></form>
    <form id=newconfig method=GET>
      <input type=hidden name=doohicky value="Y" style="visibility:hidden;display:none" />
    </form>
    <center>
      <table width="75%">
        <tr>
          <td width="30%"><input type=submit form=none formaction="./download.php" value="Updates" style="min-width:6rem" /></td>
          <td width="70%" style="margin-left:10px">Check for and optionally update system</td>
        </tr>
        <tr style="font-size:1.2rem;line-height:1.2rem;padding:0;margin:0"><td>&nbsp;</td><td>&nbsp;</td></tr>
        <tr>
          <td width="30%"><input type=submit form=none formaction="./configuration-backup.php" value="Backup" style="min-width:6rem" /></td>
          <td width="70%" style="margin-left:10px">Backup configuration file</td>
        </tr>
        <tr style="font-size:0.1rem;line-height:0.1rem;padding:0;margin:0"><td>&nbsp;</td><td>&nbsp;</td></tr>
        <tr>
          <td width="30%"><input type=submit form=none formaction="./configuration-restore.php" value="Restore" style="min-width:6rem" /></td>
          <td width="70%" style="margin-left:10px">Restore configuration from backup file</td>
        </tr>
        <tr style="font-size:1.2rem;line-height:1.2rem;padding:0;margin:0"><td>&nbsp;</td><td>&nbsp;</td></tr>
        <tr>
          <td width="30%"><input type=submit form=none formaction="./edit.php" value="Edit Config" style="min-width:6rem" /></td>
          <td width="70%" style="margin-left:10px">Edit configuration</td>
        </tr>
<?php
  if(strlen($ip_addr) > 4 && substr($ip_addr, 0, 4) != "127.")
  {
?>
        <tr style="font-size:0.8rem;line-height:0.8rem;padding:0;margin:0"><td>&nbsp;</td><td>&nbsp;</td></tr>
        <tr>
          <td width="30%"><input type=submit form=newconfig formaction="index.php" value="New Config" style="min-width:6rem" /></td>
          <td width="70%" style="margin-left:10px">Create a New Config File and download it</td>
        </tr>
<?php
  }
?>
      </table>
    </center>


    <div style="position:absolute;left:0;bottom:0.75rem;width:100%;padding:0;margin:0;min-height:2rem">
      <center>
        <input type=submit form=none formaction="/system-menu.php" value="System Menu" style="position:relative;bottom:0"/>
      </center>
    </div>

    <script>
      // This special script is not documented
      // must be defined before any 'onClick' field refers to it
      // 'Semprini' is a Monty Python joke

      var nTimes=0;
      var nLastTime=Date.now();

      function Semprini()
      {
        var nNow = Date.now();

        if(!nTimes)
        {
          nTimes = 1;
          nLastTime = nNow;
          return;
        }

        if((nNow - nLastTime) < 500 || // less than half sec
           (nNow - nLastTime) > 1500) // more than 1.5 sec
        {
          nTimes = 0;
          nLastTime = nNow;
          return;
        }

        nTimes = nTimes + 1;
        nLastTime = nNow;

        if(nTimes > 5)
        {
          // change this according to the need
          window.location.assign("/test-index.php");
          return;
        }
      }
    </script>

    <div style="font-size:10px;position: absolute;bottom:4px;right:4px;margin:0;padding:0">
      <!-- this feature is undocumented.  Again -->
      <div onClick="Semprini();" style="min-height:0.83rem;min-width:1.25rem">&nbsp;</div>
    </div>

  </BODY>
</HTML>

