<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include '../glue/config_utils.php';

  // use sessions for the wizard (always)
  session_start(); // using session control

  $back = do_getvar("back", "");

  if(strlen($back) > 0) // editing the global file
  {
    if(isset($_SESSION["LocalConfig"]))
      unset($_SESSION["LocalConfig"]);

    $LocalConfig = "";
  }
  else if(isset($_SESSION["LocalConfig"]))
  {
    $LocalConfig = $_SESSION["LocalConfig"];
  }
  else
  {
    $LocalConfig = "";
  }

  $parseconf = load_parseconf($LocalConfig);

  $Build = $parseconf["vessels"]["Build"];
  $Verify = $parseconf["vessels"]["Verify"];

  $SubmitF=do_getvar("SubmitF", "");

  if($SubmitF == "Y")
  {
    $HasBanking  = do_getvar("HasBanking", "off");

    // TODO:  sanitize user input data first?  go back and re-edit?

?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=initial-setup-Build-Verify.php?SubmitF=YY<?php
            if(strlen($back) > 0)
              print "&back=" . urlencode($back);
            print "&HasBanking=" . urlencode($HasBanking); ?>" >
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($SubmitF == "YY")
  {
    $HasBanking  = do_getvar("HasBanking", "off");

    $has_banking = ($parseconf["Verify"]["Banking"] == "1"
                    || $parseconf["Verify"]["Banking"] == "yes") ? 1 : 0;
    $xhas_banking = $HasBanking == "on" ? 1 : 0;

    $changed = $has_banking != $xhas_banking
             || ($has_banking && empty($Verify));

    if($changed)
    {
      if(empty($Verify))
        unset($parseconf["Verify"]); // = false; // so it is deleted
      else if($xhas_banking)
        $parseconf["Verify"]["Banking"] = "yes";
      else
        $parseconf["Verify"]["Banking"] = "no";

      write_configuration_file($parseconf, "initial-setup6.php", $LocalConfig);
    }

    // flow through to the next page

    header("HTTP/1.0 302 Moved Temporarily");
    if(strlen($back) > 0)
      header("Location: " . $back);
    else
      header("Location: initial-setup6.php");

    if(strlen($back) > 0)
    {
      shell_exec("curl http://localhost:3042/reload");
    }

    exit;
  }

  // TODO:  add the ability to re-invoke this page by specifying
  //        the previous values and selecting focus on an item that
  //        has a problem

  $HasBanking = ($parseconf["Verify"]["Banking"] == "1"
                 || $parseconf["Verify"]["Banking"] == "yes") ? "on" : "off";

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Configuration for Split Recycler System</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }
    </style>
  </HEAD>
  <BODY bgcolor="#101824" text="#ffffe0">
    <form id=none></form>
    <form id=reload>
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <center>
      <b>
        <H1 style="margin:0;padding:0">
<?php
  if(strlen($back) != 0)
  {
?>
          Split Recycler - Edit Config
<?php
  }
  else if(strlen($LocalConfig) != 0)
  {
?>
          Split Recycler - New Config
<?php
  }
  else
  {
?>
          Split Recycler - Initial Setup
<?php
  }
?>
        </H1>
        <H4 style="margin:0;margin-bottom:0.83rem !important;padding:0">
<?php
  if(!empty($Build))
  {
    if(!empty($Verify))
    {
      print "          " . $Build . " and " . $Verify . "\n";
    }
    else
    {
      print "          " . $Build . "\n";
    }
  }
  else
  {
      print "          " . $Verify . "\n";
  }
?>
       </H4>
      </b>
    </center>
    <form id=the_form method=GET>
      <input type=hidden name="SubmitF" value="Y" style="visibility:hidden" />
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
      <center>
        <table>
<?php
  if(!empty($Build))
  {
?>
          <tr>
            <td>
              <?php print $Build; ?> process will be performed
            </td>
          </tr>
<?php
  }

  if(!empty($Build) && !empty($Verify))
  {
?>
          <tr>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
          </tr>
<?php
  }

  if(!empty($Verify))
  {
?>
          <tr>
            <td>
              <?php print $Verify; ?> process will be performed
            </td>
          </tr>
          <tr>
            <td>
              <input id=HasBanking name=HasBanking type=checkbox <?php if($HasBanking == "on") print "checked"; ?> >
                Has Banking (deposit transactions)
              </input>
            </td>
          </tr>
<?php
  }
?>
        </table>
      </center>
    </form>

    <input type=submit form=none
           formaction=
<?php
      print '"';

      if(strlen($back) > 0)
        print $back;
      else if(!empty($parseconf["vessels"]["Class5"]))
        print "initial-setup-Class5.php";
      else if(!empty($parseconf["vessels"]["Class4"]))
        print "initial-setup-Class4.php";
      else if(!empty($parseconf["vessels"]["Class3"]))
        print "initial-setup-Class3.php";
      else if(!empty($parseconf["vessels"]["Class2"]))
        print "initial-setup-Class2.php";
      else if(!empty($parseconf["vessels"]["Class1"]))
        print "initial-setup-Class1.php";
      else
        print "initial-setup5.php";

      print '"';
?>
           value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem" />

    <input type=submit form=reload
           formaction="initial-setup-Build-Verify.php"
           value="Re-load" style="position:absolute;bottom:0.75rem;width:5rem;left:14.2rem"/>
    <input type=submit form=the_form
           formaction="initial-setup-Build-Verify.php"
           value="Next" style="position:absolute;bottom:0.75rem;width:3.33rem;right:3.33rem"/>

  </BODY>
</HTML>

