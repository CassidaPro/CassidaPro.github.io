<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include '../glue/config_utils.php';

  // use sessions for the wizard (always)
  session_start(); // using session control

  $back = do_getvar("back", "");

  if(strlen($back) > 0) // editing the global file
  {
    if(isset($_SESSION["LocalConfig"]))
      unset($_SESSION["LocalConfig"]);

    $LocalConfig = "";
  }
  else if(isset($_SESSION["LocalConfig"]))
  {
    $LocalConfig = $_SESSION["LocalConfig"];
  }
  else
  {
    $LocalConfig = "";
  }

  $parseconf = load_parseconf($LocalConfig);

  $Submit4 = do_getvar("Submit4", "");

  if($Submit4 == "Y")
  {
    $Class1=do_getvar("Class1", "");
    $Class2=do_getvar("Class2", "");
    $Class3=do_getvar("Class3", "");
    $Class4=do_getvar("Class4", "");
    $Class5=do_getvar("Class5", "");

    $Build=do_getvar("Build", "");
    $Verify=do_getvar("Verify", "");

    $Class1Enable = do_getvar("Class1Enable", "off");
    $Class2Enable = do_getvar("Class2Enable", "off");
    $Class3Enable = do_getvar("Class3Enable", "off");
    $Class4Enable = do_getvar("Class4Enable", "off");
    $Class5Enable = do_getvar("Class5Enable", "off");

    $BuildEnable = do_getvar("BuildEnable", "off");
    $VerifyEnable = do_getvar("VerifyEnable", "off");

    $Order=do_getvar("Order", "");

    // TODO:  additional sanitization checks.  Go back and re-edit if bad

    if(empty($Order) ||
       ($Class1Enable != "on" &&
        $Class2Enable != "on" &&
        $Class3Enable != "on" &&
        $Class4Enable != "on" &&
        $Class5Enable != "on" &&
        $BuildEnable != "on" &&
        $VerifyEnable != "on") ||
       ($Class1Enable == "on" && empty($Class1)) ||
       ($Class2Enable == "on" && empty($Class2)) ||
       ($Class3Enable == "on" && empty($Class3)) ||
       ($Class4Enable == "on" && empty($Class4)) ||
       ($Class5Enable == "on" && empty($Class5)) ||
       ($BuildEnable == "on" && empty($Build)) ||
       ($VerifyEnable == "on" && empty($Verify))  )
    {
?>
      <HTML>
        <HEAD>
          <TITLE>Saving Configuration Info</TITLE>
          <meta http-equiv="refresh" content="10;url=initial-setup4.php?Refresh=Y<?php
                if(strlen($back) > 0)
                  print "&back=" . urlencode($back);
                print "&Class1=" . urlencode($Class1);
                print "&Class2=" . urlencode($Class2);
                print "&Class3=" . urlencode($Class3);
                print "&Class4=" . urlencode($Class4);
                print "&Class5=" . urlencode($Class5);
                print "&Class1Enable=" . urlencode($Class1Enable);
                print "&Class2Enable=" . urlencode($Class2Enable);
                print "&Class3Enable=" . urlencode($Class3Enable);
                print "&Class4Enable=" . urlencode($Class4Enable);
                print "&Class5Enable=" . urlencode($Class5Enable);
                print "&Build=" . urlencode($Build);
                print "&Verify=" . urlencode($Verify);
                print "&BuildEnable=" . urlencode($BuildEnable);
                print "&VerifyEnable=" . urlencode($VerifyEnable);
                print "&Order=" . urlencode($Order); ?>" >
        </HEAD>
        <BODY bgcolor="#e0e0e0" text="#8068ff">
          <br><br><br><br>
          <H1><center>ERROR - Bad Configuration Info</center></H1>
        </BODY>
      </HTML>
<?php
      exit;
    }

?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=initial-setup4.php?Submit4=YY<?php
            if(strlen($back) > 0)
              print "&back=" . urlencode($back);
            print "&Class1=" . urlencode($Class1);
            print "&Class2=" . urlencode($Class2);
            print "&Class3=" . urlencode($Class3);
            print "&Class4=" . urlencode($Class4);
            print "&Class5=" . urlencode($Class5);
            print "&Class1Enable=" . urlencode($Class1Enable);
            print "&Class2Enable=" . urlencode($Class2Enable);
            print "&Class3Enable=" . urlencode($Class3Enable);
            print "&Class4Enable=" . urlencode($Class4Enable);
            print "&Class5Enable=" . urlencode($Class5Enable);
            print "&Build=" . urlencode($Build);
            print "&Verify=" . urlencode($Verify);
            print "&BuildEnable=" . urlencode($BuildEnable);
            print "&VerifyEnable=" . urlencode($VerifyEnable);
            print "&Order=" . urlencode($Order); ?>" >
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($Submit4 == "YY")
  {
    $Class1=do_getvar("Class1", "");
    $Class2=do_getvar("Class2", "");
    $Class3=do_getvar("Class3", "");
    $Class4=do_getvar("Class4", "");
    $Class5=do_getvar("Class5", "");

    $Build=do_getvar("Build", "");
    $Verify=do_getvar("Verify", "");

    // if the class is not in use, re-define it as a blank description

    $Class1Enable = do_getvar("Class1Enable", "off");
    $Class2Enable = do_getvar("Class2Enable", "off");
    $Class3Enable = do_getvar("Class3Enable", "off");
    $Class4Enable = do_getvar("Class4Enable", "off");
    $Class5Enable = do_getvar("Class5Enable", "off");

    $BuildEnable = do_getvar("BuildEnable", "off");
    $VerifyEnable = do_getvar("VerifyEnable", "off");

    $Order=do_getvar("Order", "");

    if($Class1Enable != "on")
      $Class1 = "";
    if($Class2Enable != "on")
      $Class2 = "";
    if($Class3Enable != "on")
      $Class3 = "";
    if($Class4Enable != "on")
      $Class4 = "";
    if($Class5Enable != "on")
      $Class5 = "";
    if($BuildEnable != "on")
      $Build = "";
    if($VerifyEnable != "on")
      $Verify = "";

    $Cls1 = array_key_exists("Class1", $parseconf["vessels"])
          ? $parseconf["vessels"]["Class1"] : "";

    $Cls2 = array_key_exists("Class2", $parseconf["vessels"])
          ? $parseconf["vessels"]["Class2"] : "";

    $Cls3 = array_key_exists("Class3", $parseconf["vessels"])
          ? $parseconf["vessels"]["Class3"] : "";

    $Cls4 = array_key_exists("Class4", $parseconf["vessels"])
          ? $parseconf["vessels"]["Class4"] : "";

    $Cls5 = array_key_exists("Class5", $parseconf["vessels"])
          ? $parseconf["vessels"]["Class5"] : "";

    $Bld  = array_key_exists("Build", $parseconf["vessels"])
          ? $parseconf["vessels"]["Build"] : "";

    $Vrfy = array_key_exists("Verify", $parseconf["vessels"])
          ? $parseconf["vessels"]["Verify"] : "";

    $changed = $Cls1 !== $Class1 ||
               $Cls2 !== $Class2 ||
               $Cls3 !== $Class3 ||
               $Cls4 !== $Class4 ||
               $Cls5 !== $Class5 ||
               $Bld !== $Build ||
               $Vrfy !== $Verify ||
               $parseconf["vessels"]["Order"] !== $Order;

    if($changed)
    {
      // if the description changed, make sure I change the key to match the new one
      // if the key exists, that is...

      // re-naming the entries (as needed)

      if($Class1 === false || !strlen($Class1))
      {
        unset($parseconf["Class1"]); // = false; // remove the OLD section
        unset($parseconf["vessels"]["Class1"]);
      }
      else
      {
        $parseconf["vessels"]["Class1"] = $Class1;
      }

      if($Class2 === false || !strlen($Class2))
      {
        unset($parseconf["Class2"]); // = false; // remove the OLD section
        unset($parseconf["vessels"]["Class2"]);
      }
      else
      {
        $parseconf["vessels"]["Class2"] = $Class2;
      }

      if($Class3 === false || !strlen($Class3))
      {
        unset($parseconf["Class3"]); // = false; // remove the OLD section
        unset($parseconf["vessels"]["Class3"]);
      }
      else
      {
        $parseconf["vessels"]["Class3"] = $Class3;
      }

      if($Class4 === false || !strlen($Class4))
      {
        unset($parseconf["Class4"]); // = false; // remove the OLD section
        unset($parseconf["vessels"]["Class4"]);
      }
      else
      {
        $parseconf["vessels"]["Class4"] = $Class4;
      }

      if($Class5 === false || !strlen($Class5))
      {
        unset($parseconf["Class5"]); // = false; // remove the OLD section
        unset($parseconf["vessels"]["Class5"]);
      }
      else
      {
        $parseconf["vessels"]["Class5"] = $Class5;
      }

      if($Build === false || !strlen($Build))
      {
        unset($parseconf["Build"]); // = false; // remove the OLD section
        unset($parseconf["vessels"]["Build"]);
      }
      else
      {
        $parseconf["vessels"]["Build"] = $Build;
      }

      if($Verify === false || !strlen($Verify))
      {
        unset($parseconf["Verify"]); // = false; // remove the OLD section
        unset($parseconf["vessels"]["Verify"]);
      }
      else
      {
        $parseconf["vessels"]["Verify"] = $Verify;
      }


      $parseconf["vessels"]["Order"] = $Order;

      write_configuration_file($parseconf, "initial-setup4.php", $LocalConfig);
    }

    // flow through to the next page

    header("HTTP/1.0 302 Moved Temporarily");
    if(strlen($back) > 0)
      header("Location: " . $back);
    else
      header("Location: initial-setup5.php");

    if(strlen($back) > 0)
    {
      shell_exec("curl http://localhost:3042/reload");
    }

    exit;
  }

  $Refresh=empty($_GET) || empty($_GET["Refresh"]) ? "" : $_GET["Refresh"];

  $Process = do_getconf($parseconf,"terms",'Process','Daily Tasks');
  $Pulls = do_getconf($parseconf,"terms",'Pulls','Pulls');
  $Preload = do_getconf($parseconf,"terms",'Preload','Preload');

//  print $Process . "<br>;\n";
//  print_r($parseconf);
//  exit;


  if($Refresh=='Y')
  {
    // TODO:  add the ability to re-invoke this page by specifying
    //        the previous values and selecting focus on an item that
    //        has a problem

    $Class1Enable = do_getvar("Class1Enable", "off");
    $Class2Enable = do_getvar("Class2Enable", "off");
    $Class3Enable = do_getvar("Class3Enable", "off");
    $Class4Enable = do_getvar("Class4Enable", "off");
    $Class5Enable = do_getvar("Class5Enable", "off");

    $BuildEnable = do_getvar("BuildEnable", "off");
    $VerifyEnable = do_getvar("VerifyEnable", "off");

    $Class1=do_getvar("Class1", "");
    $Class2=do_getvar("Class2", "");
    $Class3=do_getvar("Class3", "");
    $Class4=do_getvar("Class4", "");
    $Class5=do_getvar("Class5", "");

    $Build=do_getvar("Build", "");
    $Verify=do_getvar("Verify", "");
    $Order=do_getvar("Order", "");


//    print "POOBAH<br>\n";
//    print_r($_GET);
//    exit;
  }
  else
  {
    $Class1Enable = "on";
    $Class2Enable = "on";
    $Class3Enable = "on";

    $BuildEnable = "on";
    $VerifyEnable = "on";

    $Class1 = do_getconf($parseconf,"vessels",'Class1','');
    if(!strlen($Class1))
    {
      $Class1Enable = "off";
      $Class1 = 'Safe';
    }

    $Class2 = do_getconf($parseconf,"vessels",'Class2','');
    if(!strlen($Class2))
    {
      $Class2Enable = "off";
      $Class2 = 'Drawer';
    }

    $Class3 = do_getconf($parseconf,"vessels",'Class3','');
    if(!strlen($Class3))
    {
      $Class3Enable = "off";
      $Class3 = 'Till';
    }

    $Build = do_getconf($parseconf,"vessels",'Build','');
    if(!strlen($Build))
    {
      $BuildEnable = "off";
      $Build = 'Build Tills';
    }

    $Verify = do_getconf($parseconf,"vessels",'Verify','');
    if(!strlen($Verify))
    {
      $VerifyEnable = "off";
      $Verify = 'Verify Deposit';
    }

    $Class4 = do_getconf($parseconf,"vessels",'Class4','');
    if(!strlen($Class4) || ($VerifyEnable == "on" && $BuildEnable == "on"))
    {
      $Class4Enable = "off";
      $Class4 = 'Class 4';
    }
    else
    {
      $Class4Enable = "on";
    }

    $Class5  = do_getconf($parseconf,"vessels",'Class5','');
    if(!strlen($Class5) || $VerifyEnable == "on" || $BuildEnable == "on")
    {
      $Class5Enable = "off";
      $Class5 = 'Class 5';
    }
    else
    {
      $Class5Enable = "on";
    }

    $Order   = do_getconf($parseconf,"vessels",'Order','1,2,3');
  }

  // if I can enable class 4 or class 5, handle it here
  if($VerifyEnable == "on" && $BuildEnable == "on")
  {
    $Class4Disabled = "on";
  }
  else
  {
    $Class4Disabled = "off";
  }

  if($VerifyEnable == "on" || $BuildEnable == "on")
  {
    $Class5Disabled = "on";
  }
  else
  {
    $Class5Disabled = "off";
  }



//  $Order = "2,3,1,4" ; // temporary
  // TODO:  sanitize this and if enabled items aren't included, or specified more than once,
  //        fix it so that it is as correct as possible.  Then proceed.

  // First, parse $Order as best as I can
  $aOrder=explode(",", $Order . ",,,,,");
  $aClasses = [];
  $Rows=[];

  // pre-assign zeros and clean up $aOrder
  for($ii=0; $ii < 5; $ii++)
  {
    $aOrder[$ii] = rtrim(ltrim($aOrder[$ii]));
    $aClasses[$ii+1] = 0; // pre-zerio it
  }

  // create an inverse index in '$aClasses'
  for($ii=0; $ii < 5; $ii++)
  {
    if($aOrder[$ii] == "") // skip
      break; // I am done

    $aClasses[$aOrder[$ii]] = $ii + 1; // 1-based row number essentially
  }

  // try to fill in things not already present in '$aOrder'
  // this needs to be improved to avoid missing classes
  for($jj=1; $jj <= 5; $jj++)
  {
    if($aClasses[$jj] == 0) // class has no row
    {
      $ii++;
      $aClasses[$jj] = $ii; // assign next row index to it
    }
  }

  // map 'aOrder' back to 'Rows' so that 'Rows' is an array of class names
  for($ii=1; $ii <= 5; $ii++)
  {
    // map rows to classes
    $Rows[$aClasses[$ii]] = "Class" . $ii;
  }

//  if($Refresh=='Y')
//  {
//    print "\"" . $Rows[1] . "\", \"" . $Rows[2] . "\", \"" . $Rows[3] . "\", \"" . $Rows[4] . "\", \"" . $Rows[5] . "\"";
//    print_r($aOrder);
//    print_r($aClasses);
//    print_r($Order);
//    exit;
//  }

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Configuration for Split Recycler System</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }
    </style>
    <script>
      function doClickKB(strID)
      {
        do_vkey_single(strID, null);
      }

      function doFixOrder()
      {
        var ii;
        var xTemp;
        var aRows = new Array();
<?php
        // transfer '$Rows' in PHP to javascript 'aRows'
        for($ii=1; $ii <= 5; $ii++)
        {
          print "aRows[" . $ii . "]='" . $Rows[$ii] . "';\n";
        }
?>
        xTemp = "";
        for(ii=1; ii <= 5; ii++)
        {
          if(aRows[ii].length > 0)
          {
            var xx = document.getElementById(aRows[ii] + "Enable");
            if(xx && xx.checked == true)
            {
              var jj = aRows[ii].substr(5,99);

              if(xTemp.length > 0)
                xTemp = xTemp + ",";

              xTemp = xTemp + jj;
            }
          }

//          console.log("aRows[" + ii.toString() + "]=", aRows[ii]);
        }

//        console.log("xTemp=", xTemp);

        // assign the 'Order' hidden field (must do this here)
        document.getElementById("Order").value = xTemp;

        // now add all of the disabled ones, in numerical order
        for(ii=1; ii <= 5; ii++)
        {
          if(aRows[ii].length > 0)
          {
            var xx = document.getElementById(aRows[ii] + "Enable");
            if(xx && xx.checked == false)
            {
              var jj = aRows[ii].substr(5,99);

              if(xTemp.length > 0)
                xTemp = xTemp + ",";

              xTemp = xTemp + jj;
            }
          }
        }
      }

      function doUpButton(strID)
      {
        var ii;
        var xTemp;
        var aRows = new Array();
//        var szAlert = "";
<?php
        // transfer '$Rows' in PHP to javascript 'aRows'
        for($ii=1; $ii <= 5; $ii++)
        {
          print "aRows[" . $ii . "]='" . $Rows[$ii] . "';\n";
        }
?>
        for(ii=2; ii <= 5; ii++)
        {
          // bump this one item up in the list by
          // exchanging it with the one above
          if(strID == aRows[ii])
          {
            xTemp = aRows[ii - 1];
            aRows[ii - 1] = aRows[ii];

            aRows[ii] = xTemp; // exchange with item above
            break;
          }
        }

        // rebuild 'Order' and assign to 'Order' element's value

        xTemp = "";
        for(ii=1; ii <= 5; ii++)
        {
          if(aRows[ii].length > 0)
          {
            var xx = document.getElementById(aRows[ii] + "Enable");
            if(xx && xx.checked == true)
            {
              var jj = aRows[ii].substr(5,99);

              if(xTemp.length > 0)
                xTemp = xTemp + ",";

              xTemp = xTemp + jj;
            }
          }

//          szAlert = szAlert + "aRows[" + ii.toString() + "]=" + aRows[ii] + "\n";
        }

//        szAlert = szAlert + "xTemp=" + xTemp + "\n";

        document.getElementById("Order").value = xTemp;

//        alert(szAlert);

        // invoke the form's 'submit' method
        document.getElementById("the_form").submit();
      }

      function doDownButton(strID)
      {
        var ii;
        var xTemp;
        var aRows = new Array();
//        var szAlert = "";
<?php
        // transfer '$Rows' in PHP to javascript 'aRows'
        for($ii=1; $ii <= 5; $ii++)
        {
          print "aRows[" . $ii . "]='" . $Rows[$ii] . "';\n";
        }
?>
        for(ii=1; ii < 5; ii++)
        {
          // bump this one item down in the list by
          // exchanging it with the one above
          if(strID == aRows[ii])
          {
            xTemp = aRows[ii + 1];
            aRows[ii + 1] = aRows[ii];

            aRows[ii] = xTemp; // exchange with item underneath

            break;
          }
        }

        // rebuild 'Order' and assign to 'Order' element's value

        xTemp = "";
        for(ii=1; ii <= 5; ii++)
        {
          if(aRows[ii].length > 0)
          {
            var xx = document.getElementById(aRows[ii] + "Enable");
            if(xx && xx.checked == true)
            {
              var jj = aRows[ii].substr(5,99);

              if(xTemp.length > 0)
                xTemp = xTemp + ",";

              xTemp = xTemp + jj;
            }
          }

//          szAlert = szAlert + "aRows[" + ii.toString() + "]=" + aRows[ii] + "\n";
        }

//        szAlert = szAlert + "xTemp=" + xTemp + "\n";

        document.getElementById("Order").value = xTemp;

//        alert(szAlert);

        // invoke the form's 'submit' method
        document.getElementById("the_form").submit();
      }

      function doClickEnable(strID)
      {
        var xx;

        doFixOrder();

//        xx = document.getElementById(strID + "Enable");
//        if(xx && xx.checked == true)
//        {
//          console.log("test1 " + xx.toString());
//        }
//        else
//        {
//        }

        // for now, just do this
        document.getElementById("the_form").submit();
      }

    </script>
  </HEAD>
  <BODY bgcolor="#101824" text="#ffffe0">
    <form id=noscan method=GET><!-- needed for page 3 -->
      <input type=hidden name="NoScan" value="Y" style="visibility:hidden" />
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <form id=none></form>
    <center>
      <b>
        <H1 style="margin:0;padding:0">
<?php
  if(strlen($back) != 0)
  {
?>
          Split Recycler - Edit Config
<?php
  }
  else if(strlen($LocalConfig) != 0)
  {
?>
          Split Recycler - New Config
<?php
  }
  else
  {
?>
          Split Recycler - Initial Setup
<?php
  }
?>
        </H1>
        <H4 style="margin:0;padding:0;vertical-align:middle">
          Vessels and Process Order
        </H4>
        <div style="margin:0;padding:0;font-size:0.62rem;line-height:0.62rem;margin-bottom:0.33rem">
          Enable and enter description for each vessel class<br>
          Use arrow buttons to change the order on <?php print $Process; ?>
        </div>
      </b>
    </center>
    <form id=the_form method=GET action="initial-setup4.php">
      <input type=hidden id=Refresh name="Refresh" value="Y" style="visibility:hidden" />
      <input type=hidden id=Submit4 name="Submit4" value="Y" style="visibility:hidden" disabled />
      <input type=hidden id=Order   name="Order" value="<?php print $Order; ?>" style="visibility:hidden" />
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
      <center>
        <table width="75%">
          <thead style="font-size:0.71rem"><th>Class</th><th>Class Name Entry</th><th>Class Features</th></thead>
<?php
  for($ii=1; $ii <= 5; $ii++)
  {
    $rr = $Rows[$ii];
    if($rr == "Class1")
    {
?>
          <tr>
            <td width="20%" style="valign:top;text-align:left;font-size:0.75rem;">
              <input id=Class1Enable name=Class1Enable type=checkbox <?php if($Class1Enable == "on") print "checked"; ?>
                     onClick='doClickEnable("Class1");'>
                Class 1
              </input>
            </td>
            <td width="60%" style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Class1 name=Class1 style="width:9.16rem;height:0.92rem"
                     value=<?php print '"' . sanitize_for_html($Class1) . '"'; ?> />
              <a onClick='doClickKB("Class1");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
              <a onClick='doUpButton("Class1");'><img src="../img/up-button.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
              <a onClick='doDownButton("Class1");'><img src="../img/down-button.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
            </td>
            <td width="20%">
              <div style="font-size:0.67rem;text-align:left;vertical-align:middle">
                Balance&nbsp;Reporting
              </div>
            </td>
          </tr>
<?php
    }
    else if($rr == "Class2")
    {
?>
          <tr>
            <td style="valign:top;text-align:left;font-size:0.75rem;">
              <input id=Class2Enable name=Class2Enable type=checkbox <?php if($Class2Enable == "on") print "checked"; ?>
                     onClick='doClickEnable("Class2");'>
                Class 2
              </input>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=16 id=Class2 name=Class2 style="width:9.16rem;height:0.92rem"
                     value=<?php print '"' . sanitize_for_html($Class2) . '"'; ?> />
              <a onClick='doClickKB("Class2");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
              <a onClick='doUpButton("Class2");'><img src="../img/up-button.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
              <a onClick='doDownButton("Class2");'><img src="../img/down-button.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
<?php
    }
    else if($rr == "Class3")
    {
?>
          <tr>
            <td style="valign:top;text-align:left;font-size:0.75rem;">
              <input id=Class3Enable name=Class3Enable type=checkbox <?php if($Class3Enable == "on") print "checked"; ?>
                     onClick='doClickEnable("Class3");'>
                Class 3
              </input>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Class3 name=Class3 style="width:9.16rem;height:0.92rem"
                     value=<?php print '"' . sanitize_for_html($Class3) . '"'; ?> />
              <a onClick='doClickKB("Class3");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
              <a onClick='doUpButton("Class3");'><img src="../img/up-button.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
              <a onClick='doDownButton("Class3");'><img src="../img/down-button.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
            </td>
            <td>
              <div style="font-size:0.67rem;text-align:left;vertical-align:middle">
                <?php print $Pulls; ?>,&nbsp;<?php print $Preload; ?>
              </div>
            </td>
          </tr>
<?php
    }
    else if($rr == "Class4")
    {
      if($Class4Disabled == "on")
      {
?>
          <input type=hidden size=14 id=Class4 name=Class4 style="visibility:hidden"
                 value=<?php print "'" . $Class4 . "'"; ?> />
<?php
      }
      else
      {
?>
          <tr>
            <td style="valign:top;text-align:left;font-size:0.75rem;">
              <input id=Class4Enable name=Class4Enable type=checkbox <?php if($Class4Enable == "on") print "checked"; ?>
                     onClick='doClickEnable("Class4");' >
                Class 4
              </input>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Class4 name=Class4 style="width:9.16rem;height:0.92rem"
                     value=<?php print '"' . sanitize_for_html($Class4) . '"'; ?> />
              <a onClick='doClickKB("Class4");' ><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
              <a onClick='doUpButton("Class4");' ><img src="../img/up-button.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
              <a onClick='doDownButton("Class4");' ><img src="../img/down-button.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
<?php
      }
    }
    else if($rr == "Class5")
    {
      if($Class5Disabled == "on")
      {
?>
          <input type=hidden size=14 id=Class5 name=Class5 style="visibility:hidden"
                 value=<?php print "'" . $Class5 . "'"; ?> />
<?php
      }
      else
      {
?>
          <tr>
            <td style="valign:top;text-align:left;font-size:0.75rem;">
              <input id=Class5Enable name=Class5Enable type=checkbox <?php if($Class5Enable == "on") print "checked"; ?>
                     onClick='doClickEnable("Class5");' >
                Class 5
              </input>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Class5 name=Class5 style="width:9.16rem;height:0.92rem"
                     value=<?php print '"' . sanitize_for_html($Class5) . '"'; ?> />
              <a onClick='doClickKB("Class5");' ><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
              <a onClick='doUpButton("Class5");' ><img src="../img/up-button.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
              <a onClick='doDownButton("Class5");' ><img src="../img/down-button.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
<?php
      }
    }
  }
?>
          <tr>
            <td style="valign:top;text-align:left;font-size:0.75rem;">
              <input id=BuildEnable name=BuildEnable type=checkbox <?php if($BuildEnable == "on") print "checked"; ?>
                     onClick='doClickEnable("Build");'>
                Build
              </input>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Build name=Build style="width:9.16rem;height:0.92rem"
                     value=<?php print '"' . sanitize_for_html($Build) . '"'; ?> />
              <a onClick='doClickKB("Build");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>
          <tr>
            <td style="valign:top;text-align:left;font-size:0.75rem;">
              <input id=VerifyEnable name=VerifyEnable type=checkbox <?php if($VerifyEnable == "on") print "checked"; ?>
                     onClick='doClickEnable("Verify");'>
                Verify
              </input>
            </td>
            <td style="font-size:0.83rem;margin-right:10px">
              <input type=text size=14 id=Verify name=Verify style="width:9.16rem;height:0.92rem"
                     value=<?php print '"' . sanitize_for_html($Verify) . '"'; ?> />
              <a onClick='doClickKB("Verify");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:middle"></a>
            </td>
            <td>
              <div style="font-size:0.67rem;text-align:left;vertical-align:middle">
                Balance Transfer
              </div>
            </td>
          </tr>
        </table>
      </center>
    </form>

    <input type=submit form=<?php if(strlen($back) > 0) print "none"; else print "noscan"; ?>
           formaction="<?php if(strlen($back) > 0) print $back;
                             else if(strlen($LocalConfig) > 0) print "initial-setup3a.php";
                             else print "initial-setup3.php"; ?>"
           value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem"/>
    <input type=submit form=reload
           formaction="initial-setup4.php"
           value="Re-load" style="position:absolute;bottom:0.75rem;width:5rem;left:14.2rem"/>
    <input type=submit
           onClick='document.getElementById("Submit4").disabled = false; document.getElementById("Refresh").disabled = true; document.getElementById("the_form").submit();'
           value="Next" style="position:absolute;bottom:0.75rem;width:3.33rem;right:3.33rem"/>

<?php

  include "../glue/virtual_keyboard.php";

?>

  </BODY>
</HTML>

