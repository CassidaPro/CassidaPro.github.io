<?php

  include "../glue/common_utils.php";

  // parse config file for things I need
  $parseconf = load_parseconf();

  $CustomerMod = !empty($parseconf["settings"]) && !empty($parseconf["settings"]["CustomerMod"])
               ? $parseconf["settings"]["CustomerMod"] : "0";

  $Quickie = do_getvar("Quickie");
  $StoreID = do_getvar("StoreID");

  if($Quickie == "Y")
  {
    if($CustomerMod == '0')
      shell_exec("cp factory_default_configuration.conf /var/cache/skyy/configuration.conf");
    else
      shell_exec("cp factory_default_configuration." . $CustomerMod . ".conf /var/cache/skyy/configuration.conf");

    skyyreq("reload");

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /config/initial-setup.php?Quickie=Y&StoreID=" . urlencode($StoreID));
    exit;
  }

  header("HTTP/1.0 500 Server Error");
?>
  <HTML>
    <HEAD>
      <TITLE>Server Error</TITLE>
      <meta http-equiv="refresh" content="10;url=/maintenance.php">
      <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
      <link rel="shortcut icon" href="../img/favicon.ico">
    </HEAD>
    <BODY>
      <H1><center>SERVER ERROR</center></H1>
      <br><br><br>
      <H3>
        <center>unable to perform desired action. RESET in 10 seconds...<br>
        </center>
      </H3>
      <br>
    </BODY>
  </HTML>


