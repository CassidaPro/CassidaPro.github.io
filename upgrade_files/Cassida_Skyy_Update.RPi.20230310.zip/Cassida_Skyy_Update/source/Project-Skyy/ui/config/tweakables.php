<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include '../glue/config_utils.php';

  $parseconf = load_parseconf($LocalConfig);

  $Build = $parseconf["vessels"]["Build"];
  $Verify = $parseconf["vessels"]["Verify"];


  // default values for tweakables
  $DefaultMaxPayoutStirTime = "2000";


  $MaxPayoutStirTime = ltrim(rtrim(skyyreq("get-tweakable/MaxPayoutStirTime/" . $DefaultMaxPayoutStirTime)));


  $Submit=do_getvar("Submit", "");

  if($Submit == "Y")
  {
?>
    <HTML><HEAD><TITLE>Saving 'Tweakable' Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=tweakables.php?Submit=YY<?php
            print "&MaxPayoutStirTime=" . do_getvar("MaxPayoutStirTime", $DefsaultMaxPayoutStirTime);
            ?>" >
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <H1><center>Saving 'Tweakable' Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($Submit == "YY")
  {
    $XMaxPayoutStirTime = do_getvar("MaxPayoutStirTime", $DefaultMaxPayoutStirTime);

    $changed = $XMaxPayoutStirTime != $MaxPayoutStirTime
             ;

    if($changed)
    {
      skyyreq("set-tweakable/MaxPayoutStirTime/" . $XMaxPayoutStirTime);
    }

    // flow through to the next page

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /");

    exit;
  }

  // TODO:  add the ability to re-invoke this page by specifying
  //        the previous values and selecting focus on an item that
  //        has a problem

  $HasBanking = ($parseconf["Verify"]["Banking"] == "1"
                 || $parseconf["Verify"]["Banking"] == "yes") ? "on" : "off";

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>'Tweakable' Configuration Settings for Split Recycler System</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }
    </style>
  </HEAD>
  <BODY bgcolor="#101824" text="#ffffe0">
    <form id=reload>
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <form id=none></form>
    <center>
      <b>
        <H1 style="margin:0;padding:0">
          Split Recycler - Edit 'Tweakable' Settings
        </H1>
      </b>
    </center>
    <form id=the_form method=GET>
      <input type=hidden name="Submit" value="Y" style="visibility:hidden" />
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
      <br />
      <br />
      <center>
        <table border=1 style="border-color:#ffffff;text-align:left;width:85%;max-height:75%;overflow:auto !important">
          <!--thead>
            <th style="min-width:50%;max-width:50%;width:50% !important">
              Description&nbsp;&nbsp;
            </th>
            <th  style="min-width:50%;max-width:50%;width:50% !important">
              Value
            </th>
          </thead-->
          <tbody>
            <tr border=1 width=100%>
              <td style="text-align:right;min-width:50%">
                Max Payout Stir Time&nbsp;&nbsp;&nbsp;
              </td>
              <td style="min-width:50% !important;max-width:50%;width:50%">
                <select id=MaxPayoutStirTime name=MaxPayoutStirTime
                        style="min-width:40%;width:40%;font-size:0.75rem;margin:0px;padding:0px;padding-left:4;padding-right:4;display:block;height:1.2rem;border-stye:double;border-color:white">
                  <option value="0" <?php if(intval($MaxPayoutStirTime) == 0) print "selected"; ?> >
                    OFF
                  </option>
                  <option value="1000" <?php if(intval($MaxPayoutStirTime) == 1000) print "selected"; ?> >
                    1
                  </option>
                  <option value="1500" <?php if(intval($MaxPayoutStirTime) == 1500) print "selected"; ?> >
                    1.5
                  </option>
                  <option value="2000" <?php if(intval($MaxPayoutStirTime) == 2000) print "selected"; ?> >
                    2
                  </option>
                  <option value="2500" <?php if(intval($MaxPayoutStirTime) == 2500) print "selected"; ?> >
                    2.5
                  </option>
                  <option value="3000" <?php if(intval($MaxPayoutStirTime) == 3000) print "selected"; ?> >
                    3
                  </option>
                  <option value="4000" <?php if(intval($MaxPayoutStirTime) == 4000) print "selected"; ?> >
                    4
                  </option>
                  <option value="5000" <?php if(intval($MaxPayoutStirTime) == 5000) print "selected"; ?> >
                    5
                  </option>
                </select>
              </td>
            </tr>
          </tbody>
        </table>
      </center>
    </form>

    <input type=submit form=none
           formaction="/"
           value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem" />

    <input type=submit form=reload
           formaction="tweakables.php"
           value="Re-load" style="position:absolute;bottom:0.75rem;width:5rem;left:14.2rem"/>
    <input type=submit form=the_form
           formaction="tweakables.php"
           value="Save" style="position:absolute;bottom:0.75rem;width:3.33rem;right:3.33rem"/>

  </BODY>
</HTML>

