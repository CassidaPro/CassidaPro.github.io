<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/config_utils.php";

  setup_screen_res();

  $parseconf = load_parseconf();

  $ColorScheme = do_getconf($parseconf, "settings", "ColorScheme", "");

//  if($ColorScheme != "banana"
//     && $ColorScheme != "cardena"
//     && $ColorScheme != "energy"
//     && $ColorScheme != "grey"
//     && $ColorScheme != "industrial"
//     && $ColorScheme != "padre"
//     && $ColorScheme != "USA")

  for($ii=0; $ii < sizeof($ColorList); $ii++)
  {
    if($ColorScheme == $ColorList[$ii])
      break;
  }

  if($ii >= sizeof($ColorList))
  {
    $ColorScheme = "default";
  }

  $set_color_scheme = do_getvar("set_color_scheme", "");

  if($set_color_scheme == "Y")
  {
    $ColorSchemeX=do_getvar("ColorScheme", "");
    if($ColorScheme != $ColorSchemeX) // only if it changes
    {
?>
      <HTML>
        <HEAD>
          <TITLE>Saving Configuration Info</TITLE>
          <meta http-equiv="refresh"
                content="0.1;url=edit.php?set_color_scheme=YY&ColorScheme=<?php print urlencode($ColorSchemeX); ?>" >
          </HEAD>
          <BODY bgcolor="#e0e0e0" text="#8068ff">
            <br><br><br><br>
            <H1><center>Saving Configuration Info</center></H1>
          </BODY>
        </HTML>
<?php
      exit;
    }

    // re-load
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: edit.php");

    exit;
  }
  else if($set_color_scheme == "YY")
  {
    $ColorSchemeX=do_getvar("ColorScheme", "");

//    if($ColorSchemeX != "banana"
//       && $ColorSchemeX != "cardena"
//       && $ColorSchemeX != "energy"
//       && $ColorSchemeX != "grey"
//       && $ColorSchemeX != "industrial"
//       && $ColorSchemeX != "padre"
//       && $ColorSchemeX != "USA")
    for($ii=0; $ii < sizeof($ColorList); $ii++)
    {
      if($ColorSchemeX == $ColorList[$ii])
        break;
    }

    if($ii >= sizeof($ColorList))
    {
      $ColorSchemeX = "default";
    }

    if($ColorScheme != $ColorSchemeX)
    {
      // re-naming the entries (as needed)
      $parseconf["settings"]["ColorScheme"] = $ColorSchemeX;

      write_configuration_file($parseconf, "edit.php");
    }

    // reload anyway

    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: edit.php");

    // always do the reset
    shell_exec("curl http://localhost:3042/reload");

    exit;
  }


  $Class1 = do_getconf($parseconf, "vessels", "Class1", "");
  $Class2 = do_getconf($parseconf, "vessels", "Class2", "");
  $Class3 = do_getconf($parseconf, "vessels", "Class3", "");
  $Class4 = do_getconf($parseconf, "vessels", "Class4", "");
  $Class5 = do_getconf($parseconf, "vessels", "Class5", "");
  $Build  = do_getconf($parseconf, "vessels", "Build", "");
  $Verify = do_getconf($parseconf, "vessels", "Verify", "");



?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html5>
<html lang="en">
  <HEAD>
    <TITLE>Split Recycler System - Configuration Edit</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.8rem;
        line-height: 1em;
      }
      input
      {
        font-size: 0.8rem !important;
        line-height: 1em;
        padding: 0;
      }
      span
      {
        font-size:0.75rem;
      }
    </style>
  </HEAD>
  <BODY>
    <form id=none></form>
    <form id=back>
      <input type=hidden name=back value="./edit.php" style="visibility:hidden" />
    </form>
    <center>
      <b>
        <H1>Split Recycler - Configuration</H1>
        <H4>Configuration Edit</H4>
      </b>
    </center>
    <br>
    <center>
      <table width="90%">
        <tr style="min-height:1.6rem;margin-bottom:4px">
          <td width="18%">
            <input type=submit form=back formaction="./initial-setup.php" value="Company" style="min-width:6.2rem" />
          </td>
          <td width="0.5%">&nbsp;</td>
          <td width="31.5%">
            <span>
              Company Information
            </span>
          </td>
          <td width="18%">
            <input type=submit form=back formaction="./initial-setup2.php" value="Terms" style="min-width:6.2rem" />
          </td>
          <td width="0.5%">&nbsp;</td>
          <td width="31.5%">
            <span>
              Terms used by Split Recycler
            </span>
          </td>
        </tr>
        <tr style="min-height:38px;margin-bottom:4px">
          <td>
            <input type=submit form=back formaction="./initial-setup5.php" value="Icons" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Choose Icons for<br>buttons and tasks
            </span>
          </td>
          <td>
            <input type=submit form=back formaction="./initial-setup3a.php" value="Equipment" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Installed Equipment
            </span>
          </td>
        </tr>
        <tr style="min-height:38px;margin-bottom:4px">
          <td>
            <input type=submit form=back formaction="./initial-setup4.php" value="Classes" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Vessel Classes and<br>Process Order
            </span>
          </td>
          <td>
            <input type=submit form=back formaction="./initial-setup-Class1.php" value="Class1" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Vessel Class 1<br><?php print $Class1; ?>
            </span>
          </td>
        </tr>
        <tr style="min-height:38px;margin-bottom:4px">
          <td>
            <input type=submit form=back formaction="./initial-setup-Class2.php" value="Class2" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Vessel Class 2<br><?php print $Class2; ?>
            </span>
          </td>
          <td>
            <input type=submit form=back formaction="./initial-setup-Class3.php" value="Class3" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Vessel Class 3<br><?php print $Class3; ?>
            </span>
          </td>
        </tr>
        <tr style="min-height:38px;margin-bottom:4px">
<?php
  if(strlen($Build) > 0 && strlen($Verify) > 0)
  {
?>
          <td>
            <input type=submit form=back formaction="./initial-setup-Build-Verify.php" value="Build+Verify" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              <?php print $Build . "<br>" . $Verify; ?>
            </span>
          </td>
<?php
  }
  else // if(strlen($Build) == 0 || strlen($Verify) == 0)
  {
    $curcol = 0;
    if(strlen($Class4) > 0)
    {
?>
          <td>
            <input type=submit form=back formaction="./initial-setup-Class4.php" value="Class4" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Vessel Class 4<br><?php print $Class4; ?>
            </span>
          </td>
<?php
      $curcol ++;
    }

    if(strlen($Build) > 0)
    {
?>
          <td>
            <input type=submit form=back formaction="./initial-setup-Build-Verify.php" value="Build" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Build Class<br><?php print $Build; ?>
            </span>
          </td>
<?php
      $curcol ++;
    }
    else if(strlen($Verify) > 0)
    {
?>
          <td>
            <input type=submit form=back formaction="./initial-setup-Build-Verify.php" value="Verify" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Verify Classes<br><?php print $Verify; ?>
            </span>
          </td>
<?php
      $curcol ++;
    }
    else if(strlen($Class5) > 0)
    {
?>
          <td>
            <input type=submit form=back formaction="./initial-setup-Class5.php" value="Class5" style="min-width:6.2rem" />
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Vessel Class 5<br><?php print $Class5; ?>
            </span>
          </td>
<?php
      $curcol ++;
    }

    if($curcol == 2) // I need a new row
    {
?>
        </tr>
        <tr style="min-height:38px;margin-bottom:4px">
<?php
      $curcol = 0;
    }

    if($curcol == 0) // I need a blank col
    {
?>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
<?php
    }
  }
?>
          <td>
            <form id=color_scheme method="GET" action="edit.php" style="margin:0;padding:0">
              <input type=hidden name="set_color_scheme" value="Y" style="visibility:hidden" />
              <select name=ColorScheme onchange="getElementById('color_scheme').submit();"
                      style="padding:0;margin:0;font-size:0.83rem;padding-left:4px;padding-right:4px;min-height:1.7rem;min-width:6.2rem;text-align-last:center;vertical-align:bottom">
                <option value="default" <?php if($ColorScheme == "default") print "selected"; ?> >
                  Default
                </option>
<?php
  for($ii=0; $ii < sizeof($ColorList); $ii++)
  {
    print '                <option value="' . $ColorList[$ii] . '"';

    if($ColorScheme == $ColorList[$ii])
      print "selected";

    if(strlen($ColorList[$ii]) == 1)
      $ccc = strtoupper($ColorList[$ii]);
    else
      $ccc = strtoupper(substr($ColorList[$ii], 0, 1))
           . substr($ColorList[$ii], 1, strlen($ColorList[$ii]));

    print " >\n                  " . $ccc . "\n                </option>\n";
  }
?>
              </select>
            </form>
          </td>
          <td>&nbsp;</td>
          <td>
            <span>
              Color Scheme
            </span>
          </td>
        </tr>
      </table>
    </center>


    <div style="position:absolute;left:0;bottom:0.75rem;width:100%;margin-bottom:2px;">
      <form action="./" method="GET">
        <center>
          <input type=submit value="Config Menu" style="position:relative;bottom:2px;padding:0.2rem"/>
        </center>
      </form>
    </div>

    <script>
      // This special script is not documented
      // must be defined before any 'onClick' field refers to it
      // 'Semprini' is a Monty Python joke

      var nTimes=0;
      var nLastTime=Date.now();

      function Semprini()
      {
        var nNow = Date.now();

        if(!nTimes)
        {
          nTimes = 1;
          nLastTime = nNow;
          return;
        }

        if((nNow - nLastTime) < 500 || // less than half sec
           (nNow - nLastTime) > 1500) // more than 1.5 sec
        {
          nTimes = 0;
          nLastTime = nNow;
          return;
        }

        nTimes = nTimes + 1;
        nLastTime = nNow;

        if(nTimes > 5)
        {
          // change this according to the need
          window.location.assign("/test-index.php");
          return;
        }
      }
    </script>

    <div style="font-size:10px;position: absolute;bottom:4px;right:4px;margin:0;padding:0">
      <!-- this feature is undocumented.  Again -->
      <div onClick="Semprini();" style="min-height:0.83rem;min-width:1.25rem">&nbsp;</div>
    </div>

  </BODY>
</HTML>

