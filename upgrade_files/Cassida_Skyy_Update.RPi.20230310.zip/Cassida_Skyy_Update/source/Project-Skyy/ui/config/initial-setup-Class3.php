<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include '../glue/config_utils.php';

  // use sessions for the wizard (always)
  session_start(); // using session control

  $back = do_getvar("back", "");

  $Quickie = do_getvar("Quickie", "N");

  if(strlen($back) > 0) // editing the global file
  {
    if(isset($_SESSION["LocalConfig"]))
      unset($_SESSION["LocalConfig"]);

    $LocalConfig = "";
  }
  else if(isset($_SESSION["LocalConfig"]))
  {
    $LocalConfig = $_SESSION["LocalConfig"];
  }
  else
  {
    $LocalConfig = "";
  }

  $parseconf = load_parseconf($LocalConfig);

  $SubmitC = do_getvar("SubmitC", "");
  $back = do_getvar("back", "");

  // this page is for class 1 vessels
  $VesselClass = "Class3";
  $VesselClassName = do_getconf($parseconf, "vessels", $VesselClass, "Class 3");
  $Class3Icon = do_getconf($parseconf, "icons", "Class3", "till.svg");


  // get terms for straps and rolls and stuff
  $Straps = do_getconf($parseconf,"terms",'Straps','Straps');
  $Notes = do_getconf($parseconf,"terms",'Notes','Notes');
  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Rolls = do_getconf($parseconf,"terms",'Rolls','Rolls');
  $Pulls = do_getconf($parseconf,"terms",'Pulls','Pulls');

  $DefaultPreload = do_getconf($parseconf, $VesselClass, "preload", '0');

  $DefaultPreloadC1 = do_getconf($parseconf, $VesselClass, "preload.C1", '0');
  $DefaultPreloadC5 = do_getconf($parseconf, $VesselClass, "preload.C5", '0');
  $DefaultPreloadC10 = do_getconf($parseconf, $VesselClass, "preload.C10", '0');
  $DefaultPreloadC25 = do_getconf($parseconf, $VesselClass, "preload.C25", '0');

  $DefaultPreload1 = do_getconf($parseconf, $VesselClass, "preload.1", '0');
  $DefaultPreload5 = do_getconf($parseconf, $VesselClass, "preload.5", '0');
  $DefaultPreload10 = do_getconf($parseconf, $VesselClass, "preload.10", '0');
  $DefaultPreload20 = do_getconf($parseconf, $VesselClass, "preload.20", '0');

  // determine if the preload amount is in balance.  If it is not, calculate an
  // "ideal" preload that's suitable
  $TotalPreload = $DefaultPreloadC1 + $DefaultPreloadC5 * 5
                + $DefaultPreloadC10 * 10 + $DefaultPreloadC25 * 25
                + $DefaultPreload1 * 100 + $DefaultPreload5 * 500
                + $DefaultPreload10 * 1000 + $DefaultPreload20 * 2000;

// debug codd verifying pulls and algorithms
//  print_r(calc_ideal_preload($DefaultPreload));
//  print "<br>\n" . $TotalPreload . "<br>\n";
//  exit;


  if($DefaultPreload * 100 != $TotalPreload) // out of balance
  {
    $aPreload = calc_ideal_preload($DefaultPreload);

    $DefaultPreloadC1 = $aPreload[0];
    $DefaultPreloadC5 = $aPreload[1];
    $DefaultPreloadC10 = $aPreload[2];
    $DefaultPreloadC25 = $aPreload[3];

    $DefaultPreload1 = $aPreload[4];
    $DefaultPreload5 = $aPreload[5];
    $DefaultPreload10 = $aPreload[6];
    $DefaultPreload20 = $aPreload[7];
  }

  if($SubmitC == "Y" || $SubmitC == "Z")
  {
    $StrapsEnable = do_getvar("StrapsEnable", "off");
    $NotesEnable = do_getvar("NotesEnable", "off");
    $CoinsEnable = do_getvar("CoinsEnable", "off");
    $RollsEnable = do_getvar("RollsEnable", "off");
    $HasBanking  = do_getvar("HasBanking", "off");
    $MultiCount  = do_getvar("MultiCount", "off");
    $HasPulls    = do_getvar("HasPulls", "off");

    $XDefaultPreload = do_getvar("DefaultPreload", "0");
    $XDefaultPreloadC1 = do_getvar("DefaultPreloadC1", "0");
    $XDefaultPreloadC5 = do_getvar("DefaultPreloadC5", "0");
    $XDefaultPreloadC10 = do_getvar("DefaultPreloadC10", "0");
    $XDefaultPreloadC25 = do_getvar("DefaultPreloadC25", "0");
    $XDefaultPreload1 = do_getvar("DefaultPreload1", "0");
    $XDefaultPreload5 = do_getvar("DefaultPreload5", "0");
    $XDefaultPreload10 = do_getvar("DefaultPreload10", "0");
    $XDefaultPreload20 = do_getvar("DefaultPreload20", "0");

    $count=do_getvar("count", "");

    if($SubmitC == "Z")
    {
      $AddEditItemIndex = do_getvar("AddEditItemIndex", "");

      if(strlen($AddEditItemIndex) > 0)
      {
        $AddEditItemName = do_getvar("AddEditItemName", false); // special, default is 'false'
        $AddEditPreload = do_getvar("AddEditPreload", "*"); // special, default is '*'
        if($AddEditPreload != "*")
        {
          $AddEditPreloadC1 = do_getvar("AddEditPreloadC1", "");
          $AddEditPreloadC5 = do_getvar("AddEditPreloadC5", "");
          $AddEditPreloadC10 = do_getvar("AddEditPreloadC10", "");
          $AddEditPreloadC25 = do_getvar("AddEditPreloadC25", "");
          $AddEditPreload1 = do_getvar("AddEditPreload1", "");
          $AddEditPreload5 = do_getvar("AddEditPreload5", "");
          $AddEditPreload10 = do_getvar("AddEditPreload10", "");
          $AddEditPreload20 = do_getvar("AddEditPreload20", "");
        }

        $AddEditMakeRolls = do_getvar("AddEditMakeRolls", "");
      }
    }

    // TODO:  additional sanitization checks.  Go back and re-edit if bad

    if(empty($count) ||
       ($StrapsEnable != "on" &&
        $NotesEnable != "on" &&
        $CoinsEnable != "on" &&
        $RollsEnable != "on" ) ||
       ($StrapsEnable == "on" && empty($Straps)) ||
       ($NotesEnable == "on" && empty($Notes)) ||
       ($CoinsEnable == "on" && empty($Coins)) ||
       ($RollsEnable == "on" && empty($Rolls))  )
    {
?>
      <HTML>
        <HEAD>
          <TITLE>Saving Configuration Info</TITLE>
          <meta http-equiv="refresh" content="10;url=initial-setup-Class3.php?Refresh=Y<?php
                if(strlen($back) > 0)
                  print "&back=" . urlencode($back);
                print "&StrapsEnable=" . urlencode($StrapsEnable);
                print "&NotesEnable=" . urlencode($NotesEnable);
                print "&CoinsEnable=" . urlencode($CoinsEnable);
                print "&RollsEnable=" . urlencode($RollsEnable);
                print "&HasBanking=" . urlencode($HasBanking);
                print "&MultiCount=" . urlencode($MultiCount);
                print "&HasPulls=" . urlencode($HasPulls);
                print "&DefaultPreload=" . urlencode($XDefaultPreload);
                print "&DefaultPreloadC1=" . urlencode($XDefaultPreloadC1);
                print "&DefaultPreloadC5=" . urlencode($XDefaultPreloadC5);
                print "&DefaultPreloadC10=" . urlencode($XDefaultPreloadC10);
                print "&DefaultPreloadC25=" . urlencode($XDefaultPreloadC25);
                print "&DefaultPreload1=" . urlencode($XDefaultPreload1);
                print "&DefaultPreload5=" . urlencode($XDefaultPreload5);
                print "&DefaultPreload10=" . urlencode($XDefaultPreload10);
                print "&DefaultPreload20=" . urlencode($XDefaultPreload20);
                print "&count=" . urlencode($count);
                if($Quickie == "Y")
                  print "&Quickie=Y";
                ?>" >
        </HEAD>
        <BODY bgcolor="#e0e0e0" text="#8068ff">
          <br><br><br><br>
          <H1><center>ERROR - Bad Configuration Info</center></H1>
<?php
  print $StraqpsEnable . ", " . $NotesEnable . ", " . $CoinsEnable . ", "
        . $RollsEnable . ", " . $Straps . ", " . $Notes . ", "
        . $Coins . ", " . $Rolls;
?>
        </BODY>
      </HTML>
<?php
      exit;
    }

?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=initial-setup-Class3.php?SubmitC=<?php
            print $SubmitC . $SubmitC; // double it for the next phase
            if(strlen($back) > 0)
              print "&back=" . urlencode($back);
            print "&StrapsEnable=" . urlencode($StrapsEnable);
            print "&NotesEnable=" . urlencode($NotesEnable);
            print "&CoinsEnable=" . urlencode($CoinsEnable);
            print "&RollsEnable=" . urlencode($RollsEnable);
            print "&HasBanking=" . urlencode($HasBanking);
            print "&MultiCount=" . urlencode($MultiCount);
            print "&HasPulls=" . urlencode($HasPulls);
            print "&DefaultPreload=" . urlencode($XDefaultPreload);
            print "&DefaultPreloadC1=" . urlencode($XDefaultPreloadC1);
            print "&DefaultPreloadC5=" . urlencode($XDefaultPreloadC5);
            print "&DefaultPreloadC10=" . urlencode($XDefaultPreloadC10);
            print "&DefaultPreloadC25=" . urlencode($XDefaultPreloadC25);
            print "&DefaultPreload1=" . urlencode($XDefaultPreload1);
            print "&DefaultPreload5=" . urlencode($XDefaultPreload5);
            print "&DefaultPreload10=" . urlencode($XDefaultPreload10);
            print "&DefaultPreload20=" . urlencode($XDefaultPreload20);
            print "&count=" . urlencode($count);
            if($Quickie == "Y")
              print "&Quickie=Y";
            if($SubmitC == "Z" && strlen($AddEditItemIndex) > 0)
            {
              print "&AddEditItemIndex=" . urlencode($AddEditItemIndex);
              print "&AddEditItemName=" . urlencode($AddEditItemName);
              print "&AddEditPreload=" . urlencode($AddEditPreload);
              if($AddEditPreload != "*")
              {
                print "&AddEditPreloadC1=" . urlencode($AddEditPreloadC1);
                print "&AddEditPreloadC5=" . urlencode($AddEditPreloadC5);
                print "&AddEditPreloadC10=" . urlencode($AddEditPreloadC10);
                print "&AddEditPreloadC25=" . urlencode($AddEditPreloadC25);
                print "&AddEditPreload1=" . urlencode($AddEditPreload1);
                print "&AddEditPreload5=" . urlencode($AddEditPreload5);
                print "&AddEditPreload10=" . urlencode($AddEditPreload10);
                print "&AddEditPreload20=" . urlencode($AddEditPreload20);
              }
              print "&AddEditMakeRolls=" . urlencode($AddEditMakeRolls);
            }
            ?>" >
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($SubmitC == "YY" || $SubmitC == "ZZ")
  {
    $StrapsEnable = do_getvar("StrapsEnable", "off");
    $NotesEnable = do_getvar("NotesEnable", "off");
    $CoinsEnable = do_getvar("CoinsEnable", "off");
    $RollsEnable = do_getvar("RollsEnable", "off");
    $HasBanking  = do_getvar("HasBanking", "off");
    $MultiCount  = do_getvar("MultiCount", "off");
    $HasPulls    = do_getvar("HasPulls", "off");

    $XDefaultPreload = do_getvar("DefaultPreload", $DefaultPreload);

    $XDefaultPreload = do_getvar("DefaultPreload", "0");
    $XDefaultPreloadC1 = do_getvar("DefaultPreloadC1", "0");
    $XDefaultPreloadC5 = do_getvar("DefaultPreloadC5", "0");
    $XDefaultPreloadC10 = do_getvar("DefaultPreloadC10", "0");
    $XDefaultPreloadC25 = do_getvar("DefaultPreloadC25", "0");
    $XDefaultPreload1 = do_getvar("DefaultPreload1", "0");
    $XDefaultPreload5 = do_getvar("DefaultPreload5", "0");
    $XDefaultPreload10 = do_getvar("DefaultPreload10", "0");
    $XDefaultPreload20 = do_getvar("DefaultPreload20", "0");

    $count=do_getvar("count", "");

    if($SubmitC == "ZZ")
    {
      $AddEditItemIndex = do_getvar("AddEditItemIndex", "");

      if(strlen($AddEditItemIndex) > 0)
      {
        $AddEditItemName = do_getvar("AddEditItemName", false); // special, default is 'false'
        $AddEditPreload = do_getvar("AddEditPreload", "*"); // special, default is '*'
        if($AddEditPreload != "*")
        {
          $AddEditPreloadC1 = do_getvar("AddEditPreloadC1", "");
          $AddEditPreloadC5 = do_getvar("AddEditPreloadC5", "");
          $AddEditPreloadC10 = do_getvar("AddEditPreloadC10", "");
          $AddEditPreloadC25 = do_getvar("AddEditPreloadC25", "");
          $AddEditPreload1 = do_getvar("AddEditPreload1", "");
          $AddEditPreload5 = do_getvar("AddEditPreload5", "");
          $AddEditPreload10 = do_getvar("AddEditPreload10", "");
          $AddEditPreload20 = do_getvar("AddEditPreload20", "");
        }

        $AddEditMakeRolls = do_getvar("AddEditMakeRolls", "");
      }
    }

    if($StrapsEnable != "on")
      $Straps = "";
    if($NotesEnable != "on")
      $Notes = "";
    if($CoinsEnable != "on")
      $Coins = "";
    if($RollsEnable != "on")
      $Rolls = "";

    // compare 1 or 0 for 'has banking' setting vs current
    $has_banking = (do_getconf($parseconf,$VesselClass,"Banking","") == "yes") ? 1 : 0;
    $xhas_banking = $HasBanking == "on" ? 1 : 0;
    $multi_count = (do_getconf($parseconf,$VesselClass,"MultiCount","") == "yes") ? 1 : 0;
    $xmulti_count = $MultiCount == "on" ? 1 : 0;

    $has_pulls = ($parseconf[$VesselClass]["pulls"] == "1" || // allow either 1 or yes but only write 'yes'
                  $parseconf[$VesselClass]["pulls"] == "yes") ? 1 : 0;
    $xhas_pulls = $HasPulls == "on" ? 1 : 0;

    $changed = $parseconf[$VesselClass]["count"] !== $count
             || $has_banking != $xhas_banking
             || $multi_count != $xmulti_count
             || $has_pulls != $xhas_pulls
             || $XDefaultPreload != $DefaultPreload
             || $XDefaultPreloadC1 != $parseconf[$VesselClass]["preload.C1"]
             || $XDefaultPreloadC5 != $parseconf[$VesselClass]["preload.C5"]
             || $XDefaultPreloadC10 != $parseconf[$VesselClass]["preload.C10"]
             || $XDefaultPreloadC25 != $parseconf[$VesselClass]["preload.C25"]
             || $XDefaultPreload1 != $parseconf[$VesselClass]["preload.1"]
             || $XDefaultPreload5 != $parseconf[$VesselClass]["preload.5"]
             || $XDefaultPreload10 != $parseconf[$VesselClass]["preload.10"]
             || $XDefaultPreload20 != $parseconf[$VesselClass]["preload.20"]
             ;

    if($changed || $SubmitC == "ZZ")
    {
      $parseconf[$VesselClass]["preload"] = $XDefaultPreload;

      $parseconf[$VesselClass]["preload.C1"] = $XDefaultPreloadC1;
      $parseconf[$VesselClass]["preload.C5"] = $XDefaultPreloadC5;
      $parseconf[$VesselClass]["preload.C10"] = $XDefaultPreloadC10;
      $parseconf[$VesselClass]["preload.C25"] = $XDefaultPreloadC25;
      $parseconf[$VesselClass]["preload.1"] = $XDefaultPreload1;
      $parseconf[$VesselClass]["preload.5"] = $XDefaultPreload5;
      $parseconf[$VesselClass]["preload.10"] = $XDefaultPreload10;
      $parseconf[$VesselClass]["preload.20"] = $XDefaultPreload20;

      $parseconf[$VesselClass]["count"] = $count;

      if($xhas_banking != 0)
        $parseconf[$VesselClass]["Banking"] = "yes";
      else
        $parseconf[$VesselClass]["Banking"] = "no";

      if($xmulti_count != 0)
        $parseconf[$VesselClass]["MultiCount"] = "yes";
      else
        $parseconf[$VesselClass]["MultiCount"] = "no";

      if($xhas_pulls)
        $parseconf[$VesselClass]["pulls"] = 'yes';
      else
        $parseconf[$VesselClass]["pulls"] = 'no';

      if($SubmitC == "ZZ" && strlen($AddEditItemIndex) > 0)
      {
        // if the description changed, make sure I change the key to match the new one
        // if the key exists, that is...

        // this suports re-naming the entries (as needed)

        if(empty($parseconf[$VesselClass][$AddEditItemIndex]))
          $oldsection = false;
        else
          $oldsection = $VesselClass . "." . $parseconf[$VesselClass][$AddEditItemIndex];

        if($AddEditItemName === false) // delete it
        {
          unset($parseconf[$VesselClass][$AddEditItemIndex]); // = false;

          if($oldsection !== false)
          {
            unset($parseconf[$oldsection]); // = false; // delete the old section associated with it
          }
        }
        else
        {
          $parseconf[$VesselClass][$AddEditItemIndex] = $AddEditItemName;

          $newsection = $VesselClass . "." . $AddEditItemName;

          if($oldsection !== false && $oldsection != $newsection
             && !empty($parseconf[$oldsection]))
          {
            $parseconf[$newsection] = $parseconf[$oldsection]; // copy to new location
            unset($parseconf[$oldsection]); // = false; // deletes it
          }
          else
          {
            $parseconf[$mewsection] = []; // new empty section
          }

          $parseconf[$newsection]["preload"] = $AddEditPreload; // assign it at this time

          if(!strlen($AddEditPreload) || $AddEditPreload == "*")
          {
            unset($parseconf[$newsection]["preload.C1"]);
            unset($parseconf[$newsection]["preload.C5"]);
            unset($parseconf[$newsection]["preload.C10"]);
            unset($parseconf[$newsection]["preload.C25"]);
            unset($parseconf[$newsection]["preload.1"]);
            unset($parseconf[$newsection]["preload.5"]);
            unset($parseconf[$newsection]["preload.10"]);
            unset($parseconf[$newsection]["preload.20"]);
          }
          else
          {
            $parseconf[$newsection]["preload.C1"] = $AddEditPreloadC1;
            $parseconf[$newsection]["preload.C5"] = $AddEditPreloadC5;
            $parseconf[$newsection]["preload.C10"] = $AddEditPreloadC10;
            $parseconf[$newsection]["preload.C25"] = $AddEditPreloadC25;
            $parseconf[$newsection]["preload.1"] = $AddEditPreload1;
            $parseconf[$newsection]["preload.5"] = $AddEditPreload5;
            $parseconf[$newsection]["preload.10"] = $AddEditPreload10;
            $parseconf[$newsection]["preload.20"] = $AddEditPreload20;
          }

          $parseconf[$newsection]["make_rolls"] = $AddEditMakeRolls;

          // TODO:  any 'newsection' things that need to be written...
        }
      }

      write_configuration_file($parseconf, "initial-setup-Class3.php", $LocalConfig);
    }

    // flow through to the next page

    header("HTTP/1.0 302 Moved Temporarily");

    // the next one I go to depends on what I've configured

    if($SubmitC == "ZZ")
    {
      if(strlen($back) > 0)
        header("Location: initial-setup-Class3.php?back=" . urlencode($back) . "&Quickie=" . urlencode($Quickie)); // back to me, and include 'back='
      else
        header("Location: initial-setup-Class3.php?Quickie=" . urlencode($Quickie)); // back to me, refreshing everything
    }
    else if($Quickie == "Y") // quicky mode finishes here
    {
      header("Location: initial-setup6.php");
      shell_exec("curl http://localhost:3042/reload"); // do this anyway
      exit;
    }
    else if(strlen($back) > 0)
      header("Location: " . $back);
    else if(!empty($parseconf["vessels"]["Class4"]))
      header("Location: initial-setup-Class4.php");
    else if(!empty($parseconf["vessels"]["Class5"]))
      header("Location: initial-setup-Class5.php");
    else if(!empty($parseconf["vessels"]["Build"]) ||
            !empty($parseconf["vessels"]["Verify"]))
      header("Location: initial-setup-Build-Verify.php");
    else
      header("Location: initial-setup6.php");

    if(strlen($back) > 0)
    {
      shell_exec("curl http://localhost:3042/reload");
    }

    exit;
  }

  $Refresh=empty($_GET) || empty($_GET["Refresh"]) ? "" : $_GET["Refresh"];

  $Process = do_getconf($parseconf,"terms",'Process','Daily Tasks');

//  print $Process . "<br>;\n";
//  print_r($parseconf);
//  exit;


  if($Refresh=='Y')
  {
    // TODO:  add the ability to re-invoke this page by specifying
    //        the previous values and selecting focus on an item that
    //        has a problem

    $StrapsEnable = do_getvar("StrapsEnable", "off");
    $NotesEnable = do_getvar("NotesEnable", "off");
    $CoinsEnable = do_getvar("CoinsEnable", "off");
    $RollsEnable = do_getvar("RollsEnable", "off");
    $HasBanking  = do_getvar("HasBanking", "off");
    $MultiCount  = do_getvar("MultiCount", "off");
    $HasPulls    = do_getvar("HasPulls", "off");
    $DefaultPreload = do_getvar("DefaultPreload",
                                do_getconf($parseconf, $VesselClass, "preload", '0'));

    $DefaultPreloadC1 = do_getvar("DefaultPreloadC1",
                                  do_getconf($parseconf, $VesselClass, "preload.C1", '0'));
    $DefaultPreloadC5 = do_getvar("DefaultPreloadC5",
                                  do_getconf($parseconf, $VesselClass, "preload.C5", '0'));
    $DefaultPreloadC10 = do_getvar("DefaultPreloadC10",
                                  do_getconf($parseconf, $VesselClass, "preload.C10", '0'));
    $DefaultPreloadC25 = do_getvar("DefaultPreloadC25",
                                  do_getconf($parseconf, $VesselClass, "preload.C25", '0'));

    $DefaultPreload1 = do_getvar("DefaultPreload1",
                                  do_getconf($parseconf, $VesselClass, "preload.1", '0'));
    $DefaultPreload5 = do_getvar("DefaultPreload5",
                                  do_getconf($parseconf, $VesselClass, "preload.5", '0'));
    $DefaultPreload10 = do_getvar("DefaultPreload10",
                                  do_getconf($parseconf, $VesselClass, "preload.10", '0'));
    $DefaultPreload20 = do_getvar("DefaultPreload20",
                                  do_getconf($parseconf, $VesselClass, "preload.20", '0'));

    $count = do_getvar("count", "");
  }
  else
  {
    $StrapsEnable = "off";
    $NotesEnable = "off";
    $CoinsEnable = "off";
    $RollsEnable = "off";

    $HasBanking  = do_getconf($parseconf,$VesselClass, 'Banking','no') == "yes"
                 ? "on" : "off";

    $MultiCount  = do_getconf($parseconf,$VesselClass, 'MultiCount','no') == "yes"
                 ? "on" : "off";

    // $DefaultPreload etc. already assigned

    $HasPulls = (do_getconf($parseconf,$VesselClass, 'pulls','0') == 1
                 || do_getconf($parseconf,$VesselClass, 'pulls','0') == "yes")
              ? "on" : "off";

    $count = do_getconf($parseconf,$VesselClass,
                        'count','notes,coins,rolls');
  }


  // TODO:  sanitize this and if enabled items aren't included, or specified more than once,
  //        fix it so that it is as correct as possible.  Then proceed.

  // First, parse $count as best as I can
  $aCount=explode(",", $count . ",,,,");
  $aCountTypes = [];
  $Rows=[];

  // pre-assign zeros and clean up $aCount
  for($ii=0; $ii < 4; $ii++)
  {
    $vv = rtrim(ltrim($aCount[$ii]));
    if($vv == "straps")
    {
      $StrapsEnable = "on";
      $aCount[$ii] = 1;  // temporarily use a number
    }
    else if($vv == "notes")
    {
      $NotesEnable = "on";
      $aCount[$ii] = 2;
    }
    else if($vv == "coins")
    {
      $CoinsEnable = "on";
      $aCount[$ii] = 3;
    }
    else if($vv == "rolls")
    {
      $RollsEnable = "on";
      $aCount[$ii] = 4;
    }
    else
    {
      $aCount[$ii] = "";
    }

    $aCountTypes[$ii+1] = 0; // pre-zerio it
  }

  // create an inverse index in '$aCountTypes'
  for($ii=0; $ii < 5; $ii++)
  {
    if($aCount[$ii] == "") // skip
      break; // I am done

    $aCountTypes[$aCount[$ii]] = $ii + 1; // 1-based row number essentially
  }

  // try to fill in things not already present in '$aCount'
  // this needs to be improved to avoid missing classes
  for($jj=1; $jj <= 5; $jj++)
  {
    if(!array_key_exists($jj,$aCountTypes) ||
       $aCountTypes[$jj] == 0) // count type has no row
    {
      $ii++;
      $aCountTypes[$jj] = $ii; // assign next row index to it
    }
  }

  // map 'aCount' back to 'Rows' so that 'Rows' is an array of count names
  $CountNames = ["","Straps","Notes","Coins","Rolls"]; // these are related to the names of the controls
  for($ii=1; $ii <= 4; $ii++)
  {
    // map rows to count types using the name
    $Rows[$aCountTypes[$ii]] = $CountNames[$ii];
  }

//  if($Refresh=='Y')
//  {
//    print "\"" . $Rows[1] . "\", \"" . $Rows[2] . "\", \"" . $Rows[3] . "\", \"" . $Rows[4] . "\", \"" . $Rows[5] . "\"";
//    print_r($aCount);
//    print_r($aCountTypes);
//    print_r($count);
//    exit;
//  }

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Configuration for Split Recycler System</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
      input
      {
        font-size: 0.83rem;
      }
    </style>
    <script>
      function validate_vessel_id(strID, strVal)
      {
        var nMax = <?php print register_max(); ?>;
        var nVal = Number(strVal);

        if(nVal > 0 && nVal <= nMax)
        {
          // prompt invalid value?
          document.getElementById(strID).value = nVal;
        }
        else
        {
          if(!window.confirm("The id value '" + strVal + "' is out of range - must be 1 through <?php print register_max(); ?>"))
          {
            doCancelEdit();
          }
        }
      }

      function doClickKB(strID)
      {
        if(strID == "vessel_id")
        {
          do_vkey_numeric(strID, validate_vessel_id);
        }
        else if(strID == "start_amt" || strID == "default_preload"
           || strID.substr(0,7)=="preload"
           || strID.substr(0,15)=="default_preload"
           || strID == "DefaultPreload" )
        {
          do_vkey_numeric(strID, null);
        }
        else
          do_vkey_single(strID, null);
      }

      function doDelButton(strID)
      {
        document.getElementById("AddEditItemIndex").value = strID;
        document.getElementById("AddEditItemIndex").disabled = false;
        document.getElementById("AddEditItemOldIndex").value = "";
        document.getElementById("AddEditItemOldIndex").disabled = true;
        document.getElementById("AddEditItemName").value = "";
        document.getElementById("AddEditItemName").disabled = true; // make sure, it means 'delete'

        document.getElementById("AddEditPreload").value = "";
        document.getElementById("AddEditPreload").disabled = true;

        document.getElementById("AddEditPreloadC1").value = "";
        document.getElementById("AddEditPreloadC1").disabled = true;
        document.getElementById("AddEditPreloadC5").value = "";
        document.getElementById("AddEditPreloadC5").disabled = true;
        document.getElementById("AddEditPreloadC10").value = "";
        document.getElementById("AddEditPreloadC10").disabled = true;
        document.getElementById("AddEditPreloadC25").value = "";
        document.getElementById("AddEditPreloadC25").disabled = true;

        document.getElementById("AddEditPreload1").value = "";
        document.getElementById("AddEditPreload1").disabled = true;
        document.getElementById("AddEditPreload5").value = "";
        document.getElementById("AddEditPreload5").disabled = true;
        document.getElementById("AddEditPreload10").value = "";
        document.getElementById("AddEditPreload10").disabled = true;
        document.getElementById("AddEditPreload20").value = "";
        document.getElementById("AddEditPreload20").disabled = true;

        document.getElementById("AddEditMakeRolls").disabled = true;

        // disable 'Refresh', enable 'SubmitC' with 'SubmitC's value set to 'Z'
        document.getElementById("Refresh").disabled = true;
        document.getElementById("SubmitC").disabled = false;
        document.getElementById("SubmitC").value = "Z"; // this means to submit but come back HERE

        // now, submit the form
        document.getElementById("the_form").submit();
      }

      function doEditButton(strID, strPreload, bMakeRolls=false)
      {
        var aVessels = new Array();
<?php
        // transfer 'vessels in PHP to javascript 'aVessels'
        $maxID = 0;
        foreach($parseconf[$VesselClass] as $kk => $vv) // search through known vessels
        {
          if(!empty($kk) && substr($kk,0,1) >= '0' && substr($kk,0,1) <= '9')
          {
            // sanitize '$vv' if it has single-quotes in it
            $vv2 = str_replace("'", "\\'", $vv);

            print "aVessels[" . $kk . "]='" . $vv2 . "';\n";

            if($kk > $maxID)
              $maxID = $kk;
          }
        }
?>
        document.getElementById("old_id").value = strID;

        if(strID == "")
        {
          document.getElementById("edit_vessel_title").innerHTML = "<?php print 'Add New ' . make_singular($VesselClassName); ?>";
          document.getElementById("vessel_id").value = <?php print $maxID + 1; ?>;
          document.getElementById("vessel_id").readOnly = false;
          document.getElementById("vessel_name").value = "<?php print 'New ' . $VesselClassName; ?>";
          document.getElementById("default_start_amt").checked = true;
          document.getElementById("start_amt").disabled = true;
          document.getElementById("start_amt").value = "<?php print $parseconf[$VesselClass]["preload"]; ?>";
          document.getElementById("make_rolls").checked = false;

<?php
  if($Quickie != "Y") // quickie mode does not include denominations
  {
?>
          // default preload goes here
          document.getElementById("preload_C1").value = "<?php print $DefaultPreloadC1; ?>";
          document.getElementById("preload_C5").value = "<?php print $DefaultPreloadC5; ?>";
          document.getElementById("preload_C10").value = "<?php print $DefaultPreloadC10; ?>";
          document.getElementById("preload_C25").value = "<?php print $DefaultPreloadC25; ?>";
          document.getElementById("preload_1").value = "<?php print $DefaultPreload1; ?>";
          document.getElementById("preload_5").value = "<?php print $DefaultPreload5; ?>";
          document.getElementById("preload_10").value = "<?php print $DefaultPreload10; ?>";
          document.getElementById("preload_20").value = "<?php print $DefaultPreload20; ?>";

          document.getElementById("preload_C1").disabled = true;
          document.getElementById("preload_C5").disabled = true;
          document.getElementById("preload_C10").disabled = true;
          document.getElementById("preload_C25").disabled = true;
          document.getElementById("preload_1").disabled = true;
          document.getElementById("preload_5").disabled = true;
          document.getElementById("preload_10").disabled = true;
          document.getElementById("preload_20").disabled = true;
<?php
  }
?>
        }
        else
        {
          document.getElementById("edit_vessel_title").innerHTML = "<?php print 'Edit ' . make_singular($VesselClassName); ?> " + strID;
          document.getElementById("vessel_id").value = strID;
          document.getElementById("vessel_id").readOnly = false; //true;
          document.getElementById("vessel_name").value = aVessels[strID];

          console.log("strPreload", strPreload);
          console.log("bMakeRolls", bMakeRolls);

          if(strPreload == "*" || !strPreload.length)
          {
            document.getElementById("default_start_amt").checked = true;
            document.getElementById("start_amt").disabled = true;
            document.getElementById("start_amt").value = "<?php print $DefaultPreload; ?>";

<?php
  if($Quickie != "Y") // quickie mode does not include denominations
  {
?>
            document.getElementById("preload_C1").value = "<?php print $DefaultPreloadC1; ?>";
            document.getElementById("preload_C5").value = "<?php print $DefaultPreloadC5; ?>";
            document.getElementById("preload_C10").value = "<?php print $DefaultPreloadC10; ?>";
            document.getElementById("preload_C25").value = "<?php print $DefaultPreloadC25; ?>";
            document.getElementById("preload_1").value = "<?php print $DefaultPreload1; ?>";
            document.getElementById("preload_5").value = "<?php print $DefaultPreload5; ?>";
            document.getElementById("preload_10").value = "<?php print $DefaultPreload10; ?>";
            document.getElementById("preload_20").value = "<?php print $DefaultPreload20; ?>";

            document.getElementById("preload_C1").disabled = true;
            document.getElementById("preload_C5").disabled = true;
            document.getElementById("preload_C10").disabled = true;
            document.getElementById("preload_C25").disabled = true;
            document.getElementById("preload_1").disabled = true;
            document.getElementById("preload_5").disabled = true;
            document.getElementById("preload_10").disabled = true;
            document.getElementById("preload_20").disabled = true;
<?php
  }
?>
          }
          else
          {
            var aPreload;

            aPreload = strPreload;

            document.getElementById("default_start_amt").checked = false;
            document.getElementById("start_amt").disabled = false;

            aPreload = strPreload.split(":");
            document.getElementById("start_amt").value = aPreload[0];

<?php
  if($Quickie != "Y") // quickie mode does not include denominations
  {
?>
            document.getElementById("preload_C1").value = aPreload[1];
            document.getElementById("preload_C5").value = aPreload[2];
            document.getElementById("preload_C10").value = aPreload[3];
            document.getElementById("preload_C25").value = aPreload[4];
            document.getElementById("preload_1").value = aPreload[5];
            document.getElementById("preload_5").value = aPreload[6];
            document.getElementById("preload_10").value = aPreload[7];
            document.getElementById("preload_20").value = aPreload[8];

            document.getElementById("preload_C1").disabled = false;
            document.getElementById("preload_C5").disabled = false;
            document.getElementById("preload_C10").disabled = false;
            document.getElementById("preload_C25").disabled = false;
            document.getElementById("preload_1").disabled = false;
            document.getElementById("preload_5").disabled = false;
            document.getElementById("preload_10").disabled = false;
            document.getElementById("preload_20").disabled = false;
<?php
  }
?>
          }

          document.getElementById("make_rolls").checked =
            (bMakeRolls.length > 0 &&  bMakeRolls > 0) ? true : false;
        }

        OnChangeAnyPreLoadDetail();

        document.getElementById("edit_vessel").style.display = "block";
        document.getElementById("edit_vessel").style.visibility = "visible";
      }

      function doClickDefaultStartAmt()
      {
        var bCheck = document.getElementById("default_start_amt").checked;
        if(bCheck)
        {
          document.getElementById("start_amt").disabled = true;

<?php
  if($Quickie != "Y") // quickie mode does not include denominations
  {
?>
          document.getElementById("preload_C1").disabled = true;
          document.getElementById("preload_C5").disabled = true;
          document.getElementById("preload_C10").disabled = true;
          document.getElementById("preload_C25").disabled = true;
          document.getElementById("preload_1").disabled = true;
          document.getElementById("preload_5").disabled = true;
          document.getElementById("preload_10").disabled = true;
          document.getElementById("preload_20").disabled = true;

          document.getElementById("start_amt").value = "<?php print $DefaultPreload; ?>";
          document.getElementById("preload_C1").value = "<?php print $DefaultPreloadC1; ?>";
          document.getElementById("preload_C5").value = "<?php print $DefaultPreloadC5; ?>";
          document.getElementById("preload_C10").value = "<?php print $DefaultPreloadC10; ?>";
          document.getElementById("preload_C25").value = "<?php print $DefaultPreloadC25; ?>";
          document.getElementById("preload_1").value = "<?php print $DefaultPreload1; ?>";
          document.getElementById("preload_5").value = "<?php print $DefaultPreload5; ?>";
          document.getElementById("preload_10").value = "<?php print $DefaultPreload10; ?>";
          document.getElementById("preload_20").value = "<?php print $DefaultPreload20; ?>";
<?php
  }
?>
        }
        else
        {
          document.getElementById("start_amt").disabled = false;

<?php
  if($Quickie != "Y") // quickie mode does not include denominations
  {
?>
          document.getElementById("preload_C1").disabled = false;
          document.getElementById("preload_C5").disabled = false;
          document.getElementById("preload_C10").disabled = false;
          document.getElementById("preload_C25").disabled = false;
          document.getElementById("preload_1").disabled = false;
          document.getElementById("preload_5").disabled = false;
          document.getElementById("preload_10").disabled = false;
          document.getElementById("preload_20").disabled = false;
<?php
  }
?>
        }

        OnChangeAnyPreLoadDetail();
      }

      function OnChangeAnyPreLoadDetail()
      {
<?php
  if($Quickie != "Y") // quickie mode does not include denominations
  {
?>
        document.getElementById("preload_total").value =
          ((document.getElementById("preload_C1").value * 1
            + document.getElementById("preload_C5").value * 5
            + document.getElementById("preload_C10").value * 10
            + document.getElementById("preload_C25").value * 25
            + document.getElementById("preload_1").value * 100
            + document.getElementById("preload_5").value * 500
            + document.getElementById("preload_10").value * 1000
            + document.getElementById("preload_20").value * 2000) / 100.0).toString();

        if((document.getElementById("preload_total").value + 0) != document.getElementById("start_amt").value + 0)
        {
          document.getElementById("preload_total").style.backgroundColor = "#ff0000";
          document.getElementById("preload_total").style.color = "#ffff00";
          document.getElementById("preload_save").disabled = true;
        }
        else
        {
          document.getElementById("preload_total").style.backgroundColor = "#ffffff";
          document.getElementById("preload_total").style.color = "#000000";
          document.getElementById("preload_save").disabled = false;
        }
<?php
  }
?>
      }

      function doAddEdit()
      {
        var aVessels = new Array();
<?php
        // transfer 'vessels in PHP to javascript 'aVessels'
        $maxID = 0;
        foreach($parseconf[$VesselClass] as $kk => $vv)
        {
          if(!empty($kk) && substr($kk,0,1) >= '0' && substr($kk,0,1) <= '9')
          {
            // sanitize '$vv' if it has single-quotes in it
            $vv2 = str_replace("'", "\\'", $vv);

            print "aVessels[" . $kk . "]='" . $vv2 . "';\n";

            if($kk > $maxID)
              $maxID = $kk;
          }
        }
?>
        // copy appropriate values into the 'add' form things and enable them
        document.getElementById("AddEditItemIndex").value = document.getElementById("vessel_id").value;
        document.getElementById("AddEditItemIndex").disabled = false;
        document.getElementById("AddEditItemName").value = document.getElementById("vessel_name").value;
        document.getElementById("AddEditItemName").disabled = false;

        document.getElementById("AddEditItemOldIndex").value = ""; // initially
        document.getElementById("AddEditItemOldIndex").disabled = true;

        var id = Number(document.getElementById("vessel_id").value);

        if(id <= 0 || id >= <?php print register_max(); ?>)
        {
          if(!window.confirm("The id value '" + id + "' is out of range - must be 1 through <?php print register_max(); ?>"))
          {
            doCancelEdit();
            return;
          }

          document.getElementById("vessel_id").focus(); // go there
          return;
        }

        if(document.getElementById("old_id").value == "" || // new one
           id != document.getElementById("old_id").value)  // id changed, and isn't a new one
        {
          // data validation
          // see if I used an index for something that exists already...

          if(aVessels[id] && aVessels[id].length > 0) // oops
          {
            if(!window.confirm("The id value '" + id + "' is already in use"))
            {
              doCancelEdit();
              return;
            }

            document.getElementById("vessel_id").focus(); // go there
            return;
          }

          if(document.getElementById("old_id").value != "") // NOT a new one
          {
            document.getElementById("AddEditItemOldIndex").value = document.getElementById("old_id").value;
            document.getElementById("AddEditItemOldIndex").disabled = false;
          }
        }

        // determining the preload
        if(document.getElementById("default_start_amt").checked)
        {
          document.getElementById("AddEditPreload").value = "*";

          document.getElementById("AddEditPreloadC1").value = "";
          document.getElementById("AddEditPreloadC1").disabled = true; // using default
          document.getElementById("AddEditPreloadC5").value = "";
          document.getElementById("AddEditPreloadC5").disabled = true;
          document.getElementById("AddEditPreloadC10").value = "";
          document.getElementById("AddEditPreloadC10").disabled = true;
          document.getElementById("AddEditPreloadC25").value = "";
          document.getElementById("AddEditPreloadC25").disabled = true;

          document.getElementById("AddEditPreload1").value = "";
          document.getElementById("AddEditPreload1").disabled = true;
          document.getElementById("AddEditPreload5").value = "";
          document.getElementById("AddEditPreload5").disabled = true;
          document.getElementById("AddEditPreload10").value = "";
          document.getElementById("AddEditPreload10").disabled = true;
          document.getElementById("AddEditPreload20").value = "";
          document.getElementById("AddEditPreload20").disabled = true;
        }
        else
        {
          document.getElementById("AddEditPreload").value = document.getElementById("start_amt").value;

<?php
  if($Quickie == "Y") // quickie mode does not include denominations - all of preload goes to $1
  {
?>
          document.getElementById("AddEditPreloadC1").value = 0;
          document.getElementById("AddEditPreloadC1").disabled = false;
          document.getElementById("AddEditPreloadC5").value = 0;
          document.getElementById("AddEditPreloadC5").disabled = false;
          document.getElementById("AddEditPreloadC10").value = 0;
          document.getElementById("AddEditPreloadC10").disabled = false;
          document.getElementById("AddEditPreloadC25").value = 0;
          document.getElementById("AddEditPreloadC25").disabled = false;

          document.getElementById("AddEditPreload1").value = document.getElementById("AddEditPreload").value
          document.getElementById("AddEditPreload1").disabled = false;
          document.getElementById("AddEditPreload5").value = 0;
          document.getElementById("AddEditPreload5").disabled = false;
          document.getElementById("AddEditPreload10").value = 0;
          document.getElementById("AddEditPreload10").disabled = false;
          document.getElementById("AddEditPreload20").value = 0;
          document.getElementById("AddEditPreload20").disabled = false;
<?php
  }
  else
  {
?>
          document.getElementById("AddEditPreloadC1").value = document.getElementById("preload_C1").value;
          document.getElementById("AddEditPreloadC1").disabled = false;
          document.getElementById("AddEditPreloadC5").value = document.getElementById("preload_C5").value;
          document.getElementById("AddEditPreloadC5").disabled = false;
          document.getElementById("AddEditPreloadC10").value = document.getElementById("preload_C10").value;
          document.getElementById("AddEditPreloadC10").disabled = false;
          document.getElementById("AddEditPreloadC25").value = document.getElementById("preload_C25").value;
          document.getElementById("AddEditPreloadC25").disabled = false;

          document.getElementById("AddEditPreload1").value = document.getElementById("preload_1").value;
          document.getElementById("AddEditPreload1").disabled = false;
          document.getElementById("AddEditPreload5").value = document.getElementById("preload_5").value;
          document.getElementById("AddEditPreload5").disabled = false;
          document.getElementById("AddEditPreload10").value = document.getElementById("preload_10").value;
          document.getElementById("AddEditPreload10").disabled = false;
          document.getElementById("AddEditPreload20").value = document.getElementById("preload_20").value;
          document.getElementById("AddEditPreload20").disabled = false;
<?php
  }
?>
        }

        document.getElementById("AddEditMakeRolls").value = document.getElementById("make_rolls").checked ? "1" : "0";
        document.getElementById("AddEditMakeRolls").disabled = false;

        document.getElementById("AddEditPreload").disabled = false;

        // disable 'Refresh', enable 'SubmitC' with 'SubmitC's value set to 'Z'
        document.getElementById("Refresh").disabled = true;
        document.getElementById("SubmitC").disabled = false;
        document.getElementById("SubmitC").value = "Z"; // this means to submit but come back HERE

        document.getElementById("edit_vessel").style.display = "none"; // on general principle
        document.getElementById("edit_vessel").style.visibility = "hidden";

        // now, submit the form
        document.getElementById("the_form").submit();
      }

      function doCancelEdit()
      {
        document.getElementById("edit_vessel").style.display = "none";
        document.getElementById("edit_vessel").style.visibility = "hidden"; // hide it
      }

<?php
  if($Quickie == "Y")
  {
?>
      function doDefaultPreload()
      {
        doClickKB("DefaultPreload");
      }

      function doDefaultPreloadFixup()
      {
        document.getElementById("DefaultPreloadC1").value = 0;
        document.getElementById("DefaultPreloadC5").value = 0;
        document.getElementById("DefaultPreloadC10").value = 0;
        document.getElementById("DefaultPreloadC25").value = 0;
        document.getElementById("DefaultPreload1").value = document.getElementById("DefaultPreload").value;
        document.getElementById("DefaultPreload5").value = 0;
        document.getElementById("DefaultPreload10").value = 0;
        document.getElementById("DefaultPreload20").value = 0;

        document.getElementById("the_form").submit();
      }
<?php
  }
  else
  {
?>
      function doDefaultPreload()
      {
        document.getElementById("default_preload_dlg").style.display = "block";
        document.getElementById("default_preload_dlg").style.visibility = "visible";

        document.getElementById("default_preload").value = document.getElementById("DefaultPreload").value;

        document.getElementById("default_preload_C1").value = document.getElementById("DefaultPreloadC1").value;
        document.getElementById("default_preload_C5").value = document.getElementById("DefaultPreloadC5").value;
        document.getElementById("default_preload_C10").value = document.getElementById("DefaultPreloadC10").value;
        document.getElementById("default_preload_C25").value = document.getElementById("DefaultPreloadC25").value;
        document.getElementById("default_preload_1").value = document.getElementById("DefaultPreload1").value;
        document.getElementById("default_preload_5").value = document.getElementById("DefaultPreload5").value;
        document.getElementById("default_preload_10").value = document.getElementById("DefaultPreload10").value;
        document.getElementById("default_preload_20").value = document.getElementById("DefaultPreload20").value;

        OnChangeAnyDefaultPreLoadDetail();
      }

      function doCancelDefaultPreload()
      {
        document.getElementById("default_preload_dlg").style.display = "none";
        document.getElementById("default_preload_dlg").style.visibility = "hidden";
      }

      function doUpdateDefaultPreload()
      {
        document.getElementById("DefaultPreload").value = document.getElementById("default_preload").value;
        document.getElementById("DefaultPreloadText").value = document.getElementById("DefaultPreload").value;

        document.getElementById("DefaultPreloadC1").value = document.getElementById("default_preload_C1").value;
        document.getElementById("DefaultPreloadC5").value = document.getElementById("default_preload_C5").value;
        document.getElementById("DefaultPreloadC10").value = document.getElementById("default_preload_C10").value;
        document.getElementById("DefaultPreloadC25").value = document.getElementById("default_preload_C25").value;
        document.getElementById("DefaultPreload1").value = document.getElementById("default_preload_1").value;
        document.getElementById("DefaultPreload5").value = document.getElementById("default_preload_5").value;
        document.getElementById("DefaultPreload10").value = document.getElementById("default_preload_10").value;
        document.getElementById("DefaultPreload20").value = document.getElementById("default_preload_20").value;

        document.getElementById("default_preload_dlg").style.display = "none";
        document.getElementById("default_preload_dlg").style.visibility = "hidden";

        // disable 'Refresh', enable 'SubmitC' with 'SubmitC's value set to 'Z'
        document.getElementById("Refresh").disabled = true;
        document.getElementById("SubmitC").disabled = false;
        document.getElementById("SubmitC").value = "Z"; // this means to submit but come back HERE

        // disable these things (not adding nor editing anything)
        document.getElementById("AddEditItemIndex").disabled = true;
        document.getElementById("AddEditItemName").disabled = true;
        document.getElementById("AddEditItemOldIndex").disabled = true;
        document.getElementById("AddEditPreload").disabled = true;

        // now, submit the form
        document.getElementById("the_form").submit();
      }

      function OnChangeAnyDefaultPreLoadDetail()
      {
        document.getElementById("default_preload_total").value =
          ((document.getElementById("default_preload_C1").value * 1
            + document.getElementById("default_preload_C5").value * 5
            + document.getElementById("default_preload_C10").value * 10
            + document.getElementById("default_preload_C25").value * 25
            + document.getElementById("default_preload_1").value * 100
            + document.getElementById("default_preload_5").value * 500
            + document.getElementById("default_preload_10").value * 1000
            + document.getElementById("default_preload_20").value * 2000) / 100.0).toString();

        if((document.getElementById("default_preload_total").value + 0) != document.getElementById("default_preload").value + 0)
        {
          document.getElementById("default_preload_total").style.backgroundColor = "#ff0000";
          document.getElementById("default_preload_total").style.color = "#ffff00";
          document.getElementById("default_preload_save").disabled = true;
        }
        else
        {
          document.getElementById("default_preload_total").style.backgroundColor = "#ffffff";
          document.getElementById("default_preload_total").style.color = "#000000";
          document.getElementById("default_preload_save").disabled = false;
        }
      }
<?php
  }
?>

      function doFixCount()
      {
        var ii;
        var xTemp;
        var aRows = new Array();
<?php
        // transfer '$Rows' in PHP to javascript 'aRows'
        for($ii=1; $ii <= 5; $ii++)
        {
          if(array_key_exists($ii,$Rows))
            print "aRows[" . $ii . "]='" . $Rows[$ii] . "';\n";
          else
            print "aRows[" . $ii . "]='0';\n";
        }
?>
        xTemp = "";
        for(ii=1; ii <= 5; ii++)
        {
          if(aRows[ii].length > 0)
          {
            var xx = document.getElementById(aRows[ii] + "Enable");
            if(xx && xx.checked == true)
            {
              var jj = aRows[ii].toLowerCase(); // convert case to lower case - an artifact of the naming convention

              if(xTemp.length > 0)
                xTemp = xTemp + ",";

              xTemp = xTemp + jj;
            }
          }
        }

        // assign the 'count' hidden field
        document.getElementById("count").value = xTemp;
      }

      function doUpButton(strID)
      {
        var ii;
        var xTemp;
        var aRows = new Array();
//        var szAlert = "";
<?php
        // transfer '$Rows' in PHP to javascript 'aRows'
        for($ii=1; $ii <= 5; $ii++)
        {
          if(array_key_exists($ii,$Rows))
            print "aRows[" . $ii . "]='" . $Rows[$ii] . "';\n";
          else
            print "aRows[" . $ii . "]='0';\n";
        }
?>
        for(ii=2; ii <= 5; ii++)
        {
          // bump this one item up in the list by
          // exchanging it with the one above
          if(strID == aRows[ii])
          {
            xTemp = aRows[ii - 1];
            aRows[ii - 1] = aRows[ii];

            aRows[ii] = xTemp; // exchange with item above
            break;
          }
        }

        // rebuild 'count' and assign to 'count' element's value

        xTemp = "";
        for(ii=1; ii <= 5; ii++)
        {
          if(aRows[ii].length > 0)
          {
            var xx = document.getElementById(aRows[ii] + "Enable");
            if(xx && xx.checked == true)
            {
              var jj = aRows[ii].toLowerCase(); // convert case to lower case - an artifact of the naming convention

              if(xTemp.length > 0)
                xTemp = xTemp + ",";

              xTemp = xTemp + jj;
            }
          }
        }

//        szAlert = szAlert + "xTemp=" + xTemp + "\n";

        document.getElementById("count").value = xTemp;

//        alert(szAlert);

        // invoke the form's 'submit' method
        document.getElementById("the_form").submit();
      }

      function doDownButton(strID)
      {
        var ii;
        var xTemp;
        var aRows = new Array();
//        var szAlert = "";
<?php
        // transfer '$Rows' in PHP to javascript 'aRows'
        for($ii=1; $ii <= 5; $ii++)
        {
          if(array_key_exists($ii,$Rows))
            print "aRows[" . $ii . "]='" . $Rows[$ii] . "';\n";
          else
            print "aRows[" . $ii . "]='0';\n";
        }
?>
        for(ii=1; ii < 5; ii++)
        {
          // bump this one item down in the list by
          // exchanging it with the one above
          if(strID == aRows[ii])
          {
            xTemp = aRows[ii + 1];
            aRows[ii + 1] = aRows[ii];

            aRows[ii] = xTemp; // exchange with item underneath

            break;
          }
        }

        // rebuild 'count' and assign to 'count' element's value

        xTemp = "";
        for(ii=1; ii <= 5; ii++)
        {
          if(aRows[ii].length > 0)
          {
            var xx = document.getElementById(aRows[ii] + "Enable");
            if(xx && xx.checked == true)
            {
              var jj = aRows[ii].toLowerCase(); // convert case to lower case - an artifact of the naming convention

              if(xTemp.length > 0)
                xTemp = xTemp + ",";

              xTemp = xTemp + jj;
            }
          }
        }

//        szAlert = szAlert + "xTemp=" + xTemp + "\n";

        document.getElementById("count").value = xTemp;

//        alert(szAlert);

        // invoke the form's 'submit' method
        document.getElementById("the_form").submit();
      }

      function doClickEnable(strID)
      {
        var xx;

        doFixCount();

        // for now, just do this
        document.getElementById("the_form").submit();
      }

    </script>
  </HEAD>
  <BODY bgcolor="#101824" text="#ffffe0">
    <form id=none>
<?php
  if($Quickie == "Y")
  {
?>
      <input type=hidden name="Quickie" value="Y" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <form id=reload>
<?php
  if($Quickie == "Y")
  {
?>
      <input type=hidden name="Quickie" value="Y" style="visibility:hidden" />
<?php
  }
?>
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <center>
      <b>
        <img src="../img/<?php print $Class3Icon; ?>" width=48 height=48 style="position:absolute;left:0.83rem;top:0.42rem;">
        <img src="../img/<?php print $Class3Icon; ?>" width=48 height=48 style="position:absolute;right:20px;top:0.42rem;">
        <H1 style="margin:0;padding:0">
<?php
  if(strlen($back) != 0)
  {
?>
          Split Recycler - Edit Config
<?php
  }
  else if(strlen($LocalConfig) != 0)
  {
?>
          Split Recycler - New Config
<?php
  }
  else
  {
?>
          Split Recycler - Initial Setup
<?php
  }
?>
        </H1>
        <H4 style="margin:0;padding:0;vertical-align:middle">
          <?php print $VesselClassName; ?> - Vessel Setup
        </H4>
        <div style="margin:0;padding:0;font-size:15px;line-height:15px;margin-bottom:10px">
          Use checkbox to enable a count; Use arrow buttons to change the order.
        </div>
      </b>
    </center>
    <form id=none method=GET></form>
    <form id=the_form method=GET action="initial-setup-Class3.php">
      <input type=hidden id=Refresh name="Refresh" value="Y" style="visibility:hidden" />
      <input type=hidden id=SubmitC name="SubmitC" value="Y" style="visibility:hidden" disabled />
      <input type=hidden id=count   name="count" value="<?php print $count; ?>" style="visibility:hidden" />
<?php
  if($Quickie != "Y")
  {
?>
      <input type=hidden id=DefaultPreload name=DefaultPreload value="<?php print $DefaultPreload; ?>" style="visibility:hidden" />
<?php
  }
?>
      <input type=hidden id=DefaultPreloadC1 name=DefaultPreloadC1 value="<?php print $DefaultPreloadC1; ?>" style="visibility:hidden" />
      <input type=hidden id=DefaultPreloadC5 name=DefaultPreloadC5 value="<?php print $DefaultPreloadC5; ?>" style="visibility:hidden" />
      <input type=hidden id=DefaultPreloadC10 name=DefaultPreloadC10 value="<?php print $DefaultPreloadC10; ?>" style="visibility:hidden" />
      <input type=hidden id=DefaultPreloadC25 name=DefaultPreloadC25 value="<?php print $DefaultPreloadC25; ?>" style="visibility:hidden" />
      <input type=hidden id=DefaultPreload1 name=DefaultPreload1 value="<?php print $DefaultPreload1; ?>" style="visibility:hidden" />
      <input type=hidden id=DefaultPreload5 name=DefaultPreload5 value="<?php print $DefaultPreload5; ?>" style="visibility:hidden" />
      <input type=hidden id=DefaultPreload10 name=DefaultPreload10 value="<?php print $DefaultPreload10; ?>" style="visibility:hidden" />
      <input type=hidden id=DefaultPreload20 name=DefaultPreload20 value="<?php print $DefaultPreload20; ?>" style="visibility:hidden" />
<?php
  if($Quickie == "Y")
  {
?>
      <input type=hidden name="Quickie" value="Y" style="visibility:hidden" />
<?php
  }
?>
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
      <table width=100%><tr style="vertical-align:top;"> <!-- use this to do side-by-side columns -->
        <td width=40%>
          <center>
            <table><!-- width="300px"-->
<?php
  for($ii=1; $ii <= 4; $ii++)
  {
    $rr = $Rows[$ii];
    if($rr == "Straps")
    {
?>
              <tr>
                <td width="45%" style="valign:top;text-align:left;font-size:0.75rem;">
                  <input id=StrapsEnable name=StrapsEnable type=checkbox <?php if($StrapsEnable == "on") print "checked"; ?>
                         onClick='doClickEnable("Straps");'>
                    <?php print $Straps; ?>
                  </input>
                </td>
                <td width="10%">&nbsp;</td>
                <td width="45%" style="font-size:0.83rem;margin-right:10px">
                  <a onClick='doUpButton("Straps");'><img src="../img/up-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                  <a onClick='doDownButton("Straps");'><img src="../img/down-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                </td>
              </tr>
<?php
    }
    else if($rr == "Notes")
    {
?>
              <tr>
                <td style="valign:top;text-align:left;font-size:0.75rem;">
                  <input id=NotesEnable name=NotesEnable type=checkbox <?php if($NotesEnable == "on") print "checked"; ?>
                         onClick='doClickEnable("Notes");'>
                    <?php print $Notes; ?>
                  </input>
                </td>
                <td>&nbsp;</td>
                <td style="font-size:0.83rem;margin-right:10px">
                  <a onClick='doUpButton("Notes");'><img src="../img/up-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                  <a onClick='doDownButton("Notes");'><img src="../img/down-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                </td>
              </tr>
<?php
    }
    else if($rr == "Coins")
    {
?>
              <tr>
                <td style="valign:top;text-align:left;font-size:0.75rem;">
                  <input id=CoinsEnable name=CoinsEnable type=checkbox <?php if($CoinsEnable == "on") print "checked"; ?>
                         onClick='doClickEnable("Coins");'>
                    <?php print $Coins; ?>
                  </input>
                </td>
                <td>&nbsp;</td>
                <td style="font-size:0.83rem;margin-right:10px">
                  <a onClick='doUpButton("Coins");'><img src="../img/up-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                  <a onClick='doDownButton("Coins");'><img src="../img/down-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                </td>
              </tr>
<?php
    }
    else if($rr == "Rolls")
    {
?>
              <tr>
                <td style="valign:top;text-align:left;font-size:0.75rem;">
                  <input id=RollsEnable name=RollsEnable type=checkbox <?php if($RollsEnable == "on") print "checked"; ?>
                         onClick='doClickEnable("Rolls");' >
                    <?php print $Rolls; ?>
                  </input>
                </td>
                <td>&nbsp;</td>
                <td style="font-size:0.83rem;margin-right:10px">
                  <a onClick='doUpButton("Rolls");' ><img src="../img/up-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                  <a onClick='doDownButton("Rolls");' ><img src="../img/down-button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a>
                </td>
              </tr>
<?php
    }
  }
?>
          <!-- TODO:  put things like pulls, banking, default start amount here -->

            </table>

            <div style="position:absolute;left:0.83rem;width:10.4rem;top:11.04rem">
                <table style="margin:0;padding:0;border:0">
                <tr style="margin:0;padding:0;border:0"><td style="font-size:0.75rem;line-height:18px;margin:0;padding:0;border:0">
                  <input id=HasPulls name=HasPulls type=checkbox <?php if($HasPulls == "on") print "checked"; ?> >
                    Has <?php print $Pulls; ?>
                  </input>
                </td></tr>
                <tr style="margin:0;padding:0;border:0"><td style="font-size:0.75rem;line-height:18px;margin:0;padding:0;border:0">
                  <input id=HasBanking name=HasBanking type=checkbox <?php if($HasBanking == "on") print "checked"; ?> >
                    Banking Support
                  </input>
                </td></tr>
                <tr style="margin:0;padding:0;border:0"><td style="font-size:0.75rem;line-height:18px;margin:0;padding:0;border:0">
                  <input id=MultiCount name=MultiCount type=checkbox <?php if($MultiCount == "on") print "checked"; ?> >
                    Multi-Count
                  </input>
                </td></tr>
                <tr style="margin:0;padding:0;border:0;">
                 <td style="white-space:nowrap;font-size:0.75rem;line-height:18px;margin:0;padding:0;border:0;min-width:40%;max-width:40;width:40%">
                  <center>
                    <font style="font-size:0.65rem;vertical-align:middle;">
                      <span style="margin:0;padding:0;border:0">
                        Default <?php print $parseconf["terms"]["Preload"]; ?>:&nbsp;
                      </span>
                    </font>
<?php
  if($Quickie == "Y")
  {
?>
                    <input type=numeric form=the_form id=DefaultPreload name=DefaultPreload size=5
                          style="display:inline-block;font-size:0.7rem;line-height:1rem;width:1.67rem;margin:0;padding:0;vertical-align:middle;color:#000000;background:#fffff0;border:1px"
                          onChange='doDefaultPreloadFixup();'
                          value=<?php print '"' . $DefaultPreload . '"'; ?> />
                    &nbsp;
                    <a onClick='doDefaultPreload();'><img src="../img/keyboard.png" width=34 height=34 style="vertical-align:top;padding:0;margin:0"></a>
<?php
  }
  else
  {
?>
                    <span id=DefaultPreloadText
                          style="display:inline-block;font-size:0.7rem;line-height:0.9rem;min-width:1.67rem;max-width:1.67rem;width:1.67rem;margin:0;padding:0;padding-left:0px;vertical-align:middle;color:#000000;background:#fffff0;border:1px">
                      <?php print $DefaultPreload; ?>
                    </span>
                    &nbsp;
                    <!--a onClick='doDefaultPreload();' ><img src="../img/edit_button.png" width="<?php print cached_font_size(); ?>px" height="<?php print cached_font_size(); ?>px" style="vertical-align:middle"></a-->
                    <button type=button onclick="javascript:doDefaultPreload();"
                            style="color:#000000;font-size:0.7rem;line-height:1rem;vertical-align:middle;margin:0;padding:0;padding-left:0.1rem;padding-right:0.1rem" >
                      Edit
                    </button>
                    <!--input type=numeric size=4 id=DefaultPreload name=DefaultPreload
                           value="<?php print $DefaultPreload; ?>"
                           style="font-size:0.75rem;height:1.25rem;vertical-align:middle" /-->
<?php
  }
?>
                  </center>
                </td></tr>
              </table>
            </div>

          </td>
          <td>
            <H4 style="margin:0;border:0;padding:0;">List of Vessels</H4>
            <table border=1 style="width:17rem;height:10rem;display:inline-block;overflow:auto;">
              <thead>
                <tr style="font-size:0.67rem">
                  <th>ID</th>
                  <th>Vessel Name</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
<?php
  $aVV = $parseconf[$VesselClass];
  $aV = [];
  foreach($aVV as $kk => $vv)
  {
    if(substr($kk,0,1) >= '0' && substr($kk,0,1) <= '9')
    {
      $jj = "0000000000" . $kk; // prepend 10 zeros
      $aV[$kk] = substr($jj, strlen($jj) - 10, 10); // right-hand 10 chars
    }
  }

  asort($aV); // sorts numerically

  foreach($aV as $kk => $vvv)
  {
    $vv = $aVV[$kk]; // grab value from previous array

//    if(substr($kk,0,1) >= '0' && substr($kk,0,1) <= '9')
    {
      // <!-- line-height:18px -->
      $ventry = $VesselClass . "." . $vv;
      $preload = do_getconf($parseconf, $ventry, "preload", "*");
      if(strlen($preload) > 0 && $preload != "*")
      {
        $preload = $preload
                  . ":" . do_getconf($parseconf, $ventry, "preload.C1", "0")
                  . ":" . do_getconf($parseconf, $ventry, "preload.C5", "0")
                  . ":" . do_getconf($parseconf, $ventry, "preload.C10", "0")
                  . ":" . do_getconf($parseconf, $ventry, "preload.C25", "0")
                  . ":" . do_getconf($parseconf, $ventry, "preload.1", "0")
                  . ":" . do_getconf($parseconf, $ventry, "preload.5", "0")
                  . ":" . do_getconf($parseconf, $ventry, "preload.10", "0")
                  . ":" . do_getconf($parseconf, $ventry, "preload.20", "0");
      }

      $make_rolls = do_getconf($parseconf, $ventry, "make_rolls", "0");

      //print "<tr><td width=60px>" . $kk . "</td><td width=250px>" . $vv . "</td>";
      print '<tr><td width="2.5rem" style="min-width:2.5rem">' . $kk . '</td><td width="10.4rem" style="min-width:10.4rem">' . $vv . "</td>";

?>
                  <td style="min-width:2.5rem;max-width:2.5rem;width:2.5rem;white-space: nowrap;">
                    <a onClick='doDelButton("<?php print $kk; ?>");' >
                      <img src="../img/delete_button.png"
                           width=<?php print round(cached_font_size() * 32 / 24); ?>px height=<?php print round(cached_font_size() * 32 / 24); ?>px
                           style="vertical-align:middle">
                    </a>
                    <a onClick='doEditButton("<?php print $kk . '","' . $preload . '","' . $make_rolls; ?>");' >
                      <img src="../img/edit_button.png"
                           width=<?php print round(cached_font_size() * 32 / 24); ?>px height=<?php print round(cached_font_size() * 32 / 24); ?>px
                           style="vertical-align:middle">
                    </a>
                  </td>
                </tr>
<?php
    }
  }
?>
              </tbody>
            </table>
          </td></tr>
        </table>
        <!-- enable these to send an item to add or update -->
        <input type=hidden id=AddEditItemIndex name=AddEditItemIndex value="" disabled />
        <input type=hidden id=AddEditItemOldIndex name=AddEditItemOldIndex value="" disabled />
        <input type=hidden id=AddEditItemName name=AddEditItemName value="" disabled />
        <input type=hidden id=AddEditPreload name=AddEditPreload value="" disabled />
        <input type=hidden id=AddEditPreloadC1 name=AddEditPreloadC1 value="" disabled />
        <input type=hidden id=AddEditPreloadC5 name=AddEditPreloadC5 value="" disabled />
        <input type=hidden id=AddEditPreloadC10 name=AddEditPreloadC10 value="" disabled />
        <input type=hidden id=AddEditPreloadC25 name=AddEditPreloadC25 value="" disabled />
        <input type=hidden id=AddEditPreload1 name=AddEditPreload1 value="" disabled />
        <input type=hidden id=AddEditPreload5 name=AddEditPreload5 value="" disabled />
        <input type=hidden id=AddEditPreload10 name=AddEditPreload10 value="" disabled />
        <input type=hidden id=AddEditPreload20 name=AddEditPreload20 value="" disabled />
        <input type=hidden id=AddEditMakeRolls name=AddEditMakeRolls value="" disabled />
        <!-- TODO add others as needed, turn off 'disabled' and process with form submit -->
      </center>
    </form>

    <input type=submit form=none formaction=
<?php
      print '"';

      if(strlen($back) > 0)
        print $back;
      else if($Quickie == "Y")
        print "initial-setup3_noscan_q.php";
      else if(!empty($parseconf["vessels"]["Class2"]))
        print "initial-setup-Class2.php";
      else if(!empty($parseconf["vessels"]["Class1"]))
        print "initial-setup-Class1.php";
      else
        print "initial-setup5.php";

      print '"';
?>
           value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem" />

    <input type=submit value="Add New" onClick='doEditButton("");'
           style="position:absolute;bottom:0.75rem;width:5.5rem;left:9.5rem" />

    <input type=submit form=reload formaction="initial-setup-Class3.php"
           value="Re-load"
           style="position:absolute;bottom:0.75rem;width:5rem;right:10.3rem" />
    <input type=submit
<?php
  if($Quickie == "Y")
  {
?>
           value="Done"
<?php
  }
  else
  {
?>
           value="Next"
<?php
  }
?>
           style="position:absolute;bottom:0.75rem;width:3.33rem;right:3.33rem"
           onClick='document.getElementById("SubmitC").disabled = false; document.getElementById("Refresh").disabled = true; document.getElementById("the_form").submit();' />

<?php
  if($Quickie != "Y") // quickie mode edits it directly
  {
?>
    <!-- edit default preload -->
    <div id=default_preload_dlg class="modal-container">
      <div style="background-color:#feeecc;color:#000000;position:absolute;width:20.83rem;height:14.59rem;right:6.25rem;top:2.08rem;z-index:90;">
        <center>
          <H4 style="margin:4px;padding:4px">Edit Default <?php print $parseconf["terms"]["Preload"]; ?></H4>
          Preload Amount:&nbsp;
          <input type=numeric size=4 id=default_preload name=default_preload value=<?php print $DefaultPreload;?>
                 onChange="OnChangeAnyDefaultPreLoadDetail();"
                 style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
          <a onClick='doClickKB("default_preload");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
          &nbsp;&nbsp;<input type=numeric size=4 id=default_preload_total style="font-size:0.75rem;" disabled />
          <br>
          <table>
            <tr>
              <td>Pennies</td>
              <td>
                <a onClick='doClickKB("default_preload_C1");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                <input type=numeric size=4 id=default_preload_C1 name=default_preload_C1
                       onChange="OnChangeAnyDefaultPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
              </td>
              <td>&nbsp;&nbsp;</td>
              <td>Ones</td>
              <td>
                <input type=numeric size=4 id=default_preload_1 name=default_preload_1
                       onChange="OnChangeAnyDefaultPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
                <a onClick='doClickKB("default_preload_1");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
            <tr>
              <td>Nickels</td>
              <td>
                <a onClick='doClickKB("default_preload_C5");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                <input type=numeric size=4 id=default_preload_C5 name=default_preload_C5
                       onChange="OnChangeAnyDefaultPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
              </td>
              <td>&nbsp;&nbsp;</td>
              <td>Fives</td>
              <td>
                <input type=numeric size=4 id=default_preload_5 name=default_preload_5
                       onChange="OnChangeAnyDefaultPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
                <a onClick='doClickKB("default_preload_5");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
            <tr>
              <td>Dimes</td>
              <td>
                <a onClick='doClickKB("default_preload_C10");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                <input type=numeric size=4 id=default_preload_C10 name=default_preload_C10
                       onChange="OnChangeAnyDefaultPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
              </td>
              <td>&nbsp;&nbsp;</td>
              <td>Tens</td>
              <td>
                <input type=numeric size=4 id=default_preload_10 name=default_preload_10
                       onChange="OnChangeAnyDefaultPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
                <a onClick='doClickKB("default_preload_10");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
            <tr>
              <td>Quarters</td>
              <td>
                <a onClick='doClickKB("default_preload_C25");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                <input type=numeric size=4 id=default_preload_C25 name=default_preload_C25
                       onChange="OnChangeAnyDefaultPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
              </td>
              <td>&nbsp;&nbsp;</td>
              <td>Twenties</td>
              <td>
                <input type=numeric size=4 id=default_preload_20 name=default_preload_20
                       onChange="OnChangeAnyDefaultPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
                <a onClick='doClickKB("default_preload_20");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
          </table>
        </center>
        <input type=submit onClick='doCancelDefaultPreload()'; value="Cancel" style="position:absolute;width:4.16rem;left:2.08rem;bottom:1.208rem"/>
        <input id=default_preload_save type=submit onClick='doUpdateDefaultPreload()'; value="Save" style="position:absolute;width:4.16rem;right:50px;bottom:0.83rem" disabled/>
      </div>
    </div>
<?php
  }
?>

    <!-- add/edit vessel -->
    <div id=edit_vessel class="modal-container">
      <input type=hidden id=old_id value="1" style="visibility:hidden" />
<?php
  if($Quickie == "Y") // quickie mode does not include denominations
  {
?>
      <div style="background-color:#fef8fc;color:#000000;position:absolute;width:16.67rem;height:12.5rem;right:8.33rem;top:4.16rem;z-index:90;">
<?php
  }
  else
  {
?>
      <div style="background-color:#fef8fc;color:#000000;position:absolute;width:20.8rem;height:15.83rem;right:6.25rem;top:2.08rem;z-index:90;">
<?php
  }
?>
        <center>
          <H4 id=edit_vessel_title style="margin:2px;padding-bottom:4px">New <?php print $VesselClassName; ?></H4>
          <table style="min-width:16.67rem;height:4.3rem;display:inline-block;overflow:auto;z-index:99">
            <tr>
              <td>
                <a id=vessel_id_keyboard onClick='doClickKB("vessel_id");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                <input type=numeric size=4 id=vessel_id value="1" style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
              </td>
              <td>&nbsp;&nbsp;</td>
              <td style="color:#000000">
                <input type=text id=vessel_name size=14 value="<?php print sanitize_for_html($VesselClassName); ?>" />
                <a onClick='doClickKB("vessel_name");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                &nbsp;&nbsp;<input type=numeric size=4 id=preload_total style="font-size:0.75rem;" disabled />
              </td>
            </tr>
            <tr>
              <td>
                <input id=default_start_amt type=checkbox onClick="doClickDefaultStartAmt();" style="white-space:nowrap;">
                  Use&nbsp;Default
                </input>
              </td>
              <td>&nbsp;</td>
              <td>
                <?php print $parseconf["terms"]["Preload"]; ?>:
                <input type=numeric size=6 id=start_amt value=""
                       onChange="OnChangeAnyPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
                <a onClick='doClickKB("start_amt");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
          </table>
<?php
  if($Quickie != "Y") // quickie mode does not include denominations
  {
?>
          <table>
            <tr>
              <td>Pennies</td>
              <td>
                <a onClick='doClickKB("preload_C1");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                <input type=numeric size=4 id=preload_C1 name=preload_C1
                       onChange="OnChangeAnyPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
              </td>
              <td>&nbsp;&nbsp;</td>
              <td>Ones</td>
              <td>
                <input type=numeric size=4 id=preload_1 name=preload_1
                       onChange="OnChangeAnyPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
                <a onClick='doClickKB("preload_1");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
            <tr>
              <td>Nickels</td>
              <td>
                <a onClick='doClickKB("preload_C5");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                <input type=numeric size=4 id=preload_C5 name=preload_C5
                       onChange="OnChangeAnyPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
              </td>
              <td>&nbsp;&nbsp;</td>
              <td>Fives</td>
              <td>
                <input type=numeric size=4 id=preload_5 name=preload_5
                       onChange="OnChangeAnyPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
                <a onClick='doClickKB("preload_5");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
            <tr>
              <td>Dimes</td>
              <td>
                <a onClick='doClickKB("preload_C10");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                <input type=numeric size=4 id=preload_C10 name=preload_C10
                       onChange="OnChangeAnyPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
              </td>
              <td>&nbsp;&nbsp;</td>
              <td>Tens</td>
              <td>
                <input type=numeric size=4 id=preload_10 name=preload_10
                       onChange="OnChangeAnyPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
                <a onClick='doClickKB("preload_10");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
            <tr>
              <td>Quarters</td>
              <td>
                <a onClick='doClickKB("preload_C25");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
                <input type=numeric size=4 id=preload_C25 name=preload_C25
                       onChange="OnChangeAnyPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
              </td>
              <td>&nbsp;&nbsp;</td>
              <td>Twenties</td>
              <td>
                <input type=numeric size=4 id=preload_20 name=preload_20
                       onChange="OnChangeAnyPreLoadDetail();"
                       style="font-size:0.75rem;height:1.25rem;vertical-align:middle" />
                <a onClick='doClickKB("preload_20");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.2; ?>px" height="<?php print cached_font_size() * 1.2; ?>px" style="vertical-align:top"></a>
              </td>
            </tr>
          </table>
<?php
  }
?>
          <input id=make_rolls type=checkbox style="white-space:nowrap;">
            Make&nbsp;<?php print $Rolls; ?>
          </input>
        </center>
        <input type=submit onClick='doCancelEdit()'; value="Cancel" style="position:absolute;width:4.16rem;bottom:15px;left:2.08rem;"/>
        <input id=preload_save type=submit onClick='doAddEdit()'; value="Save" style="position:absolute;width:4.16rem;bottom:15px;right:50px;"/>
      </div>
    </div>

<?php

  include "../glue/virtual_keyboard.php";

?>

  </BODY>
</HTML>

