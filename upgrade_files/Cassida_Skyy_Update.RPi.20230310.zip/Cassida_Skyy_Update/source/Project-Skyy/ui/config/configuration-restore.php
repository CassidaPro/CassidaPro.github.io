<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/config_utils.php";

  $ip_addr = empty($_SERVER) || empty($_SERVER["REMOTE_ADDR"])
           ? "" // unlikely, but here anyway
           : $_SERVER["REMOTE_ADDR"];

  // if the requesting IP address isn't local, show a different page

  if(strlen($ip_addr) > 4 && substr($ip_addr, 0, 4) != "127.")
  {
    // for people connecting from "not localhost" I allow uploading a file
    if ($_SERVER['REQUEST_METHOD'] == 'POST')
    {
      if(!isset($_POST["submit"]) || empty($_FILES) || empty($_FILES["fileToUpload"]))
      {
        header("HTTP/1.0 500 Server Error");
?>
        <HTML>
          <HEAD>
            <TITLE>Server Error</TITLE>
            <meta http-equiv="refresh" content="10;url=/config/">
            <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
            <link rel="shortcut icon" href="../img/favicon.ico">
            <style>
<?php
  set_ideal_font_height();
?>
            </style>
          </HEAD>
          <BODY>
            <H1><center>SERVER ERROR</center></H1>
            <br><br><br>
            <H3><center>unable to perform desired action. RESET in 10 seconds...</center></H3>
            <br>
          </BODY>
        </HTML>
<?php
        exit;
      }

      $LoadFrom=$_FILES["fileToUpload"]["tmp_name"];

      // TODO:  validate that it's a good config file???

      // for now just make a blank config first
      shell_exec("sudo -u pi /bin/cp /dev/null /var/cache/skyy/configuration.conf");

      // see /etc/sudoers.d/997_wifi where permissions for doing this exist
      shell_exec("sudo -u pi -g www-data /bin/chown pi:www-data /var/cache/skyy/configuration.conf");
      shell_exec("sudo -u pi /bin/chmod 664 /var/cache/skyy/configuration.conf");

      // next, move the target file there.  Hopefully with dest permissions it will be kept as-is
      move_uploaded_file($LoadFrom, "/var/cache/skyy/configuration.conf");

      shell_exec("curl http://localhost:3042/reload"); // perform a reset - this will reload everything

      // TODO:  check for errors...?
?>
        <HTML>
          <HEAD>
            <TITLE>Restore Configuration Info</TITLE>
            <meta http-equiv="refresh" content="2;url=/config/">
            <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
            <link rel="shortcut icon" href="../img/favicon.ico">
            <style>
<?php
  set_ideal_font_height();
?>
            </style>
          </HEAD>
          <BODY>
            <H1><center>Configuration Restored</center></H1>
            <br><br><br>
          </BODY>
        </HTML>
<?php
      exit;
    }
?>
    <HTML>
      <HEAD>
        <TITLE>Restore Configuration Info</TITLE>
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Restore Configuration Info</center></H1>
        <br><br><br>
        <H3><center>Select a configuration file to upload</center></H3>
        <center>
          <form action="configuration-restore.php" method="post" enctype="multipart/form-data" style='margin:0'>
            <input type="file" name="fileToUpload" id="fileToUpload" style="font-size:22px">
            <input type="submit" value="Upload Config" name="submit">
          </form>
        </center>
        <br>
        <form action="./" method=GET>
          <center>
            <input type=submit value="Cancel" />
          </center>
        </form,>
      </BODY>
    </HTML>
<?php
    exit;
  }

  $parseconf = load_parseconf();

  $Submit=do_getvar("Submit", "");

  $LoadFrom = do_getvar("LoadFrom", "");

  if(strlen($LoadFrom) > 0)
  {
    // for now just make a copy of it
    shell_exec("sudo -u pi /bin/cp '" . $LoadFrom . "/configuration.conf' /var/cache/skyy/configuration.conf");
    // TODO:  check permissions, ownership, group?
    // see /etc/sudoers.d/997_wifi where permissions for doing this exist
    shell_exec("sudo -u pi -g www-data /bin/chown pi:www-data /var/cache/skyy/configuration.conf");
    shell_exec("sudo -u pi /bin/chmod 664 /var/cache/skyy/configuration.conf");

    shell_exec("curl http://localhost:3042/reload"); // perform a reset - this will reload everything

    shell_exec("sync");

    // unmount the drive, now.
    shell_exec("sudo /usr/bin/eject '" . $LoadFrom . "'");

//    header("HTTP/1.0 302 Moved Temporarily");
//    header("Location: /config/");
?>
    <HTML>
      <HEAD>
        <TITLE>Restore Configuration Info</TITLE>
        <meta http-equiv="refresh" content="3;url=/config/">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Restore Configuration Info</center></H1>
        <br><br><br>
        <H3><center>Restore complete - you may remove the USB Drive</center></H3>
        <br>
      </BODY>
    </HTML>
<?php
    exit;
  }

  // NOTE:  need to run this at least once to stop popup dialog box on inserting a drive
  // (NO) gsettings set org.gnome.desktop.media-handling automount-open false
  //
  // edit /home/pi/.config/pcmanfm/LXDE-pi/pcmanfm.conf change 'autorun=1 to 'autorun=0'

  // step 1:  find out if there are mounted volumes.  if thre aren't, have the user insert a drive
  // and press the button [which will refresh this page]

  $Result = shell_exec("/bin/grep /dev/sd </proc/mounts | awk '{ print " . '$2' . "; }'");

  $aList = [];
  $aList0 = explode("\n", ltrim(rtrim($Result)));

  // NOTE:  /proc/mounts can convert chars into 4 char octal sequences, like '\040' for a space
  //        which is necessary to make columns work properly.  So this code will "fix it"
  foreach($aList0 as $jj => $xx)
  {
    $xxx = $xx;
    $newval = "";
    // look for '\040' and other escapes, convert back to normal ASCII
    while(true)
    {
      $yy = strpos($xxx, "\\");  // is there one?
      if($yy === false)
      {
        $newval = $newval . $xxx;
        break;
      }

//      print "yy=" . $yy . '  xxx="' . $xxx . '"  ' . octdec(substr($xxx,1,4)) . "<br>\n";

      if($yy > 0)
        $newval = $newval . substr($xxx, 0, $yy); // up to but not including the backslash

      $xxx = substr($xxx, $yy, strlen($xxx));

      $newval = $newval . chr(octdec(substr($xxx, 1, 4)));

      $xxx = substr($xxx, 4, strlen($xxx));
    }

    $aList0[$jj] = $newval; // replace it
  }


  // look for 'configuration.conf' on the drive
  if(!empty($aList0) && !empty($aList0[0]))
  {
    $command = "";

    foreach($aList0 as $xx)
    {
//      print $xx . "<br>\n";
      if(strlen($xx) > 0)
      {
        if(strlen($command) == 0)
          $command = "sudo -u pi /bin/ls -d";

        $command = $command . " '" . $xx . "/configuration.conf'";
      }
    }

    if(strlen($command) > 0)
    {
      $Result = shell_exec($command);
      $aList = explode("\n", ltrim(rtrim($Result)));
    }
  }


  if(empty($aList) || empty($aList[0]))
  {
?>
    <HTML>
      <HEAD>
        <TITLE>Restore Configuration Info</TITLE>
        <meta http-equiv="refresh" content="2;url=/config/configuration-restore.php">
        <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
        <link rel="shortcut icon" href="../img/favicon.ico">
        <style>
<?php
  set_ideal_font_height();
?>
        </style>
      </HEAD>
      <BODY>
        <H1><center>Restore Configuration Info</center></H1>
        <br><br><br>
        <H3><center>Insert USB drive containing a configuration backup</center></H3>
        <br>
        <br>
        <form action="./" method=GET>
          <center>
            <input type=submit value="Cancel" />
          </center>
        </form,>
      </BODY>
    </HTML>
<?php
    exit;
  }
?>

<HTML>
  <HEAD>
    <TITLE>Restore Configuration Info</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </HEAD>
  <BODY>
    <H1><center>Restore Configuration Info</center></H1>
    <H3><center>Indicate which drive to load from</center></H3>
    <br>
    <br>
    <center>
      <table width="50%">
<?php
  foreach($aList as $vv)
  {
    $qq = ltrim(rtrim($vv));
    $qq = substr($qq, 0, strlen($qq) - 19);
    if(strlen($qq) > 0)
    {
      print "<tr style='font-size:0.9rem'>";
      print "<td width='70%'><div style='text-align:center;vertical-align:middle;line-height:1.2em'>" . $qq . "</div></td><td>&nbsp;</td>";
      print "<td width='30%' style='text-align:center'>";
      print "<form method=GET action='/config/configuration-restore.php' style='margin:0'>";
      print "<input type=hidden name=LoadFrom style='visibility:hidden' value='" . $qq . "'>";
      print "<input type=submit value='Restore' /></form></td></tr>\n";
    }
  }
?>
      </table>
      <br><br>
      <form action="./" method=GET>
        <center>
          <input type=submit value="Cancel" />
        </center>
      </form,>
    </center>
  </BODY>
</HTML>

