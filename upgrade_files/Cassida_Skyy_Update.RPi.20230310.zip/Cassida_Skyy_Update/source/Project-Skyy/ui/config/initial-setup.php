<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "../glue/config_utils.php";

  // use sessions for the wizard (always)
  session_start(); // using session control

  $LocalConfig = do_getvar("LocalConfig", "");

  $back = do_getvar("back", "");

  $Quickie = do_getvar("Quickie", "N");
  if($Quickie == "Y")
    $StoreID = do_getvar("StoreID", "");
  else
    $StoreID = "";

  if(strlen($LocalConfig) > 0)
  {
    if($LocalConfig == "*")
    {
      $LocalConfig = "";

      // '* undoes any session hanging onto a local config file name
      if(isset($_SESSION["LocalConfig"]))
        unset($_SESSION["LocalConfig"]);
    }
    else if(strpos($LocalConfig, "/") !== false ||
            strpos($LocalConfig, "*") !== false ||
            strpos($LocalConfig, "\\") !== false ||
            strpos($LocalConfig, "?") !== false ||
            strpos($LocalConfig, "[") !== false ||
            strpos($LocalConfig, "]") !== false ||
            strpos($LocalConfig, "{") !== false ||
            strpos($LocalConfig, "}") !== false ||
            strpos($LocalConfig, "(") !== false ||
            strpos($LocalConfig, ")") !== false ||
            strpos($LocalConfig, "..") !== false)
    {
      header("HTTP/1.0 500 Server Error");
?>
      <HTML>
        <HEAD><TITLE>ERROR</TITLE>
          <meta http-equiv="refresh" content="30;url=/config/" >
        </HEAD>
        <BODY bgcolor="#e0e0e0" text="#8068ff">
          <br><br><br><br>
          <center>
            <H1>Loading New Configuration Info</H1><br>
            <H1><b>ERROR:  Unable to load configuration info!</b></H1>
            <H3>Problem with configuration file name<br>
                <?php print $LocalConfig; ?></H3>
          </center>
        </BODY>
      </HTML>
<?php
      exit;
    }

    session_start(); // using session control

    // clear the session vars associated with logins, logging me out
    $_SESSION["LocalConfig"] = $LocalConfig;
  }
  else if(strlen($back) > 0) // editing the global file
  {
    if(isset($_SESSION["LocalConfig"]))
      unset($_SESSION["LocalConfig"]);

    $LocalConfig = "";
  }
  else
  {
    if(isset($_SESSION["LocalConfig"]))
      $LocalConfig = $_SESSION["LocalConfig"];
    else
      $LocalConfig = "";
  }

  $parseconf = load_parseconf($LocalConfig);

  $Submit=do_getvar("Submit", "");

  $EndOfDay = do_getconf($parseconf, "settings", "EndOfDay", "00:00");
  if(strlen($EndOfDay) == 0)
  {
    $EndOfDay = "00:00";
  }

  $aTemp = explode(":", $EndOfDay);

  $EndOfDayHour = "00" . ltrim(rtrim($aTemp[0]));
  $EndOfDayHour = substr($EndOfDayHour, strlen($EndOfDayHour) - 2, 2);

  $EndOfDayMinute = "00" . ltrim(rtrim($aTemp[1]));
  $EndOfDayMinute = substr($EndOfDayMinute, strlen($EndOfDayMinute) - 2, 2);

  if($Submit == "Y")
  {
    $business_name     = do_getvar("business_name", "");
    $business_location = do_getvar("business_location", "");
    $StoreID           = do_getvar("StoreID", "");
    $StoreIDLabel      = do_getvar("StoreIDLabel", "");

    $EndOfDayHourX     = do_getvar("end_day_hour", "");
    $EndOfDayMinuteX   = do_getvar("end_day_minute", "");

    // TODO:  sanitize user input data first?  go back and re-edit?

    // NOTE:  2-step process displays a 'Saving Configuration' in-between screen
?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=initial-setup.php?Submit=YY<?php
            if(strlen($back) > 0)
              print "&back=" . urlencode($back);
            print "&business_name=" . urlencode($business_name);
            print "&business_location=" . urlencode($business_location);
            print "&StoreID=" . urlencode($StoreID);
            print "&StoreIDLabel=" . urlencode($StoreIDLabel);
            print "&end_day_hour=" . urlencode($EndOfDayHourX);
            print "&end_day_minute=" . urlencode($EndOfDayMinuteX);
            print "&Quickie=" . urlencode($Quickie);
            ?>" >
      </HEAD>
      <BODY bgcolor="#e0e0e0" text="#8068ff">
        <br><br><br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($Submit == "YY")
  {
    $business_name     = do_getvar("business_name", "");
    $business_location = do_getvar("business_location", "");
    $StoreID           = do_getvar("StoreID", "");
    $StoreIDLabel      = do_getvar("StoreIDLabel", "");

    $EndOfDayHourX     = do_getvar("end_day_hour", "");
    $EndOfDayMinuteX   = do_getvar("end_day_minute", "");

    // line feeds are changed to ':' for business address
    $BusinessLocation = str_replace("\r\n", ":", $business_location);
    $BusinessLocation = str_replace("\n", ":", $BusinessLocation);

    $changed = $parseconf["business"]["BusinessName"] !== $business_name ||
               $parseconf["business"]["BusinessLocation"] !== $BusinessLocation ||
               $parseconf["business"]["StoreID"] !== $StoreID ||
               $parseconf["terms"]["StoreID"] !== $StoreIDLabel ||
               $EndOfDayHour !== $EndOfDayHourX ||
               $EndOfDayMinute !== $EndOfDayMinuteX;

    if($changed)
    {
      $parseconf["business"]["BusinessName"] = $business_name;
      $parseconf["business"]["BusinessLocation"] = $BusinessLocation;
      $parseconf["business"]["StoreID"] = $StoreID;
      $parseconf["terms"]["StoreID"] = $StoreIDLabel;

      $parseconf["settings"]["EndOfDay"] = $EndOfDayHourX . ":" . $EndOfDayMinuteX;

      write_configuration_file($parseconf, "initial-setup.php", $LocalConfig);
    }

    // flow through to the next page

    header("HTTP/1.0 302 Moved Temporarily");
    if(strlen($back) > 0)
      header("Location: " . $back);
    else if($Quickie == "Y")
      header("Location: initial-setup3.php?Quickie=Y");
    else
      header("Location: initial-setup2.php?");

    if(strlen($back) > 0)
    {
      shell_exec("curl http://localhost:3042/reload");
    }

    exit;
  }

  // TODO:  add the ability to re-invoke this page by specifying
  //        the previous values and selecting focus on an item that
  //        has a problem

  $BusinessName = do_getconf($parseconf,"business",'BusinessName','{Your Business Name}');
  $BusinessLocation = do_getconf($parseconf,"business",'BusinessLocation','');

  $BusinessLocation = str_replace(":", "\n",$BusinessLocation);

  if($Quickie != "Y" // special handling for 'Quickie' with specified store Id - leave it as-is
     || strlen($StoreID) == 0)
  {
    // load store id from config if not starting in 'quickie' mode
    // which is most of the time, actually
    $StoreID = do_getconf($parseconf,"business",'StoreID','');
  }

  $StoreIDLabel = do_getconf($parseconf,"terms",'StoreID','Store ID');

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Configuration for Split Recycler System</TITLE>
    <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="../img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
        font-size: 0.83rem;
      }
/*
      input
      {
        font-size: 0.7rem !important;
      }
*/
      select
      {
        font-size: 0.80rem /*22px*/;
        line-height: 0.80rem;
        padding: 0;
        /*border-top-width: 2px;
        border-bottom-width: 2px;
        border-right-width: 21px;*/
      }
      .me-and-my-highlight /* can apply to a screen on dark green background */
      {
      	/*box-shadow: 0 24px 24px 0 rgba(0,0,0,0.30);*/
        box-shadow: 0 4px 4px 4px rgba(0, 255, 0, .14), 0 6px 2px -4px rgba(0, 255, 0, .2), 0 2px 40px 20px rgba(0, 255, 0, .12) !important;
      }
      .modal-set-datetime
      {
        font-size:0.9rem;
        background-color:#fffce8;
        color:#000000;
        position:absolute;
        width:75%;
        height:12.5rem;
        right:4.16rem;
        top:4.16rem;
        z-index:90;
        border-radius: 10px
      }
    </style>
    <script>
      var strOldTZ, strOldNTP; // need to know if these change
      var strOldDate, strOldTime;

      function doClickKB(strID)
      {
        if(strID == "business_location")
        {
          do_vkey_multi(strID, null);
        }
        else if(strID == "StoreID")
        {
          do_vkey_numeric(strID, null);
        }
        else
        {
          do_vkey_single(strID, null);
        }
      }

      function doDateTime()
      {
        // this part gives user feedback by greying the screen prior
        // to loading things up and displaying current date/time and TZ (etc.)

        document.getElementById("date_time").style.display="block";
        document.getElementById("date_time").style.visibility="visible";

        // request gets date, time, time zone, and NTP enable
        var myRequest = new Request("../glue/get_system_date_time.php?plain=Y");

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("status", response.status);
                    doCancelDateTime();

                    return "";
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                  if(text.length > 0)
                  {
                    var strZ, strA, ii;

                    document.getElementById("year").value = text.substr(0,4);
                    document.getElementById("month").value = text.substr(4,2);

                    doLoadDays();

                    document.getElementById("day").value = text.substr(6,2);

                    document.getElementById("hour").value = text.substr(8,2);
                    document.getElementById("minute").value = text.substr(10,2);
                    document.getElementById("second").value = text.substr(12,2);

                    // for consistency, build old date/time from element valuesw

                    strOldDate = document.getElementById("year").value + "-"
                               + document.getElementById("month").value + "-"
                               + document.getElementById("day").value;

                    strOldTime = document.getElementById("hour").value + ":"
                               + document.getElementById("minute").value + ":"
                               + document.getElementById("second").value;

                    strZ = text.substr(14,99).trim();

                    ii = strZ.indexOf(" "); // find space
                    strA = strZ.substr(ii + 1, 99).trim();
                    strZ = strZ.substr(0, ii);

                    document.getElementById("zone").value = strZ;
                    if(strA.toUpperCase() == "YES")
                    {
                      console.log("it was YES");
                      document.getElementById("ntp_enabled").checked = true;

                      strOldNTP = "Y"; // what it was
                    }
                    else
                    {
                      console.log("it was " + strA);
                      document.getElementById("ntp_enabled").checked = false;

                      strOldNTP = "N"; // what it was
                    }

                    // keep track of what the TZ was
                    strOldTZ = strZ;

                    doOnClickNTP();

                    // this last bit makes the screen visible so I can edit with it
                    document.getElementById("date_time_inner").style.visibility="visible";
                  }
                });

      }

      function doOnClickNTP()
      {
        if(document.getElementById("ntp_enabled").checked)
        {
          document.getElementById("year").disabled = true;
          document.getElementById("month").disabled = true;
          document.getElementById("day").disabled = true;

          document.getElementById("hour").disabled = true;
          document.getElementById("minute").disabled = true;
          document.getElementById("second").disabled = true;
        }
        else
        {
          document.getElementById("year").disabled = false;
          document.getElementById("month").disabled = false;
          document.getElementById("day").disabled = false;

          document.getElementById("hour").disabled = false;
          document.getElementById("minute").disabled = false;
          document.getElementById("second").disabled = false;
        }
      }

      function doCancelDateTime()
      {
        document.getElementById("date_time_inner").style.visibility="hidden";

        document.getElementById("date_time").style.display="none";
        document.getElementById("date_time").style.visibility="hidden";
      }

      function doSetDateTime()
      {
        var bNTP = true;

        // first, hide this stuff for user feedback
        document.getElementById("date_time_inner").style.visibility="hidden";

        var strD = document.getElementById("year").value + "-"
                 + document.getElementById("month").value + "-"
                 + document.getElementById("day").value;

        var strT = document.getElementById("hour").value + ":"
                 + document.getElementById("minute").value + ":"
                 + document.getElementById("second").value;

        var strZ = document.getElementById("zone").value;

        var strA = document.getElementById("ntp_enabled").checked ? "Y" : "N";

        if(strZ != strOldTZ || strA != strOldNTP ||
           strD != strOldDate || strT != strOldTime) // do nothing if no change
        {
          if(strZ == strOldTZ)
            strZ = ""; // don't set it

          if(strA == "Y") // dont check date/time at all
          {
            bNTP = true;
            strD = "";
            strT = "";
          }
          else
          {
            bNTP = false;
            if(strD == strOldDate &&
               strT == strOldTime)
            {
              strD = ""; // both empty, time won't change
              strT = "";
            }
            else if(strD == strOldDate)
            {
              strD = ""; // ok to not set the date.  not setting time gets me 00:00:00 though
            }
          }

          SetDateTime(bNTP, strD, strT, strZ)
        }

        // last, ungrey the rest of the screen.  refresh will show latest date/time and TZ
        document.getElementById("date_time").style.display="none";
        document.getElementById("date_time").style.visibility="hidden";
      }

      function doLoadDays()
      {
        var yy, mm, ii, nn, strC;
        yy = document.getElementById("year").value;
        mm = document.getElementById("month").value;

        if(mm == 2)
        {
          if(!(yy % 4) && ((yy % 100) || !(yy % 400))) // leap year?
          {
            nn = 29;
          }
          else
          {
            nn = 28;
          }
        }
        else if(mm == 4 || mm == 6 || mm == 9 || mm == 11)
        {
          nn = 30;
        }
        else
        {
          nn = 31;
        }

        var dd = document.getElementById("day").options;

        while(dd.length > 0) // empty the options list
          dd.remove(0);

        for(ii=1; ii <= nn; ii++)
        {
          var oo = document.createElement("option");

          if(ii < 10)
            strC = '0' + ii;
          else
            strC = '' + ii;

          oo.value = strC;
          oo.text = strC;
          dd.add(oo);
        }
      }

      function GetDateTimeInfo() // call this to load date/time info into date/time edit popup thingy
      {
        // 1st request puts date, time, time zone, and
        var myRequest = new Request("../glue/get_system_date_time.php?plain=Y");

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("status", response.status);
                    doCancelDateTime();

                    return "";
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                  if(text.length > 0)
                  {
                    var strZ, strA, ii;

                    document.getElementById("year").value = text.substr(0,4);
                    document.getElementById("month").value = text.substr(4,2);

                    doLoadDays();

                    document.getElementById("day").value = text.substr(6,2);

                    document.getElementById("hour").value = text.substr(8,2);
                    document.getElementById("minute").value = text.substr(10,2);
                    document.getElementById("second").value = text.substr(12,2);

                    strZ = text.substr(14,99).trim();

                    ii = strZ.indexOf(" "); // find space
                    strA = strZ.substr(ii + 1, 99).trim();
                    strZ = strZ.substr(0, ii);

                    document.getElementById("zone").value = strZ;
                    if(strZ.toUpperCase == "YES")
                    {
                      document.getElementById("ntp_enabled").checked = true;
                    }
                    else
                    {
                      document.getElementById("ntp_enabled").checked = false;
                    }
                  }
                });
      }

      function SetDateTime(bNTP, strD, strT, strZ)
      {
        var myRequest, strParam;

        strParam = "";
        if(bNTP)
        {
          strParam = "&Auto=Y";
        }
        else
        {
          strParam = "&Auto=N";

          if(strD.length > 0 && strT.length > 0)
          {
            strParam += "&DateTimeStr=" + encodeURIComponent(strD + "/" + strT);
          }
          else if(strD.length > 0)
          {
            strParam += "&DateTimeStr=" + encodeURIComponent(strD);
          }
          else if(strT.length > 0)
          {
            strParam += "&DateTimeStr=" + encodeURIComponent(strT);
          }
        }

        if(strZ.length > 0)
        {
          strParam += "&TZone=" + encodeURIComponent(strZ);
        }

        myRequest = new Request("../glue/set_system_date_time.php?No_I_Really_Really_Mean_It=YES"
                                + strParam);

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("status", response.status);
                  }
                  return  response.text();
                })
          .then(function(text)
                {
                  document.getElementById("clock").innerHTML = text;
                });

      }
    </script>
  </HEAD>
  <BODY bgcolor="#101824" text="#ffffe0">
    <form id=none></form>
    <center>
      <b>
        <H1 style="margin:0;padding:0">
<?php
  if(strlen($back) != 0)
  {
?>
          Split Recycler - Edit Config
<?php
  }
  else if(strlen($LocalConfig) != 0)
  {
?>
          Split Recycler - New Config
<?php
  }
  else
  {
?>
          Split Recycler - Initial Setup
<?php
  }
?>
        </H1>
        <H4 style="margin:0;padding:0;padding-bottom:0.67rem">Business Info</H4>
      </b>
    </center>
    <form id=none method=GET></form>
    <form id=reload>
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <form id=the_form method=GET>
      <input type=hidden id="Quickie" name="Quickie" value="N" style="visibility:hidden" />
      <input type=hidden name="Submit" value="Y" style="visibility:hidden" />
<?php
  if(strlen($back) > 0)
  {
?>
      <input type=hidden name="back" value="<?php print $back; ?>" style="visibility:hidden" />
<?php
  }
?>
      <center>
        <table width="85%">
          <tr>
            <td width="30%"><span style="font-size:0.9rem">Business&nbsp;Name:</span></td>
            <td width="70%" style="font-size:0.83rem;margin-right:10px">
              <input type=text size=40 id=business_name name=business_name style="width:16.67rem"
                     value=<?php print '"' . sanitize_for_html($BusinessName) . '"'; ?> />
              <a onClick='doClickKB("business_name");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
            </td>
          </tr>

          <tr>
            <td width="30%" style="vertical-align:top"><span style="font-size:0.9rem">Business&nbsp;Location:</span></td>
            <td width="70%" style="font-size:0.83rem;margin-right:10px">
              <textarea id=business_location name=business_location style="align:left;width:16.67rem;height:4.16rem"><?php print  $BusinessLocation; ?></textarea>
              <a onClick='doClickKB("business_location");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:top"></a>
            </td>
          </tr>

          <tr>
            <td width="30%">
              <a onClick='doClickKB("StoreIDLabel");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
              <input type=text size=16 id=StoreIDLabel name=StoreIDLabel style="width:5.83rem"
                     value=<?php print '"' . sanitize_for_html($StoreIDLabel) . '"'; ?>:&nbsp;</td>
            <td width="70%" style="font-size:0.83rem;margin-right:10px">
              <input type=text size=20 id=StoreID name=StoreID style="width:5.83rem"
                     value=<?php print '"' . sanitize_for_html($StoreID) . '"'; ?> />
              <a onClick='doClickKB("StoreID");'><img src="../img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle"></a>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;End Day:
                  <select name=end_day_hour><?php
                     for($ii=0; $ii < 10; $ii++)
                     {
                       print "\n<!-- debug: " . $ii . " -->\n";
                       print '<option value="0' . $ii . '"';

                       if($EndOfDayHour == "0" . $ii)
                         print " selected";

                       print '>0' . $ii . '</option>';
                     }
                     for($ii=10; $ii < 24; $ii++)
                     {
                       print "\n<!-- debug: " . $ii . " -->\n";
                       print '<option value="' . $ii . '"';

                       if($EndOfDayHour == $ii)
                         print " selected";

                       print '>' . $ii . '</option>';
                     } ?></select>
                  :
                  <select name=end_day_minute><?php
                     for($ii=0; $ii < 10; $ii++)
                     {
                       print '<option value="0' . $ii . '"';

                       if($EndOfDayMinute == "0" . $ii)
                         print " selected";

                       print '>0' . $ii . '</option>';
                     }
                     for($ii=10; $ii < 60; $ii++)
                     {
                       print '<option value="' . $ii . '"';

                       if($EndOfDayMinute == $ii)
                         print " selected";

                       print '>' . $ii . '</option>';
                     } ?></select>
            </td>
          </tr>
        </table>
        <br><br>
        <input type="submit" formaction="javascript:doDateTime();" value="Date/Time" />&nbsp;&nbsp;&nbsp;<span id="clock"><?php print shell_exec("/bin/date"); ?></span>
      </center>
    </form>

    <input type=submit form=none
           formaction="<?php if(strlen($back) > 0) print $back;
                             else if(strlen($LocalConfig) > 0) print "./index.php";
                             else print "/system-menu.php"; ?>"
           value="Back" style="position:absolute;bottom:0.75rem;width:3.33rem;left:3.33rem"/>
<?php
  if(strlen($back) == 0)
  {
?>
    <input type=submit form=reload formaction="initial-setup.php" value="Re-load" style="position:absolute;bottom:0.75rem;width:5rem;left:10rem"/>
    <input type=submit value="Quick" onClick="DoQuickie();" style="position:absolute;bottom:0.75rem;width:5rem;right:10rem"/>
<?php
  }
  else // editig the config - no quicky
  {
?>
    <input type=submit form=reload formaction="initial-setup.php" value="Re-load" style="position:absolute;bottom:0.75rem;width:5rem;left:14.5rem"/>
<?php
  }
?>
    <input type=submit form=the_form formaction="initial-setup.php" value="Next"
           style="position:absolute;bottom:0.75rem;width:3.33rem;right:3.33rem" <?php if($Quickie == "Y") print "disabled" ?> />

    <!-- date/time -->
    <div id=date_time class="modal-container">
      <div id=date_time_inner class="me-and-my-highlight modal-set-datetime" style="visibility:hidden;">
        <center>
          <font style="font-size:0.916rem">
            <input type=checkbox id=ntp_enabled onClick="doOnClickNTP();"
                   checked>NTP Enabled</input>
                   <!--style="transform:scale(2) translateY(0.33rem);vertical-align:bottom"-->
            <table>
              <tr>
                <th>Date</th><th>Time</th>
              </tr>
              <tr>
                <td width=50%>
                  <select id=year><?php for($ii=2020; $ii < 2049; $ii++) print '<option value="' . $ii . '">' . $ii . '</option>'; ?></select>
                  -
                  <select id=month><?php for($ii=1; $ii < 10; $ii++) print '<option value="0' . $ii . '">0' . $ii . '</option>';
                                         for($ii=10; $ii <= 12; $ii++) print '<option value="' . $ii . '">' . $ii . '</option>'; ?></select>
                  -
                  <select id=day></select>
                  &nbsp;&nbsp;
                </td>
                <td width=50%>
                  &nbsp;&nbsp;
                  <select id=hour><?php for($ii=0; $ii < 10; $ii++) print '<option value="0' . $ii . '">0' . $ii . '</option>';
                                        for($ii=10; $ii < 24; $ii++) print '<option value="' . $ii . '">' . $ii . '</option>'; ?></select>
                  :
                  <select id=minute><?php for($ii=0; $ii < 10; $ii++) print '<option value="0' . $ii . '">0' . $ii . '</option>';
                                        for($ii=10; $ii < 60; $ii++) print '<option value="' . $ii . '">' . $ii . '</option>'; ?></select>
                  :
                  <select id=second><?php for($ii=0; $ii < 10; $ii++) print '<option value="0' . $ii . '">0' . $ii . '</option>';
                                          for($ii=10; $ii < 60; $ii++) print '<option value="' . $ii . '">' . $ii . '</option>'; ?></select>
                </td>
              </tr>
            </table>
            <br>
            Time Zone:&nbsp;&nbsp;
            <select id=zone>
              <!-- TODO find a good way to do this "live" - for now hard code -->
              <option value="America/Anchorage">Alaska</option>
              <option value="America/Adak">Aleutian</option>
              <option value="America/Phoenix">Arizona</option>
              <option value="America/Chicago">Central</option>
              <option value="posixrules">Eastern</option>
              <option value="America/Fort_Wayne">East-Indiana</option>
              <option value="Pacific/Honolulu">Hawaii</option>
              <option value="America/Knox_IN">Indiana-Starke</option>
              <option value="America/Detroit">Michigan</option>
              <option value="Navajo">Mountain</option>
              <option value="America/Los_Angeles">Pacific</option>
              <option value="Pacific/Midway">Samoa</option>
            </select>
          </font>
        </center>
        <br><br><br>
        <input type=submit onClick='doCancelDateTime()'; value="Cancel" style="position:absolute;width:4.16rem;left:2.08rem;"/>
        <input type=submit onClick='doSetDateTime()'; value="Set" style="position:absolute;width:4.16rem;right:2.08rem;"/>
      </div>
    </div>

<?php

  include "../glue/virtual_keyboard.php";

?>

    <script>
      function DoQuickie()
      {
        document.getElementById("Quickie").value = "Y";
        document.getElementById("the_form").submit();
      }

      /* This script updates the date/time info next to the 'Date/Time' button */
      function DoTimeUpdate()
      {
        // 2nd parall request displays time on main pge.
        var myRequest = new Request("../glue/get_system_date_time.php"); // the original way

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("status", response.status);
                  }
                  return  response.text();
                })
          .then(function(text)
                {
                  document.getElementById("clock").innerHTML = text;
                });
      }


      setInterval(DoTimeUpdate, 1000);
    </script>
  </BODY>
</HTML>

