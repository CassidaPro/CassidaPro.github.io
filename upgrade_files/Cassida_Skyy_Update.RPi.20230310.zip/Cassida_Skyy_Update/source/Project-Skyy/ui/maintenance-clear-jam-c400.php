<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $Equipment = coin_counter_equipment();
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Clear Jam (C400)</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Clear Jam (C400)
          <img width=42 height=42 src="/img/<?php if(coin_counter_is_c400r($Equipment)) print 'c400r'; else print 'c400'; ?>-only.png">
        </a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <table style="width:85%;border:0">
        <tr>
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle;margin:15 0 0 0px">Visual Inspection
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Inspect Hopper.  Remove as many coins as possible</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Open the top cover.  Take care to prevent excess coins from spilling out of the hopper, and remove any loose coins that may have spilled out into the unit along the sides.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Slowly rotate each of the two metal disks by hand, in each direction.  This may clear the jam.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">If the jam has been cleared, close the lid and re-start the coin count for the coins that are already in the machine.  Add more coins when the hopper indicates 'empty'</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Resume normal operation once the jam has been cleared.</LI>
                </UL>
              </LI>
              <LI style="list-style-type:disc;padding:0;margin:0 0 0 0px">
                <UL style="list-style-type:circle;margin:15 0 0 0px">Jam still not cleared, or keeps recurring.
                  <!--LI style="list-style-type:circle;margin:15 0 0 0px">You will need to power off the unit.  This will lose the count and batch information and you will need to start the counting process over</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">De-energize the C400 using the power switch at the back, and remove the power cord.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Re-open the top cover, and remove the 4 screws holding the brush assembly, and remove it.  Remove any jammed coins or foreign material.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Replace the brush assembly, taking care to correctly position it.  Replace the power cord and re-energize the unit</LI-->
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Contact customer service.</LI>
                </UL>
              </LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/wrench.png" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">&nbsp; &nbsp;BACK</span>
      </a><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

