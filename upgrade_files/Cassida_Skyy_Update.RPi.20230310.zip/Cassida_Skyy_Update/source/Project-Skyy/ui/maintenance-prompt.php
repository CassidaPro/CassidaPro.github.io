<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $nextM="/"; // just in case
  $desc="Error";

  if(empty($_GET) || empty($_GET["code"]))
  {
    $code = "";
  }
  else
  {
    $code = $_GET["code"];
  }

  $code = ltrim(rtrim($code)); // get rid of white space, just in case

  // if the code is one I understand, do the appropriate thing.  Otherwise, display
  // an 'unknown code' page.

  if(!strlen($code))
  {
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
        <meta http-equiv="refresh" content="5;url=/">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Missing Maintenance Code</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }

  // I've been reminded, so disable the reminder for today
  skyyreq("reminder/" . $code );

  if($code == 100 || $code == 200 || $code == 400 || $code == 600)
  {
    if($code == 100)
    {
      $nextM = "/maintenance-zeus-received.php";
      $desc = "Zeus";
    }
    else if($code == 200)
    {
      $nextM = "/maintenance-printer-received.php";
      $desc = "Printer";
    }
    else if($code == 400)
    {
      $nextM = "/maintenance-c400-received.php";
      $desc = "C400";
    }
    else // if($code == 600)
    {
      $nextM = "/maintenance-recycler-received.php";
      $desc = "Recycler";
    }
  }
  else
  {
    // the code is an error, so permanently disable reminder for this code
    skyyreq("del-reminder/" . $code );
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
        <meta http-equiv="refresh" content="5;url=/">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Invalid Maint Code &quot;<?php print $code; ?>&quot;</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Receive New Equipment</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Equipment Replacement</a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <span style="font-size:28px">Have you received your new <?php print $desc; ?>?</span>
      <br>
      <table style="width:70%">
        <tr>
          <td style="align:center;"><!--all:revert-->
            <center>
            <!-- TODO: if there is a 'next' param, go there -->
            <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow">
              <span style="vertical-align:middle">No</span>
            </a>
            </center>
          </td>
          <td style="align:center;"><!--all:revert-->
            <center>
            <a href=<?php print '"' . $nextM . '"'; ?> class="btn btn-small waves-effect primary-fill btn-shadow">
              <img src="/img/wrench.png" class="invertible-icon" height=32 width=32>
              <span style="vertical-align:middle">Yes</span>
            </a>
            </center>
          </td>
        </tr>
      </table>
      <div style="font-size:0.83rem">NOTE:  if you cannot install the new <?php print $desc; ?> at this time, select 'No'.  You<br>
                                     will be reminded again the next time you power on the ZC4 system.<br>
                                     Otherwise press 'Yes' to install the new <?php print $desc; ?> at this time.
      </div>
      <br>
    </center>
  </body>
</html>

