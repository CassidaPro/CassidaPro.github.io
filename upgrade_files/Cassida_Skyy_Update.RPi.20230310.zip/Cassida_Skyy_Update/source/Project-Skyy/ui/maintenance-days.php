<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  // MAINTENANCE CODE PROCESOR
  //
  // For most things this just does a re-direct
  //
  // In some cases I need to set a reminder date - hence the file name
  //
  // code ranges (typical)
  // 100-199 - Zeus
  // 200-299 - Printer
  // 300-399 - C300
  // 400-499 - C400
  // 500-599 - supervisory stuff (including 555 for config screen)
  // 600-699 - Recyclers
  // 900-999 - Special
  //
  // Codes not defined here invoke videos, i.e. 999 invokes 999.avi (screen burn fix)
  //
  // sub-code (except 500,900)
  // x00 - Device Replacement
  // x01 - receive replacement
  // x10 - JAM / RESET
  // x11 - Self Test
  // x20 - stats and batch
  // x99 - device testing (thorough test)


  if(empty($_POST) || empty($_POST["code"]))
  {
    $code = "";
  }
  else
  {
    $code = $_POST["code"];
  }

  $code = ltrim(rtrim($code)); // get rid of white space, just in case

  // if the code is one I understand, do the appropriate thing.  Otherwise, display
  // an 'unknown code' page.

  if(!strlen($code))
  {
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
        <meta http-equiv="refresh" content="5;url=/">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Missing Maintenance Code</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  //   _  _   ___      _  _    _   ___       __    _   ___       __    _  _               _    _     __  __      __  ____                   _
  //  / |/ | / _ \    | || |  / | / _ \     / /_  / | / _ \     / /_  / |/ |             | |  / \   |  \/  |    / / |  _ \  ___  ___   ___ | |_
  //  | || || | | |   | || |_ | || | | |   | '_ \ | || | | |   | '_ \ | || |  _____   _  | | / _ \  | |\/| |   / /  | |_) |/ _ \/ __| / _ \| __|
  //  | || || |_| |_  |__   _|| || |_| |_  | (_) || || |_| |_  | (_) || || | |_____| | |_| |/ ___ \ | |  | |  / /   |  _ <|  __/\__ \|  __/| |_
  //  |_||_| \___/( )    |_|  |_| \___/( )  \___/ |_| \___/( )  \___/ |_||_|          \___//_/   \_\|_|  |_| /_/    |_| \_\\___||___/ \___| \__|
  //              |/                   |/                  |/
  else if($code == 110) // clear zeus jam
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /maintenance-clear-jam-zeus.php");
    exit;
  }
  else if($code == 410)   // clear C400 jam
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /maintenance-clear-jam-c400.php");
    exit;
  }
  else if($code == 610)   // clear recycler jam
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /maintenance-clear-jam-recycler.php"); // for now, goes here (TODO:  make the page)
    exit;
  }
  else if($code == 611)   // reset Recycler
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /glue/reset_recycler.php");
    exit;
  }

  //  _  ____    ___       __   ____    ___            ____   _          _                            _   ___          __
  // / ||___ \  / _ \     / /_ |___ \  / _ \          / ___| | |_  __ _ | |_  ___    __ _  _ __    __| | |_ _| _ __   / _|  ___
  // | |  __) || | | |   | '_ \  __) || | | |  _____  \___ \ | __|/ _` || __|/ __|  / _` || '_ \  / _` |  | | | '_ \ | |_  / _ \
  // | | / __/ | |_| |_  | (_) |/ __/ | |_| | |_____|  ___) || |_| (_| || |_ \__ \ | (_| || | | || (_| |  | | | | | ||  _|| (_) |
  // |_||_____| \___/( )  \___/|_____| \___/          |____/  \__|\__,_| \__||___/  \__,_||_| |_| \__,_| |___||_| |_||_|   \___/
  //                 |/
  else if($code == 120) // zeus statistics
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /statistics_zeus.php?next=/");
    exit;
  }
  else if($code == 620) // recycler info
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /info_recycler.php?next=/");
    exit;
  }

  //    __    _  _     ___     __    _  _    _   ____                           _               ____   _    _         _____                    _
  //   / /_  | || |   / _ \   / /_  | || |  / | |  _ \  ___   ___  _   _   ___ | |  ___  _ __  / ___| | |_ (_) _ __  | ____| _ __ ___   _ __  | |_  _   _
  //  | '_ \ | || |_ | | | | | '_ \ | || |_ | | | |_) |/ _ \ / __|| | | | / __|| | / _ \| '__| \___ \ | __|| || '__| |  _|  | '_ ` _ \ | '_ \ | __|| | | |
  //  | (_) ||__   _|| |_| |_| (_) ||__   _|| | |  _ <|  __/| (__ | |_| || (__ | ||  __/| |     ___) || |_ | || | _  | |___ | | | | | || |_) || |_ | |_| |
  //   \___/    |_|   \___/( )\___/    |_|  |_| |_| \_\\___| \___| \__, | \___||_| \___||_|    |____/  \__||_||_|( ) |_____||_| |_| |_|| .__/  \__| \__, |
  //                       |/                                      |___/                                         |/                    |_|          |___/
  else if($code == 640) // recycler stir
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /maintenance-recycler-stir.php");
    exit;
  }
  else if($code == 641) // recycler dump
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /maintenance-recycler-dump.php");
    exit;
  }
  //    __    _  _    _  _     ____   _                                        ____        _
  //   / /_  | || |  | || |   |  _ \ (_) ___  _ __    ___  _ __   ___   ___   / ___| ___  (_) _ __   ___
  //  | '_ \ | || |_ | || |_  | | | || |/ __|| '_ \  / _ \| '_ \ / __| / _ \ | |    / _ \ | || '_ \ / __|
  //  | (_) ||__   _||__   _| | |_| || |\__ \| |_) ||  __/| | | |\__ \|  __/ | |___| (_) || || | | |\__ \
  //   \___/    |_|     |_|   |____/ |_||___/| .__/  \___||_| |_||___/ \___|  \____|\___/ |_||_| |_||___/
  //                                         |_|
  else if($code == 644) // recycler dispense coins
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /dispense-coins.php?origin=/maintenance.php&rolls_only=N");
    exit;
  }

  //  ____                          _        _             _
  // | ___|__  ____  __            / \    __| | _ __ ___  (_) _ __
  // |___ \\ \/ /\ \/ /  _____    / _ \  / _` || '_ ` _ \ | || '_ \
  //  ___) |>  <  >  <  |_____|  / ___ \| (_| || | | | | || || | | |
  // |____//_/\_\/_/\_\         /_/   \_\\__,_||_| |_| |_||_||_| |_|
  //
  else if($code == 500) // starting amounts (preload)
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /config/initial-setup-Class3.php?back=/maintenance.php");
    exit;
  }
  else if($code == 501) // SYSTEM RESET
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /glue/reset.php");
    exit;
  }
  else if($code == 510) // statistics output
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /maintenance-overall-statistics.php");
    exit;
  }
  else if($code == 520) // load config from USB with choices
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /config/configuration-load.php");
    exit;
  }
  else if($code == 530) // load config from master config via store ID
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /config/configuration-load-from-master.php");
    exit;
  }
  else if($code == 555) // config menu
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /config/index.php");
    exit;
  }
  else if($code == 573) // FOB keys
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /config/fob-keys.php");
    exit;
  }
  else if($code == 580) // 580 - "tweakables"
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /config/tweakables.php");
    exit;
  }

  //  _  _   ____    ___            ____         _     ____          _         _
  // | || | |___ \  / _ \          / ___|   ___ | |_  | __ )   __ _ | |_  ___ | |__
  // | || |_  __) || | | |  _____  \___ \  / _ \| __| |  _ \  / _` || __|/ __|| '_ \
  // |__   _|/ __/ | |_| | |_____|  ___) ||  __/| |_  | |_) || (_| || |_| (__ | | | |
  //    |_| |_____| \___/          |____/  \___| \__| |____/  \__,_| \__|\___||_| |_|
  //
  else if($code == 420)   // set C400 or Recycler batch (RECYCLER ALSO)
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /c400-batch-qty.php?back=/&auto=Y");
    exit;
  }
  else if($code == 320)   // set C300 batch
  {
?>
    <HTML>
      <HEAD>
        <TITLE>Maintenane Code</TITLE>
        <meta http-equiv="refresh" content="5;url=/">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Code 320 not yet implemented</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }

  //    __   ____   _   __  __  _           ____        _          _                       _
  //   / /_ |___ \ / | |  \/  |(_) _ __    / ___| ___  (_) _ __   | |     ___ __   __ ___ | | ___
  //  | '_ \  __) || | | |\/| || || '_ \  | |    / _ \ | || '_ \  | |    / _ \\ \ / // _ \| |/ __|
  //  | (_) |/ __/ | | | |  | || || | | | | |___| (_) || || | | | | |___|  __/ \ V /|  __/| |\__ \
  //   \___/|_____||_| |_|  |_||_||_| |_|  \____|\___/ |_||_| |_| |_____|\___|  \_/  \___||_||___/
  //
  else if($code == 621)   // set min coin levels (Escrow)
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /recycler-min-qty.php?back=/");
    exit;
  }


  //   _   ___   _      ____    ___   _      _  _     ___   _       __     ___   _           ____                   _               ____               _                                            _
  //  / | / _ \ / |    |___ \  / _ \ / |    | || |   / _ \ / |     / /_   / _ \ / |         |  _ \  ___   ___  ___ (_)__   __ ___  |  _ \  ___  _ __  | |  __ _   ___  ___  _ __ ___    ___  _ __  | |_
  //  | || | | || |      __) || | | || |    | || |_ | | | || |    | '_ \ | | | || |  _____  | |_) |/ _ \ / __|/ _ \| |\ \ / // _ \ | |_) |/ _ \| '_ \ | | / _` | / __|/ _ \| '_ ` _ \  / _ \| '_ \ | __|
  //  | || |_| || | _   / __/ | |_| || | _  |__   _|| |_| || | _  | (_) || |_| || | |_____| |  _ <|  __/| (__|  __/| | \ V /|  __/ |  _ <|  __/| |_) || || (_| || (__|  __/| | | | | ||  __/| | | || |_
  //  |_| \___/ |_|( ) |_____| \___/ |_|( )    |_|   \___/ |_|( )  \___/  \___/ |_|         |_| \_\\___| \___|\___||_|  \_/  \___| |_| \_\\___|| .__/ |_| \__,_| \___|\___||_| |_| |_| \___||_| |_| \__|
  //               |/                   |/                    |/                                                                               |_|
  else if($code == 401 || // C400 replacement
          $code == 601 || // Recycler replacement
          $code == 101 || // Zeus replacement
          $code == 201) // printer replacement
  {
    // receive the replacement equipment

    header("HTTP/1.0 302 Moved Temporarily");

    if($code == 101)
      header("Location: /maintenance-zeus-received.php");
    else if($code == 201)
      header("Location: /maintenance-printer-received.php");
    else if($code == 301 || $code == 401)
      header("Location: /maintenance-c400-received.php");
    else if($code == 601)
      header("Location: /maintenance-recycler-received.php");

    exit;
  }
  //  _   ___    ___      ____    ___    ___      _  _    ___    ___            _____           _    _
  // / | / _ \  / _ \    |___ \  / _ \  / _ \    | || |  / _ \  / _ \          |_   _|___  ___ | |_ (_) _ __    __ _
  // | || (_) || (_) |     __) || (_) || (_) |   | || |_| (_) || (_) |  _____    | | / _ \/ __|| __|| || '_ \  / _` |
  // | | \__, | \__, |_   / __/  \__, | \__, |_  |__   _|\__, | \__, | |_____|   | ||  __/\__ \| |_ | || | | || (_| |
  // |_|   /_/    /_/( ) |_____|   /_/    /_/( )    |_|    /_/    /_/            |_| \___||___/ \__||_||_| |_| \__, |
  //                 |/                      |/                                                                |___/
  else if($code == 499 || // C400 test
          $code == 699 || // Recycler test
          $code == 199 || // Zeus test
          $code == 299)   // printer test
  {
    header("HTTP/1.0 302 Moved Temporarily");

    if($code == 199)
      header("Location: /maintenance-zeus-test.php");
    else if($code == 299)
      header("Location: /maintenance-printer-test.php");
    else if($code == 399 || $code == 499)
      header("Location: /maintenance-c400-test.php");
    else if($code == 699)
      header("Location: /maintenance-recycler-test.php");

    exit;
  }

  //  ____  _  ___     ____  _ _           ____       _       _              ____                _                     _   ____       _  __   _____         _
  // |___ \/ |/ _ \   |___ \/ / |         |  _ \ _ __(_)_ __ | |_ ___ _ __  |  _ \ ___  ___  ___| |_    __ _ _ __   __| | / ___|  ___| |/ _| |_   _|__  ___| |_
  //   __) | | | | |    __) | | |  _____  | |_) | '__| | '_ \| __/ _ \ '__| | |_) / _ \/ __|/ _ \ __|  / _` | '_ \ / _` | \___ \ / _ \ | |_    | |/ _ \/ __| __|
  //  / __/| | |_| |   / __/| | | |_____| |  __/| |  | | | | | ||  __/ |    |  _ <  __/\__ \  __/ |_  | (_| | | | | (_| |  ___) |  __/ |  _|   | |  __/\__ \ |_
  // |_____|_|\___( ) |_____|_|_|         |_|   |_|  |_|_| |_|\__\___|_|    |_| \_\___||___/\___|\__|  \__,_|_| |_|\__,_| |____/ \___|_|_|     |_|\___||___/\__|
  //              |/

  else if($code == 210)   // printer reset
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /glue/printer-reset.php");

    exit;
  }

  else if($code == 211)   // printer self-test
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /glue/printer-self-test.php");

    exit;
  }

  //   _   ___    ___      ____    ___    ___      _  _     ___    ___       __     ___    ___            ____               _                                            _      __ ___            _            __
  //  / | / _ \  / _ \    |___ \  / _ \  / _ \    | || |   / _ \  / _ \     / /_   / _ \  / _ \          |  _ \  ___  _ __  | |  __ _   ___  ___  _ __ ___    ___  _ __  | |_   / // _ \  _ __  __| |  ___  _ __\ \
  //  | || | | || | | |     __) || | | || | | |   | || |_ | | | || | | |   | '_ \ | | | || | | |  _____  | |_) |/ _ \| '_ \ | | / _` | / __|/ _ \| '_ ` _ \  / _ \| '_ \ | __| | || | | || '__|/ _` | / _ \| '__|| |
  //  | || |_| || |_| |_   / __/ | |_| || |_| |_  |__   _|| |_| || |_| |_  | (_) || |_| || |_| | |_____| |  _ <|  __/| |_) || || (_| || (__|  __/| | | | | ||  __/| | | || |_  | || |_| || |  | (_| ||  __/| |   | |
  //  |_| \___/  \___/( ) |_____| \___/  \___/( )    |_|   \___/  \___/( )  \___/  \___/  \___/          |_| \_\\___|| .__/ |_| \__,_| \___|\___||_| |_| |_| \___||_| |_| \__| | | \___/ |_|   \__,_| \___||_|   | |
  //                  |/                      |/                       |/                                            |_|                                                        \_\                             /_/
  else if($code == 400 || // C400 replacement
          $code == 600 || // Recycler replacement
          $code == 100 || // Zeus replacement
          $code == 200) // printer replacement
  {
    if($code == 100)
      $formaction="/maintenance-zeus-replacement.php";
    else if($code == 200)
      $formaction="/maintenance-printer-replacement.php";
    else if($code == 300 || $code == 400)
      $formaction="/maintenance-c400-replacement.php";
    else if($code == 600)
      $formaction="/maintenance-recycler-replacement.php";

    // flows through to HTML below this section
    // needs to prompt for days for delivery
  }
  else
  {
    // check for an existing video which consists of "this number.avi" as its name
    // both in ~/Videos and in ~/Videos/custom

    $response = shell_exec("find /home/pi/Videos -name " . $code . ".avi -o -name " . $code . ".mp4");

    $response = ltrim(rtrim($response));
    $ll = "";

    if(strlen($response) > 0)
    {
      $aNames = explode("\n", $response);
      foreach($aNames as $nn)
      {
        $nnn = ltrim(rtrim($nn));
        if(strlen($nnn) > 0)
        {
          if(strlen($ll) > 0)
            $ll = $ll . " ";
          $ll = $ll . $nnn;
        }
      }
    }

    if(strlen($ll))
    {
      header("HTTP/1.0 302 Moved Temporarily");
      header("Location: /maintenance.php");

      shell_exec( "/usr/bin/sudo /home/pi/bin/play-video.sh " . $ll);
      exit;
    }

    // NO VIDEO - display error screen, re-dir back to 'maintenance' code entry screen
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
         <meta http-equiv="refresh" content="5;url=/maintenance.php">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Unrecognized Code &quot;<?php print $code; ?>&quot;</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Equipment Replacement</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Maintenance - Reminder (days)</a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <form id=the_form method=GET action=<?php print '"' . $formaction . '"'; ?> >
      <input type=hidden name="code" value=<?php print '"' . $code . '"'; ?> style="visibility:hidden" />
    </form>
    <form id=none method=GET></form>
    <br/>
    <center>
      <span style="font-size:28px">
        Please indicate the expected number of<br>
        days until you receive new equipment
      </span>
      <br/>
      <br/>
      <table style="width:70%">
        <tr>
          <td>
            <button type="submit" name=days value=2 form=the_form class="btn btn-small waves-effect primary-fill btn-shadow">
              TWO
            </button>
          </td>
          <td>
            <button type="submit" name=days value=3 form=the_form class="btn btn-small waves-effect primary-fill btn-shadow">
              THREE
            </button>
          </td>
          <td>
            <button type="submit" name=days value=4 form=the_form class="btn btn-small waves-effect primary-fill btn-shadow">
              FOUR
            </button>
          </td>
          <td>
            <button type="submit" name=days value=5 form=the_form class="btn btn-small waves-effect primary-fill btn-shadow">
              FIVE
            </button>
          </td>
        </tr>
      </table>
    </center>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;left:12px">
      <button type="submit" id="skip" formaction="/" form=none class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">Exit</span>
      </button>&nbsp;&nbsp;
    </div>

    <!--  Scripts-->

  </body>
</html>

