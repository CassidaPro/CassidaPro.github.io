<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $poobah = empty($_GET) || empty($_GET["poobah"]) ? "" : $_GET["poobah"];
  $next = empty($_GET) || empty($_GET["next"]) ? "" : $_GET["next"];

  $do_print=empty($_GET) || empty($_GET["print"]) ? "" : $_GET["print"];
  $do_clear=empty($_GET) || empty($_GET["clear"]) ? "" : $_GET["clear"];

  if($poobah != "Y")
  {
    if(strlen($next) > 0)
      $next = "&next=" . urlencode($next);
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
<?php
    if($do_clear == "1")
    {
?>
        <meta http-equiv="refresh" content="0.1;url=/statistics_zeus.php?clear=1&poobah=Y<?php print $next; ?>">
<?php
    }
    else if($do_print == "1")
    {
?>
        <meta http-equiv="refresh" content="0.1;url=/statistics_zeus.php?print=1&poobah=Y<?php print $next; ?>">
<?php
    }
    else
    {
?>
        <meta http-equiv="refresh" content="0.1;url=/statistics_zeus.php?poobah=Y<?php print $next; ?>">
<?php
    }

    set_inbetween_style();
?>
      </HEAD>
      <BODY>
        <br><br>
        <H1>
          <center>
<?php
    if($do_clear == "1")
    {
?>
            Clear Zeus Statistics
<?php
    }
    else if($do_print == "1")
    {
?>
            Print Zeus Statistics
<?php
    }
    else
    {
?>
            Get Zeus Statistics
<?php
    }
?>
          </center>
        </H1>
        <br><br><br>
        <center>
          <div style="font-size:1.5rem">
            <a href="/statistics_zeus.php">
              Tap HERE to re-try
            </a>
            <br>
            <br>
            <br>
            <a href=
<?php
    if(strlen($next) > 0)
      print '"' . $next . '"';
    else
      print "/maintenance.php";
?>
            >
              Tap HERE to exit
            </a>
          </div>
        </center>
      </BODY>
    </HTML>
<?php
    exit;
  }

  if($do_clear == "1")
  {
    skyyreq("clear-zeus-statistics" );
  }
  else if($do_print == "1")
  {
    skyyreq("print-zeus-statistics" );
  }

  $Results = skyyreq("get-zeus-statistics" );

  if(strlen($Results) < 10 ||
     substr($Results, 0, 5) == "ERROR")
  {
?>
    <!DOCTYPE html5>
    <HTML>
      <HEAD>
        <TITLE>Zeus Statistics</TITLE>
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <center>
          <H1>
            Error - Zeus Statistics
          </H1>
          <H3>
            <?php print $Results; ?>
          </H3>
        </center>
        <br><br><br>
        <center><a href="/statistics_zeus.php">Tap HERE to re-try</a></center>
        <br>
        <br>
        <center><a href=
<?php
    if(strlen($next) > 0)
      print '"' . $next . '"';
    else
      print "/maintenance.php";
?>
        >Tap HERE to exit</a></center>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else
  {
    eval($Results);
  }

?>
<!DOCTYPE html5>
<HTML>
<HEAD>
  <TITLE>Zeus Statistics</TITLE>
  <STYLE>
<?php
  set_ideal_font_height();
?>
    input
    {
     font-size:1rem;
     font-weight: bold;
     height : 1.75rem;
    }
    @font-face
    {
     font-family: Lato;
     src: url(/fonts/lato-v15-latin-regular.woff);
    }
  </STYLE>
</HEAD>
<BODY bgcolor="#003030" text="#ffffe0">
  <H2 style="font-size:1.25rem"><center>Zeus Statistics Report</center></H2>
  <table align=center style="font-size:0.65rem !important">
    <tr><td>
      <table style="font-size:0.65rem !important">
        <tr>
          <th style="border-bottom:solid 1px">Parameter</th>
          <th>&nbsp;</th>
          <th style="border-bottom:solid 1px">Quantity</th>
        </tr>
        <tr>
          <td align=right>Total Notes Counted:</td><td>&nbsp;&nbsp;<td><?php print $StatCounts; ?></td></tr>
          <td align=right>Rejects:</td><td>&nbsp;&nbsp;</td><td><?php print $StatRejects; ?></td></tr>
          <td align=right>Double:</td><td>&nbsp;&nbsp;</td><td><?php print $StatDouble; ?></td></tr>
          <td align=right>Chain:</td><td>&nbsp;&nbsp;</td><td><?php print $StatChain; ?></td></tr>
          <td align=right>Half:</td><td>&nbsp;&nbsp;</td><td><?php print $StatHalf; ?></td></tr>
          <td align=right>Read Error:</td><td>&nbsp;&nbsp;</td><td><?php print $StatRead; ?></td></tr>
          <td align=right>ID Error:</td><td>&nbsp;&nbsp;</td><td><?php print $StatID; ?></td></tr>
          <td align=right>Suspect Note:</td><td>&nbsp;&nbsp;</td><td><?php print $StatSuspect; ?></td></tr>
          <td align=right>JAM 1:</td><td>&nbsp;&nbsp;</td><td><?php print $StatJAM1; ?></td></tr>
          <td align=right>JAM 2:</td><td>&nbsp;&nbsp;</td><td><?php print $StatJAM2; ?></td></tr>
          <td align=right>Motor Error:</td><td>&nbsp;&nbsp;</td><td><?php print $StatMotor; ?></td></tr>
          <td align=right>Diverter Error:</td><td>&nbsp;&nbsp;</td><td><?php print $StatDiverter; ?></td></tr>
          <td align=right>Feed Error:</td><td>&nbsp;&nbsp;</td><td><?php print $StatFeed; ?></td></tr>
      </table>
    </td></tr>
  </table>
  <form id=none method=GET></form>
  <form id=print method=GET>
    <input type=hidden name="print" style"visibility:none" value=1 />
<?php
    if(strlen($next) > 0)
      print '    <input type=hidden name="next" style"visibility:none" value="' . $next .'" />' . "\r\n";
?>
  </form>
  <form id=clear method=GET>
    <input type=hidden name="clear" style"visibility:none" value=1 />
<?php
    if(strlen($next) > 0)
      print '    <input type=hidden name="next" style"visibility:none" value="' . $next .'" />' . "\r\n";
?>
  </form>
  <table align=center width=60%>
    <tr>
      <td align=center>
        <input type=submit form=print formaction="/statistics_zeus.php" style="font-size:0.75rem" value="Print" />
      </td>
      <td align=center>
        <input type=submit form=clear formaction="/statistics_zeus.php" style="font-size:0.75rem" value="Clear" />
      </td>
      <td align=center>
        <input type=submit form=none formaction=
<?php
    if(strlen($next) > 0)
      print '"' . $next . '"';
    else
      print "/maintenance.php";
?>
        style="font-size:0.75rem" value="Back" />
      </td>
    </tr>

  </table>
</BODY>
</HTML>

