<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $scrnres = setup_screen_res();

  // parse config file for things I need
  $parseconf = load_parseconf();

  // if I attempt to go to this page from outside of the system,
  // re-direct to the config page

  $ip_addr = $_SERVER["REMOTE_ADDR"];
//  if(strlen($ip_addr) > 4 && substr($ip_addr, 0, 4) != "127.")
//  {
//    header("HTTP/1.0 302 Moved Temporarily");
//    header("Location: /config/");
//
//    exit;
//  }

//  $parseconf = parse_ini_file("/var/cache/skyy/configuration.conf",
//                              TRUE, // to process sections
//                              INI_SCANNER_NORMAL); // process values normally

  $ProcessName = do_getconf($parseconf,"terms",'Process','DAILY-PREP');
  $NotesName   = do_getconf($parseconf,"terms",'Notes','Notes');
  $CoinsName   = do_getconf($parseconf,"terms",'Coins','Coins');
  $StrapsName  = do_getconf($parseconf,"terms",'Straps','Straps');
  $RollsName   = do_getconf($parseconf,"terms",'Rolls','Rolls');

  $Class1      = do_getconf($parseconf,"vessels",'Class1','');
  $Class2      = do_getconf($parseconf,"vessels",'Class2','');
  $Class3      = do_getconf($parseconf,"vessels",'Class3','');

  $MultiCount  = do_getconf($parseconf,"Class3",'MultiCount','no');
  if($MultiCount == 'yes')
    $MultiCount = 1;
  else
    $MultiCount = 0;

  $IconClass1  = do_getconf($parseconf,"icons",'Class1','safe.svg');
  $IconClass2  = do_getconf($parseconf,"icons",'Class2','drawer.svg');
  $IconClass3  = do_getconf($parseconf,"icons",'Class3','register.svg');

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  $result = skyyreq("task-status");

  eval($result); // for now...

  $DoDailyTask = do_getvar("DoDailyTask", "");
  if($DoDailyTask == "Y")
  {
    if(!$AllTasksInProgress || !strlen($CountDate) > 0)
    {
      if(!strlen($result)) // server not running
      {
?>
        <HTML>
          <HEAD>
            <TITLE>re-direct</TITLE>
            <meta http-equiv="refresh" content="15;url=/index.php">
<?php set_inbetween_style(); ?>
          </HEAD>
          <BODY>
            <br><br>
            <center>
              <H1>
                Internal Error
              </H1>
              <span style="font-size:22px">
                Server Not Running (please re-start system)
              </span>
            </center>
          </BODY>
        </HTML>
<?php
        exit;
      }

      $auth = ltrim(rtrim(skyyreq("fobkey-auth-required-count")));

      // do I need authentication??
      if(!strlen($auth))
      {
?>
        <HTML>
          <HEAD>
            <TITLE>re-direct</TITLE>
            <meta http-equiv="refresh" content="15;url=/index.php">
<?php set_inbetween_style(); ?>
          </HEAD>
          <BODY>
            <br><br>
            <center>
              <H1>
                Internal Error (no auth)
              </H1>
              <span style="font-size:22px">
                Server Not Running (please re-start system)
              </span>
            </center>
          </BODY>
        </HTML>
<?php
        exit;
      }
      else if($auth > 0) // no default, server must be running and respond to the request
      {
        if(is_authenticated(true) != "OK")
        {
          $authenticate = do_getvar("authenticate","");

          if($authenticate != "Y")
          {
            authenticate_prompt("/index.php?DoDailyTask=Y&authenticate=Y", true);

            exit;
          }
          else if(do_authenticate($Origin, true) != "OK")
          {
  ?>
            <HTML>
              <HEAD>
                <TITLE>Authenticated</TITLE>
                <meta http-equiv="refresh" content="5;url=/index.php">
              </HEAD>
              <BODY>
                <center>
                  <br><br>
                  <H1>NOT Authenticated</H1>
                </center>
              </BODY>
            </HTML>
  <?php

            exit;
          }
        }
        else
        {
          skyyreq("fobkey-deauth");
        }
      }
    }

    /* THIS IS THE PART WHERE I GO TO /tasks.php OR /date.php DEPENDING ON STATE */

    header("HTTP/1.0 302 Moved Temporarily");
    if($AllTasksInProgress && strlen($CountDate) > 0)
    {
      // I've entered the date already, and daily tasks are in progress
      header("Location: /tasks.php");
    }
    else
    {
      // daily task NOT in progress, need to enter a system date and start it up
      header("Location: /date.php");
    }
    exit;
  }




?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html5>
<html lang="en">
  <!-- these next 3 lines are to stop ridiculous translate popups -->
  <meta charset="UTF-8">
  <meta name="google" content="notranslate">
  <meta http-equiv="Content-Language" content="en">
  <!-- end of hack to prevent translate popup -->
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>ZC4 - Start Page <?php print $scrnres; ?></title>

    <!-- CSS  -->
    <!--link href="/css/style.css?version=newest" type="text/css" rel="stylesheet" media="screen,projection"/-->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
      .adhoc-button
      {
<?php
  if($MultiCount != 0) // need 4 buttons, so skinny it up!
  {
?>
        margin-top: 1.5rem !important; /* 36 px - note btn-med font size is 28px */
<?php
  }
  else
  {
?>
        margin-top: 2.33rem !important; /* 56 px same as btn-med with font size 28px */
<?php
  }
?>
/*        box-shadow: 0 4px 4px 0 rgba(0, 0, 0, .14), 0 6px 2px -2px rgba(0, 0, 0, .2), 0 2px 10px 0 rgba(0, 0, 0, .12) !important;*/
        box-shadow: 0 0.167rem 0.167rem 0 rgba(0, 0, 0, .14), 0 0.25rem 0.083rem -0.1rem rgba(0, 0, 0, .2), 0 0.083rem 0.416rem 0 rgba(0, 0, 0, .12) !important;
      }
      .cleaning-button-container
      {
        font-size: <?php print cached_font_size(); ?>px;
        position:absolute;
        bottom:0.18em;
        left:0.5em;
        min-width:2em;
        padding:0;
        margin:0;
        min-height:1.5em;
        transition:none;
      }
      .cleaning-button-anchor
      {
        min-height:<?php print cached_font_size() * 1.75; ?>px !important;
        width: 100%;
        text-align:center;
        font-size:inherit;
        margin:0;
        padding:0;
/*        box-shadow: 0 4px 4px 0 rgba(0, 0, 0, .14), 0 6px 2px -2px rgba(0, 0, 0, .2), 0 2px 10px 0 rgba(0, 0, 0, .12) !important; */
        box-shadow: 0 0.167rem 0.167rem 0 rgba(0, 0, 0, .14), 0 0.25rem 0.083rem -0.1rem rgba(0, 0, 0, .2), 0 0.083rem 0.416rem 0 rgba(0, 0, 0, .12) !important;
        transition:none;
      }
      .cleaning-button-icon-div
      {
        width:1.3em;
        height:1.3em;
        padding-left:0.3em;
        padding-top:0.1em;
        transition:none;
      }
    </style>

  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Select Task</a>
        <div class="area">START</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button">
          <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
               src="/img/poweroff.svg" />
        </a>
      </div>
    </nav>
    <div class="container">
      <div class="row center">
        <div class="col s5 light">
          <a id="daily_task" class="btn-large waves-effect  primary-fill"
             href="index.php?DoDailyTask=Y"
            ><?php print $ProcessName; ?><p><?php
              if(strlen($Class2) > 0)
                print '<img src="/img/' . $IconClass2 . '" class="invertible-icon">';
              if(strlen($Class1) > 0)
                print '<img src="/img/' . $IconClass1 . '" class="invertible-icon">';
              if(strlen($Class3) > 0)
                print '<img src="/img/' . $IconClass3 . '" class="invertible-icon">';
            ?></p>
          </a>
        </div>
        <div class="col s7 light" style="margin-top:0px">
          <a href="/glue/initiate-adhoc-coins.php" class="btn btn-med waves-effect  primary-fill adhoc-button">
            <img src="/img/coins.svg" class="invertible-icon">
<?php
  if($CustomerMod == "2")  // TODO: make determination based on c400 equip type?
  {
?>
            &nbsp; &nbsp;MAKE <?php print $RollsName; ?>
<?php
  }
  else
  {
?>
            &nbsp; &nbsp;COUNT <?php print $CoinsName; ?>
<?php
  }
?>
          </a><br>
          <a href="/glue/initiate-adhoc-notes.php" class="btn btn-med waves-effect  primary-fill adhoc-button">
            <img src="/img/notes.svg" class="invertible-icon">&nbsp; &nbsp;COUNT <?php print $NotesName; ?>
          </a><br>
          <a href="/strap-quantity.php" class="btn btn-med waves-effect  primary-fill adhoc-button">
            <img src="/img/straps.svg" class="invertible-icon">&nbsp; &nbsp;MAKE <?php print $StrapsName; ?>
          </a>
<?php
  if($MultiCount != 0)
  {
?>
          <a href="/glue/count_register.php" class="btn btn-med waves-effect  primary-fill adhoc-button">
            <img src=<?php print '"/img/' . $IconClass3 . '"'; ?> class="invertible-icon">&nbsp;&nbsp;Count <?php print $Class3; ?>
          </a>
<?php
  }
?>
        </div>
      </div>
    </div>

    <!-- Uncomment this section to enable the 'cleaning' button/feature -->
    <div class = "cleaning-button-container" style="left:0.25em;">
        <a href="/cleaning.php" class="btn waves-effect  primary-fill cleaning-button-anchor">
          <div class="cleaning-button-icon-div">
            <img src="/img/cleaning.svg" class="invertible-icon" style="width:1.3em;height:1.3em;" /><!-- this one must be 'auto' -->
          </div>
        </a>
    </div>
    <div class = "cleaning-button-container" style="left:2.5em;">
        <a href="/maintenance.php" class="btn waves-effect  primary-fill cleaning-button-anchor">
          <div class="cleaning-button-icon-div">
            <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
                 src="/img/wrench.png" class="invertible-icon" style="margin:0;padding:0" />
          </div>
        </a>
    </div>

    <div style="font-size:10px;position: absolute;bottom:2px;right:2px;">
      <!-- this feature is undocumented -->
      <div id=Semprini class="btn-flat">&nbsp;&nbsp;&nbsp;&nbsp;</div>
    </div>

    <!-- copyright message - see 'DoCopyrightThing()' -->
    <div id="copyright-message" style="text-align:center;font-size:0.6rem;line-height:1.1em;position: absolute;bottom:0.4rem;left:9%;right:9%;"></div>


    <!--  Scripts-->

    <script>
      // The remaining (global, timer) scripts go here

      // display copyright and server version for 5 seconds after waiting for 2
      // this happens each time you come to this screen until you've done something
      // such as setting the business date.

      function DoCopyrightThing()
      {
        var myRequest = new Request("/glue/copyright.php");

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("status", response.status);
                  }
                  return  response.text();
                })
          .then(function(text)
                {
                  document.getElementById("copyright-message").innerHTML = text;
                });


        setTimeout(UndoCopyrightThing,5000);
      }

      function UndoCopyrightThing()
      {
        document.getElementById("copyright-message").innerHTML = "";

        // this is where we check for maintenance items

        var myRequest = new Request("/glue/next-maint-reminder.php");

        fetch(myRequest)
          .then(function(response)
                {
                  if (!response.ok)
                  {
                    console.log("status", response.status);
                  }
                  return  response.text();
                })
          .then(function(text)
                {
                  text = text.trim();

                  // if I get a return code, invoke the maintenance prompt page using that code
                  // this will display a prompt for equipment arrival, and install as needed

                  if(text.length > 0)
                    document.location.href="/maintenance-prompt.php?code=" + text;
                });
      }

      // This special script is not documented
      // must be defined before any 'onClick' field refers to it
      // 'Semprini' is a Monty Python joke

      var nTimes=0;
      var nLastTime = null;

      function Semprini()
      {
        var nNow = Date.now();

        if(!nTimes || nLastTime == null)
        {
          nTimes = 1;
          nLastTime = nNow;
          return;
        }

        if((nNow - nLastTime) < 500 || // less than half sec
           (nNow - nLastTime) > 1500) // more than 1.5 sec
        {
          nTimes = 0;
          nLastTime = nNow;
          return;
        }

        nTimes = nTimes + 1;
        nLastTime = nNow;

        if(nTimes > 5)
        {
          // change this according to the need
          window.location.assign("/?screen_res=x"); //("/system-menu.php");
          return;
        }
      }

      // set up 'semprini' click event
      document.getElementById("Semprini").addEventListener('click',Semprini);

      setTimeout(DoCopyrightThing,2000);

    </script>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>

