<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Clear Jam (Zeus)</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Clear Jam (Zeus)<img width=42 height=42 src="/img/zeus-only.png"></a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <table style="width:85%;border:0">
        <tr>
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle;margin:15 0 0 0px">Visual Inspection
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Inspect Hopper.  Clear any notes that may have been partially fed in.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Inspect Reject Tray.  Clear any notes that may be covering the sensors</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Inspect Stackr.  Clearn any notes that may be covering the sensors.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Open the upper access door, located at the back of the machine, just below the hopper</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Check for (and remove) any notes or debris that might be there</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Shut the upper access door, and open the lower access door, which is just below the upper door on the back panel</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Again, c heck for (and remove) any notes or debris that might be there</LI>
                </UL>
              </LI>
              <LI style="list-style-type:disc;padding:0;margin:0 0 0 0px">
                Once the jam has been cleared, press the large 'C' button on the front panel.  You will need to re-count any notes that were in
                the process of being counted at the time of the jam.
              </LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/wrench.png" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">&nbsp; &nbsp;BACK</span>
      </a><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

