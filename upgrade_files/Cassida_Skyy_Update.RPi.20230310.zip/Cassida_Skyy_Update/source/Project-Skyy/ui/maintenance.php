<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/config_utils.php"; // also includes "glue/common_utils.php"

  $Equipment = coin_counter_equipment();
?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance Code</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
      table, th, td, tdata, tr
      {
        border: 0px;
        padding: 0;
      }
    </style>

    <script>
      var output = "code";

      function DoClick(key) // keypad click number key
      {
        var ww = document.getElementById(output);
        var strText = ww.value;

        console.log(output + ' ' + ww.id + ' ' + ww.value + ' ' + key);

        if(ww.id == "rv1")
        {
          var vv = Math.floor(strText * 10);

          console.log(vv);

          vv = (vv * 10 + Math.floor(key)) / 10;

          console.log(vv);

          ww.value = vv.toFixed(2);
        }
        else
        {
          ww.value = ww.value * 10 + Math.floor(key);
        }
      }

      function DoClickClr() // keyboard click clear
      {
        document.getElementById(output).value = '0';
      }

      function DoClickEntor() // keyboard click 'entor' which is like 'enter' but more epic
      {
        console.log('Entor');
      }


      function doSelChange()
      {
        var vv;
        vv = document.forms["selector"]["entitynum"].value;
        //document.getElementById("entitynum"),value;
        if(vv > 0)
        {
          document.forms["submitTheNumber"]["qty"].value = vv;
        }

        DoCheckValidNumber();
      }

      function do_help()
      {
        document.getElementById("popup_help").style.visibility="visible";
        document.getElementById("popup_help").style.display="block";
        console.log("do help");
      }

      function do_help_exit()
      {
        document.getElementById("popup_help").style.visibility="hidden";
        document.getElementById("popup_help").style.display="none";
        console.log("do help_exit");
      }

      var nTimes=0; // for Semprini
      var nLastTime = null;

      function Semprini()
      {
        var nNow = Date.now();

        if(!nTimes || nLastTime == null)
        {
          nTimes = 1;
          nLastTime = nNow;
          return;
        }

        if((nNow - nLastTime) < 500 || // less than half sec
           (nNow - nLastTime) > 1500) // more than 1.5 sec
        {
          nTimes = 0;
          nLastTime = nNow;
          return;
        }

        nTimes = nTimes + 1;
        nLastTime = nNow;

        if(nTimes > 5)
        {
          // change this according to the need

          nTimes = 0;
          nLastTime = nNow;

          do_help();

          return;
        }
      }

    </script>

  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation">
      <div class="nav-wrapper container">
      <a id="logo-container" href="#" class="brand-logo titlebar">Maintenance Code
        <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
             src="/img/zeus-only.png" style="margin:0;padding:0;border:0;">
<?php
  if(coin_counter_is_c300($Equipment))
  {
?>
        <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
             src="/img/c300-icon.png" style="margin:0;padding:0;border:0;">
<?php
  }
  else if(coin_counter_is_recycler_twin($Equipment))
  {
?>
        <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
             src="/img/twin-recycler-only.png" style="margin:0;padding:0;border:0;">
<?php
  }
  else if(coin_counter_is_recycler($Equipment))
  {
?>
        <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
             src="/img/recycler-only.png" style="margin:0;padding:0;border:0;">
<?php
  }
  else if(coin_counter_is_c400r($Equipment))
  {
?>
        <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
             src="/img/c400r-only.png" style="margin:0;padding:0;border:0;">
<?php
  }
  else
  {
?>
        <img width=<?php print round(cached_font_size() * 1.5); ?>px height=<?php print round(cached_font_size() * 1.5); ?>px
             src="/img/c400-only.png" style="margin:0;padding:0;border:0;">
<?php
  }
?>
         </a>
         <div class="area" style="font-size:0.87rem">MAINT</div>
      </div>
    </nav>


    <form name="submitCode" id="submitCode"
          action="/maintenance-days.php"
          method="post" onsubmit="return DoOnSubmit">
      <table width="100%" style="padding:0;margin:0;line-height:1.2rem">
        <tr style="padding:0;margin:0;line-height:1.2rem;max-height:1.4rem">
          <td width=30%>&nbsp;</td>
          <td width=30%>
            <div class="row button-row">
              <div class="input-selector" id="a1">
                <label>Code</label>
                <div class="mdl-textfield denom">
                  <input name="code" id="code"
                         class="special-text-input"
                         type="text" value="" maxlength="3" disabled />
                </div>
              </div>
            </div>
          </td>
          <td width=40%>
            <div id="value-warn" style="display:none;font-size:0.83rem">Must be between 1 and 9999
            </div>
          </td>
        </tr>
      </table>
    </form>

    <div id="quantity" class="center">
      <div class="row">
        <div id="registers-calc" class=" calc-card mdl-card mdl-shadow--2dp">
          <div class="buttons" id="wrapper">
            <button onClick="DoClick('7');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">7</button>
            <button onClick="DoClick('8');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">8</button>
            <button onClick="DoClick('9');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">9</button>
            <button onClick="DoClickClr();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent">
              <span style="display:none">backspace</span>
              <img src="img/baseline-backspace-24px.svg" style="color:white">
            </button>

            <button onClick="DoClick('4');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">4</button>
            <button onClick="DoClick('5');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">5</button>
            <button onClick="DoClick('6');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">6</button>
            <button class="mdl-button">&nbsp;</button>

            <button onClick="DoClick('1');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">1</button>
            <button onClick="DoClick('2');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">2</button>
            <button onClick="DoClick('3');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">3</button>
            <button onClick="DoClickEntor();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent tall"
                    style="line-height:1em;height:">
              E<br/>n<br/>t<br/>e<br/>r
            </button>

            <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide">0</button>
          </div>
        </div>
      </div>
    </div>

    <form id=none method="GET"></form>
    <div style="text-align:center;position:absolute;margin:0px;padding:0;bottom:0.83rem;left:38%;">
      <button formaction="/" form="none" class="btn btn-small waves-effect primary-fill btn-shadow">Exit</button>
    </div>
    <div class="next-button codes-done">
      <button name="next" id="next" form="none" class="btn btn-small waves-effect primary-fill btn-shadow"
              type="button" onclick="OnClickNext();" disabled>NEXT &gt;</button>
    </div>

    <div style="font-size:10px;position: absolute;bottom:2px;left:2px;">
      <!-- this feature is undocumented -->
      <div id=Semprini class="btn-flat">&nbsp;&nbsp;&nbsp;&nbsp;</div>
    </div>

    <!-- popup help -->
    <div id=popup_help class="modal-container"
         style="position:absolute;top:0px;visibility:hidden">
      <div id=help_dlg class="medium-modal me-and-my-shadow"
           style="visibility:inherit;position:relative;left:25%;width:50%;min-height:77%;min-height:77%;top:13%">
        <center style="font-size:0.7rem !important;line-height:0.7rem !important;">
          <table border=1 style="width:90%;">
            <thead>
              <tr style="text-align:left;font-size:0.72rem !important;line-height:0.72rem !important;">
                <th width=12% >Code</th>
                <th width=33% >Sub-System</th>
                <th width=55% >Description</th>
              </tr>
            </thead>
          </table>
          <table border=1 style="border-color:#000000;text-align:left;width:90%;max-height:12rem;display:inline-block;overflow:auto !important">
            <tbody>
              <!-- see maintenance_codes.xlsx and maintenance-days.php -->
              <tr><td width="12%">100</td><td width="33%">Zeus</td><td width="55%">Device Replacement</td></tr>
              <tr><td>101</td><td>Zeus</td><td>Receive Replacement</td></tr>
              <tr><td>110</td><td>Zeus</td><td>Clear Jam</td></tr>
              <tr><td>120</td><td>Zeus</td><td>Statistics</td></tr>
              <tr><td>199</td><td>Zeus</td><td>device test (thorough)</td></tr>
              <tr><td>200</td><td>Printer</td><td>Device Replacement</td></tr>
              <tr><td>201</td><td>Printer</td><td>Receive Replacement</td></tr>
              <tr><td>210</td><td>Printer</td><td>Reset</td></tr>
              <tr><td>211</td><td>Printer</td><td>Self-Test</td></tr>
              <tr><td>299</td><td>Printer</td><td>device test (thorough)</td></tr>
              <tr><td>300</td><td>C300</td><td>Device Replacement</td></tr>
              <tr><td>320</td><td>C300</td><td>Set Batch Amounts (reserved)</td></tr>
              <tr><td>399</td><td>C300</td><td>device test (thorough) (reserved)</td></tr>
              <tr><td>400</td><td>C400</td><td>Device Replacement</td></tr>
              <tr><td>401</td><td>C400</td><td>Receive Replacement</td></tr>
              <tr><td>410</td><td>C400</td><td>Clear Jam</td></tr>
              <tr><td>420</td><td>C400/Recycler</td><td>Set Batch Amounts</td></tr>
              <tr><td>499</td><td>C400</td><td>device test (thorough)</td></tr>
              <tr><td>500</td><td>System</td><td>Till Starting Amounts (pre-load)</td></tr>
              <tr><td>501</td><td>System</td><td>Reset</td></tr>
              <tr><td>510</td><td>System</td><td>Statistics</td></tr>
              <tr><td>520</td><td>System</td><td>Load config from USB (with choices)</td></tr>
              <tr><td>530</td><td>System</td><td>Load config from master config file</td></tr>
              <tr><td>555</td><td>System</td><td>Configuration menu</td></tr>
              <tr><td>573</td><td>System</td><td>FOB Keys</td></tr>
              <tr><td>580</td><td>System</td><td>Tweakable Settings</td></tr>
              <tr><td>600</td><td>Recycler</td><td>Device Replacement</td></tr>
              <tr><td>601</td><td>Recycler</td><td>Receive Replacement</td></tr>
              <tr><td>610</td><td>Recycler</td><td>Clear Jam</td></tr>
              <tr><td>611</td><td>Recycler</td><td>Reset</td></tr>
              <tr><td>620</td><td>Recycler</td><td>Info</td></tr>
              <tr><td>621</td><td>Recycler</td><td>Set Min Coin Levels (escrow)</td></tr>
              <tr><td>640</td><td>Recycler</td><td>Stir</td></tr>
              <tr><td>641</td><td>Recycler</td><td>Dump/Empty</td></tr>
              <tr><td>644</td><td>Recycler</td><td>Dispense Coins (full, maintenance version)</td></tr>
              <tr><td>699</td><td>Recycler</td><td>device test (thorough)</td></tr>
            </tbody>
          </table>
          <br />
          <br />
          <!--div style="position:relative;margin:0px;padding:0;bottom:20px;visibility:inherit"-->
            <button id=help_exit type=button onClick="do_help_exit();" class="btn waves-effect primary-fill btn-shadow"
                    style="visibility:inherit;width:30%;margin-left:0;">
              Close
            </button>
          <!--/div-->
          <br />
        </center>
      </div>
    </div>


    <!--  Scripts-->
    <script>
    //-- Set Defaults  --//
      var nDisplayed = 10;

      function setTotal ()
      {
        // does nothing, presence required by some of the previously written scripts
      }

      function OnClickNext()
      {
        var x = document.getElementById("code").value;
        if (x == "" || x < 1 || x > 9999)
        {
          window.alert("Please select a valid strap quantity");
          return false;
        }

        document.getElementById("code").disabled = false; // needs to be enabled
        document.forms["submitCode"].submit();
      }

      function DoCheckValidNumber()
      {
        var x = document.getElementById("code").value;
        if (x == "" || x < 1 || x > 9999)
        {
          document.getElementById("next").disabled = true;
          if(nDisplayed < 10)
          {
            document.getElementById("value-warn").style = "font-size:20px";
            nDisplayed += 1;
          }
          else
          {
            document.getElementById("value-warn").style = "display:none;font-size:20px";
          }
        }
        else
        {
          document.getElementById("next").disabled = false;
          nDisplayed = 0;
          document.getElementById("value-warn").style = "display:none;font-size:20px";
        }
      }

      // set up 'semprini' click event
      document.getElementById("Semprini").addEventListener('click',Semprini);

      setInterval(DoCheckValidNumber, 200);

    </script>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>

