<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $days = empty($_GET) || empty($_GET["days"]) ? "0" : $_GET["days"];

  if($days < 2 || $days > 5) // an error of  some kind
  {
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
        <meta http-equiv="refresh" content="5;url=/">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Invalid number of days specified</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }

  // transact the maintenance code and number of days via the skyy server

  skyyreq("add-reminder/100/" . $days);

?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>ZC4 - Daily Cleaning</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Zeus Replacement</a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <table style="width:85%;border:0">
        <tr> <!--style="margin:0 20 0 0px;line-height:28px;border:0"-->
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle;margin:15 0 0 0px">
                  Your replacement Zeus is to be delivered in approximately <?php print $days; ?> days.
                  <LI style="list-style-type:circle;margin:15 0 0 0px">
                    You will receive daily reminders after <?php print $days - 1; ?> day<?php if($days != 2) print 's'; ?></LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">
                    These daily reminders will ask you to perform a maintenance operation
                    as soon as you receive your replacement equipment.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">
                    If you receive your replacement Zeus before getting any reminders,
                    contact customer service for the correct maintenance code, and any additional instructions.</LI>
                </UL>
              </LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/wrench.png" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">&nbsp; &nbsp;Done</span>
      </a><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

