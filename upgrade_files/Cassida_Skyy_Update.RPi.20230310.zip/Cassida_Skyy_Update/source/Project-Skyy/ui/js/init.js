/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

(function($){
  $(function(){

    $('.sidenav').sidenav();

  }); // end of document ready
})(jQuery); // end of jQuery name space
