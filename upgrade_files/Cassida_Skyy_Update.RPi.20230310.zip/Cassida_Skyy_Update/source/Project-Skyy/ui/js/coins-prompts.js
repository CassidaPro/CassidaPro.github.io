/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

// all of the functions are contained within the 'document ready' callback

// to get rid of JQuery-ism, this code uses load event status - see bottom section

// overrideable globals
var CustomerMod = 0;
var isRecycler = false, isC400 = false, isC300 = false, isC400R = false;
var HasAutoResume = false; // assign to 'true' in php code to support auto resume
var refreshInterval = 1000;
var restartInterval = 2000; // needs to be longer because a single coin to make batch might otherwise stop too early
var printInterval   = 1500; // a bit o' extra time for printing, not quite what it was
// for modal dialogs
var MD_inner_id = 'alert_dlg';
var MD_inner_title_id = 'alert_dlg_title';
var MD_inner_div_id = 'alert_dlg_guts';
var MD_font_size = 24; // default, overide in main PHP doc with actual font size via PHP

function GetJavaScriptMillis()
{
//  var rval = d.getHours() * 3600000
//           + d.getMinutes() * 60000
//           + d.getSeconds() * 1000
//           + d.getMilliseconds();

   var rval=Date.now();

   return rval;
}

function MakeResultsVisible()
{
  try
  {
    if(CustomerMod == '1' && !HasAutoResume)
    {
      // if I have an 'operator message' make it hidden
      // if I have a 'results', make it visible

      if(document.getElementById("operator_messages") != null)
        document.getElementById("operator_messages").style.visibility = "hidden";
    }
  }
  finally {}

  try
  {
    if(document.getElementById("results") != null)
      document.getElementById("results").style.visibility = "visible";
  }
  finally {}
}


/* For modal dialogs, the class name for the background must be "modal-container", the
   main dialog class "coins_prompts_modal", and the inner 'div' class "coins_prompts_guts".
   The entire section should look something like this:

  <!-- coins prompts alerts -->
  <div id=popup_alert class="modal-container"
       style="position:absolute;top:0px;visibility:hidden;background-color: rgba(0, 0, 0, 0.4) !important">
    <div id=alert_dlg class="medium-modal me-and-my-shadow coins_prompts_modal"
         style="position:relative;left:25%;width:50%;top:4rem;min-height:14rem">
      <H1 id=alert_dlg_title style="font-size:1.5rem;text-align:center;width:100%;margin:0;margin-bottom:0.5rem;padding:0">The Title</H1>
      <div id=alert_dlg_guts class="coins_prompts_guts"
           style="position:relative;font-size:0.75rem;line-height:0.83rem;top:4px;height:12rem;text-align:center;margin:0;padding:0;display:block">
        The Content
      </div>
    </div>
  </div>

  Note that for backweard compatibility the shading is at 0.4 rather than the default value

*/

var MD_promise = false;
var MD_oldcolor = "rgba(0,0,0,0.4)";

function ModalOutsidepointerdown(evt)
{
  var zz = document.getElementsByClassName("medium-modal")[0];
  var zzz = zz.getBoundingClientRect();
  if(evt.buttons == 1 &&
     (evt.clientX < zzz.left || evt.clientX > zzz.right ||
      evt.clientY < zzz.top || evt.clientY > zzz.bottom))
  {
//  MD_oldcolor=document.getElementsByClassName("modal-container")[0].style.backgroundColor;
//  document.getElementsByClassName("modal-container")[0].style.backgroundColor="transparent";
    zz.style.visibility="hidden";
    console.log("pointerdown");
  }

}

function ModalOutsidepointerup(evt)
{
  var zz = document.getElementsByClassName("medium-modal")[0];
  var zzz = zz.getBoundingClientRect();
  if(zz.style.visibility == "hidden")
  {
    zz.style.visibility="visible";
    console.log("pointerup");
  }
}

/*async*/ function DoModalDialog(title, inner_html) /* uses 'await', must be async */
{
  // remove events from any existing coins_prompts_button class buttons
  var ii, ww;
  try
  {
    ww = document.getElementsByClassName("coins_prompts_button");
    if(ww != null)
    {
      for(ii=0; ii < ww.length; ii++)
      {
        ww[ii].removeEventListener('click', onClickCoinPromptButtonUIFB, {capture:true});
        ww[ii].removeEventListener('click', onClickCoinPromptButtonUIFB, {capture:false});
      }
    }
    ww = null;
  }
  finally { }

  // if a promise is active, remdove it and its effects

  if(MD_promise)
  {
    MD_promise = false;

    try
    {
      document.getElementsByClassName("modal-container")[0].style.visibility="hidden";
      document.getElementsByClassName("modal-container")[0].style.display="none";
      document.getElementsByClassName("modal-container")[0].removeEventListener('pointerdown', ModalOutsidepointerdown, {capture:false});
      document.getElementsByClassName("modal-container")[0].removeEventListener('pointerup', ModalOutsidepointerup, {capture:false});

      document.getElementById(MD_inner_id).style.visibility="hidden";
      document.getElementById(MD_inner_id).style.display="none";

      document.getElementById(MD_inner_title_id).innerHTML="";
      document.getElementById(MD_inner_div_id).innerHTML="";
    }
    finally { }
  }

  // create promise for dialog completion

  MD_promise = true; // new Promise();
  // display the modal stuff

  try
  {
    document.getElementsByClassName("modal-container")[0].style.visibility="visible";
    document.getElementsByClassName("modal-container")[0].style.display="block";
    document.getElementsByClassName("modal-container")[0].addEventListener('pointerdown', ModalOutsidepointerdown, {capture:false});
    document.getElementsByClassName("modal-container")[0].addEventListener('pointerup', ModalOutsidepointerup, {capture:false});

    document.getElementById(MD_inner_id).style.visibility="visible";
    document.getElementById(MD_inner_id).style.display="block";

    document.getElementById(MD_inner_title_id).innerHTML=title;
    document.getElementById(MD_inner_div_id).innerHTML = inner_html;

//    await MD_promise;
//    MD_promise = null;

    ww = document.getElementsByClassName("coins_prompts_button");
    if(ww != null)
    {
      for(ii=0; ii < ww.length; ii++)
      {
        ww[ii].addEventListener('click', onClickCoinPromptButtonUIFB, {capture:true});
      }
    }
    ww = null;
  }
  catch(err)
  {
    console.error(err);
  }
  finally { }

/*
  return MD_promise;
*/
}

async function EndModalDialog()
{
  // remove events from any existing coins_prompts_button class buttons
  var ii, ww;
  try
  {
    ww = document.getElementsByClassName("coins_prompts_button");
    if(ww != null)
    {
      for(ii=0; ii < ww.length; ii++)
      {
        ww[ii].removeEventListener('click', onClickCoinPromptButtonUIFB, {capture:true});
        ww[ii].removeEventListener('click', onClickCoinPromptButtonUIFB, {capture:false});
      }
    }
    ww = null;
  }
  finally { }

  if(MD_promise)
  {
    MD_promise = false;
//    MD_promise.resolve('success'); // for anything that is waiting on it
  }

  try
  {
    document.getElementsByClassName("modal-container")[0].style.visibility="hidden";
    document.getElementsByClassName("modal-container")[0].style.display="none";
    document.getElementsByClassName("modal-container")[0].removeEventListener('pointerdown', ModalOutsidepointerdown, {capture:false});
    document.getElementsByClassName("modal-container")[0].removeEventListener('pointerup', ModalOutsidepointerup, {capture:false});

    document.getElementById(MD_inner_id).style.visibility="hidden";
    document.getElementById(MD_inner_id).style.display="none";

    document.getElementById(MD_inner_title_id).innerHTML="";
    document.getElementById(MD_inner_div_id).innerHTML="";
  }
  finally { }
}

function onClickCoinPromptButtonUIFB(evt)
{
  var w = evt.currentTarget;

  var ll = w.style.left;
  var tt = w.style.top;

  if(ll.substring(ll.length - 2, ll.length) == "px")
    ll = ll.substring(0, ll.length - 2);

  if(tt.substring(tt.length - 2, tt.length) == "px")
    tt = tt.substring(0, tt.length - 2);

  w.style.left = (Math.floor(ll - 0) + 2) + 'px';
  w.style.top = (Math.floor(tt - 0) + 2) + 'px';

  setTimeout(function(){endClickCoinPromptButtonUIFB(w);}, 50);
}

function endClickCoinPromptButtonUIFB(w)
{
  var ll = w.style.left;
  var tt = w.style.top;

  if(ll.substring(ll.length - 2, ll.length) == "px")
    ll = ll.substring(0, ll.length - 2);

  if(tt.substring(tt.length - 2, tt.length) == "px")
    tt = tt.substring(0, tt.length - 2);

  w.style.left = (Math.floor(ll) - 2) + 'px';
  w.style.top = (Math.floor(tt) - 2) + 'px';

  console.log("tap"); // temporary for debugging
}




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                                            //
//   ____                                               _     ____                   _           ____        _  _  _                   _      //
//  |  _ \   ___    ___  _   _  _ __ ___    ___  _ __  | |_  |  _ \  ___   __ _   __| | _   _   / ___| __ _ | || || |__    __ _   ___ | | __  //
//  | | | | / _ \  / __|| | | || '_ ` _ \  / _ \| '_ \ | __| | |_) |/ _ \ / _` | / _` || | | | | |    / _` || || || '_ \  / _` | / __|| |/ /  //
//  | |_| || (_) || (__ | |_| || | | | | ||  __/| | | || |_  |  _ <|  __/| (_| || (_| || |_| | | |___| (_| || || || |_) || (_| || (__ |   <   //
//  |____/  \___/  \___| \__,_||_| |_| |_| \___||_| |_| \__| |_| \_\\___| \__,_| \__,_| \__, |  \____|\__,_||_||_||_.__/  \__,_| \___||_|\_\  //
//                                                                                      |___/                                                 //
//                                                                                                                                            //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////
// Main 'document ready' stuff for coin prompts
/////////////////////////////////////////////////

function DocReadyCallback() // this wraps the functionality to be invoked on 'document ready'
{
  var refreshTable = null;
  var bDialogDisplaying = false;
  var nTimesWithDialog = 0;

  console.log("Document Ready");

  if(CustomerMod == '1' && !HasAutoResume)
  {
    MakeResultsVisible();
    setTimeout(MakeOperatorMessageVisible, 1500);
    // 1.5 second delay - that way you could still see the totals for a bit
  }

  // a sleep function implementation that was found online, uses async to assist better performance
  function Sleep(msec)
  {
    return new Promise(resolve => setTimeout(resolve, msec));
  }



  function Resume()
  {
//      // TODO:  get rid of JQuery-isms, use 'Request' and async handling
//      //        and *THEN* have 'Resume' do what 'delay_get_status' is doing
//      //        in a reliable way, and retry (?) the 'continue' request on error,
//      //        and if it fails enough times, restart the interval anyway so
//      //        that it can display error messages..
//      $.ajax(
//      {
//        url : '/glue/continue-c400.php',
//        success : function(text){ }
//      });
    if(!HasAutoResume)
    {
      var myRequest = new Request("/glue/continue-c400.php");

      fetch(myRequest)
        .then(function(response)
              {
                if (!response.ok)
                {
                  console.log("continue-c400", response.status); // debug only (TODO: remove?  this is actually an error condition...)
                }
                return  response.text();
              })
        .then(function(text)
              {
                // TODO:  anything?
                myRequest = null;
              })
       .catch(function(err)
              {
                console.log("Error detected in Resume()");
                console.error(err);
              });
    }

    bDialogDisplaying = false;

    if(CustomerMod == '1' && !HasAutoResume)
    {
      setTimeout(MakeOperatorMessageVisible, 1500);
      // 1.5 second delay - that way you could still see the totals for a bit
    }
  }

  function delay_get_status()
  {
    if(refreshTable != null)
    {
      clearInterval(refreshTable);
      refreshTable = null;
    }

    refreshTable = setInterval(getStatus, refreshInterval);
  }

  function getStatus()
  {
    var bWithPrint = false;

    if(!bDialogDisplaying || nTimesWithDialog < 2)
    {
      if(bDialogDisplaying) // limit how many times I let this happen when a dialog is being displayed
      {
        nTimesWithDialog++; // for now, query the count 2 times while dialog visible - issue #217
      }
      else
      {
        nTimesWithDialog = 0;
      }
      try
      {
        bWithPrint = ShowPrintButton(); // if defined, can show print button
      }
      catch(e)
      {
        bWithPrint = false; // make sure
      }

      _getStatus(bWithPrint); // if there's a better way I'll change it
    }
  }

  function MakeOperatorMessageVisible()
  {
    if(CustomerMod == '1' && !HasAutoResume)
    {
      try
      {
        // if I have an 'operator message' make it hidden
        // if I have a 'results', make it visible
        if(document.getElementById("operator_messages") != null)
        {
          document.getElementById("operator_messages").style.visibility = "visible";

          if(document.getElementById("results") != null)
            document.getElementById("results").style.visibility = "hidden";
        }
      }
      finally {}
    }
  }

  var bWasCode0 = false;
  var nCode0Tick = 0;
  var nWasEmptyMillis = 0;
  var bWasEmpty = false;
  var getting_status = false;

  function _getStatus(bWithPrint)
  {
    if(getting_status) // I think I have been seeingt 'lockups' with this
    {
      console.log("Skipping recursion on getStatus");
      return;
    }

    getting_status = true;
    var myRequest = new Request("/glue/status-c400.php");

    // Issue #217 - call this as part of the status update, and not in a separate
    //              periodic timed callback.  Better control, no leaks, etc..
    DoCoinResultsUpdate(); // do this first (async function located in scripts.js)

    try
    {
      fetch(myRequest)
        .then(
          function(response)
          {
            if (!response.ok)
            {
              console.log("status-c400", response.status); // debug only (TODO: remove?)
            }

            myRequest = null;
            return  response.text();
          })
        .then(
          async function(text) /* mark as 'async' so that I can use 'await'? already async really! */
          {
            if(text.length == 0) // tracking zero-length return as skyy not running
            {
              if(!bWasEmpty)
              {
                nWasEmptyMillis = GetJavaScriptMillis();
                bWasEmpty = true;

                document.getElementById("messagething").innerHTML = "ERROR - no response from server";
                document.getElementById("messagething").style.color="#ffff00"; // YELLOW
                document.getElementById("messagething").style.backgroundColor="#ff0000"; // RED
              }
              else if((GetJavaScriptMillis() - nWasEmptyMillis) > 30000)
              {
                doFinished();
              }

              return;
            }

            // xx will be a DOM Parser type of object from which to parse XML
            // This is how we parse XML without resorting to bloatware libs like JQuery
            // Reason behind this update, see issue #217 for Project Skyy / Split Recycler project

            var xx = (new window.DOMParser()).parseFromString(text, "text/xml");

            if(xx == null
               || xx.getElementsByTagName("entity") == null
               || xx.getElementsByTagName("entity")[0] == null
               || xx.getElementsByTagName("entity")[0].childNodes == null
               || xx.getElementsByTagName("entity")[0].childNodes[0] == null) // server error
            {
              if(!bWasEmpty)
              {
                nWasEmptyMillis = GetJavaScriptMillis();
                bWasEmpty = true;

                document.getElementById("messagething").innerHTML = "SERVER ERROR; please restart system";
                document.getElementById("messagething").style.color="#ffff00"; // YELLOW
                document.getElementById("messagething").style.backgroundColor="#ff0000"; // RED
              }
              else if((GetJavaScriptMillis() - nWasEmptyMillis) > 30000)
              {
                doFinished();
              }

              xx = null;
              return;
            }

            bWasEmpty = false;

            var msec;
            var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
            var the_date = xx.getElementsByTagName("date")[0];
            var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
            var st = xx.getElementsByTagName("status")[0].children;
            var code = "";
            var subcode = "";
            var msgtext = "";
            var denom = "";
            var today = "";

            if(the_date && the_date.childNodes.length > 0)
            {
              today = the_date.childNodes[0].nodeValue;
            }
            else
            {
              today = "unknown date";
            }

            for (var i1 = 0; i1 < st.length; i1++)
            {
              if(st[i1].nodeName == "code")
                code = st[i1].childNodes[0].nodeValue;
              else if(st[i1].nodeName == "subcode")
                subcode = st[i1].childNodes[0].nodeValue;
              else if(st[i1].nodeName == "text")
                msgtext = st[i1].childNodes[0].nodeValue;
              else if(st[i1].nodeName == "denom")
                denom = st[i1].childNodes[0].nodeValue;
            }

            // 'ba' may not exist
            try
            {
              var ba = xx.getElementsByTagName("batch");
              if(ba && ba.length > 0)
                ba = ba[0].children;

              for (var i1 = 0; i1 < ba.length; i1++)
              {
                if(ba[i1].nodeName == "denom")
                  denom = ba[i1].childNodes[0].nodeValue;
              }
            }
            finally { }

            if (code=="19") // hopper empty
            {
//              console.log("Temporary, Hopper Empty");

              MakeResultsVisible();

              document.getElementById("messagething").innerHTML = "";
              clearInterval(refreshTable);
              refreshTable = null;

              var the_delay;

              if(isRecycler)
                the_delay = 100; // shorter wait for recycler (helps with the UI a bit, but slight delay so as not to shock the user)
              else
                the_delay = 900; // wait almost a second... (so print report 'beep' happens at same time)

              Sleep(the_delay).then(
              function()
              {
                if(bWithPrint == true)
                  modalEmptyWithPrint();
                else
                  modalEmpty();

                try
                {
                  // if I have a stop button, un-disable it
                  if(document.getElementById("stop") != null)
                    document.getElementById("stop").disabled = false;
                }
                finally {}
              });

              msec = null;
              xx = null;
              entity = null;
              the_date = null;
              tick = null;
              st = null;
              code = null;
              msgtext = null;
              denom = null;
              today = null;

              return;
            }
            else if(code == "0" || code == "17" || code == "18" // idle, counting, stopping
                    || code == "22") // count updated
            {
//              if(code == "22") // count updated - recycler uses this
//              {
//                console.log("Temporary, code = " + code);
//              }
//              else
//              {
//                console.log("Temporary, code = " + code);
//              }

              // normal messages
              document.getElementById("messagething").innerHTML = msgtext; // + " code " + code;
              document.getElementById("messagething").style.color="#000000"; // BLACK
              document.getElementById("messagething").style.backgroundColor="#ffffff"; // WHITE

              msec = null;
              xx = null;
              entity = null;
              the_date = null;
              st = null;
              msgtext = null;
              denom = null;
              today = null;
//              tick = null;
//              code = null;

              // code 0 for more than 30 seconds?
              if(code == "0")
              {
                if(bWasCode0) // part of a timer to cancel and go to index.php when no server running
                {
                  if((parseFloat(tick) - nCode0Tick) > 30000)
                  {
                    doFinished();
                  }
                }
                else
                {
                  nCode0Tick = parseFloat(tick);
                  bWasCode0 = true;
                }
              }
              else //if(code != "0")
              {
                if(bWasCode0)
                {
                  bWascode0 = false; // part of a timer to cancel and go to index.php when no server running
                }
              }

              return; // no dialog box - running
            }
/*
            else if(code == "22") // count updated - recycler uses this
            {
              console.log("count updated");

              MakeResultsVisible();
              clearInterval(refreshTable);
              refreshTable = null;

              msec = null;
              xx = null;
              entity = null;
              the_date = null;
              tick = null;
              st = null;
              code = null;
              msgtext = null;
              denom = null;
              today = null;

              myRequest = null;
              return;
            }
*/
            else if(code == 30 && isRecycler)
            {
              MakeResultsVisible();

              document.getElementById("messagething").innerHTML = "";
              clearInterval(refreshTable);
              refreshTable = null;

              modalRecyclerDrawer();

              try
              {
                // if I have a stop button, un-disable it
                if(document.getElementById("stop") != null)
                  document.getElementById("stop").disabled = false;
              }
              finally {}

              msec = null;
              xx = null;
              entity = null;
              the_date = null;
              tick = null;
              st = null;
              code = null;
              msgtext = null;
              denom = null;
              today = null;

              return;
            }
            else if(code != "21") //if (code == "31" || code < 16)
            {
              console.log("Temporary, code = " + code);

              MakeResultsVisible();

              document.getElementById("messagething").innerHTML = "";
              clearInterval(refreshTable);
              refreshTable = null;

              if(code == "31" && subcode == "1") // definitely a comm error
                modalCommError();
              else if(code == "31" && subcode == "2") // definitely an error with info
                modalErrorText(msgtext);
              else // all other errors
                modalError(code);

              try
              {
                // if I have a stop button, un-disable it
                if(document.getElementById("stop") != null)
                  document.getElementById("stop").disabled = false;
              }
              finally {}

              msec = null;
              xx = null;
              entity = null;
              the_date = null;
              tick = null;
              st = null;
              code = null;
              msgtext = null;
              denom = null;
              today = null;

              return;
            }

            // BATCH

            MakeResultsVisible();
            clearInterval(refreshTable);
            refreshTable = null;

            document.getElementById("messagething").innerHTML = "";

            // oddly , the length of time I must sleep is a little different
            // for each denomination.  For pennies, 0.9 seconds.  For quarters, 0.70 seconds
            // The others are interpolated.  These are approximate, giving reasonable results

            if (denom=="1")
              msec=900;
            else if (denom=="5")
              msec=833;
            else if (denom=="10")
              msec=766;
            else if (denom=="25")
              msec=700;
            else
              msec=1000;

            Sleep(msec).then( // wait about a second... (so print report 'beep' happens at same time)
              function()
              {
                if (denom=="1")
                {
                  modalBatch1();
//                  NOTE:  handilng 'Resume()' is done within the modal box.  works better
//                      Resume();
//                      refreshTable = setInterval(delay_get_status, refreshInterval);
                }
                else if (denom=="5")
                {
                  modalBatch5();
//                  NOTE:  handilng 'Resume()' is done within the modal box.  works better
//                      Resume();
//                      refreshTable = setInterval(delay_get_status, refreshInterval);
                }
                else if (denom=="10")
                {
                  modalBatch10();
//                  NOTE:  handilng 'Resume()' is done within the modal box.  works better
//                      Resume();
//                      refreshTable = setInterval(delay_get_status, refreshInterval);
                }
                else if (denom=="25")
                {
                  modalBatch25();
//                  NOTE:  handilng 'Resume()' is done within the modal box.  works better
//                      Resume();
//                      refreshTable = setInterval(delay_get_status, refreshInterval);
                }
                else
                {
                  modalError(denom + 100);
                }

                try
                {
                  // if I have a stop button, un-disable it
                  if(document.getElementById("stop") != null)
                    document.getElementById("stop").disabled = false;
                }
                finally {}

                msec = null;
                xx = null;
                entity = null;
                the_date = null;
                tick = null;
                st = null;
                code = null;
                msgtext = null;
                denom = null;
                today = null;

              });
          })
      .catch(
          function(err)
          {
            console.log("Error detected in _getStatus(" + bWithPrint + ")");
            console.error(err);
          });

          getting_status = false;
        }
        catch(e)
        {
          console.error(e);
          getting_status = false;
        }
        finally
        {
        }
  }

  if(refreshTable != null)
  {
    clearInterval(refreshTable);

    refreshTable = null;
  }
  refreshTable = setInterval(delay_get_status, refreshInterval);


  // ------------------- Modal Messages when Coin Counting -------------
  function modalError(modalCode)
  {
      DoModalDialog(isRecycler ? "Recycler Error" : "C400 Error",
                    '<h6><img width=' + (MD_font_size * 216 / 24)
                    + 'px height=' + (MD_font_size * 79 / 24) + 'px '
                    + 'src="img/' + (isRecycler ? "refill-hopper-recycler" : "refill-hopper") + '.png"></h6>' + "\n"
                    + '<p class="coins_prompts_paragraph">'
                    + "A problem exists with the "
                    + (isRecycler ? "Recycler" : "C400")
                    + (" (" + modalCode + ")")
                    + '.<br>Please check connections<br>and re-start the system.</p>'
                    + '<div class="coins_prompts_button_container">'
                    + '<a onClick="doFinished();" class="btn btn-next waves-effect primary-fill btn-shadow coins_prompts_button">EXIT</a>',
                    + '</div>');
  }

  function modalErrorText(msgtext)
  {
      DoModalDialog(isRecycler ? "Recycler Error" : "C400 Error",
                    '<h6><img width=' + (MD_font_size * 216 / 24)
                    + 'px height=' + (MD_font_size * 79 / 24) + 'px '
                    + 'src="img/' + (isRecycler ? "refill-hopper-recycler" : "refill-hopper") + '.png"></h6>' + "\n"
                    + '<p class="coins_prompts_paragraph">'
                    + msgtext + '<br />'
                    + 'Please check for JAM or<br>other abnormality.</p>'
                    + '<div class="coins_prompts_button_container">'
                    + (isRecycler ? '<a class="btn-flat waves-effect primary-text coins_prompts_button printButton">PRINT</a>' : '')
                    + '<a onClick="doFinished();" class="btn btn-next waves-effect primary-fill btn-shadow coins_prompts_button">EXIT</a>',
                    + '</div>');


    if(isRecycler)
    {
      if(document.getElementsByClassName("printButton") == null ||
         document.getElementsByClassName("printButton")[0] == null)
      {
        console.log("cannot find printButton");
      }
      else
      {
        document.getElementsByClassName("printButton")[0].addEventListener('click',
          function()
          {
            EndModalDialog();

            document.getElementById("messagething").innerHTML = "Printing...";
            doPrint();
            bDialogDisplaying = false;

            if(refreshTable != null)
            {
              clearInterval(refreshTable);
              refreshTable = null;
            }

            refreshTable = setInterval(delay_get_status, printInterval); // * 2); // print takes a bit
          });
      }
    }
  }

  function modalCommError()
  {
      DoModalDialog(isRecycler ? "Recycler Error" : "C400 Error",
                    '<h6><img width=' + (MD_font_size * 216 / 24)
                    + 'px height=' + (MD_font_size * 79 / 24) + 'px '
                    + 'src="img/' + (isRecycler ? "refill-hopper-recycler" : "refill-hopper") + '.png"></h6>' + "\n"
                    + '<p class="coins_prompts_paragraph">'
                    + "A problem exists with the "
                    + (isRecycler ? "Recycler" : "C400")
                    + '.<br>Check usb connection between<br>Coin Counter and Tablet.<br>Reseat connections.</p>'
                    + '<div class="coins_prompts_button_container">'
                    + '<a onClick="doFinished();" class="btn-flat waves-effect primary-text coins_prompts_button">EXIT</a>',
                    + '<a href="#" class="btn btn-next waves-effect primary-fill btn-shadow restartButton coins_prompts_button">RECOVER</a>'
                    + '</div>');

    document.getElementsByClassName("restartButton")[0].addEventListener('click',
      function()
      {
        EndModalDialog(); //Swal.close();
        Resume();

        document.getElementById("messagething").innerHTML = "Recovering...";
        if(refreshTable != null)
        {
          clearInterval(refreshTable);
          refreshTable = null;
        }
        refreshTable = setInterval(delay_get_status, refreshInterval);
      });
  }

  async function modalRecyclerDrawer()
  {
    var checkRestart = null;

    bDialogDisplaying = true;

    DoModalDialog(isRecycler ? "Recycler Error" : "C400 Error",
                  '<h6><img width=' + (MD_font_size * 216 / 24)
                  + 'px height=' + (MD_font_size * 79 / 24) + 'px '
                  + 'src="img/' + (isRecycler ? "refill-hopper-recycler" : "refill-hopper") + '.png"></h6>' + "\n"
                  + '<p class="coins_prompts_paragraph">'
                  + 'Coin drawer position<br>'
                  + 'Please move drawer to<br/>&quot;Loose Coins&quot;</p>'
                  + '<div class="coins_prompts_button_container">'
                  + '<a onClick="doFinished();" class="btn btn-next waves-effect primary-fill btn-shadow coins_prompts_button">EXIT</a>',
                  + '</div>');

    function CheckDrawer() /* called periodically while dialog displays - see below */
    {
      var myRequest = new Request("/glue/status-c400.php");

      fetch(myRequest)
        .then(
          function(response)
          {
            if (!response.ok)
            {
              console.log("status-c400", response.status); // debug only (TODO: remove?)
            }

            return  response.text();
          })
        .then(
          function(text)
          {
            if(text.length == 0) // tracking zero-length return as skyy not running
            {
              myRequest = null;
              return;
            }

            // xx will be a DOM Parser type of object from which to parse XML
            // This is how we parse XML without resorting to bloatware libs like JQuery
            // Reason behind this update, see issue #217 for Project Skyy / Split Recycler project

            var xx = (new window.DOMParser()).parseFromString(text, "text/xml");

            if(xx == null
               || xx.getElementsByTagName("entity") == null
               || xx.getElementsByTagName("entity")[0] == null
               || xx.getElementsByTagName("entity")[0].childNodes == null
               || xx.getElementsByTagName("entity")[0].childNodes[0] == null) // server error
            {
              myRequest = null;
              return;
            }

            var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
            var the_date = xx.getElementsByTagName("date")[0];
            var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
            var st = xx.getElementsByTagName("status")[0].children;
            var code = "";

            for (var i1 = 0; i1 < st.length; i1++)
            {
              if(st[i1].nodeName == "code")
                code = st[i1].childNodes[0].nodeValue;
            }

            if(code == "19") // hopper empty
            {
              EndModalDialog(); // Swal.close();
              Resume();

              clearInterval(checkRestart);
              checkRestart = null;

              document.getElementById("messagething").innerHTML = "Restarting...";
              if(refreshTable != null)
              {
                clearInterval(refreshTable);
                refreshTable = null;
              }
              refreshTable = setInterval(delay_get_status, refreshInterval);
            }

            xx = null;
            entity = null;
            the_date = null;
            tick = null;
            st = null;
            code = null;

            myRequest = null;
          })
      .catch(
          function(err)
          {
            console.log("Error detected in CheckForResume()");
            console.error(err);
          });
    }

    checkRestart = setInterval(CheckDrawer, 500); // 1/2 sec interval
  }

  async function modalEmpty() // new version uses new dialog!
  {
    var checkRestart = null;

    bDialogDisplaying = true;

    if(HasAutoResume)
      DoModalDialog('Hopper Empty',
                    '<h6><img width=' + (MD_font_size * 216 / 24)
                    + 'px height=' + (MD_font_size * 79 / 24) + 'px '
                    + 'src="img/' + (isRecycler ? "refill-hopper-recycler" : "refill-hopper") + '.png"></h6>' + "\n"
                    +'<p class="coins_prompts_paragraph">Insert more '
                    + CoinsTerm().toLowerCase()
                    + '<br>into the hopper</p>'
                    + '<div class="coins_prompts_button_container">'
                    +'<a onClick="doFinished();" '
                    + 'class="btn btn-next waves-effect primary-fill btn-shadow coins_prompts_button">FINISHED</a>'
                    + '</div>');
    else
      DoModalDialog('Hopper Empty',
                    '<h6><img width=' + (MD_font_size * 216 / 24)
                    + 'px height=' + (MD_font_size * 79 / 24) + 'px '
                    + 'src="img/' + (isRecycler ? "refill-hopper-recycler" : "refill-hopper") + '.png"></h6>' + "\n"
                    +'<p class="coins_prompts_paragraph">Insert more '
                    + CoinsTerm().toLowerCase()
                    + '<br>into the hopper</p>'
                    + '<div class="coins_prompts_button_container">'
                    + '<a onClick="doFinished();" '
                    + 'class="btn btn-next waves-effect primary-fill btn-shadow coins_prompts_button">FINISHED</a>'
                    + '<a href="#" class="btn-flat waves-effect primary-text coins_prompts_button restartButton">RESUME</a>'
                    + '</div>');

    if(!HasAutoResume)
      document.getElementsByClassName("restartButton")[0].addEventListener('click',
        function()
        {
          EndModalDialog(); //Swal.close();
          Resume();

          if(checkRestart)
            clearInterval(checkRestart);
          checkRestart = null;

          document.getElementById("messagething").innerHTML = "Restarting...";
          if(refreshTable != null)
          {
            clearInterval(refreshTable);
            refreshTable = null;
          }
          refreshTable = setInterval(delay_get_status, refreshInterval);
        });

    function CheckForResume() /* called periodically while dialog displays - see below */
    {
      var myRequest = new Request("/glue/status-c400.php");

      fetch(myRequest)
        .then(
          function(response)
          {
            if (!response.ok)
            {
              console.log("status-c400", response.status); // debug only (TODO: remove?)
            }

            return  response.text();
          })
        .then(
          function(text)
          {
            if(text.length == 0) // tracking zero-length return as skyy not running
            {
              myRequest = null;
              return;
            }

            // xx will be a DOM Parser type of object from which to parse XML
            // This is how we parse XML without resorting to bloatware libs like JQuery
            // Reason behind this update, see issue #217 for Project Skyy / Split Recycler project

            var xx = (new window.DOMParser()).parseFromString(text, "text/xml");

            if(xx == null
               || xx.getElementsByTagName("entity") == null
               || xx.getElementsByTagName("entity")[0] == null
               || xx.getElementsByTagName("entity")[0].childNodes == null
               || xx.getElementsByTagName("entity")[0].childNodes[0] == null) // server error
            {
              myRequest = null;
              return;
            }

            var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
            var the_date = xx.getElementsByTagName("date")[0];
            var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
            var st = xx.getElementsByTagName("status")[0].children;
            var code = "";

            for (var i1 = 0; i1 < st.length; i1++)
            {
              if(st[i1].nodeName == "code")
                code = st[i1].childNodes[0].nodeValue;
            }

            if(code=="22") // coin count update
            {
//                console.log("Temporary, coin count update with dialog visible");

              EndModalDialog(); // Swal.close();
              Resume();

              clearInterval(checkRestart);
              checkRestart = null;

              document.getElementById("messagething").innerHTML = "Restarting...";
              if(refreshTable != null)
              {
                clearInterval(refreshTable);
                refreshTable = null;
              }
              refreshTable = setInterval(delay_get_status, refreshInterval);
            }

            xx = null;
            entity = null;
            the_date = null;
            tick = null;
            st = null;
            code = null;

            myRequest = null;
          })
      .catch(
          function(err)
          {
            console.log("Error detected in CheckForResume()");
            console.error(err);
          });
    }

    if(HasAutoResume)
      checkRestart = setInterval(CheckForResume, 500); // 1/2 sec interval
  }

  function modalEmptyWithPrint()
  {
    var checkRestart = null;

    bDialogDisplaying = true;

    if(HasAutoResume)
      DoModalDialog('Hopper Empty',
                    '<h6><img width=' + (MD_font_size * 216 / 24)
                    + 'px height=' + (MD_font_size * 79 / 24) + 'px '
                    + 'src="img/' + (isRecycler ? "refill-hopper-recycler" : "refill-hopper") + '.png"></h6>' + "\n"
                    +'<p class="coins_prompts_paragraph">Insert more '
                    + CoinsTerm().toLowerCase()
                    + '<br>into the hopper</p>'
                    + '<div class="coins_prompts_button_container">'
                    +'<a class="btn-flat waves-effect primary-text coins_prompts_button printButton">PRINT</a>'
                    +'<a onClick="doFinished();" '
                    + 'class="btn btn-next waves-effect primary-fill btn-shadow coins_prompts_button">FINISHED</a>'
                    + '</div>');
    else
      DoModalDialog('Hopper Empty',
                    '<h6><img width=' + (MD_font_size * 216 / 24)
                    + 'px height=' + (MD_font_size * 79 / 24) + 'px '
                    + 'src="img/' + (isRecycler ? "refill-hopper-recycler" : "refill-hopper") + '.png"></h6>' + "\n"
                    +'<p class="coins_prompts_paragraph">Insert more '
                    + CoinsTerm().toLowerCase()
                    + '<br>into the hopper</p>'
                    + '<div class="coins_prompts_button_container">'
                    +'<a class="btn-flat waves-effect primary-text coins_prompts_button printButton">PRINT</a>'
                    +'<a onClick="doFinished();" '
                    + 'class="btn btn-next waves-effect primary-fill btn-shadow coins_prompts_button">FINISHED</a>'
                    + '<a href="#" class="btn-flat waves-effect primary-text coins_prompts_button restartButton">RESUME</a>'
                    + '</div>');

    if(!HasAutoResume)
      document.getElementsByClassName("restartButton")[0].addEventListener('click',
        function()
        {
          EndModalDialog(); // Swal.close();
          Resume();

          if(checkRestart)
            clearInterval(checkRestart);
          checkRestart = null;

          document.getElementById("messagething").innerHTML = "Restarting...";

          if(refreshTable != null)
          {
            clearInterval(refreshTable);
            refreshTable = null;
          }

          refreshTable = setInterval(delay_get_status, restartInterval);
        });

    if(document.getElementsByClassName("printButton") == null ||
       document.getElementsByClassName("printButton")[0] == null)
    {
      console.log("cannot find printButton");
    }
    else
    {
      document.getElementsByClassName("printButton")[0].addEventListener('click',
        function()
        {
          EndModalDialog();

          if(checkRestart)
            clearInterval(checkRestart);
          checkRestart = null;

          document.getElementById("messagething").innerHTML = "Printing...";
          doPrint();
          bDialogDisplaying = false;

          if(refreshTable != null)
          {
            clearInterval(refreshTable);
            refreshTable = null;
          }

          refreshTable = setInterval(delay_get_status, printInterval); // * 2); // print takes a bit
        });
    }

    // TODO: consolidate into single  callback
    function CheckForResume()
    {
      var myRequest = new Request("/glue/status-c400.php");

      fetch(myRequest)
        .then(
          function(response)
          {
            if (!response.ok)
            {
              console.log("status-c400", response.status); // debug only (TODO: remove?)
            }

            return  response.text();
          })
        .then(
          function(text)
          {
            if(text.length == 0 || // tracking zero-length return as skyy not running
               checkRestart == null)  // if I turned off the interval, any async requests need to go away too
            {
              myRequest = null;
              return;
            }

            // xx will be a DOM Parser type of object from which to parse XML
            // This is how we parse XML without resorting to bloatware libs like JQuery
            // Reason behind this update, see issue #217 for Project Skyy / Split Recycler project

            var xx = (new window.DOMParser()).parseFromString(text, "text/xml");

            if(xx == null
               || xx.getElementsByTagName("entity") == null
               || xx.getElementsByTagName("entity")[0] == null
               || xx.getElementsByTagName("entity")[0].childNodes == null
               || xx.getElementsByTagName("entity")[0].childNodes[0] == null) // server error
            {
              myRequest = null;
              return;
            }

            var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
            var the_date = xx.getElementsByTagName("date")[0];
            var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
            var st = xx.getElementsByTagName("status")[0].children;
            var code = "";

            for (var i1 = 0; i1 < st.length; i1++)
            {
              if(st[i1].nodeName == "code")
                code = st[i1].childNodes[0].nodeValue;
            }

            if(code=="22") // coin count update
            {
//                console.log("Temporary, coin count update with dialog visible");

              EndModalDialog(); // Swal.close();
              Resume();

              clearInterval(checkRestart);
              checkRestart = null;

              document.getElementById("messagething").innerHTML = "Restarting...";

              if(refreshTable != null)
              {
                clearInterval(refreshTable);
                refreshTable = null;
              }

              refreshTable = setInterval(delay_get_status, refreshInterval);
            }

            xx = null;
            entity = null;
            the_date = null;
            tick = null;
            st = null;
            code = null;

            myRequest = null;
          })
      .catch(
          function(err)
          {
            console.log("Error detected in CheckForResume()");
            console.error(err);
          });
    }

    if(HasAutoResume)
      checkRestart = setInterval(CheckForResume, 500); // 1/2 sec interval
  }

  function modalBatchGeneric(theGraphic, theText, theColor)
  {
    bDialogDisplaying = true;

    DoModalDialog('Batch Complete',
                  '<img width=' + (MD_font_size * 110 / 24) + 'px '
                  + 'height=' + (MD_font_size * 110 / 24) + ' src= "' + theGraphic + '">'
                  + '<br><br style="line-height:1.6rem">'
                  + '<span style="word-wrap:normal;font-size:2.7rem;font-weight: bold;font-family:Liberation Sans;color:'
                  + theColor + ';">'
                  + theText + '</span>'
                  + '<br><br><br>'
                  + '<div class="coins_prompts_button_container">'
                  + '<a href="#" class="btn btn-next waves-effect primary-fill btn-shadow coins_prompts_button restartButton">RESUME</a>'
                  + '</div>');

    document.getElementsByClassName("restartButton")[0].addEventListener('click',
      function()
      {
        EndModalDialog(); // Swal.close();

        // 'Resume' handling here
        Resume();

        document.getElementById("messagething").innerHTML = "Restarting...";

        if(refreshTable != null)
        {
          clearInterval(refreshTable);
          refreshTable = null;
        }

        refreshTable = setInterval(delay_get_status, restartInterval);
      });
  }

  function modalBatch1()
  {
    modalBatchGeneric("/img/penny.png","PENNIES", '#ae1900');
  }

  function modalBatch5()
  {
    modalBatchGeneric("/img/nickel.png","NICKELS", '#006b93');
  }

  function modalBatch10()
  {
    modalBatchGeneric("/img/dime.png","DIMES", '#327100');
  }

  function modalBatch25()
  {
    modalBatchGeneric("/img/quarter.png","QUARTERS", '#dd6300');
  }


  if(CustomerMod == '1' && !HasAutoResume)
  {
    // global initialization function calls go here
    MakeOperatorMessageVisible();
  }
}





/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
//   ____                                               _     _                       _            _   //
//  |  _ \   ___    ___  _   _  _ __ ___    ___  _ __  | |_  | |     ___    __ _   __| |  ___   __| |  //
//  | | | | / _ \  / __|| | | || '_ ` _ \  / _ \| '_ \ | __| | |    / _ \  / _` | / _` | / _ \ / _` |  //
//  | |_| || (_) || (__ | |_| || | | | | ||  __/| | | || |_  | |___| (_) || (_| || (_| ||  __/| (_| |  //
//  |____/  \___/  \___| \__,_||_| |_| |_| \___||_| |_| \__| |_____|\___/  \__,_| \__,_| \___| \__,_|  //
//                                                                                                     //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////


// this solution was found online, to help get rid of JQuery
if(document.readyState === "complete" ||
   (document.readyState !== "loading" && !document.documentElement.doScroll))
{
  // if I'm done loading, or I'm still loading but I won't be scrolling,
  // it's "safe" to call the 'on doc ready' callback

  DocReadyCallback(); // call my callback now - the event fired already or don't need to wait
}
else
{
  document.addEventListener("DOMContentLoaded", DocReadyCallback); // set up an event listener, fire when ready
}

