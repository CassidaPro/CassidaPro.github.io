<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include 'config_utils.php';

  // re-direct to the correct edit page depending upon the banking system chosen
  // it's being done this way because it's a bit simpler to code than to place
  // a "but if" section in 'banking.php'

  // parse config file for things I need
  $parseconf = load_parseconf();

  $banking = do_parse_banking();

  $BankingType = do_bankingvar($banking, "system",
                               do_getconf($parseconf, "banking", "type", ""));


  if($BankingType == "cirreon")
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /banking_cirreon.php");

    exit;
  }
  else if($BankingType == "compass/vms")
  {
    // TODO:  the 'compass/vms' page
  }

  // anythihg else flows through
?>
<HTML><HEAD><TITLE>Banking Configuration</TITLE>
  <meta http-equiv="refresh" content="10;url=/banking.php" >
<?php set_inbetween_style(); ?>
  </HEAD>
  <BODY>
    <br><br><br><br>
    <H1><center>Specified banking type<br />&quot;<?php print $BankingType; ?>&quot;<br />is not supported</center></H1>
  </BODY>
</HTML>

