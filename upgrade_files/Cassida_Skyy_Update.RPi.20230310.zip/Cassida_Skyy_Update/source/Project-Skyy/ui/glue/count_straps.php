<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/xml");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems (TODO:  do I still need this?)
?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE count SYSTEM "count.dtd">
<count>
<?php

$Entity = '';
$CountDate = '';

// strapped bills
$strap1 = '0';
$strap2 = '0';
$strap5 = '0';
$strap10 = '0';
$strap20 = '0';
$strap50 = '0';
$strap100 = '0';

// per-denom strap quantities

  $Solution = skyyreq("count-entity");
  eval($Solution);

  $Solution = skyyreq("result-strap");
  eval($Solution);
?>

<entity><?php print $Entity;?></entity>
<date><?php print $CountDate;?></date>
<strap><type>1</type><batch>30</batch><qty><?php print $strap1;?></qty></strap>
<strap><type>5</type><batch>20</batch><qty><?php print $strap5;?></qty></strap>
<strap><type>10</type><batch>20</batch><qty><?php print $strap10;?></qty></strap>
<strap><type>20</type><batch>10</batch><qty><?php print $strap20;?></qty></strap>

</count>

