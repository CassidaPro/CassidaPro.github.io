<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  header("Content-type: text/plain; charset=UTF-8");

  $Semprini = isset($_GET) && isset($_GET["Semprini"]) ? $_GET["Semprini"] : "";

  if($Semprini == "1")
  {
    print skyyreq("ssh-enable" );
  }
  else
  {
    print skyyreq("ssh-disable" );
  }

?>

