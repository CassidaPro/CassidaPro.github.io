<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  // see if I need to authenticate
  $auth = ltrim(rtrim(skyyreq("fobkey-auth-required-count")));

  if(!strlen($auth))
  {
?>
        <HTML>
          <HEAD>
            <TITLE>re-direct</TITLE>
            <meta http-equiv="refresh" content="15;url=/index.php">
<?php set_inbetween_style(); ?>
          </HEAD>
          <BODY>
            <br><br>
            <center>
              <H1>
                Internal Error (no auth)
              </H1>
              <span style="font-size:22px">
                Server Not Running (please re-start system)
              </span>
            </center>
          </BODY>
        </HTML>
<?php
        exit;
  }
  else if($auth > 0)
  {
    // for now, ALWAYS re-authenticate
//    if(is_authenticated(true) != "OK")
    {
      $authenticate = do_getvar("authenticate","");

      if($authenticate != "Y")
      {
        authenticate_prompt("/glue/count_register.php?authenticate=Y", true);
      }
      else if(do_authenticate($Origin, true) == "OK")
      {
?>
        <HTML>
          <HEAD>
            <TITLE>Authenticated</TITLE>
            <meta http-equiv="refresh" content="0.5;url=/entity-number.php?class=3&multi=1">
<?php set_inbetween_style(); ?>
          </HEAD>
          <BODY>
            <center>
              <br><br>
              <H1>Authenticated</H1>
            </center>
          </BODY>
        </HTML>
<?php
      }
      else // authentication failed
      {
        header("HTTP/1.0 302 Moved Temporarily");
        header("Location: /");
      }

      exit;
    }
  }
  else
  {
    skyyreq("fobkey-deauth");
  }

  // essentially this activates the count Till process for multple Till counts

  header("HTTP/1.0 302 Moved Temporarily");
  header("Location: /entity-number.php?class=3&multi=1");

?>

