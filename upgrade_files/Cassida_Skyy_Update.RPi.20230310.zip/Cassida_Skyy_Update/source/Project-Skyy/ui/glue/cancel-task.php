<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php"; // things common to all

  $doohickey=do_getvar("doohickey", "");

  if($doohickey=="")
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="0.2;url=/glue/cancel-task.php?doohickey=Y">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY><br><br><br><br><H1><center>Cancel Running Task</center></H1>
    </BODY>
    </HTML>
<?php
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /tasks.php");

    skyyreq("complete");
  }
?>

