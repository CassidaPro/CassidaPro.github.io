<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  header("Content-type: text/plain; charset=UTF-8");

  // default mode is 1
  $the_mode = empty($_GET) ? 1 : empty($_GET["mode"]) ? 1 : $_GET["mode"];

  // this is really asynchronous, may not need a glue page
  print skyyreq("zeus-mode/" . $the_mode );
?>

