<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  // TODO:  consider folding this into /adhoc-count-notes.php

  header("HTTP/1.0 302 Moved Temporarily");
  header("Location: /adhoc-count-notes.php");

  skyyreq("count-zeus");
?>

