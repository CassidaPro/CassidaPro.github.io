<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  $video_list="/home/pi/Videos/zc4_daily.mp4";

  header("HTTP/1.0 302 Moved Temporarily");
  header("Location: /cleaning.php");

  // TODO:  validate '$complete', as it can only be 'safe' 'drawer' or 'register'

  shell_exec( "/usr/bin/sudo /home/pi/bin/play-video.sh " . $video_list);

?>

