<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

    $xx = rtrim(ltrim(skyyreq("printer-reset" )));
    if($xx != "OK")
    {
      header("HTTP/1.0 500 Server Error");
?>
      <HTML>
        <HEAD>
          <TITLE>Server Error</TITLE>
          <meta http-equiv="refresh" content="10;url=/maintenance.php">
          <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
          <link rel="shortcut icon" href="../img/favicon.ico">
          <style>
<?php
  set_ideal_font_height();
?>
          </style>
        </HEAD>
        <BODY>
          <H1><center>PRINTER ERROR</center></H1>
          <br><br><br>
          <H4>
            <center>
              Error resetting printer<br>
              <?php print $xx; ?><br>
              <br>
              Screen RESET in 10 seconds...
            </center>
          </H3>
          <br>
        </BODY>
      </HTML>
<?php
    }
    else
    {
?>
      <HTML>
        <HEAD>
          <TITLE>Printer Reset</TITLE>
          <meta http-equiv="refresh" content="10;url=/maintenance.php">
          <link href="../css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
          <link rel="shortcut icon" href="../img/favicon.ico">
          <style>
<?php
  set_ideal_font_height();
?>
          </style>
        </HEAD>
        <BODY>
          <H1><center>PRINTER RESET SENT</center></H1>
          <br><br><br>
          <H4>
            <center>
              Please check the printer for a printout indicating a successful reset.<br>
              <br>
              For additional assistance, contact Cassida Customer Support.<br>
            </center>
          </H4>
          <br>
        </BODY>
      </HTML>
<?php
    }
?>

