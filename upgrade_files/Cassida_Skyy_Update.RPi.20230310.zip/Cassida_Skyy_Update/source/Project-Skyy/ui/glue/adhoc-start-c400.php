<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $Equipment = coin_counter_equipment();

  header("HTTP/1.0 302 Moved Temporarily");
  header("Location: /adhoc-count-coins.php");

  if($Equipment == "C300")
    skyyreq("count-c300");
  else if(coin_counter_is_recycler($Equipment))
    skyyreq("count-coin-recycler");
  else
    skyyreq("count-c400");
?>

