<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  if(isset($_POST) && !empty($_POST)) // post transaction - set the date
  {
    $date = empty($_POST) || empty($_POST["date"]) ? "" : $_POST["date"];
//    extract($_POST,  EXTR_OVERWRITE);
?>
    <HTML>
      <HEAD>
        <TITLE>re-direct</TITLE>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
        <meta http-equiv="refresh" content="0.5;url=/glue/set-date.php?date=<?php print $date; ?>">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br><br><br>
        <H1 style="position:relative;left:300px;width:480px">
          Initializing<span id=dots></span>
        </H1>
        <center>
          <span style="font-size:22px;">
            <b>
              Date of Record:&nbsp;&nbsp;
              <?php print $date; ?>
            </b>
          </span>
        </center>
      <script>
        function DoDots()
        {
          var xx=document.getElementById("dots");
          if(xx)
          {
            xx.innerHTML = xx.innerHTML + ".";
          }
        }
        setInterval(DoDots,500);
      </script>
      </BODY>
    </HTML>
<?php
    exit;
  }

  $date = empty($_GET) || empty($_GET["date"]) ? "" : $_GET["date"];

  print skyyreq("date/" . $date );

  // if setting the date causes a reminder to show up, I need to invoke the reminder page.
  // Otherwiwe, invoke 'tasks.php'.  So simple!

  $num_reminders=0;

  $rval = skyyreq("reminders");
  eval($rval);

  header("HTTP/1.0 302 Moved Temporarily");

  if($num_reminders > 0)
    header("Location: /maintenance-prompt.php?code=" . $reminder0);
  else
    header("Location: /tasks.php");

?>

