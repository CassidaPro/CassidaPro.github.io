<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  // This should happen very fast.  Assume it works.
  // TODO:  do I need some kind of feedback?  Probably not.

  include "common_utils.php";

  $Equipment = coin_counter_equipment();

  if($Equipment == "C300")
    skyyreq("stop-c300");
  else if(coin_counter_is_recycler($Equipment))
  {
//    skyyreq("stop-recycler");
  }
  else
    skyyreq("stop-c400");

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/plain");

?>
OK


