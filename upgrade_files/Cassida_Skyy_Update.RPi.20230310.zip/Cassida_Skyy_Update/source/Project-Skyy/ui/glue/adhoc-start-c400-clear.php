<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  // see if I made a mistake going here by displaying a web page first
  // and continuing forward if the user presses 'NEXT', 'BACK' going
  // to wherever this came from

  include "common_utils.php";

  $parseconf = load_parseconf();

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Baggies = do_getconf($parseconf,"terms",'Baggies','Baggies');

  $Equipment = coin_counter_equipment();

  $doohickey=do_getvar("doohickey", "");

  if($doohickey=="Y")
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: /adhoc-count-coins.php");

    // doing a clear first - this takes 5+ seconds
    if($Equipment == "C300")
    {
      skyyreq("clear-c300");

      skyyreq("count-c300");
    }
    else if(coin_counter_is_recycler($Equipment))
    {
      skyyreq("clear-recycler");

      skyyreq("count-coin-recycler");
    }
    else
    {
      skyyreq("clear-c400");

      skyyreq("count-c400");
    }
    exit;
  }
  else if($doohickey=="N")
  {
?>
      <HTML><HEAD><TITLE>Clearing and Initializing</TITLE>
      <meta http-equiv="refresh" content="0.2;url=/glue/adhoc-start-c400-clear.php?doohickey=Y">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br><br><br>
        <H1><center>Clearing and Initializing <?php if(substr($Equipment,0,4)=="C400") print "C400"; else print $Equipment; ?></H1>
      </BODY></HTML>
<?php
    exit;
  }

  // where 'back' will lead me
  $back = empty($_GET['back'])
        ?  empty($_SERVER['HTTP_REFERER']) ? "/index.php" : $_SERVER['HTTP_REFERER']
        : $_GET['back'];

  // pressing 'next' on the form will proceed by doing a GET with doohickey=Y
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title><?php print $Equipment; ?> - Count <?php print $Coins; ?></title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->

    <style>
<?php
  set_ideal_font_height();
?>
      .off-button
      {
        /*background-color: #645eff !important;
        color:#ffffff;*/
        position: absolute;
        right: 8px;
        top: 8px;
        height: 42px;
      }

      .btn-shadow
      {
        box-shadow: 0 4px 4px 0 rgba(0, 0, 0, .14), 0 6px 2px -2px rgba(0, 0, 0, .2), 0 2px 10px 0 rgba(0, 0, 0, .12) !important;
      }
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">
          <?php if(substr($Equipment,0,4)=="C400") print "C400"; else print $Equipment; ?> Count <?php print $Coins; ?>
        </a>
        <div class="area">COUNT</div>
      </div>
    </nav>
    <br/>
    <center style="all:revert">
      <table style="all:revert;width:85%;border:0">
        <tr> <!-- style="all:revert;margin:0 20 0 0px;line-height:28px;border:0"-->
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:none;padding:0;margin:0;margin-left:-0.83rem">
                <b>Please confirm the desired action:</b>
              </LI>
              <LI style="list-style-type:disc;margin:0.62rem 0 0 0px">
                Proceeding will clear the current count on the <?php if(substr($Equipment,0,4)=="C400") print "C400"; else print $Equipment; ?> for batch purposes</LI>
              <LI style="list-style-type:disc;margin:0.62rem 0 0 0px">
                Ensure all <?php print strtolower($Baggies); ?>/bins are empty</LI>
              <LI style="list-style-type:disc;margin:0.62rem 0 0 0px">
                Press 'Next' to continue, 'Back' to return</LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>

    <form id=none method=GET></form>
    <form id=doohickey method=GET><input type=hidden name=doohickey style="visibility:hidden" value="N"></input></form>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:0.75rem;left:0px">
      <button type=submit form=none formaction=<?php print '"' . $back . '"';?> class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">BACK</span>
      </button><br/>
    </div>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:0.75rem;right:0.5rem">
      <button type=submit form=doohickey formaction="/glue/adhoc-start-c400-clear.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">NEXT</span>
      </button><br/>
    </div>

    <script src="/js/UserFeedback.js"></script>

  </body>
</html>

