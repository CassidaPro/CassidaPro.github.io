<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/plain");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems
  header("Expires: 0");
  header("Cache-control: none");

  $thingy = skyyreq("identify" );
  $thingy2 = skyyreq("copyright" );

  print $thingy2 . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" . $thingy;
?>
