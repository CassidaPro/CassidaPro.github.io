<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  // NOTE:  must put XML and doctype header up front

?>
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE c400 SYSTEM "c400.dtd">
<?php

  $Equipment = coin_counter_equipment();

  header("HTTP/1.0 200 OK");
  header("Content-Type: text/xml");
  header("Access-Control-Allow-Origin: *"); // should prevent CORS problems
  header("Expires: 0");
  header("Cache-control: none");

?>
<c400>
<?php
$Entity = '';
$CountDate = '';
$CountTick = '0';
$StatusCode = '31';
$SubStatusCode = '0';
$StatusText = 'Server error; please restart system';
$Batch = '';
$BatchStr = '';
$count1c = -1;
$count5c = -1;
$count10c = -1;
$count25c = -1;
$count100c = -1;

  $thingy = skyyreq("count-entity" );
  eval($thingy);

  if($Equipment == "C300")
    $thingy = skyyreq("status-c300" );
  else if(coin_counter_is_recycler($Equipment))
    $thingy = skyyreq("status-recycler" );
  else
    $thingy = skyyreq("status-c400" );

  $volume='-1'; // initialize this first
  eval($thingy);

// enable this to test 'batch' XML without C400 actually doing a batch
//$Batch = '99';
//$BatchStr = 'redballoons';

  // generate XML for consumption by UI

  print "<entity>" . $Entity . "</entity>\r\n";
  print "<date>" . $CountDate . "</date>\r\n";
  print "<tick>" . $CountTick . "</tick>\r\n";

  print "<status><code>" . $StatusCode . "</code><subcode>" . $SubStatusCode . "</subcode>";
  print "<text>" . $StatusText . "</text></status>\r\n";

  if(strlen($Batch) > 0)
  {
    print "<batch><denom>" . $Batch . "</denom>";
    print "<text>" . $BatchStr . "</text></batch>\r\n";
  }

  // some coin counters also have coin count status

  if(coin_counter_is_recycler($Equipment) &&
     $count1 >= 0 && $count5 >= 0 && $count10 >= 0 && $count25 >= 0 && $count100 >= 0)
  {
    print "<coin><type>1</type><qty>" . $count1c . "</qty></coin>\r\n";
    print "<coin><type>5</type><qty>" . $count5c . "</qty></coin>\r\n";
    print "<coin><type>10</type><qty>" . $count10c . "</qty></coin>\r\n";
    print "<coin><type>25</type><qty>" . $count25c . "</qty></coin>\r\n";
    print "<coin><type>100</type><qty>" . $count100c . "</qty></coin>\r\n";
    print "<volume>" . $volume . "</volume>\r\n";
  }


?>
</c400>

