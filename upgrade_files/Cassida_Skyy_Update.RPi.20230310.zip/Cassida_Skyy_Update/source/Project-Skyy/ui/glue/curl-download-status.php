<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "config_utils.php";

  $statz = ltrim(rtrim(shell_exec("/bin/ps ax | /bin/grep curl | /bin/grep -v grep")));
  $outout = ltrim(rtrim(shell_exec("/bin/sed 's/\\r/\\n/g' < " . get_upgrade_files_path() . "out.out | /usr/bin/tail -n 1 | awk '{ print $1; }'")));

//  print "hello\n" . $statz . "\n" . $outout . "\n\n";

  if(strlen($statz) == 0)
  {
    if($outout == "100")
      print $outout . "\n";
    else
    {
      // intermittent condition or file did not download?
      sleep(1); // 1 sec pause

      shell_exec("/bin/sync"); // sync up file

      $outout = ltrim(rtrim(shell_exec("/bin/sed 's/\\r/\\n/g' < " . get_upgrade_files_path() . "out.out | /usr/bin/tail -n 1 | awk '{ print $1; }'")));
      if($outout == "100")
        print $outout . "\n"; // ok it finished
      else
      {
        print "-1\n"; // error
//        print "** '" . $statz . "' ** '" . $outout . "' **\n";
      }
    }
  }
  else if(strlen($outout) > 0)
  {
    print $outout . "\n";
  }
  else
  {
    print "-1\n";
//    print "** '" . $statz . "' ** '" . $outout . "' **\n";
  }
?>
