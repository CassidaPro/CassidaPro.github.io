<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $doohickey = !empty($_GET) && !empty($_GET["doohickey"]) ? $_GET["doohickey"] : "";
  $class     = !empty($_GET) && !empty($_GET["class"]) ? $_GET["class"] : "";
  $ordinal   = !empty($_GET) && !empty($_GET["ordinal"]) ? $_GET["ordinal"] : "";
  $pull      = !empty($_GET) && !empty($_GET["pull"]) ? $_GET["pull"] : "N";

  $multi     = do_getvar("multi", "0");

  $parseconf = load_parseconf();

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Coin = make_singular($Coins);

  // this is where things get fun.  First of all, if 'ordinal' is blank, I'll need to know
  // if the class has multiple vessels.  If it does, I need to prompt for which one.
  //
  // Once I get a class with only one ordinal, or a class and a specific ordinal, I can
  // begin the process of counting for it, using the specified order in the class

  if($ordinal == "") // ordinal not specified
  {
    $thing = skyyreq("class-entity/" . $class);

    eval($thing); // todo, make this safer, see tasks.php
    // gives me $Class, $Name, and $NumEntity - '$class' and '$Class' should match, sanity check

    if($Class != $class || $NumEntity == 0) // not valid
    {
?>
      <HTML><HEAD><TITLE>ERROR</TITLE>
      <meta http-equiv="refresh" content="5;url=/tasks.php">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY><br><br><br><br>
<?php if(strlen($thing) == 0) // no response from server
      {
?>
        <H1><center>No response from server<br>You may need to restart the system</center></H1>
<?php
      }
      else
      {
?>
        <H1><center>Class <?php print $Name . "(" . $class . ")" ; ?> has no vessels</center></H1>
        <?php print "<br>" . $thing . "<br>\n"; ?>
<?php
      }
?>
      </BODY>
      </HTML>
<?php
    }
    else if($NumEntity > 0)
    {
      if($HasPulls > 0) // NOTE:  single register that has a pull will go here
      {
        header("HTTP/1.0 302 Moved Temporarily");
        header("Location: /tills-pulls-count.php?class=" . $class);
      }
      else if($NumEntity > 1)
      {
        header("HTTP/1.0 302 Moved Temporarily");
        header("Location: /entity-number.php?class=" . $class);
      }
      else
      {
        header("HTTP/1.0 302 Moved Temporarily");
        header("Location: /glue/initiate-count-class.php?ordinal=1&class=" . $class);

        // re-invoke with ordinal=1
      }
    }
    else // should never happen
    {
      header("HTTP/1.0 302 Moved Temporarily");
      header("Location: /tasks.php"); // go back
    }

    exit;
  }

  $thing = skyyreq("class-entity/" . $class . "/" . $ordinal);

  eval($thing); // todo, make this safer, see tasks.php
  // gives me $Class, $Ordinal, $ClassName, $Entity, $EntityNum

  if($multi != 0)
  {
    $EntityNum = $EntityNum | register_multi_bit_flag()
               | register_multi_timestamp();
  }
  else if($pull == 'Y') // it is a pull
  {
    $EntityNum = $EntityNum | register_pull_bit_flag(); // for now, this is how it is done
//    print $EntityNum;
//    exit;
  }

//  if($multi != 0 && $doohickey=="Y") // meaning count started and I have already auth'd if needed
//  {
//    skyyreq("fobkey-deauth"); // do this right after creating the count
//  }

  if($doohickey == "")
  {
    $thing = skyyreq("count-entity/" . $EntityNum);

    if(strtoupper(substr($thing,0,5)) == "ERROR")
    {
?>
      <HTML><HEAD><TITLE>ERROR</TITLE>
      <meta http-equiv="refresh"
            content="5;url=/tasks.php" >
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY><br><br><br><br><H1><center>ERROR:  NO TASK<br><?php print $Entity; ?></center></H1>
      </BODY>
      </HTML>
<?php
    }
    else
    {
      // TODO:  check return, make sure it works
?>
      <HTML><HEAD><TITLE>re-direct</TITLE>
      <meta http-equiv="refresh"
            content="0.1;url=/glue/initiate-count-class.php?doohickey=Y&class=<?php
                print urlencode($class) . "&ordinal=" . urlencode($ordinal); ?>" >
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY><br><br><br><br><H1><center>Initiate Count <?php print $Entity; ?></center></H1>
      </BODY>
      </HTML>
<?php
    }
    exit;
  }


  // OK find out what I'm counting, and go there
  $thing = skyyreq("count-entity-step" );
  eval($thing); // see skyy.c /count-entity-step for vars it assigns

  header("HTTP/1.0 302 Moved Temporarily");

  if(register_is_pull($EntityNum))
  {
    header("Location: /count-notes.php"); // a pull always goes here
  }
  else if(coin_counter_is_recycler($CoinCounterEquipment)
          && $CoinCountEnabled != 0
          && $CountStep != "coins" // if the first step is 'coins' it's no longer background
          && $CountStep != "" // 'no step' means go directly to the 'count summary' or 'register summary' page
          && $AutoStart != 0)
  {
    skyyreq("count-coin-background-recycler"); // initiate a backgr0und coin count

?>
      <HTML>
        <HEAD>
          <TITLE>Background Coin Count</TITLE>
<?php

//    print '        <meta http-equiv="refresh" content=';

    if($CountStep == "straps")
    {
      $Redirect = "/count-straps.php";
    }
    else if($CountStep == "rolls")
    {
      $Redirect = "/count-rolls.php";
    }
    else if($CountStep == "notes")
    {
      $Redirect = "/count-notes.php";
    }
    else
    {
      // should not happen, but...
      if($Class == 3) // tills
        $Redirect = "/register-summary.php";
      else
        $Redirect = "/count-summary.php";
    }

//    print '"15;url=';
//    print $Redirect;
//    print '"';
//    print ">\n";

?>
        <!-- CSS  -->
        <link href="/css/style.css" type="text/css" rel="stylesheet"/>
        <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
        <link rel="shortcut icon" href="/img/favicon.ico">
        <!-- CSS  -->
        <style>
<?php
  set_ideal_font_height();
?>
          .message-thing
          {
            color:#000000;/*#585858 works for bold font*/
            font-size: 1.17em; /*28px*/
            font-weight:500; /* normal - 700 is bold */
            position:absolute;
            padding-left: 0.35em; /*10px*/
            padding-top: 0px;
            padding-bottom: 0px;
            height: 2.28em; /*64px;*/
            bottom: 1.71em; /*48px*/
            width: 15.7em /*440px*/
            left: 0.42em; /*12px*/
            line-height:120%;
            vertical-align:bottom;
            text-align:left;
          }
        </style>
      </HEAD>
      <body>
        <nav class="secondary-fill lighten-1" role="navigation">
          <div class="nav-wrapper container">
          <a id="logo-container" href="#" class="brand-logo titlebar">Count <?php print $Coins; ?> <img src="/img/count-coins.svg"></a>
            <div id="entity" class="area"><?php print strtoupper($Entity); ?></div>
          </div>
        </nav>

        <div class="container">
          <div class="section">
            <div class="row center">

              <img src="/img/srb-system-recycler.png"
                   width=<?php print round(cached_font_size() * 320 / 24); ?>px
                   height=<?php print round(cached_font_size() * 240 / 24); ?>px>
              <p style="font-height:0.67rem;line-height:1em;padding:0;margin:0;text-align:center">
                Background <?php print $Coin; ?> Counting<br/>
                <span id=add_coin_message>Please add <?php print $Coins; ?> to the hopper</span>
              </p>
            </div>
          </div>
        </div>
        <div class="message-thing"><p id="messagething"></p></div>
        <form id=press_next action="<?php print $Redirect; ?>" method=GET>
          <input type=hidden style="visibility:hidden" name=clear_first value="N"></input>
          <div class="next-button" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
            <button id=start type=submit onClick="KillDoggy();KillKitty();;" class="btn waves-effect primary-fill btn-shadow">Next</button>
          </div>
        </form>
        <div id=coin_tray_warning
             style="visibility:hidden;display:none;position:absolute;right:6rem;top:10rem;width:20%;height:20%;z-order:99">
          <img height=<?php print round(cached_font_size() * 3); ?>px
               src="/img/coin_drawer_rotate_ccw.png"
               style="visibility:inherit" />
        </div>

      <script>

        var doggy = null;
        var kitty = null;
        var monitor = null;

        function KillDoggy()
        {
          if(doggy != null)
          {
            clearTimeout(doggy);
            doggy = null;
          }
        }

        function KillKitty()
        {
          if(kitty != null)
          {
            clearTimeout(kitty);
            kitty = null;
          }
        }

        function WatchDog()
        {
          KillDoggy(); // old yeller

          document.getElementById("messagething").innerHTML = "ERROR - server not responding";
        }

        function WatchCat()
        {
          KillDoggy(); // old yeller
          KillKitty();

          document.getElementById("press_next").submit(); // once i get coins, advance
        }

        function getC400Status()
        {
          // NOTE:  this glue page also works for C300 - it will check installed equipment
          var myRequest = new Request("/glue/status-c400.php");

          fetch(myRequest)
            .then(function(response)
                  {
                    myRequest = null;

                    if(!response.ok)
                    {
                      console.log("status-c400", response.status); // debug only (TODO: remove?)
                    }

                    return  response.text();
                  })
            .then(function(text)
                  {
                    // xx will be a DOM Parser type of object from which to parse XML
                    var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                    var entity = xx.getElementsByTagName("entity")[0].childNodes[0].nodeValue;
                    var the_date = xx.getElementsByTagName("date")[0];
                    var tick = xx.getElementsByTagName("tick")[0].childNodes[0].nodeValue;
                    var st = xx.getElementsByTagName("status")[0].children;
                    var status_code = "";
                    var status_text = "";
                    var today = "";

                    if(the_date && the_date.childNodes.length > 0)
                    {
                      today = the_date.childNodes[0].nodeValue
                    }
                    else
                    {
                      today = "unknown date";
                    }

                    for (var i1 = 0; i1 < st.length; i1++)
                    {
                      if(st[i1].nodeName == "code")
                        status_code = st[i1].childNodes[0].nodeValue;
                      else if(st[i1].nodeName == "text")
                        status_text = st[i1].childNodes[0].nodeValue;
                    }

                    if(status_code == 0) // checking for coin counter process even running
                    {
                      if(doggy == null)
                      {
                        doggy = setTimeout(WatchDog, 5000); // 5 secones to get a response
                      }
                    }
                    else
                    {
                      KillDoggy(); // bye bye old yeller

                      if(status_code == 30)
                      {
                        document.getElementById("coin_tray_warning").style.visibility = "visible";
                        document.getElementById("coin_tray_warning").style.display = "block";

                        document.getElementById("add_coin_message").style.visibility = "hidden";
                        document.getElementById("add_coin_message").style.display = "none";
                      }
                      else
                      {
                        document.getElementById("coin_tray_warning").style.visibility = "hidden";
                        document.getElementById("coin_tray_warning").style.display = "none";

                      }

                      if(status_code == 16)
                      {
                        document.getElementById("messagething").innerHTML = status_text;
                      }
                      else if(status_code == 19)
                      {
                        // we are waiting for coins

                        if(kitty == null)
                        {
                          kitty = setTimeout(WatchCat, 15000); // 15 secones to get a response
                        }

                        document.getElementById("add_coin_message").style.visibility = "visible";
                        document.getElementById("add_coin_message").style.display = "block";

                        document.getElementById("messagething").innerHTML = "Waiting for count start...";
                      }
                      else if(status_code == "22") // counting
                      {
                        document.getElementById("messagething").innerHTML = "Counting...";

                        if(monitor != null)
                        {
                          clearInterval(monitor);
                          monitor = null;
                        }

                        document.getElementById("press_next").submit(); // once i get coins, advance
                      }
                      else if(status_code == 30)
                      {
                        KillKitty();

                        document.getElementById("messagething").innerHTML = status_text;
                      }
                      else
                      {
                        document.getElementById("messagething").innerHTML = status_text;
                      }
                    }
                  });
        }

        monitor = setInterval(getC400Status, 500);

      </script>

      <script src="/js/UserFeedback.js"></script>

      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($CountStep == "straps")
  {
    header("Location: /count-straps.php");
  }
  else if($CountStep == "rolls")
  {
    header("Location: /count-rolls.php");
  }
  else if($CountStep == "notes")
  {
    header("Location: /count-notes.php");
  }
  else if($CountStep == "coins")
  {
    header("Location: /count-coins.php");
  }
  else if($CountStep == "")
  {
    // 'no step' means go directly to the 'count summary' or 'register summary' page

    if($Class == 3) // tills
      header("Location: /register-summary.php");
    else
      header("Location: /count-summary.php");
  }
  else
  {
    // just go back to tasks, for now
    header("Location: /tasks.php");
  }

  exit;
?>

