<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php"; // things common to all

  if ($_SERVER['REQUEST_METHOD'] == 'POST')
  {
    $next = do_postvar("next", "");

    $c1 = do_postvar("c1", "0");
    $c5 = do_postvar("c5", "0");
    $c10 = do_postvar("c10", "0");
    $c25 = do_postvar("c25", "0");
    $c50 = do_postvar("c50", "0");

//    extract($_POST, EXTR_OVERWRITE);

    if($next == '')
    {
      header("HTTP/1.0 500 Server Error");
    }
    else
    {
      header("HTTP/1.0 302 Moved Temporarily");
      header("Location: " . $next);
      header("Expires: 0");
      //header("Location: /counter.html");

      skyyreq("roll-quantity/1/" . $c1);
      skyyreq("roll-quantity/5/" . $c5);
      skyyreq("roll-quantity/10/" . $c10);
      skyyreq("roll-quantity/25/" . $c25);
      skyyreq("roll-quantity/50/" . $c50);
    }
  }
  else
  {
      header("HTTP/1.0 500 Server Error");
  }
?>

