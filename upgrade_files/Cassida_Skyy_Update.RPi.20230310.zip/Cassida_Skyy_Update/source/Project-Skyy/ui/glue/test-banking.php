<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */


  print shell_exec("/home/pi/bin/post_transactions.sh test");
?>

