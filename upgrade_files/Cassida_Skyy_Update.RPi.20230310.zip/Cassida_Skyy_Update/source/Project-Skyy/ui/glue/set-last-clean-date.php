<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include "common_utils.php";

  $back=do_getvar("back","/");

  skyyreq("set-last-clean-date");

  eval(skyyreq("task-status"));

  $text = "            WEEKLY CLEANING\n"
        . "            ====== ========\n"
        . "\n"
        . "\n"
        . "   Cleaning Completed on " . $LastCleanDate . "\n"
        . "\n"
        . "\n"
        . "\n";
//  if($CustomerMod == 2) // Academy
  {
    $text = $text
        . " Signature: _________________________\n"
        . "\n"
        . "\n"
        . "\n"
        . "Print Name: _________________________\n";
  }

  $text = $text
        . "\n";

  printer_output($text);

  if($back == "test")
  {
    print $text;
  }
  else
  {
    header("HTTP/1.0 302 Moved Temporarily");
    header("Location: " . $back);
  }

?>

