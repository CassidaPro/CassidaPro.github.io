<?php
/*          Copyright 2019-2023 by Cassida          */
/* Use only in accordance with the supplied license */

  include 'glue/utility_functions.php';

  // see https://www.php.net/manual/en/function.parse-ini-file.php
  //
  // can store individual network paramas as INI file

  $save = my_get_var("save", "");

  if($save == "") // that is, NOT saving
  {
    // TODO:  do I even need to bother with this???
    $dhcp=my_get_var("dhcp","on");
    $fixed_ip=my_get_var("fixed_ip");
    $subnet=my_get_var("subnet");
    $dns=my_get_var("dns");
    $gateway=my_get_var("gateway");

    // IPv6 support?
    $dhcp6=my_get_var("dhcp6","on");
    $fixed_ip6=my_get_var("fixed_ip6");
    $subnet6=my_get_var("subnet6");
    $dns6=my_get_var("dns6");
    $gateway6=my_get_var("gateway6");

    $ethernet_enabled=my_get_var("ethernet_enabled");

    if(strlen($ethernet_enabled) == 0) // TODO:  do I even need this test?  shouldn't I just ALWAYS do this?
    {
      // next, parse out the 'ap_wlan' config file with IP addresses
      $tval=shell_exec("grep eth0 /var/cache/skyy/ethernet");
      if(strlen($tval) > 0)
      {
        if(substr($tval,0,1)=='#') // commented out
          $ethernet_enabled="off";
        else
          $ethernet_enabled="on";

        $dhcp=shell_exec("grep dhcp /var/cache/skyy/ethernet | awk '{print $2;}'");

        if(strlen($dhcp) == 0)
          $dhcp = "off";
        else
          $dhcp = "on";

        $fixed_ip=ltrim(rtrim(shell_exec("grep address /var/cache/skyy/ethernet | awk '{print $2;}'")));
        $gateway=ltrim(rtrim(shell_exec("grep gateway /var/cache/skyy/ethernet | awk '{print $2;}'")));
        $subnet=ltrim(rtrim(shell_exec("grep netmask /var/cache/skyy/ethernet | awk '{print $2;}'")));
        # dns information is stored as a comment
        $dns=ltrim(rtrim(shell_exec("grep '$#' | grep nameserver /var/cache/skyy/ethernet | awk '{print $3;}'")));

        if(strlen($subnet) == 0 && strpos($fixed_ip, "/") !== false)
        {
          $subnet = strstr($fixed_ip, "/");
          $fixed_ip = strstr($fixed_ip, "/", true); // the part before the '/'
        }
      }
      else
      {
        $ethernet_enabled="off";
      }
    }
?>
<!DOCTYPE html5>
<?php html_tag_with_lingo(); ?>
  <HEAD>
    <!-- adjust for device width, particularly phones -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <TITLE>
      Split Recycler - Ethernet
    </TITLE>
    <link href="/css/networking.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="/img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
    </style>
    <script>
      function DoClickDHCP()
      {
        if(document.getElementById("dhcp").checked == true)
        {
          document.getElementById("fixed_ip_table").style.visibility = "hidden";
        }
        else
        {
          document.getElementById("fixed_ip_table").style.visibility = "visible";
        }
      }
      function doClickKB(strID)
      {
        do_vkey_single(strID, null);
      }
    </script>
  </HEAD>
  <BODY <?php print $BodyTagDefs; ?> >
  <center>
    <H1 style="margin:0px;padding=0px;font-size:1.5rem">
      Split Recycler - Ethernet Configuration
    </H1>
    <H4 id=clock style="font-size:1rem;margin-top:8px;margin-bottom:0.67rem;padding=0px;"><?php print shell_exec("/bin/date"); ?></H4>
  <noscript>
    <font size="+4">WARNING - this web page requires script in order to work properly</font><br>
  </noscript>
    <table width=95%><tr><td align=left>
      <form id=normal mode=GET>
        <input type=hidden name=save value="Y" style="visibility:hidden" />
        <center>
        <table>
          <tr>
            <td style="valign:top;text-align:center;font-size:0.75rem;">
              <input id=ethernet_enabled name=ethernet_enabled type=checkbox <?php if($ethernet_enabled == "on") print "checked"; ?> >
                Enable Ethernet
              </input>
            </td>
          </tr>
          <tr align=left style="vertical-align: middle;font-size:0.75rem;">
            <td align=left style="vertical-align: middle;">
              <span style="white-space: nowrap;">
                <input id=dhcp name=dhcp type=checkbox <?php if($dhcp == "on") print "checked"; ?>
                 onClick="DoClickDHCP();">Use DHCP</input>
              </span>
            </td>
          </tr>
        </table>
        <br>
        <table>
          <tr>
            <td>
              <table id=fixed_ip_table style="visibility:hidden">
                <tr style="font-size:0.75rem">
                  <td align=right>
                    IP Address:
                  </td>
                  <td>
                    <input name=fixed_ip id=fixed_ip size=20 style="font-size:0.67rem"
                           value=<?php print '"' . preg_replace('/"/', '""', $fixed_ip) . '"'; ?>/>
                    <a onClick='doClickKB("fixed_ip");'><img src="/img/keyboard.png" width=36 height=36 style="vertical-align:middle"></a>
                  </td>
                </tr>
                <tr style="font-size:0.75rem">
                  <td align=right>
                    Subnet Mask:
                  </td>
                  <td>
                    <input name=subnet id=subnet size=20 style="font-size:0.67rem"
                           value=<?php print '"' . preg_replace('/"/', '""', $subnet) . '"'; ?>/>
                    <a onClick='doClickKB("subnet");'><img src="/img/keyboard.png" width=36 height=36 style="vertical-align:middle"></a>
                  </td>
                </tr>
                <tr style="font-size:0.75rem">
                  <td align=right>
                    DNS Server:
                  </td>
                  <td>
                    <input name=dns id=dns size=20 style="font-size:0.67rem"
                           value=<?php print '"' . preg_replace('/"/', '""', $dns) . '"'; ?>/>
                    <a onClick='doClickKB("dns");'><img src="/img/keyboard.png" width=36 height=36 style="vertical-align:middle"></a>
                  </td>
                </tr>
                <tr style="font-size:0.75rem">
                  <td align=right>
                    Gateway:
                  </td>
                  <td>
                    <input name=gateway id=gateway size=20 style="font-size:0.67rem"
                           value=<?php print '"' . preg_replace('/"/', '""', $gateway) . '"'; ?>/>
                    <a onClick='doClickKB("gateway");'><img src="/img/keyboard.png" width=36 height=36 style="vertical-align:middle"></a>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
        </table></center>
      </form>
    </td></tr></table>
  </center>

  <form id=blank mode=GET></form>
  <center style="position:absolute;margin:0;padding:0;left:0;width:100%;bottom:0.8rem">
    <table width=75%>
      <tr>
        <td width=25% align=center>
          &nbsp;
        </td>
        <td width=25% align=center>
          <button form="normal" formaction="/ethernet-client.php" type=submit >
            Save
          </button>
        </td>
        <td width=25% align=center>
          <button form="blank" formaction="/networking.php" type=submit >
            Back
          </button>
        </td>
        <td width=25% align=center>
          &nbsp;
        </td>
      </tr>
    </table>
  </center>

<?php

  include "glue/virtual_keyboard.php";

?>

  <script>
/*
    function DoTimeUpdate()
    {
      var myRequest = new Request("/glue/get_system_date.php");

      fetch(myRequest)
        .then(function(response)
              {
                if (!response.ok)
                {
                  console.log("status", response.status);
                }
                return  response.text();
              })
        .then(function(text)
              {
                document.getElementById("clock").innerHTML = text;
              });
    }

    setInterval(DoTimeUpdate, 1000);
*/

    DoClickDHCP();

  </script>
  </BODY>
</HTML>
<?php
  }
  else if($save == "Y")
  {
    $dhcp=my_get_var("dhcp");
    $fixed_ip=my_get_var("fixed_ip");
    $subnet=my_get_var("subnet");
    $dns=my_get_var("dns");
    $gateway=my_get_var("gateway");

    // IPv6 support?
    $dhcp6=my_get_var("dhcp6");
    $fixed_ip6=my_get_var("fixed_ip6");
    $subnet6=my_get_var("subnet6");
    $dns6=my_get_var("dns6");
    $gateway6=my_get_var("gateway6");

    $ethernet_enabled=my_get_var("ethernet_enabled");


    if(strlen($fixed_ip) == 0)
    {
      $dhcp="on"; // default DHCP if no IP address
    }
    if(strlen($fixed_ip6) == 0)
    {
      $dhcp6="on"; // same for IPv6 [when supported]
    }


    if($dhcp == "on") // only if uniquely this
      $iface_string = "iface eth0 inet dhcp";
    else
      $iface_string = "iface eth0 inet static";

    $conf_out = "# generated by submit-ethernet-settings.php - do not edit\n";

    if($ethernet_enabled != "on")
    {
      $conf_out = $conf_out . "# " . $iface_string . "\n";
    }
    else
    {
      $conf_out = $conf_out . $iface_string . "\n";

      if($dhcp != "on")
      {
        if(substr($subnet, 0, 1) == '/')
        {
          $conf_out = $conf_out . "    address " . $fixed_ip . $subnet . "\n";
        }
        else
        {
          $conf_out = $conf_out . "    address " . $fixed_ip . "\n";
          $conf_out = $conf_out . "    netmask " . $subnet . "\n";
        }

        $conf_out = $conf_out . "    gateway " . $gateway . "\n";
        $conf_out = $conf_out . "# nameserver " . $dns . "\n";
      }

      $conf_out = $conf_out . "    metric 10\n\n";
    }

//    // IPv6 support?
//    $dhcp6;
//    $fixed_ip6;
//    $subnet6;
//    $dns6;
//    $gateway6;

    // next write this to the conf file
    $the_file = fopen("/var/cache/skyy/ethernet", "w");
    fwrite($the_file, $conf_out);
    fclose($the_file);
?>
    <!DOCTYPE html5>
    <HTML>
      <HEAD>
        <!-- adjust for device width, particularly phones -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="refresh" content="3;url='/networking.php'">
        <TITLE>Split Recycler - Save Ethernet Settings</TITLE>
        <STYLE>
<?php
    set_ideal_font_height();
?>
          @font-face
          {
           font-family: Lato;
           src: url(/fonts/lato-v15-latin-regular.woff);
          }
          html
          {
            font-family: 'Lato';
          }
          body
          {
            font-size: inherit;
            background-color: #e0e0e0;
            color: #8068ff;
          }
        </STYLE>
      </HEAD>
      <BODY <?php print $BodyTagDefs; ?>>
        <center>
          <H1 style="margin:0px;padding=0px;font-size:1.5rem">Split Recycler</H1>
          <H2 style="margin-top:-4px;margin-bottom:4px;padding=0px;font-size:1rem">Ethernet Configuration Saved</H2>
          <!--noscript><form mode=GET action="/"><button type="submit">OK</button></form></noscript-->
        </center>
      </body>
    </html>
<?php
    exit;
  }
?>

