<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";


  $next = empty($_GET) || empty($_GET["next"]) ? "" : $_GET["next"];

  $auto = empty($_GET) || empty($_GET["next"]) ? 'N'
        : (strlen($_GET["next"]) > 0 ? 'Y' : 'N'); // assume 'auto' for now if 'next' is not blank

  $StartItUp = empty($_GET) || empty($_GET["StartItUp"]) ? ''
             : $_GET["StartItUp"];

  $Equipment = coin_counter_equipment();

  if(coin_counter_is_recycler($Equipment))
  {
?>
    <HTML><HEAD><TITLE>Initializing C400</TITLE>
      <meta http-equiv="refresh" content="10;url=/">
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>BATCH not supported<br>for this device</center></H1>
      </BODY>
    </HTML>
<?php
      exit;
  }

  if($StartItUp != "Y" && $StartItUp != "YY")
  {
?>
    <HTML><HEAD><TITLE>Initializing C400</TITLE>
      <meta http-equiv="refresh" content="0.1;url=/c400-do-set-batch.php?StartItUp=Y<?php
          if(strlen($next) > 0)
            print "&next=" . urlencode($next);
          if(strlen($auto) > 0)
            print "&auto=" . urlencode($auto);
        ?>" >
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Initializing C400</center></H1>
      </BODY>
    </HTML>
<?php
      exit;
  }

  if($StartItUp == "Y" && ($Equipment == "C400" || $Equipment == "C400R"))
  {
    // maybe I am in the middle of changing it?
    skyyreq("reset");
?>
    <HTML><HEAD><TITLE>Initializing C400</TITLE>
      <meta http-equiv="refresh" content="0.1;url=/c400-do-set-batch.php?StartItUp=YY<?php
          if(strlen($next) > 0)
            print "&next=" . urlencode($next);
          if(strlen($auto) > 0)
            print "&auto=" . urlencode($auto);
        ?>" >
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Initializing C400 ...</center></H1>
      </BODY>
    </HTML>
<?php
      exit;
  }

  skyyreq("complete");
  skyyreq("c400-set-batch");
?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Coin Batch Continue</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
    .message-thing
    {
      color:#000000;/*#585858 works for bold font*/
      font-size: 1.17rem; /*28px*/
      font-weight:500; /* normal - 700 is bold */
      position:absolute;
      padding-left: 0.35em; /*10px*/
      padding-top: 0px;
      padding-bottom: 0px;
      height: 2.28em; /*64px;*/
      bottom: 2em; /*48px*/
      width: 15.7em /*440px*/
      left: 0.42em; /*12px*/
      line-height:110%;
      vertical-align:bottom;
      text-align:left;
    }
    </style>
  </head>
<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
    <a id="logo-container" href="#" class="brand-logo titlebar"><?php print make_singular($Coins); ?> Batch <img src="img/count-coins.svg"></a>
      <div id="entity" class="area"><?php print strtoupper(make_singular($Coins)); ?> BATCH</div>
    </div>
  </nav>

  <div class="container">
    <div class="section">
      <div class="row center">
<?php
  if(coin_counter_is_c300($Equipment))
  {
?>
        <img src="img/c300.png"
<?php
  }
//  else if(coin_counter_is_recycler($Equipment))
//  {
//    // probably will never do this, but...
//
//        <img src="img/srb-system-recycler.png"
//
//  }
  else if(coin_counter_is_c400r($Equipment))
  {
?>
        <img src="img/cs400r.png"
<?php
  }
  else // if(coin_counter_is_c400($Equipment))
  {
?>
        <img src="img/cs400.svg"
<?php
  }
?>
             width=<?php print round(cached_font_size() * 320 / 24); ?>px
             height=<?php print round(cached_font_size() * 240 / 24); ?>px>
      </div>

      <div class="message-thing"><p id="messagething"></p></div>
    </div>
  </div>
  <div class="next-button">
    <form id=the_form method=GET action="/glue/complete-c400-set-batch.php">
<?php
  if(strlen($next) > 0)
  {
    print '      <input type=hidden name=next value="' . $next . '" style="visibility:hidden" />';
  }
?>
      <button id=skip formaction="/glue/complete-c400-set-batch.php" class="waves-effect btn-flat primary-text">Skip</button>
<?php
  if($auto != 'Y')
  {
?>
      <button id=done formaction="/glue/complete-c400-set-batch.php" class="btn waves-effect primary-fill btn-shadow" disabled>DONE</button>
<?php
  }
?>
    </form>
  </div>


  <!--  Scripts-->
  <script src="/js/custom.js"></script>

  <script>

    function getStatus()
    {
        // NOTE:  this glue page also works for C300 - it will check installed equipment
        var myRequest = new Request("/glue/status-c400.php");

        fetch(myRequest)
          .then(function(response)
                {
                  myRequest = null;

                  if(!response.ok)
                  {
                    console.log("status-c400", response.status); // debug only (TODO: remove?)
                  }

                  return  response.text();
                })
          .then(function(text)
                {
                  // xx will be a DOM Parser type of object from which to parse XML
                  var xx = (new window.DOMParser()).parseFromString(text, "text/xml");
                  var tt = xx.getElementsByTagName("tick");
                  var ee = xx.getElementsByTagName("entity");

                  if(tt == null || tt[0] == null || tt[0].childNodes == null || tt[0].childNodes[0] == null ||
                     ee == null || ee[0] == null || ee[0].childNodes == null || ee[0].childNodes[0] == null)
                  {
                    document.getElementById("messagething").innerHTML = "Server not responding";
                    if(thing != null)
                    {
                      clearInterval(thing); // status codes no longer needed
                      thing = null;
                    }

                    tt = null;
                    ee = null;
                    return;
                  }

                  var tick = tt[0].childNodes[0].nodeValue;
                  var entity = ee[0].childNodes[0].nodeValue;
                  var the_date = xx.getElementsByTagName("date")[0];
                  var st = xx.getElementsByTagName("status")[0].children;
                  var status_code = "";
                  var status_text = "";
                  var today = "";

                  tt = null;
                  ee = null;

                  if(the_date && the_date.childNodes.length > 0)
                  {
                    today = the_date.childNodes[0].nodeValue
                  }
                  else
                  {
                    today = "unknown date";
                  }

                  for (var i1 = 0; i1 < st.length; i1++)
                  {
                    if(st[i1].nodeName == "code")
                      status_code = st[i1].childNodes[0].nodeValue;
                    else if(st[i1].nodeName == "text")
                      status_text = st[i1].childNodes[0].nodeValue;
                  }

                  if(status_code == "0")
                  {
                    document.getElementById("skip").disabled = true;
<?php
        if($auto != 'Y')
        {
?>
                    document.getElementById("done").disabled = false;
<?php
        }
?>
                    document.getElementById("messagething").innerHTML = "Complete";

<?php
        if($auto == 'Y')
        {
?>
                    document.forms["the_form"].submit();
<?php
        }
?>
                  }
                  else
                  {
                    // normal messages
                    document.getElementById("messagething").innerHTML = status_text;
                  }

                  xx = null;
                  entity = null;
                  the_date = null;
                  tick = null;
                  st = null;
                  status_code = null;
                  status_text = null;
                  today = null;
                });

    }




    function doFinished()
    {
<?php
  if(strlen($next) > 0)
  {
    print '      window.location.href="/glue/complete-c400-set-batch.php?next=' . urlencode($next) . '";';
  }
  else
  {
?>
      window.location.href="/glue/complete-c400-set-batch.php";
<?php
  } // end of php if block, not script function def (which is the next line)
?>
    }

    setInterval(getStatus,250); // once per second

  </script>

  <script src="/js/UserFeedback.js"></script>

</body>
</html>

