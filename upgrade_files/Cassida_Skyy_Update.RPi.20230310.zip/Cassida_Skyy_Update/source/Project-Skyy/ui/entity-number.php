<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include 'glue/config_utils.php';

  // on entry, pull=Y to count pulls.  'class' indicates the class number from the configuration

  // grab entity information among other things...

  $class = !empty($_GET) && !empty($_GET["class"]) ? $_GET["class"] : "";
  $pull = !empty($_GET) && !empty($_GET["pull"]) ? $_GET["pull"] : "N";
  $complete = !empty($_GET) && !empty($_GET["complete"]) ? $_GET["complete"] : "";

  // multi-count of tills
  $multi = do_getvar("multi","");


  $parseconf = load_parseconf();

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');
  $CoinsName   = do_getconf($parseconf,"terms",'Coins','Coins');
  $RollsName   = do_getconf($parseconf,"terms",'Rolls','Rolls');
  $Icon = do_getconf($parseconf,"icons",'Class' . $class, 'register.svg');

  $thing = skyyreq( "class-entity/" . $class);
  eval($thing); // todo, make this safer, see tasks.php
  // gives me $Class, $Name, $List, $HasPulls, and $NumEntity - '$class' and '$Class' should match, sanity check

  if($Class != $class || $NumEntity == 0) // not valid
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh" content="5;url=/tasks.php">
<?php set_inbetween_style(); ?>
    </HEAD>
    <BODY>
      <br><br>
      <H1>
        <center>
          Internal Error
        </center>
      </H1>
    </BODY>
    </HTML>
<?php
    exit;
  }

  if($complete == "Y")
  {
?>
    <HTML><HEAD><TITLE>re-direct</TITLE>
    <meta http-equiv="refresh"
          content=
<?php
    if(strlen($multi) > 0) // multi-count (adhoc tlll counting)
      print '"0.2;url=/entity-number.php?complete=YY&class=' . urlencode($class) . '"&multi=' . urlencode($multi) . '"';
    else
      print '"0.2;url=/entity-number.php?complete=YY&class=' . urlencode($class) . '"';
?>
    >
<?php set_inbetween_style(); ?>
    </HEAD>
      <BODY>
        <br><br>
        <H1>
          <center>
            All <?php print $Name; ?> Complete
          </center>
        </H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($complete == "YY")
  {
    skyyreq("complete-class"); // completes everything for the class

    if($Class == 3) // registers/tills
    {
      skyyreq("print-totals");   // this prints the register totals (for registers)
    }

    if($CustomerMod != 2 || ($class!="3" && $class!="1") /* || ($HasPulls && $pulls=="Y") */)
    {
      header("HTTP/1.0 302 Moved Temporarily");
      header("Location: /tasks.php");
    }
    else  // customer mod 2, display message to empty rolls and clear c400
    {
      skyyreq("clear-c400");   // this prints the register totals (for registers)
?>
      <HTML>
        <HEAD>
          <TITLE>re-direct</TITLE>

          <!-- CSS  -->
          <link href="/css/style.css" type="text/css" rel="stylesheet"/>
          <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
          <link rel="shortcut icon" href="/img/favicon.ico">

          <style>
<?php
      set_ideal_font_height();
?>
          </style>
        </HEAD>
        <BODY>
          <nav class="secondary-fill lighten-1" role="navigation">
            <div class="nav-wrapper container">
              <a id="logo-container" href="#" class="brand-logo titlebar">
                All <?php print $Name; ?> Complete<img src="<?php print '/img/' . $Icon; ?>">
              </a>
              <div class="area"><!-- style="font-size:0.83rem"-->
                &nbsp;
              </div>
            </div>
          </nav>
          <br>
          <H1 style="font-size:2.2rem;line-height:2.2rem">
            <center>
              Please remove all <?php print $CoinsName; ?><br />from Incomplete <?php print $RollsName; ?><br />
<?php
      if($class=="1")
      {
?>
              and place them in the Safe
<?php
      }
      else
      {
?>
              for Closing Count
<?php
      }
?>
            </center>
          </H1>
          <br />
          <br />
          <center>
            <div class="next-button" style="bottom:16px">
              <form>
                <button formaction="/tasks.php" class="btn waves-effect primary-fill btn-shadow">
                  CONTINUE
                </button>
              </form>
            </div>
        </BODY>
      </HTML>
<?php
    }

    exit;
  }

  // OK we've got multiple entities for this class, so show what I've got
  // and load up an array with the list...

  $Solution = skyyreq("entity-list/" . $class);
  $aL = explode("\n", $Solution);
  $aLL = [];
  $aList = [];

  foreach($aL as $ll) // build aLL array
  {
    $lll = ltrim(rtrim($ll));
    if(strlen($lll) > 0)
    {
      $vv = explode("\t", rtrim($lll));
      $jj = "0000000000" . $vv[0];
      $kk = substr($jj, strlen($jj) - 10, 10); // right-hand 10 chars
      $aLL[$kk] = $lll;
    }
  }

  ksort($aLL); // sort alphabetically by key with lead zeros
  $ii = 0; // starting index for 'aList' array.

  foreach($aLL as $ll)
  {
    $aList[$ii++] = $ll;
  }


  // TODO:  build a drop-down list table


?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title><?php print make_singular($Name); ?> Number</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">

    <style>
<?php
  set_ideal_font_height();
?>
      table, th, td, tdata, tr
      {
        border: 0px;
        padding: 0;
      }
<?php
  if($pull == "Y")
  {
    $CalcCardOverride="calc-card-override";
    $CalcButtonOverride="calc-button-override";
    $MDLCardOverride="mdl-card-override";
    $MDLButtonAccentOverride="mdl-button--accent-override";
  }
  else
  {
    $CalcCardOverride="";
    $CalcButtonOverride="";
    $MDLCardOverride="";
    $MDLButtonAccentOverride="";
  }

  if($pull == "Y") // it's a pull
  {
?>
      .mdl-button--raised
      {
        background: rgba(128, 128, 128, .2);
        box-shadow: 0 2px 2px 0 rgba(0, 0, 0, .14), 0 1px 1px -2px rgba(0, 0, 0, .2), 0 1px 5px 0 rgba(0, 0, 0, .12);
      }
<?php
  }
?>
    </style>

    <script>
      var output = "ordinal";

      function DoClick(key) // keypad click number key
      {
        var ww = document.getElementById(output);
        var strText = ww.value;

        console.log(output + ' ' + ww.id + ' ' + ww.value + ' ' + key);

        if(ww.id == "rv1")
        {
          var vv = Math.floor(strText * 10);

          console.log(vv);

          vv = (vv * 10 + Math.floor(key)) / 10;

          console.log(vv);

          ww.value = vv.toFixed(2);
        }
        else
        {
          ww.value = ww.value * 10 + Math.floor(key);
        }
      }

      function DoClickClr() // keyboard click clear
      {
        document.getElementById(output).value = '0';
      }

      function DoClickEntor() // keyboard click 'entor' which is like 'enter' but more epic
      {
        console.log('Entor');
      }


      function doSelChange()
      {
        var vv;
        vv = document.forms["selector"]["entitynum"].value;
        //document.getElementById("entitynum"),value;
        if(vv > 0)
        {
          document.forms["submitTheNumber"]["ordinal"].value = vv;
        }

        DoCheckValidNumber();
      }
    </script>

  </head>

<body>
  <nav class="secondary-fill lighten-1" role="navigation">
    <div class="nav-wrapper container">
    <!-- TODO:  change icon based on class -->
      <a id="logo-container" href="#" class="brand-logo titlebar">
        <?php print make_singular($Name); ?> Number<img src="<?php print '/img/' . $Icon; ?>">
      </a>
      <div class="area"><!-- style="font-size:0.83rem"-->
        &nbsp;
      </div>
    </div>
  </nav>

  <form name="submitTheNumber" id="submitTheNumber"
        action="/glue/initiate-count-class.php"
        method="GET" onsubmit="return DoOnSubmit">
    <input name="class" id="class" type=hidden value="<?php print $class; ?>" style="visibility:hidden" />
<?php
  if($pull == "Y")
  {
?>
    <input name="pull" id="class" type=hidden value="Y" />
<?php
  }

  if(strlen($multi) > 0 && $multi != 0)  // multi-count (adhoc tlll counting)
  {
?>
    <input name="multi" type=hidden value="<?php print $multi; ?>" style="visibility:hidden" />
<?php
  }
?>
    <table width=100%>
      <tr><td width=20%>&nbsp;</td>
      <td width=40%>
        <div class="row button-row">
          <div class="input-selector" id="a1">
            <label><?php print $Name; ?> #</label>
            <div class="mdl-textfield denom" style="padding-top:0;padding-bottom:0">
              <input name="ordinal" id="ordinal" class="mdl-textfield__input special-text-input" type="text" value="" maxlength="5" disabled />
            </div>
          </div>
        </div>
      </td>
      <td width="40%">
        <div id="value-warn" style="display:none;font-size:0.8rem">
          Must be between 1 and <?php if(class_is_register($class)) print "9999" ; else print "99";?>
        </div>
      </td></tr>
    </table>

    <input type=hidden id=till_not_used name=till_not_used value="off" style="visibility:hidden" />
  </form>

  <div id="quantity" style="width:400px"> <!-- class="center" -->
    <div class="row">
      <div id="registers-calc" class=" calc-card <?php print $CalcCardOverride; ?> mdl-card <?php print $MDLCardOverride; ?> mdl-shadow--2dp">
      <div class="buttons" id="wrapper">
        <button onClick="DoClick('7');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">7</button>
        <button onClick="DoClick('8');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">8</button>
        <button onClick="DoClick('9');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">9</button>
        <button onClick="DoClickClr();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent">
          <span style="display:none">backspace</span>
          <img src="img/baseline-backspace-24px.svg" style="color:white">
        </button>

        <button onClick="DoClick('4');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">4</button>
        <button onClick="DoClick('5');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">5</button>
        <button onClick="DoClick('6');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">6</button>
        <button class="mdl-button">&nbsp;</button>

        <button onClick="DoClick('1');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">1</button>
        <button onClick="DoClick('2');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">2</button>
        <button onClick="DoClick('3');" class="calc-button num-button mdl-button mdl-button--raised mdl-button--accent">3</button>
        <button onClick="DoClickEntor();" class="calc-button op-button mdl-button mdl-button--raised mdl-button--accent tall"
                style="line-height:1em;height:">
          E<br/>n<br/>t<br/>e<br/>r
        </button>

        <button onClick="DoClick('0');" class="calc-button calc-button-long num-button num-button-long mdl-button mdl-button--raised mdl-button--accent wide">0</button>
      </div>
    </div>

    <div style="position:absolute;right:3.34rem;width=10rem;top:3.75rem;" >
      <form id="selector">
        <span width=1rem style="font-size:0.75rem;margin:0px;padding:0px"><b><center><?php print $Name; ?> List</center></b></span>
        <select id=entitynum name=entitynum onchange="doSelChange();"
                style="min-width:10rem;font-size:0.75rem;margin:0px;padding:0px;padding-left:4;padding-right:4;display:block;height:1.2rem;border-stye:double;border-color:black">
          <option value="-1" >
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          </option>
<?php
    foreach($aList as $ll)
    {
      if(strlen($ll) > 0)
      {
        $vv = explode("\t", rtrim($ll));
        print "          <option value=\"" . $vv[0] . "\" >\n";
        $spacer = "&nbsp;&nbsp";
        for($ii=3; $ii > strlen($vv[0]); $ii--)
        {
          $spacer = $spacer . "&nbsp;&nbsp";
        }
        print '            (' . $vv[0] . ')' . $spacer . $vv[1] . "\n";
        print "          </option>\n";
      }
    }
?>
        </select>
      </form>
    </div>

    <form id="class-only" name="class-only" method="GET">
      <input name="class" type=hidden value="<?php print $class; ?>" style="visibility:hidden" />
      <input name="back" type=hidden value="Y" style="visibility:hidden" />
    </form>
    <form id="all_counted" name="all_counted" method="GET">
      <input name="class" type=hidden value="<?php print $class; ?>" style="visibility:hidden" />
      <input name="complete" type=hidden value="Y" style="visibility:hidden" />
<?php
  if(strlen($multi) > 0) // multi-count (adhoc tlll counting)
  {
?>
      <input name="multi" type=hidden value="<?php print $multi; ?>" style="visibility:hidden" />
<?php
  }
?>
    </form>
    <form id=none method="GET"></form>
<?php
  if(strlen($multi) == 0 || $multi == 0) // not doing multi count (aka adhoc tlll count)
     // && $pull != "Y") // it's _NOT_ a pull
  {
?>
    <!-- TODO implement the 'complete all vessels' as needed -->
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:0.8rem;left:0.5rem;">
      <button formaction="/entity-number.php" form="all_counted" class="btn waves-effect primary-fill btn-shadow">ALL COUNTED</button>
    </div>
<?php
  }
?>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:0.8rem;left:40%;">
      <button
<?php
  if(strlen($multi) > 0 && $multi != 0) // multi-count (adhoc tlll counting)
  {
?>
              formaction="/"
<?php
  }
  // for Tills with pulls, 'exit' goes back to /tills-pulls-count.php
  // otherwise, it goes to /tasks.php
  else if($HasPulls > 0)
  {
?>
              formaction="/tills-pulls-count.php"
<?php
  }
  else
  {
?>
              formaction="/tasks.php"
<?php
  }
?>
              form="class-only" class="btn waves-effect primary-fill btn-shadow">Back</button>
    </div>
    <div class="next-button registers-done">
      <button name="next" id="next" form="none" class="btn waves-effect primary-fill btn-shadow"
              type="button" onclick="OnClickNext();" disabled>NEXT &gt;</button>
    </div>
  </div>

  <!--  Scripts-->
  <script>
    //-- Set Defaults  --//
    var nDisplayed = 10;

    function setTotal ()
    {
      // does nothing, presence required by some of the previously written scripts
    }

    function OnClickNext()
    {
      var x = document.getElementById("ordinal").value;
      if (x == "" || x < 1 || x > <?php if(class_is_register($class)) print "9999" ; else print "99";?>)
      {
        window.alert("Please select a valid vessel number between 1 and 99");
        return false;
      }

      document.getElementById("ordinal").disabled = false; // needs to be enabled
      document.forms["submitTheNumber"].submit();
    }

    function DoCheckValidNumber()
    {
      var x = document.getElementById("ordinal").value;
      if (x == "" || x < 1 || x > <?php if(class_is_register($class)) print "9999" ; else print "99";?>)
      {
        document.getElementById("next").disabled = true;
        if(nDisplayed < 10)
        {
          document.getElementById("value-warn").style = "font-size:20px";
          nDisplayed += 1;
        }
        else
        {
          document.getElementById("value-warn").style = "display:none;font-size:20px";
        }
      }
      else
      {
        document.getElementById("next").disabled = false;
        nDisplayed = 0;
        document.getElementById("value-warn").style = "display:none;font-size:20px";
      }
    }

    setInterval(DoCheckValidNumber, 200);

  </script>

  <script src="/js/UserFeedback.js"></script>

</body>
</html>

