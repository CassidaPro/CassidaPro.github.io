<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

  $Equipment = coin_counter_equipment();

  // parse config file for things I need
  $parseconf = load_parseconf();

  $Coins = do_getconf($parseconf,"terms",'Coins','Coins');
  $Coin = make_singular($Coins);

  $CustomerMod = do_getconf($parseconf,"settings",'CustomerMod','0');

  // where 'back' will lead me
  $back = empty($_GET['back'])
        ? "/monthly-cleaning.php"
        : $_GET['back'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>SRB - Monthly Cleaning</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Monthly Cleaning</a>
        <div class="area">Cleaning</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <br/>
    <center>
      <table style="width:85%;border:0">
        <tr style="margin:0 20 0 0px;line-height:28px;border:0">
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:none;padding:0;margin:0;margin-top:-1rem;margin-left:-20px">
                <b><?php print $Coin; ?> Recycler Cleaning</b>
              </LI>
              <LI style="list-style-type:disc;padding:0;margin:0;margin-left:0px;margin-bottom:0">
                Remove <?php print $Coins; ?> from Recycler using
                <button id=rollem type=submit formaction="/dispense-coins.php" form=goback2
                        class="btn btn-small btn-maint-test waves-effect primary-fill btn-shadow-thin">
                  <span>Make Rolls</span>
                </button>
                &nbsp;&nbsp;and
                <button id=dumpem type=submit formaction="/maintenance-recycler-dump.php" form=goback2
                        class="btn btn-small btn-maint-test waves-effect primary-fill btn-shadow-thin">
                  <span>Empty</span>
                </button>
              </LI>
              <LI style="list-style-type:disc;margin:0 0 0 0px">This procedure requires that you de-energize the system and lift up the door that contains the touch screen display.  You will not easily be able to read the display during the cleaning process.</LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">Turn off the system from the power switch located on the front panel.</LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">From the bottom, lift the right-hand <?php print $Coin; ?> Counter access door.</LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">To clean the Recycler, locate the semi-circular latch on the lower front of each panel.
                                                                 Press up and slide each hopper assembly towards you to remove.</LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">For the right-hand hopper, press the front latch adjacent to the coin reject port and lift up.
                                                                 It is hinged in the back, and opens from the front.</LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">Inspect the inside of the Feeder, and remove any foreign debris.</LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">Using the soft bristle brush, sweep away any dust or particles that may be in the coin feeder, coin track, and coin wheel.</LI>
              <LI style="list-style-type:disc;margin:15 0 0 0px">To clean the coin sensor take the Canned Air Duster and dust the area as shown by the red arrow.
                                                                 Do not insert the nozzle more than half an inch into the opening.</LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>

    <form id=none method=GET></form>
    <form id=goback2 method=GET>
      <input type=hidden name="origin" value="/monthly-cleaning-recycler.php?back=<?php print rawurlencode($back);?>" style="visibility:hidden" />
    </form>
    <form id=goback method=GET><input type=hidden name=back style="visibility:hidden" value=<?php print '"' . $back . '"';?> /></form>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;left:0px">
      <button type=submit form=none formaction="<?php print $back;?>" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/cleaning.svg" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">&nbsp; &nbsp;BACK</span>
      </button><br/>
    </div>
    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <button type=submit form=goback formaction="/monthly-cleaning-recycler2.php" class="btn btn-small waves-effect primary-fill btn-shadow">
        <img src="/img/cleaning.svg" class="invertible-icon" height=32 width=32>
        <span style="vertical-align:middle">&nbsp; &nbsp;NEXT</span>
      </button><br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

