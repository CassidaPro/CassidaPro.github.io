<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include 'glue/config_utils.php';


  // parse config file for things I need
  $banking = do_parse_banking();

  // default safe ID is derived from the RPi serial #
  $rpi_serial = shell_exec("cat /sys/firmware/devicetree/base/serial-number | awk '{ print substr($0,9,8); }'");

  $safe_id = do_bankingvar($banking, "cirreon_safe", $rpi_serial);
  $banking_url = do_bankingvar($banking, "cirreon_url", "");
  $keyid = do_bankingvar($banking, "cirreon_keyid", "");
  $secret = do_bankingvar($banking, "cirreon_secret", "");


  $SaveCirreon = do_getvar("SaveCirreon", "");

  if($SaveCirreon == "Y")
  {
    $safe_idX = do_getvar("safe_id", "");
    $banking_urlX = do_getvar("banking_url", "");
    $keyidX = do_getvar("keyid", "");
    $secretX = do_getvar("secret", "");

    // TODO:  sanitize user input data first?  go back and re-edit?
?>
    <HTML><HEAD><TITLE>Saving Configuration Info</TITLE>
      <meta http-equiv="refresh" content="0.1;url=banking_cirreon.php?SaveCirreon=YY<?php
            print "&safe_id=" . urlencode($safe_idX);
            print "&banking_url=" . urlencode($banking_urlX);
            print "&keyid=" . urlencode($keyidX);
            print "&secret=" . urlencode($secretX); ?>" >
<?php set_inbetween_style(); ?>
      </HEAD>
      <BODY>
        <br><br>
        <H1><center>Saving Configuration Info</center></H1>
      </BODY>
    </HTML>
<?php
    exit;
  }
  else if($SaveCirreon == "YY")
  {
    $safe_idX = do_getvar("safe_id", "");
    $banking_urlX = do_getvar("banking_url", "");
    $keyidX = do_getvar("keyid", "");
    $secretX = do_getvar("secret", "");

    if($safe_id !== $safe_idX ||
       $banking_url !== $banking_urlX ||
       $keyid !== $keyidX ||
       $secret !== $secretX)
    {
      $banking["cirreon_safe"] = $safe_idX;
      $banking["cirreon_url"] = $banking_urlX;
      $banking["cirreon_keyid"] = $keyidX;
      $banking["cirreon_secret"] = $secretX;

      do_write_banking($banking);
    }

    header("HTTP/1.0 302 Moved Temporarily");
    if(strlen($Next) > 0)
      header("Location: " . $Next);
    else
      header("Location: /banking.php");

    exit;
  }


?>
<!--          Copyright 2019-2023 by Cassida          -->
<!-- Use only in accordance with the supplied license -->
<!DOCTYPE html>
<html lang="en">
  <HEAD>
    <TITLE>Split Recycler System - Banking (Cirreon)</TITLE>
    <link href="/css/system.css" type="text/css" rel="stylesheet" media="screen,projection" />
    <link rel="shortcut icon" href="/img/favicon.ico">
    <style>
<?php
  set_ideal_font_height();
?>
      body
      {
        background-color:#0a240a;
        color:#ffffe0;
      }
    </style>
    <script>
      function doClickKB(strID)
      {
        do_vkey_single(strID, null);
      }
    </script>
  </HEAD>
  <BODY>
    <form id=none method=GET></form>
    <center>
      <b>
        <H1 style="margin:0;padding:0;font-size:1.33rem">Split Recycler - Banking (Cirreon)</H1>
        <H4 style="margin:0;padding:0;margin-bottom:0.67rem">
          <?php print skyyreq("version"); ?>
        </H4>
      </b>
    </center>
    <br>
    <form id=Save method=GET>
      <input type=hidden name="SaveCirreon" value="Y" style="visibility:hidden" />
      <center>
        <table>
          <tr>
            <td>
              URL:&nbsp;&nbsp;
            </td>
            <td>
              <input type=text size=128 id=banking_url name=banking_url style="width:20rem;margin-top:0.2rem"
                     value="<?php print sanitize_for_html($banking_url); ?>" />
              <a onClick='doClickKB("banking_url");'>
                <img src="/img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
          </tr>
          <tr>
            <td>
              Safe ID:&nbsp;&nbsp;
            </td>
            <td>
              <input type=text size=40 id=safe_id name=safe_id style="width:9rem;margin-top:0.2rem"
                     value=<?php print '"' . sanitize_for_html($safe_id) . '"'; ?> />
              <a onClick='doClickKB("safe_id");'>
                <img src="/img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
          </tr>
          <tr>
            <td>
              Key ID:&nbsp;&nbsp;
            </td>
            <td>
              <input type=text size=40 id=keyid name=keyid style="width:9rem;margin-top:0.2rem"
                     value=<?php print '"' . sanitize_for_html($keyid) . '"'; ?> />
              <a onClick='doClickKB("keyid");'>
                <img src="/img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
          </tr>
          <tr>
            <td>
              Secret:&nbsp;&nbsp;
            </td>
            <td>
              <input type=text size=40 id=secret name=secret style="width:9rem;margin-top:0.2rem"
                     value=<?php print '"' . sanitize_for_html($secret) . '"'; ?> />
              <a onClick='doClickKB("secret");'>
                <img src="/img/keyboard.png" width="<?php print cached_font_size() * 1.5; ?>px" height="<?php print cached_font_size() * 1.5; ?>px" style="vertical-align:middle">
              </a>
            </td>
          </tr>
        </table>
      </center>
    </form>

    <table width=75% style="position:absolute;bottom:18px;left:12.5%;">
      <tr>
        <td width=25%>
          <center>
            <input type=submit value="Back" form="none" formaction="/banking.php"
                   style="min-width:120px;" />
          </center>
        </td>
        <td width=25%>
          <!--center>
            <input type=submit value="Settings" form="Save" formaction="banking.php"
                   onclick='document.getElementById("Next").value="/glue/banking_edit.php";'
                   style="min-width:120px;" />
          </center-->
        </td>
        <td width=25%>
          <center>
            <input type=submit value="Save" form="Save" formaction="banking_cirreon.php"
                   style="min-width:120px;" />
          </center>
        </td>
      </tr>
    </table>

<?php

  include "glue/virtual_keyboard.php";

?>

  </BODY>
</HTML>

