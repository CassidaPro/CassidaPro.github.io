<?php
  /*           Copyright 2019-2023 by Cassida           */
  /* Use only in accordance with the supplied license   */

  include "glue/common_utils.php";

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Unless otherwise specified, all web pages, CSS, javascript, and php 'glue' pages are Copyright 2019-2023 by Cassida -->
    <!-- You may only use these copyrighted works in accordance with the license agreement from Cassida -->
    <!-- for open source licensing for the operating system and installed software, see http://raspbian.org/ -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>Maintenance - Test Zeus</title>

    <!-- CSS  -->
    <link href="/css/style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/maintenance-styles.css" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link href="/css/custom_colors.css.php" type="text/css" rel="stylesheet" media="screen,projection"/>
    <link rel="shortcut icon" href="/img/favicon.ico">
    <!-- JS  -->


    <style>
<?php
  set_ideal_font_height();
?>
    </style>
    <script>
      function ClickTest()
      {
          var myRequest = new Request("/glue/zeus-test.php");

          document.getElementById("zeus_test").disabled=true;
          document.getElementById("test_results").innerHTML = "waiting...";

          fetch(myRequest)
            .then(function(response)
                  {
                    if (!response.ok)
                    {
                      console.log("status", response.status);
                    }

                    return  response.text();
                  })
            .then(function(text)
                  {
                    document.getElementById("zeus_test").disabled=false;
                    document.getElementById("test_results").innerHTML = text.substring(0,8);
                  });
      }
    </script>
  </head>

  <body>
    <nav class="secondary-fill lighten-1" role="navigation" style="margin:0px" >
      <div class="nav-wrapper container">
        <a id="logo-container" href="#" class="brand-logo titlebar">Test Zeus<img width=42 height=42 src="/img/zeus-only.png"></a>
        <div class="area">MAINT</div>
        <a id="off-button" href="/glue/poweroff-button.php" class="btn secondary-fill off-button"><img width=32 height=32 src="/img/poweroff.svg" /></a>
      </div>
    </nav>
    <center>
      <table style="width:85%;border:0">
        <tr>
          <td style="padding:0;margin:0">
            <UL style="list-style-type:disc;padding:0;margin:0">
              <LI style="list-style-type:disc;padding:0;margin:0">
                <UL style="list-style-type:circle;margin:15 0 0 0px">Make sure Zeus is plugged in, all cables snug, power on
                  <LI style="list-style-type:circle;margin:15 0 0 0px">Wait about 15 seconds for Zeus to power up.</LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">When the Zeus display indicates 'Ready', press&nbsp;&nbsp;
                    <button id=zeus_test type=button onClick="ClickTest();" class="btn btn-small waves-effect primary-fill btn-shadow"
                            style="margin:-4px">
                      <span style="vertical-align:middle">TEST</span>
                    </button>&nbsp;&nbsp;
                    <span id=test_results style="font-size:18px"></span></LI>
                  <LI style="list-style-type:circle;margin:15 0 0 0px">If you have any problems, contact customer service immediately.</LI>
                </UL>
              </LI>
            </UL>
          </td>
        </tr>
      </table>
    </center>

    <div class="col s7 light" style="position:absolute;margin:0px;padding:0;bottom:18px;right:12px">
      <a href="/" class="btn btn-small waves-effect primary-fill btn-shadow">
        <span style="vertical-align:middle">Exit</span>
      </a>
      <br/>
    </div>

    <!--  Scripts-->

  </body>
</html>

